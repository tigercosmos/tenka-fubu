import type { GameState } from '../../state/gameState';
import type { ClanId } from '../../state/ids';
import { CommandQueue, enqueuePendingAiOrders } from '../../commands/queue';
import { validateState } from '../../state/invariants';
import { advanceDay } from '../index';
import { dayToCalendar } from '../time';
import { dominionClanIds } from '../victory';

export interface SimulateRunSummary {
  seed: number;
  yearsSimulated: number;
  unifiedByClanId: string | null;
  unifiedYear: number | null;
  clanStats: Array<{
    clanId: string;
    survived: boolean;
    castleCount: number;
    kokudaka: number;
    peakKokudaka: number;
    destroyedYear: number | null;
  }>;
  totalBattles: number;
  totalSieges: number;
  avgTickMs: number;
  hardRejections: number;
  invalidDecisionCount: number;
  survivalAtYear10: Record<string, boolean>;
}

/** Same pending-order/command seam as the app, without rendering, clocks or browser APIs. */
export function simulateAiGame(
  state: GameState,
  years: number,
  now: () => number = () => 0,
): SimulateRunSummary {
  if (!Number.isFinite(years) || years <= 0) throw new Error('Simulation years must be positive');
  state.ai.allAi = true;
  const queue = new CommandQueue(state.meta.lastAppliedCmdSeq + 1);
  const peaks = new Map<ClanId, number>();
  const survivalAtYear10: Record<string, boolean> = {};
  let ticks = 0,
    elapsed = 0,
    totalBattles = 0,
    totalSieges = 0,
    hardRejections = 0,
    invalidDecisionCount = 0;
  let unifiedByClanId: ClanId | null = null;
  const snapshot = (): void => {
    const holdings = new Map<ClanId, number>();
    for (const district of Object.values(state.districts))
      holdings.set(
        district.ownerClanId,
        (holdings.get(district.ownerClanId) ?? 0) + district.kokudaka,
      );
    for (const clan of Object.values(state.clans))
      peaks.set(clan.id, Math.max(peaks.get(clan.id) ?? 0, holdings.get(clan.id) ?? 0));
  };
  snapshot();
  for (; ticks < Math.ceil(years * 360);) {
    enqueuePendingAiOrders(state, queue);
    const start = now();
    const result = advanceDay(state, queue.drain());
    elapsed += Math.max(0, now() - start);
    ticks++;
    totalBattles += result.events.filter((event) => event.type === 'battle.started').length;
    totalSieges += result.events.filter((event) => event.type === 'siege.started').length;
    hardRejections += result.events.filter((event) => event.type === 'command.rejected').length;
    invalidDecisionCount += state.ai.intentLog.filter(
      (intent) => intent.day === state.time.day && intent.kind === 'error.invalidCommand',
    ).length;
    const violations = validateState(state);
    if (violations.length)
      throw new Error(
        `Simulation seed=${state.meta.seed} day=${state.time.day}: ${JSON.stringify(violations)}`,
      );
    snapshot();
    if (ticks === 3600)
      for (const clan of Object.values(state.clans)) survivalAtYear10[clan.id] = clan.alive;
    const castles = Object.values(state.castles);
    for (const clan of Object.values(state.clans).sort((a, b) => a.id.localeCompare(b.id))) {
      if (!clan.alive) continue;
      const dominion = dominionClanIds(state, clan.id);
      if (castles.length > 0 && castles.every((castle) => dominion.has(castle.ownerClanId))) {
        unifiedByClanId = clan.id;
        break;
      }
    }
    if (unifiedByClanId !== null) break;
  }
  return {
    seed: state.meta.seed,
    yearsSimulated: ticks / 360,
    unifiedByClanId,
    unifiedYear: unifiedByClanId === null ? null : state.time.year,
    clanStats: Object.values(state.clans)
      .sort((a, b) => a.id.localeCompare(b.id))
      .map((clan) => ({
        clanId: clan.id,
        survived: clan.alive,
        castleCount: Object.values(state.castles).filter((castle) => castle.ownerClanId === clan.id)
          .length,
        kokudaka: Math.floor(
          Object.values(state.districts)
            .filter((district) => district.ownerClanId === clan.id)
            .reduce((sum, district) => sum + district.kokudaka, 0),
        ),
        peakKokudaka: Math.floor(peaks.get(clan.id) ?? 0),
        destroyedYear: clan.destroyedDay === null ? null : dayToCalendar(clan.destroyedDay).year,
      })),
    totalBattles,
    totalSieges,
    avgTickMs: ticks === 0 ? 0 : elapsed / ticks,
    hardRejections,
    invalidDecisionCount,
    survivalAtYear10,
  };
}

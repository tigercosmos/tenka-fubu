// advanceDay：每日 tick 的 13 步固定流程骨架（M1-7）。
// 規格：plan/03-game-loop.md §3.2（13 步流程）／§3.2.4（完整虛擬碼）／§4.1（TickResult／AutoPauseReason）；
//       plan/00-foundations.md §5.4（13 步順序 canonical，不得增刪重排）；plan/03 §3.6（月結流程）／§3.9.1（自動存檔 hook）。
//
// 本檔為骨架：13 步順序以常數陣列 STEP_ORDER 鎖定（00 §5.4）；Step 1（applyCommands，M1-6）、
// Step 2（time，M1-5）、Step 13（reports，M1-8，見 systems/reports.ts）為實作步驟，Step 3–12
// 為空殼佔位（回傳 []），待各系統里程碑替換（見各步註解）。
// 「任何系統不得跳過」（§3.2.4）：即使當日無事，每步仍被呼叫，由各系統內部依時機表閘控早退——
// 確保重放時呼叫序完全一致（決定論）。

import type { GameState } from '../state/gameState';
import type { GameEvent } from '../state/events';
import type { OfficerId } from '../state/ids';
import type { CommandEnvelope } from '../commands/types';
import type { EmitFn } from '../commands/registry';
import { applyCommands } from '../commands/queue';
import { timeSystem } from './time';
import { reportsSystem } from './reports';
import { developmentSystem } from './development';
import { economySystem } from './economy';
import type { MonthOpeningSettlement } from './monthOpeningSettlement';
import { officersSystem } from './officers';
import { militaryMovementSystem } from './military';
import { fieldCombatSystem } from './fieldCombat';
import { siegeSystem } from './siege';
import { victorySystem } from './victory';
import { runAiSystems, warmAiCaches } from './ai';
import type { AiSignal } from './ai/types';
import { diplomacySystem } from './diplomacy';
import { proposalsSystem, submitProposal } from './proposals';
import { generateProposalCandidates } from './ai/proposalGen';
import type { EventEngine } from './events/engine';
import { collectEventHooks } from './events';
import { expireTaimei } from './events/taimei';
import type { ClanId } from '../state/ids';

// ═══════════════════════════════════════════════════════════════════
// 迴圈機制型別（03 §4.1 canonical）
// ═══════════════════════════════════════════════════════════════════

/** 自動暫停原因（00 §5.2／03 §3.4.2；玩家勢力相關事件觸發，各項可於設定關閉）。 */
export type AutoPauseReason =
  | 'siegeOnPlayer'
  | 'battleAvailable'
  | 'proposalArrived'
  | 'envoyArrived'
  | 'historicalEvent'
  | 'monthStart';

/** advanceDay 回傳值（03 §4.1）。 */
export interface TickResult {
  state: GameState; // 與傳入同一參考（就地修改，§3.1）
  events: GameEvent[]; // 本 tick 全部事件（依發出順序）；不持久化（§3.4.1）
  appliedCommands: CommandEnvelope[]; // 本 tick 成功套用者；供 state 外側 command log 記錄（17 §3.10）
  autoPauseReasons: AutoPauseReason[]; // 去重後的自動暫停原因（Step 13 reports 產生；可空）
  autosaveDue: 'monthly' | null; // 驅動器據此呼叫 onAutosave（§3.9.1）
  /** Actual Step 6 opening gold settlement, not a previous-month ledger or end-of-tick balance. */
  monthOpeningSettlement?: MonthOpeningSettlement;
  perf: { totalMs: number; stepMs: number[] }; // 無注入時鐘時為 0；app 可提供單調時鐘，量測不入狀態。
}

/**
 * tick 內傳遞給各步的上下文（本檔內部型別）。
 * - `queue`：本 tick 前 app 層 drain 出的指令陣列（Step 1 輸入，§3.3.1）。
 * - `events`：本 tick 事件累加器（advanceDay 於每步後併入該步回傳值；Step 13 reports 讀此全集）。
 * - `autoPauseReasons`：Step 13 reports 寫入（M1-8 已實作，見 systems/reports.ts）。
 */
export interface TickContext {
  eventEngine?: EventEngine;
  aiSignals: AiSignal[];
  queue: readonly CommandEnvelope[];
  appliedCommands: CommandEnvelope[];
  events: GameEvent[];
  autoPauseReasons: AutoPauseReason[];
  monthOpeningSettlement?: MonthOpeningSettlement;
}

/** 單一步驟函式簽名（(state, ctx) → 該步發出的事件；就地修改 state）。 */
export type StepFn = (state: GameState, ctx: TickContext) => GameEvent[];

/** 13 步的固定名稱（00 §5.4／03 §3.2.3；Step 7/8 對應 military.movement／military.combat）。 */
export type StepName =
  | 'applyCommands'
  | 'time'
  | 'events'
  | 'diplomacy'
  | 'development'
  | 'economy'
  | 'militaryMovement'
  | 'militaryCombat'
  | 'officers'
  | 'proposals'
  | 'ai'
  | 'victory'
  | 'reports';

interface StepDef {
  name: StepName;
  run: StepFn;
}

// ═══════════════════════════════════════════════════════════════════
// Step 實作／佔位（03 §3.2.3）
// ═══════════════════════════════════════════════════════════════════

/** Step 1 applyCommands（M1-6）：就地結算本 tick 指令佇列（舊日期驗證，§3.2.3）。 */
function stepApplyCommands(state: GameState, ctx: TickContext): GameEvent[] {
  const events: GameEvent[] = [];
  const emit: EmitFn = (e) => {
    events.push(e);
  };
  ctx.appliedCommands.push(...applyCommands(state, ctx.queue, emit, ctx));
  return events;
}

/**
 * Step 2 time（M1-5）：日期 +1、發 time.monthStart／time.seasonStart。
 * 先併入合戰寫回的延遲事件（state.meta.deferredEvents）再清空（§5.2；骨架期恆空、M1-26 起填入）——
 * 此併入原列於 §5.2 timeSystem 虛擬碼開頭，因 timeSystem（M1-5）僅司曆法、不讀 meta（其 fixture
 * 不含 meta），故落實於本 Step 2 包裝（時序等價：延遲事件在月/季事件之前併入）。
 */
function stepTime(state: GameState): GameEvent[] {
  const events: GameEvent[] = [];
  const emit: EmitFn = (e) => {
    events.push(e);
  };
  for (const deferred of state.meta.deferredEvents) {
    emit(deferred);
  }
  state.meta.deferredEvents = [];
  timeSystem(state, emit);
  return events;
}

// Step 3–12：空殼佔位（回傳 []）。各步的讀寫區塊、發出事件與內部演算法見 §3.2.3「詳見」欄；
// 由對應系統里程碑替換為實作。骨架期不讀寫 state（無副作用），確保空劇本連跑無例外。
function stepEvents(state: GameState, ctx: TickContext): GameEvent[] {
  const events: GameEvent[] = [];
  if (ctx.eventEngine) ctx.eventEngine.run(state, (event) => events.push(event));
  else expireTaimei(state, (event) => events.push(event));
  return events;
}
function stepDiplomacy(state: GameState, ctx: TickContext): GameEvent[] {
  warmAiCaches(state, ctx.events);
  return diplomacySystem(state);
}
function stepDevelopment(state: GameState): GameEvent[] {
  return developmentSystem(state);
}
function stepEconomy(state: GameState, ctx: TickContext): GameEvent[] {
  return economySystem(state, (settlement) => {
    ctx.monthOpeningSettlement = settlement;
  });
}
function stepMilitaryMovement(state: GameState, ctx: TickContext): GameEvent[] {
  return militaryMovementSystem(state, (signal) => ctx.aiSignals.push(signal));
}
function stepMilitaryCombat(state: GameState): GameEvent[] {
  return [...fieldCombatSystem(state), ...siegeSystem(state)];
}
function stepOfficers(state: GameState, ctx: TickContext): GameEvent[] {
  // 欠俸忠誠懲罰於漂移之後套用（06 §3.6.2；M3 review F2）：unpaid 勢力來自本 tick economy
  // 步驟（Step 6，早於本步）已併入事件流的 economy.upkeepUnpaid。
  const unpaidPayeeIds = new Set<OfficerId>();
  for (const event of ctx.events) {
    if (event.type === 'economy.upkeepUnpaid') {
      for (const officerId of event.payeeIds) unpaidPayeeIds.add(officerId);
    }
  }
  return officersSystem(state, unpaidPayeeIds);
}
function stepProposals(state: GameState): GameEvent[] {
  const events = proposalsSystem(state);
  if (state.time.dayOfMonth === 1 && state.meta.gameOver === null && !state.ai.allAi) {
    for (const candidate of generateProposalCandidates(state)) {
      const event = submitProposal(state, candidate);
      if (event) events.push(event);
    }
  }
  return events;
}
function stepAi(state: GameState, ctx: TickContext): GameEvent[] {
  const result = runAiSystems(state, [...ctx.events, ...ctx.aiSignals]);
  state.ai.pendingOrders.push(...result.orders);
  return [];
}
function stepVictory(state: GameState, ctx: TickContext): GameEvent[] {
  // 勝敗檢查（10 §5.6；MVP 先行實作，見 systems/victory.ts 檔頭）：
  // ctx.events 傳入本 tick 至本步的事件全集，供結局統計消費 battle.ended（M8-3 前過渡）。
  return victorySystem(state, ctx.events, { battleStatsFromHooks: ctx.eventEngine !== undefined });
}
function stepReports(state: GameState, ctx: TickContext): GameEvent[] {
  // Step 13 reports（M1-8；src/core/systems/reports.ts）：消費 ctx.events（本 tick 全集）→
  // 追加 Report、修剪、計算 autoPauseReasons 併入 ctx（本步為事件終端消費者、不發事件，§3.2.3）。
  const reasons = reportsSystem(
    state,
    ctx.events,
    ctx.eventEngine
      ? { isHistoricalEvent: (id) => ctx.eventEngine!.getDef(id)?.kind === 'historical' }
      : {},
  );
  ctx.autoPauseReasons.push(...reasons);
  return [];
}

// ═══════════════════════════════════════════════════════════════════
// 13 步固定順序（常數陣列鎖定；00 §5.4／03 §3.2.4，不得增刪重排）
// ═══════════════════════════════════════════════════════════════════

/** 13 步固定順序（canonical）。advanceDay 唯一的步驟迭代來源；替換實作時僅換 `run`、不動順序。 */
export const STEP_ORDER: readonly StepDef[] = [
  { name: 'applyCommands', run: stepApplyCommands },
  { name: 'time', run: stepTime },
  { name: 'events', run: stepEvents },
  { name: 'diplomacy', run: stepDiplomacy },
  { name: 'development', run: stepDevelopment },
  { name: 'economy', run: stepEconomy },
  { name: 'militaryMovement', run: stepMilitaryMovement },
  { name: 'militaryCombat', run: stepMilitaryCombat },
  { name: 'officers', run: stepOfficers },
  { name: 'proposals', run: stepProposals },
  { name: 'ai', run: stepAi },
  { name: 'victory', run: stepVictory },
  { name: 'reports', run: stepReports },
];

/** 13 步名稱序（由 STEP_ORDER 導出，供測試斷言步序；與 STEP_ORDER 不可能漂移）。 */
export const STEP_SEQUENCE: readonly StepName[] = STEP_ORDER.map((s) => s.name);

// ═══════════════════════════════════════════════════════════════════
// advanceDay（03 §3.2.4）
// ═══════════════════════════════════════════════════════════════════

/**
 * 每日 tick：依 STEP_ORDER 固定順序執行 13 步，就地修改並回傳同一 `state` 參考。
 * 結尾（§3.2.4）：重置 territoryChangedToday 髒標記、stateVersion += 1。
 * 月結 hook（§3.9.1）：Step 2 推進後若為每月 1 日（dayOfMonth===1），autosaveDue='monthly'
 *（BAL.autosaveEveryMonths=1，每月月初存檔；驅動器讀旗標後呼叫 onAutosave，debug 跳轉期抑制）。
 */
export function advanceDay(
  state: GameState,
  queue: readonly CommandEnvelope[],
  options: { now?: () => number; eventEngine?: EventEngine } = {},
): TickResult {
  const now = options.now;
  const started = now?.() ?? 0;
  const stepMs: number[] = [];
  const leaders = options.eventEngine
    ? new Map(Object.values(state.clans).map((clan) => [clan.id, clan.leaderId] as const))
    : new Map<ClanId, OfficerId>();
  const events: GameEvent[] = [];
  const ctx: TickContext = {
    ...(options.eventEngine ? { eventEngine: options.eventEngine } : {}),
    queue,
    appliedCommands: [],
    events,
    autoPauseReasons: [],
    aiSignals: [],
  };

  for (const step of STEP_ORDER) {
    const stepStarted = now?.() ?? 0;
    const stepEvents = step.run(state, ctx);
    stepMs.push(now ? Math.max(0, now() - stepStarted) : 0);
    for (const e of stepEvents) {
      events.push(e);
    }
  }

  const autosaveDue: 'monthly' | null = state.time.dayOfMonth === 1 ? 'monthly' : null;
  if (options.eventEngine) collectEventHooks(state, events, leaders);

  state.meta.territoryChangedToday = false; // §3.2.4：重置每日髒標記（Step 12 消費後）
  state.meta.stateVersion += 1; // §3.1／§3.2.4：UI 訂閱重繪依據

  return {
    state,
    events,
    appliedCommands: ctx.appliedCommands,
    autoPauseReasons: ctx.autoPauseReasons,
    autosaveDue,
    ...(ctx.monthOpeningSettlement ? { monthOpeningSettlement: ctx.monthOpeningSettlement } : {}),
    perf: { totalMs: now ? Math.max(0, now() - started) : 0, stepMs },
  };
}

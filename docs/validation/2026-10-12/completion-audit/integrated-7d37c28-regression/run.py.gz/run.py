import gzip,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/Users/tigercosmos/tenka-fubu'); out=pathlib.Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=[r['path'] for r in json.load(open('/tmp/tenka-current-2d872d7-regression/source-before.json'))['rows']] + ['tests/ci/pixiTextureBatchIds.spec.ts','e2e/policy-responsive.spec.ts']
def proof(label):
 rows=[]
 for p in paths:
  expected=hashlib.sha256(subprocess.check_output(['git','show',head+':'+p],cwd=root)).hexdigest();actual=hashlib.sha256((root/p).read_bytes()).hexdigest();rows.append(dict(path=p,expected=expected,actual=actual))
 data=dict(head=head,passed=all(r['expected']==r['actual'] for r in rows),rows=rows);(out/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n');assert data['passed']
proof('source-before')
statuses=[]
for label,cmd in [('full',['npm','test']),('typecheck',['npm','run','typecheck']),('lint',['npm','run','lint']),('data',['npm','run','validate:data']),('assets',['npm','run','validate:assets']),('build',['npm','run','build']),('bundle',['npm','run','validate:bundle'])]:
 start=time.time()
 with open(out/(label+'.log'),'w') as f: result=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,command=cmd,exit=result.returncode,seconds=time.time()-start);statuses.append(row);(out/'status.json').write_text(json.dumps(statuses,indent=2)+'\n');print(row,flush=True)
proof('source-after')

import gzip,hashlib,json,pathlib,shutil,sys
repo=pathlib.Path('/Users/tigercosmos/tenka-fubu');src=pathlib.Path(__file__).parent
out=repo/'docs/validation/2026-10-12/completion-audit/integrated-7d37c28-regression';out.mkdir(exist_ok=True)
rows=[]
for p in sorted(src.iterdir()):
 if p.is_file():
  raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);target=out/(p.name+'.gz');target.write_bytes(packed);rows.append(dict(path=target.name,bytes=len(packed),sha256=hashlib.sha256(packed).hexdigest(),rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest()))
summary=dict(sourceInputs=1557,source='7d37c288519c70194d6d5d91070e9be924490d00',checks=json.loads((src/'status.json').read_text()),artifacts=rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

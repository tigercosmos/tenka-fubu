#!/usr/bin/env python3
import hashlib, json, os, sys
from pathlib import Path
runtime=Path('/tmp/tenka-earned-wasm-runtime-27d-c1')
manifest=json.loads(Path('/tmp/tenka-earned-wasm-payload-27d-c1/manifest.json').read_text())
assert manifest['revision']=='27d9028f01e38e67cfb0adf65b933ffd44485930'
expected_overlay=sys.argv[1]
overlay='tests/app/earnedRegionalEndingJourney.spec.tsx'
entries=manifest['entries']
def sha(x): return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
bad=[]
for name,meta in entries.items():
 p=runtime/name
 if not p.is_file():bad.append([name,'missing']);continue
 data=p.read_bytes()
 if name==overlay:
  if sha(data)!=expected_overlay or blob(data)==meta['gitBlob']:bad.append([name,'overlay'])
 elif blob(data)!=meta['gitBlob']:bad.append([name,'gitBlob'])
 if bool(p.stat().st_mode & 0o111)!=(meta['mode']=='100755'):bad.append([name,'mode'])
actual=set()
for root,dirs,files in os.walk(runtime,followlinks=False):
 dirs[:]=[d for d in dirs if d not in {'node_modules','dist','playwright-report'}]
 for f in files:actual.add(str((Path(root)/f).relative_to(runtime)))
extras=sorted(actual-set(entries));missing=sorted(set(entries)-actual)
targets=json.loads((runtime/'tools/dependencies/pixi-8.19-patch.json').read_text())['targets']
deps=[{'path':row['path'],'expected':row['patchedSha256'],'actual':sha((runtime/'node_modules/pixi.js'/row['path']).read_bytes())} for row in targets]
wasm=runtime/'public/wasm/tenka_engine.wasm'
result={'revision':manifest['revision'],'entries':len(entries),'overlay':{overlay:expected_overlay},'bad':bad,'extras':extras,'missing':missing,'dependencies':deps,'wasmSha256':sha(wasm.read_bytes()),'wasmBytes':wasm.stat().st_size,'passed':not bad and not extras and not missing and len(deps)==29 and all(r['expected']==r['actual'] for r in deps)}
print(json.dumps(result))
assert result['passed']

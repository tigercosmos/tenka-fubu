#!/usr/bin/env bash
set -euo pipefail
MODE=$1
RUN_DIR=$2
RUNTIME=/tmp/tenka-earned-wasm-runtime-27d-c1
NODE_BIN=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin
export PATH="$NODE_BIN:/usr/local/bin:/usr/bin:/bin"
export CI=1 VISUAL_GPU=1
unset VISUAL_PERF VISUAL_HEAP UPDATE_VISUAL SIMULATION_PROFILE
export REGIONAL_EARNED_ENDING_SAVE_PATH="$RUN_DIR/earned-regional-ending.tfusave"
test -x "$NODE_BIN/node"
test -x "$RUNTIME/node_modules/vitest/vitest.mjs" || test -f "$RUNTIME/node_modules/vitest/vitest.mjs"
exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- \
  "$NODE_BIN/node" "$RUNTIME/node_modules/vitest/vitest.mjs" run --project app \
  tests/app/earnedRegionalEndingJourney.spec.tsx --minWorkers=1 --maxWorkers=1 \
  -t 'loads the earned regional ending into actual App and continues without a phantom day or repeated victory'

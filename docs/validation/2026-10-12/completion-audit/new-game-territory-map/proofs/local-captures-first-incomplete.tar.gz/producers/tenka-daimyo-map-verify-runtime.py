#!/usr/bin/env python3
"""Verify every scoped Git blob plus the exact uncommitted map overlay."""
import hashlib
import json
import sys
from pathlib import Path

runtime, base_manifest, overlay_manifest = map(Path, sys.argv[1:4])
base = json.loads(base_manifest.read_text())
overlay = json.loads(overlay_manifest.read_text())
failures = []
checked = 0
for relpath, entry in base['entries'].items():
    path = runtime / relpath
    if relpath in overlay:
        continue
    if not path.is_file():
        failures.append([relpath, 'missing'])
        continue
    data = path.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if blob != entry['gitBlob']:
        failures.append([relpath, 'git-blob', entry['gitBlob'], blob])
    checked += 1
for relpath, expected in overlay.items():
    path = runtime / relpath
    if not path.is_file():
        failures.append([relpath, 'missing-overlay'])
        continue
    observed = hashlib.sha256(path.read_bytes()).hexdigest()
    if observed != expected:
        failures.append([relpath, 'overlay-sha256', expected, observed])
    checked += 1
print(json.dumps({'revision': base['revision'], 'baseFiles': len(base['entries']),
                  'overlayFiles': len(overlay), 'checked': checked,
                  'failures': failures}, indent=2))
if failures:
    sys.exit(1)

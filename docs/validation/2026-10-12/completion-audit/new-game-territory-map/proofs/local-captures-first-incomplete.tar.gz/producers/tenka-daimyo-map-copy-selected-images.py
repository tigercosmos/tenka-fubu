#!/usr/bin/env python3
"""Preserve the six reviewed endpoint screenshots without copying browser trace bulk."""
from pathlib import Path

source = Path('/tmp/tenka-daimyo-map-native-c2-images/browser-results')
target = Path('/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit/new-game-territory-map/images')
for scale in ('0.8', '1.5'):
    for state in ('initial', 'imagawa', 'oda-return'):
        name = f'territory-{scale}-{state}.png'
        found = list(source.rglob(name))
        assert len(found) == 1, (name, found)
        with (target / name).open('xb') as output:
            output.write(found[0].read_bytes())

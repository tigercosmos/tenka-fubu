#!/usr/bin/env python3
"""Freeze the eight committed map file hashes for remote source proof."""
import hashlib
import json
from pathlib import Path

repo = Path('/Users/tigercosmos/tenka-fubu')
paths = [
    'e2e/daimyo-territory-preview.spec.ts',
    'plan/11-ui-screens.md',
    'src/i18n/zh-TW.ts',
    'src/ui/screens/DaimyoSelect.module.css',
    'src/ui/screens/DaimyoSelect.tsx',
    'src/ui/screens/DaimyoTerritoryPreview.tsx',
    'src/ui/screens/territoryPreviewModel.spec.ts',
    'src/ui/screens/territoryPreviewModel.ts',
]
out = Path('/tmp/tenka-daimyo-map-overlay-c1/overlay-hashes-final.json')
with out.open('x') as file:
    json.dump({path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in paths},
              file, indent=2, sort_keys=True)
    file.write('\n')

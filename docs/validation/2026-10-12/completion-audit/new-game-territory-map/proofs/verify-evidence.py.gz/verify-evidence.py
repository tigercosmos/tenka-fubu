#!/usr/bin/env python3
"""Verify compact M8-17 map evidence from its package directory."""
import gzip
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
checksums = json.loads((root / 'SHA256SUMS.json').read_text())
for relative, expected in checksums.items():
    file = root / relative
    assert file.is_file(), relative
    assert hashlib.sha256(file.read_bytes()).hexdigest() == expected, relative

expected_runs = {
    'c1-selector-red': (0, 2, 2),
    'c2-endpoints': (2, 0, 2),
    'c3-all-scales': (15, 0, 15),
    'wizard16': (16, 0, 16),
}
for folder, (passed, unexpected, count) in expected_runs.items():
    report = json.loads((root / folder / 'report.json').read_text())
    stats = report['stats']
    assert (stats['expected'], stats['unexpected'], stats['skipped']) == (passed, unexpected, 0), folder
    specs = [spec for suite in report['suites'] for spec in suite['specs']]
    assert len(specs) == count, (folder, len(specs))
    assert all(len(spec['tests']) == 1 and len(spec['tests'][0]['results']) == 1 for spec in specs), folder
    assert json.loads((root / folder / 'result.json').read_text())['exitCode'] == (1 if unexpected else 0), folder

source_output = json.loads((root / 'proofs/remote-source/stdout-stderr.log').read_text())
assert source_output == {
    'revision': 'cb717d2466a21daa29aa15843c0de22abb8b91ce',
    'baseFiles': 1641,
    'overlayFiles': 8,
    'checked': 1645,
    'failures': [],
}
bundle_output = (root / 'proofs/remote-bundle/stdout-stderr.log').read_text()
assert '"passed": true' in bundle_output
build_output = (root / 'proofs/remote-build/stdout-stderr.log').read_text()
assert '"validated":29,"written":0' in build_output and '✓ built in ' in build_output

with tarfile.open(root / 'proofs/local-captures.tar.gz', 'r:gz') as archive:
    manifest = json.load(archive.extractfile('local/tenka-daimyo-map-scoped-cb-c1/manifest.json'))
    overlay = json.load(archive.extractfile('local/tenka-daimyo-map-overlay-c1/overlay-hashes-final.json'))
    assert manifest['revision'] == source_output['revision']
    assert len(manifest['entries']) == 1641 and len(overlay) == 8
    commit = 'f31284d6a4301b65ef9fded0ff3364efa2651c10'
    repo = root.parents[4]
    for relative, expected in overlay.items():
        data = subprocess.check_output(['git', 'show', f'{commit}:{relative}'], cwd=repo)
        assert hashlib.sha256(data).hexdigest() == expected, relative

for key in ('c1', 'c2', 'c3', 'wizard'):
    with gzip.open(root / f'proofs/remote-artifacts-{key}.txt.gz', 'rt') as stream:
        rows = [row.strip().split('  ', 1) for row in stream if row.strip()]
    assert rows and all(len(row) == 2 and re.fullmatch(r'[a-f0-9]{64}', row[0]) for row in rows), key
    if key == 'c2':
        images = {Path(path).name: digest for digest, path in rows}
        for image in (root / 'images').glob('*.png'):
            assert hashlib.sha256(image.read_bytes()).hexdigest() == images[image.name], image.name
        assert len(list((root / 'images').glob('*.png'))) == 6

print(json.dumps({'files': len(checksums), 'browserRuns': expected_runs,
                  'sourceChecked': source_output['checked'], 'overlayCommit': commit,
                  'endpointImages': 6, 'passed': True}, indent=2))

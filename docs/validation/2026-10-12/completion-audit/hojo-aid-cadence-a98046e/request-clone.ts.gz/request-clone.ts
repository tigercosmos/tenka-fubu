import { readFileSync } from 'node:fs';
import { advanceDay } from '/tmp/tenka-court-runtime-1649-v1/src/core/systems/index.ts';
import { reinforcementAidScore } from '/tmp/tenka-court-runtime-1649-v1/src/core/systems/diplomacyEval.ts';
import { validateCommand } from '/tmp/tenka-court-runtime-1649-v1/src/core/commands/validate.ts';
import type { GameState } from '/tmp/tenka-court-runtime-1649-v1/src/core/state/gameState.ts';
import type { CommandEnvelope } from '/tmp/tenka-court-runtime-1649-v1/src/core/commands/types.ts';
const saved=JSON.parse(readFileSync('/tmp/tenka-hojo-days120-150.json','utf8')) as GameState[];
for(const day of [120,121,122,125,126,150]){
 const state=structuredClone(saved.find(s=>s.time.day===day)!);
 const command={type:'proposePact' as const,clanId:'clan.takeda' as const,targetClanId:'clan.hojo' as const,kind:'requestReinforce' as const,reinforceAgainstClanId:'clan.nagao' as const};
 const legality=validateCommand(state,command);
 const before={day:state.time.day,cacheDay:state.ai.clans['clan.hojo']?.threatCache?.computedDay??null,score:reinforcementAidScore(state,'clan.takeda','clan.hojo')};
 const envelope:CommandEnvelope={seq:state.meta.lastAppliedCmdSeq+1,issuedDay:state.time.day,command};
 const result=advanceDay(state,[envelope]);
 const relevant=result.events.filter(e=>e.type.startsWith('diplo.')||e.type==='command.rejected');
 console.log(JSON.stringify({before,legality,after:{day:state.time.day,cacheDay:state.ai.clans['clan.hojo']?.threatCache?.computedDay??null,score:reinforcementAidScore(state,'clan.takeda','clan.hojo')},applied:result.appliedCommands.length,events:relevant}));
}

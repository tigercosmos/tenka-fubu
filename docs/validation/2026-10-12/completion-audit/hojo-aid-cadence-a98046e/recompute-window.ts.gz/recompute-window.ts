import { readFileSync } from 'node:fs';
import { computeThreatCache } from '/tmp/tenka-court-runtime-1649-v1/src/core/systems/ai/threat.ts';
import { reinforcementAidScore } from '/tmp/tenka-court-runtime-1649-v1/src/core/systems/diplomacyEval.ts';
import { getTrust } from '/tmp/tenka-court-runtime-1649-v1/src/core/systems/diplomacyCommon.ts';
import type { GameState } from '/tmp/tenka-court-runtime-1649-v1/src/core/state/gameState.ts';
const states=JSON.parse(readFileSync('/tmp/tenka-hojo-days120-150.json','utf8')) as GameState[];
for(const state of states){
 const trust=getTrust(state,'clan.takeda','clan.hojo');
 const prior=state.ai.clans['clan.hojo']?.threatCache;
 const fresh=computeThreatCache(state,'clan.hojo');
 state.ai.clans['clan.hojo']!.threatCache=fresh;
 const score=reinforcementAidScore(state,'clan.takeda','clan.hojo');
 console.log(JSON.stringify({day:state.time.day,trust,priorDay:prior?.computedDay??null,priorThreat:prior?.totalThreat??null,freshThreat:fresh.totalThreat,score,eligible:trust>=20&&score>=0.5}));
}

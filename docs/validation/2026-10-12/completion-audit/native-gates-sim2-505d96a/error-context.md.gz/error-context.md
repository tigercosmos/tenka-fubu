# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: live-national-map-perf.spec.ts >> actual command-driven national forty-army ×5 postrender acceptance >> close: live strategy, native historical choice, full-wall rendering
- Location: e2e/live-national-map-perf.spec.ts:92:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - region "戰略圖層" [ref=e6]:
      - group [ref=e7]:
        - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
    - banner [ref=e9]:
      - group "金錢、兵糧、兵力、威信" [ref=e10]:
        - generic [ref=e11]:
          - group "織田家" [ref=e12]:
            - strong [ref=e14]: 織田家
          - time [ref=e15]: 1560年6月1日
          - generic [ref=e16]:
            - generic [ref=e17]:
              - img [ref=e18]
              - generic [ref=e21]: 金錢
            - strong [ref=e24]: 1,557
          - generic [ref=e25]:
            - generic [ref=e26]:
              - img [ref=e27]
              - generic [ref=e29]: 兵糧
            - generic [ref=e30]:
              - strong [ref=e32]: 9,779
              - generic "兵糧可支撐23個月" [ref=e33]:
                - text: 兵糧可支撐
                - strong [ref=e34]: "23"
                - text: 個月
          - generic [ref=e35]:
            - generic [ref=e36]:
              - img [ref=e37]
              - generic [ref=e41]: 兵力
            - generic [ref=e43]:
              - strong [ref=e44]: 4,179
              - generic [ref=e45]: /4,373
          - generic [ref=e46]:
            - generic [ref=e47]:
              - img [ref=e48]
              - generic [ref=e50]: 威信
            - strong [ref=e53]: "450"
      - generic [ref=e54]:
        - generic [ref=e55]:
          - button "暫停" [disabled] [pressed]:
            - img
          - button "一倍速" [disabled]:
            - img
          - button "二倍速" [disabled]:
            - img
          - button "五倍速" [disabled]:
            - img
        - button "系統選單" [ref=e56] [cursor=pointer]:
          - img [ref=e57]
    - navigation "內政" [ref=e60]:
      - button "地圖一覽" [ref=e61] [cursor=pointer]:
        - img [ref=e62]
        - generic [ref=e65]:
          - generic [ref=e66]: 地圖
          - generic [ref=e67]: 一覽
      - button "織田家 （本城）" [ref=e68] [cursor=pointer]:
        - img [ref=e69]
        - generic "織田家" [ref=e74]: 織田
      - generic [ref=e76]: 軍政
      - button "軍事" [ref=e77] [cursor=pointer]:
        - img [ref=e78]
        - text: 軍事
      - button "內政" [ref=e80] [cursor=pointer]:
        - img [ref=e81]
        - text: 內政
      - button "武將" [ref=e83] [cursor=pointer]:
        - img [ref=e84]
        - text: 武將
      - generic [ref=e89]: 交涉
      - button "外交" [ref=e90] [cursor=pointer]:
        - img [ref=e91]
        - text: 外交
      - button "調略" [ref=e93] [cursor=pointer]:
        - img [ref=e94]
        - text: 調略
      - generic [ref=e98]: 國策
      - button "政策" [ref=e99] [cursor=pointer]:
        - img [ref=e100]
        - text: 政策
      - button "軍團" [ref=e102] [cursor=pointer]:
        - img [ref=e103]
        - text: 軍團
      - button "大命" [ref=e105] [cursor=pointer]:
        - img [ref=e106]
        - text: 大命
    - generic:
      - generic:
        - generic:
          - button:
            - img
    - img "全國小地圖" [ref=e108]
    - generic:
      - button "通報 3 則" [ref=e112] [cursor=pointer]:
        - img [ref=e113]
      - generic "通報 3 則" [ref=e115]:
        - status [ref=e116] [cursor=pointer]:
          - generic [ref=e117]:
            - img [ref=e119]
            - generic [ref=e121]:
              - strong [ref=e122]: 待處理具申 3件
              - time [ref=e123]: 1560年6月1日
        - alert [ref=e124]:
          - generic [ref=e125]:
            - img [ref=e127]
            - generic [ref=e129]:
              - strong [ref=e130]: 發生事件：種子島的商人
              - time [ref=e131]: 1560年6月1日
            - button "關閉通知" [ref=e133] [cursor=pointer]:
              - img [ref=e134]
        - alert [ref=e136]:
          - generic [ref=e137]:
            - img [ref=e139]
            - generic [ref=e141]:
              - strong [ref=e142]: 發生事件：南蠻船入港
              - time [ref=e143]: 1560年6月1日
            - button "關閉通知" [ref=e145] [cursor=pointer]:
              - img [ref=e146]
      - button "報告中心" [ref=e148] [cursor=pointer]
  - dialog "具申 ─ 1,560年6月（3件）" [ref=e150]:
    - banner [ref=e151]:
      - heading "具申 ─ 1,560年6月（3件）" [level=2] [ref=e152]
    - article [ref=e154]:
      - heading "柴田勝家・家老呈報" [level=3] [ref=e155]
      - generic [ref=e156]: 出陣具申
      - paragraph [ref=e157]: 出陣具申
      - generic [ref=e158]:
        - paragraph [ref=e159]: 由清洲城向長島城出陣，撥出1,670人及兵糧2,004石。
        - paragraph [ref=e160]: 大將：柴田勝家・副將：無
      - paragraph [ref=e161]: 預估費用 0貫・功績報酬 30
      - paragraph [ref=e162]: 尚可裁決 60日
      - paragraph [ref=e163]: 採納：具申者忠誠＋2；駁回：忠誠－2；逾期：忠誠－1。
      - generic [ref=e164]:
        - button "拒絕" [active] [ref=e166] [cursor=pointer]
        - button "採納" [ref=e168] [cursor=pointer]
      - paragraph [ref=e169]: 尚有3件具申
    - contentinfo [ref=e170]:
      - button "全部駁回" [ref=e171] [cursor=pointer]
```

# Test source

```ts
  132 |       });
  133 |       expect(environment.renderer).not.toMatch(/swiftshader|llvmpipe|software/i);
  134 |       const handled: string[] = [];
  135 |       await page.getByTestId('speed-5').click();
  136 |       await expect
  137 |         .poll(
  138 |           async () => {
  139 |             const pending = await page.evaluate(
  140 |               () => window.__tenka.debug.getState().events.pendingChoiceEventId,
  141 |             );
  142 |             if (
  143 |               pending === okehazama.id &&
  144 |               (await page
  145 |                 .getByRole('dialog', { name: okehazama.cutscene.title, exact: true })
  146 |                 .isVisible())
  147 |             )
  148 |               return true;
  149 |             await drainKnownOwner(page, handled);
  150 |             if (
  151 |               (await page.getByRole('dialog').count()) === 0 &&
  152 |               (await page.getByTestId('speed-5').isEnabled())
  153 |             ) {
  154 |               if ((await page.getByTestId('speed-5').getAttribute('aria-pressed')) !== 'true')
  155 |                 await clickBeforeWindow(page, page.getByTestId('speed-5'));
  156 |             }
  157 |             expect(
  158 |               (await page.evaluate(() => window.__tenka.debug.getLiveNationalMapWorkload()))
  159 |                 ?.failure,
  160 |             ).toBeNull();
  161 |             return false;
  162 |           },
  163 |           { timeout: 55_000, intervals: [100] },
  164 |         )
  165 |         .toBe(true);
  166 |       await page
  167 |         .getByRole('dialog', { name: okehazama.cutscene.title, exact: true })
  168 |         .getByRole('button', { name: okehazama.choices[0]!.label, exact: true })
  169 |         .click();
  170 |       await expect
  171 |         .poll(() =>
  172 |           page.evaluate(() => window.__tenka.debug.getState().events.pendingChoiceEventId),
  173 |         )
  174 |         .toBeNull();
  175 |       // Set the measured camera while paused. No strategy or army progress writes.
  176 |       await expect
  177 |         .poll(
  178 |           async () => {
  179 |             await drainKnownOwner(page, handled);
  180 |             if (
  181 |               (await page.getByRole('dialog').count()) > 0 ||
  182 |               !(await page.getByTestId('speed-pause').isEnabled())
  183 |             )
  184 |               return false;
  185 |             await clickBeforeWindow(page, page.getByTestId('speed-pause'));
  186 |             return (await page.getByTestId('speed-pause').getAttribute('aria-pressed')) === 'true';
  187 |           },
  188 |           { timeout: 15_000, intervals: [100] },
  189 |         )
  190 |         .toBe(true);
  191 |       await page.evaluate(async (camera) => {
  192 |         await window.__tenka.debug.setMapCameraPreset(camera);
  193 |         await window.__tenka.debug.waitMapIdle(3);
  194 |       }, preset);
  195 |       const before = await page.evaluate(() => ({
  196 |         state: window.__tenka.debug.getState(),
  197 |         log: window.__tenka.debug.exportCommandLog(),
  198 |       }));
  199 |       await page.getByTestId('speed-5').click();
  200 |       // No owner handling during the window: every pause/interruption remains in the artifact.
  201 |       const measurement = await page.evaluate(() =>
  202 |         window.__tenka.debug.measureLiveNationalMapFrames(30_000),
  203 |       );
  204 |       const after = await page.evaluate(() => ({
  205 |         state: window.__tenka.debug.getState(),
  206 |         log: window.__tenka.debug.exportCommandLog(),
  207 |         workload: window.__tenka.debug.getLiveNationalMapWorkload(),
  208 |       }));
  209 |       const path = info.outputPath(`live-national-${preset}.json`);
  210 |       await writeFile(
  211 |         path,
  212 |         JSON.stringify(
  213 |           { environment, original, preparation, handled, before, measurement, after },
  214 |           null,
  215 |           2,
  216 |         ),
  217 |       );
  218 |       await info.attach('actual-live-frame-and-command-proof', {
  219 |         path,
  220 |         contentType: 'application/json',
  221 |       });
  222 |       await info.attach('actual-live-national-map', {
  223 |         body: await page.screenshot(),
  224 |         contentType: 'image/png',
  225 |       });
  226 |       // Preserve raw evidence even when a mandatory owner disabled the pause button.
  227 |       if (
  228 |         (await page.getByRole('dialog').count()) === 0 &&
  229 |         (await page.getByTestId('speed-pause').isEnabled())
  230 |       )
  231 |         await clickBeforeWindow(page, page.getByTestId('speed-pause'));
> 232 |       expect(measurement.valid).toBe(true);
      |                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  233 |       expect(measurement.minMountedArmies).toBeGreaterThanOrEqual(40);
  234 |       expect(measurement.averageFps).toBeGreaterThanOrEqual(60);
  235 |       expect(measurement.frameTimeP95).toBeLessThanOrEqual(1000 / 60);
  236 |       expect(after.state.time.day).toBeGreaterThan(before.state.time.day);
  237 |       expect(after.workload?.minimumMarching).toBe(40);
  238 |       expect(after.workload?.failure).toBeNull();
  239 |       await page.evaluate(() => window.__tenka.debug.stopLiveNationalMapWorkload());
  240 |     });
  241 |   }
  242 | });
  243 | 
```
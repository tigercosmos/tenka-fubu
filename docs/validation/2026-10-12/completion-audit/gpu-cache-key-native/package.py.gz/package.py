import gzip,hashlib,json,pathlib,subprocess,tarfile
r=pathlib.Path(__file__).parent
subprocess.run(['python3',str(r/'proof.py'),'source-final'],check=True,cwd=r)
files=[p for p in r.glob('*') if p.is_file() and p.suffix in ['.log','.json','.py','.exit','.ts'] and p.name!='source.tar.gz']
for folder in ['original-results','diagnostic-results']:
 files.extend(p for p in (r/folder).rglob('*') if p.is_file())
files.extend([r/'e2e/heap-diagnostic.spec.ts',r/'tools/dependencies/pixi-8.19-patch.json'])
deps=[]
for p in sorted((r/'node_modules').rglob('*')):
 if p.is_file(): deps.append({'path':str(p.relative_to(r/'node_modules')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(r/'dependency-final.json').write_text(json.dumps(deps,indent=2)+'\n');files.append(r/'dependency-final.json')
output=r/'package';output.mkdir(exist_ok=True);rows=[]
for p in sorted(set(files)):
 name=str(p.relative_to(r)).replace('/','__');raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);target=output/(name+'.gz');target.write_bytes(packed);rows.append({'path':target.name,'sourcePath':str(p.relative_to(r)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest()})
summary={'source':json.loads((r/'source-origin.json').read_text()),'originalExit':int((r/'original.exit').read_text()),'diagnosticExit':int((r/'diagnostic.exit').read_text()),'dependencies':len(deps),'artifacts':rows}
for kind in ['original','diagnostic']:
 path=next((r/(kind+'-results')).rglob('remount-heap-samples.json'));data=json.loads(path.read_text());a=data['usedHeapBytes']; summary[kind]={'sampleCount':len(a),'first':a[0],'last':a[-1],'delta':a[-1]-a[0],'last20Delta':a[-1]-a[-20],'cacheBefore':data['cacheBefore'],'cacheAfter':data['cacheAfter']}
 if len(a)>120: summary[kind]['after120']=a[120];summary[kind]['second120Delta']=a[-1]-a[120]
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(r/'evidence.tar.gz','w:gz') as t: t.add(output,arcname='gpu-cache-key-native')
print(json.dumps({k:v for k,v in summary.items() if k!='artifacts'},indent=2))

from pathlib import Path
r=Path(__file__).parent
s=(r/'e2e/visual.spec.ts').read_text()
s=s.replace("if (process.env.VISUAL_HEAP === '1') test.setTimeout(180_000);", "if (process.env.VISUAL_HEAP === '1') test.setTimeout(600_000);")
s=s.replace("const remountCount = process.env.VISUAL_HEAP === '1' ? 20 : 10;", "const remountCount = process.env.VISUAL_HEAP === '1' ? 240 : 10;")
s=s.replace("const cacheBefore = await snapshotHeap('before-remounts');", """const gpuIdentity = await page.evaluate(() => {
      const canvas = document.querySelector('[data-testid=map-canvas-host] canvas') as HTMLCanvasElement;
      const gl = canvas.getContext('webgl2')!;
      const info = gl.getExtension('WEBGL_debug_renderer_info')!;
      return { vendor: gl.getParameter(info.UNMASKED_VENDOR_WEBGL), renderer: gl.getParameter(info.UNMASKED_RENDERER_WEBGL) };
    });
    await writeFile(testInfo.outputPath('gpu-identity.json'), JSON.stringify(gpuIdentity, null, 2));
    const cacheBefore = await snapshotHeap('before-remounts');""")
s=s.replace("      await sampleHeap();\n    }\n    const cacheAfter", "      await sampleHeap();\n      if (cycle === 119) await snapshotHeap('after-120-remounts');\n    }\n    const cacheAfter")
(r/'e2e/heap-diagnostic.spec.ts').write_text(s)
(r/'heap-diagnostic.config.ts').write_text("import base from './playwright.config';\nexport default { ...base, globalTimeout: 660_000, reporter: [['list']], outputDir: 'diagnostic-results' };\n")
print('Separate diagnostic: original source untouched;10 warmups+240 measured remounts; middle snapshot after120; per-case600s; global660s; same resource assertions')

#!/usr/bin/env python3
"""Attribute post-cap heap growth and inspect Pixi per-renderer GPU cache shape."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path('/tmp/tenka-gpu-cache-candidate')
SNAP = BASE / 'diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium'
PARSER = Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec = importlib.util.spec_from_file_location('postcap', PARSER)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod.HERE = BASE / 'scratch'

def inspect(path):
    s = mod.Snapshot(path)
    paths = s.strong_paths()
    owners = []
    for parent in range(s.count):
        if s.kind(parent) != 'object':
            continue
        gpu = s.property(parent, '_gpuData')
        if gpu is None:
            continue
        edges = list(s.edges_of(gpu))
        element_keys = [(label, target) for kind, label, target in edges if kind == 'element']
        named_keys = [(label, target) for kind, label, target in edges if kind == 'property' and label.lstrip('-').isdigit()]
        storage = [(s.attr(target, 'id'), s.attr(target, 'self_size')) for kind, label, target in edges if kind == 'internal' and label == 'elements']
        owners.append({'parentId': s.attr(parent, 'id'), 'parentName': s.name(parent),
                       'mapId': s.attr(gpu, 'id'), 'elementKeys': [label for label, _ in element_keys],
                       'namedKeys': [label for label, _ in named_keys],
                       'elementValueKinds': [s.kind(target) + '/' + s.name(target) for _,target in element_keys],
                       'namedValueKinds': [s.kind(target) + '/' + s.name(target) for _,target in named_keys],
                       'elementStorage': storage})
    kind_summary = collections.Counter((s.kind(i), s.name(i)) for i in range(s.count))
    def growth_candidates(kind, name):
        return {s.attr(i, 'id'): i for i in range(s.count) if s.kind(i) == kind and s.name(i) == name}
    return s, paths, owners, kind_summary, growth_candidates

old, oldpaths, owners0, groups0, family0 = inspect(SNAP/'after-120-remounts.heapsnapshot')
new, newpaths, owners1, groups1, family1 = inspect(SNAP/'after-remounts.heapsnapshot')

def summarize(owners):
    return {'count':len(owners), 'parentNames':dict(collections.Counter(o['parentName'] for o in owners)),
            'elementKeyCounts':dict(collections.Counter(len(o['elementKeys']) for o in owners)),
            'namedKeyCounts':dict(collections.Counter(len(o['namedKeys']) for o in owners)),
            'namedKeys':dict(collections.Counter(key for o in owners for key in o['namedKeys'])),
            'elementKeys':dict(collections.Counter(key for o in owners for key in o['elementKeys'])),
            'elementStorageBytes':sum(size for o in owners for _, size in o['elementStorage']),
            'nullNamedValues':sum(v=='native/null' for o in owners for v in o['namedValueKinds']),
            'nullElementValues':sum(v=='native/null' for o in owners for v in o['elementValueKinds'])}

def stable_growth(kind,name,limit=8):
    a=family0(kind,name);b=family1(kind,name)
    stable=a.keys()&b.keys()
    rows=[]
    for ident in stable:
        i,j=a[ident],b[ident]
        delta=new.attr(j,'self_size')-old.attr(i,'self_size')
        if delta<=0:continue
        path=new.path(j,newpaths)
        rows.append({'id':ident,'oldBytes':old.attr(i,'self_size'),'newBytes':new.attr(j,'self_size'),
                     'delta':delta,'strongPath':[(x['from'],x['edge'],x['to']) for x in path[-16:]] if path else None})
    rows.sort(key=lambda row:row['delta'],reverse=True)
    return {'kind':kind,'name':name,'positiveStableCount':len(rows),
            'positiveStableBytes':sum(row['delta'] for row in rows),
            'largest':rows[:limit]}

stable_owners0={(o['parentId'],o['mapId']) for o in owners0}
stable_owners1={(o['parentId'],o['mapId']) for o in owners1}
report={'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [SNAP/'after-120-remounts.heapsnapshot',SNAP/'after-remounts.heapsnapshot']],
        'snapshots':{'midSelfBytes':sum(old.attr(i,'self_size') for i in range(old.count)),
                     'finalSelfBytes':sum(new.attr(i,'self_size') for i in range(new.count)),
                     'midNodes':old.count,'finalNodes':new.count},
        'gpuData':{'mid':summarize(owners0),'final':summarize(owners1),
                   'stableOwnerMapIds':len(stable_owners0&stable_owners1),
                   'midOwners':owners0,'finalOwners':owners1},
        'stableGrowth':[stable_growth('array','(object elements)'),
                        stable_growth('code','system / InstructionStream'),
                        stable_growth('code','system / TrustedByteArray'),
                        stable_growth('native','system / WeakArrayList')]}
print(json.dumps(report,indent=2))

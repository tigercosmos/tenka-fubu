#!/usr/bin/env python3
"""Count Pixi BatchTextureArray.ids sparse backing storage at midpoint/final."""
import collections
import importlib.util
import json
from pathlib import Path
BASE=Path('/tmp/tenka-gpu-cache-candidate')
SNAP=BASE/'diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium'
P=Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec=importlib.util.spec_from_file_location('postcap',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=BASE/'scratch'

def inspect(path):
 s=m.Snapshot(path);parents=s.strong_paths();rows=[]
 for i in range(s.count):
  if s.kind(i)!='object':continue
  props={label:target for kind,label,target in s.edges_of(i) if kind=='property'}
  if not {'ids','textures'}<=props.keys():continue
  ids=props['ids']
  if s.kind(ids)!='object':continue
  stores=[target for kind,label,target in s.edges_of(ids) if kind=='internal' and label=='elements']
  if not stores:continue
  pathrow=s.path(ids,parents)
  if not pathrow or pathrow[-1]['edge']!='ids':continue
  # The live/pool object has the Pixi BatchTextureArray shape and indexed map.
  edges=[(int(label),target) for kind,label,target in s.edges_of(ids) if kind=='element']
  rows.append({'ownerId':s.attr(i,'id'),'ownerName':s.name(i),'idsId':s.attr(ids,'id'),
               'texturesId':s.attr(props['textures'],'id'),
               'elementCount':len(edges),'minKey':min((k for k,_ in edges),default=None),
               'maxKey':max((k for k,_ in edges),default=None),
               'nullValues':sum(s.kind(target)=='native' and s.name(target)=='null' for _,target in edges),
               'storageId':s.attr(stores[0],'id'),'storageBytes':s.attr(stores[0],'self_size'),
               'pathTail':[(x['from'],x['edge'],x['to']) for x in pathrow[-10:]]})
 rows.sort(key=lambda r:r['storageBytes'],reverse=True)
 return {'path':str(path),'count':len(rows),'storageBytes':sum(r['storageBytes'] for r in rows),
         'keyCount':sum(r['elementCount'] for r in rows),'nullValues':sum(r['nullValues'] for r in rows),
         'maxKeys':dict(collections.Counter(str(r['maxKey']) for r in rows)),
         'largest':rows[:12],'rows':rows}
result=[inspect(SNAP/'after-120-remounts.heapsnapshot'),inspect(SNAP/'after-remounts.heapsnapshot')]
print(json.dumps(result,indent=2))

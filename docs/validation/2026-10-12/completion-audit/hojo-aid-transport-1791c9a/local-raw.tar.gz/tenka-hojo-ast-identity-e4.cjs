const fs = require('node:fs');
const crypto = require('node:crypto');
const ts = require('/Users/tigercosmos/tenka-fubu/node_modules/typescript');

function fingerprint(path) {
  const source = ts.createSourceFile(path, fs.readFileSync(path, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (source.parseDiagnostics.length) throw new Error(`${path} has parse errors`);
  const normalize = (node) => {
    const children = [];
    ts.forEachChild(node, (child) => { children.push(normalize(child)); });
    const text = ts.isIdentifier(node) || ts.isLiteralExpression(node)
      ? node.text : undefined;
    return [node.kind, text, children];
  };
  return crypto.createHash('sha256').update(JSON.stringify(normalize(source))).digest('hex');
}
const rows = process.argv.slice(2).map((path) => ({ path, sha256: fingerprint(path) }));
console.log(JSON.stringify(rows));
if (rows.some((row) => row.sha256 !== rows[0].sha256)) process.exitCode = 1;

import { readFileSync } from 'node:fs';
import { BAL } from '/Users/tigercosmos/tenka-fubu/src/core/balance.ts';
import { computeThreatCache } from '/Users/tigercosmos/tenka-fubu/src/core/systems/ai/threat.ts';
import { estCastlePower, nodeOwner, nodesWithin } from '/Users/tigercosmos/tenka-fubu/src/core/systems/ai/shared.ts';
import { validateCommand } from '/Users/tigercosmos/tenka-fubu/src/core/commands/validate.ts';
import { applyTransport } from '/Users/tigercosmos/tenka-fubu/src/core/commands/domesticCommands.ts';
import { reinforcementAidScore } from '/Users/tigercosmos/tenka-fubu/src/core/systems/diplomacyEval.ts';
import type { GameState } from '/Users/tigercosmos/tenka-fubu/src/core/state/gameState.ts';
import type { ClanId, MapNodeId } from '/Users/tigercosmos/tenka-fubu/src/core/state/ids.ts';

const state = JSON.parse(readFileSync('/tmp/tenka-hojo-day119-extract-e4-v1/day119.json', 'utf8')) as GameState;
const hojo = 'clan.hojo' as ClanId;
const takeda = 'clan.takeda' as ClanId;
const borders = new Set<MapNodeId>();
for (const edge of Object.values(state.roads)) {
  const a = nodeOwner(state, edge.a), b = nodeOwner(state, edge.b);
  if ((a === hojo && b === takeda) || (a === takeda && b === hojo)) {
    borders.add(edge.a);
    borders.add(edge.b);
  }
}
const range = nodesWithin(state, borders, BAL.aiBorderNodeRange);
const source = Object.values(state.castles)
  .filter(c => c.ownerClanId === takeda && range.has(c.id))
  .map(c => ({ id: c.id, name: c.name, soldiers: c.soldiers, morale: c.morale,
    estimatedPower: estCastlePower(state, c), lordId: c.lordId }));
const destinations = Object.values(state.castles)
  .filter(c => c.ownerClanId === takeda && !range.has(c.id))
  .map(c => ({ id: c.id, name: c.name, soldiers: c.soldiers }));
const before = computeThreatCache(state, hojo);
const trials = [];
for (const from of source) for (const to of destinations) for (const soldiers of [1200, 1500, 2000]) {
  if (soldiers > from.soldiers) continue;
  const cmd = {type:'transport' as const, clanId:takeda, fromCastleId:from.id, toCastleId:to.id, soldiers, gold:0, food:0};
  const validity = validateCommand(state, cmd);
  if (!validity.ok) { trials.push({from:from.id,to:to.id,soldiers,validity}); continue; }
  const changed = structuredClone(state);
  applyTransport(changed, cmd);
  const after = computeThreatCache(changed, hojo);
  changed.ai.clans[hojo]!.threatCache = after;
  trials.push({from:from.id,to:to.id,soldiers,validity,
    afterThreat:after.totalThreat, afterScore:reinforcementAidScore(changed,takeda,hojo),
    takedaPower:after.entries.find(e=>e.enemyClanId===takeda)?.borderPowerEnemy,
    path: Object.values(changed.transports).at(-1)?.path});
}
console.log(JSON.stringify({day:state.time.day,border:[...borders], range:[...range].length,
  source,destinations,beforeThreat:before.totalThreat,
  beforeCachedThreat:state.ai.clans[hojo]?.threatCache?.totalThreat,
  beforeScore:reinforcementAidScore(state,takeda,hojo),trials},null,2));

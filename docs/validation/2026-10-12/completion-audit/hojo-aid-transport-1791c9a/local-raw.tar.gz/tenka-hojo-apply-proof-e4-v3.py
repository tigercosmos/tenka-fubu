import hashlib
import json
import shutil
import sys
import tarfile
from pathlib import Path

runtime = Path('/tmp/tenka-hojo-e4-runtime-v1')
overlay = Path('/tmp/tenka-hojo-e4-overlay-v3')
manifest = json.loads((overlay / 'manifest.json').read_text())
phase = sys.argv[1]
if phase == 'apply':
    with tarfile.open(overlay / 'source.tar') as archive:
        archive.extractall(runtime, filter='data')
    shutil.copyfile(overlay / 'earned-hojo-aid.spec.ts', runtime / 'e2e/earned-hojo-aid.spec.ts')
elif phase not in ('before', 'after', 'probe-before', 'probe-after'):
    raise SystemExit(f'unknown phase {phase}')

mismatches = []
for name, row in manifest['entries'].items():
    path = runtime / name
    try:
        data = path.read_bytes()
        digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    except FileNotFoundError:
        digest = 'missing'
    expected = row['gitBlob']
    if phase.startswith('probe-') and name == 'e2e/earned-hojo-aid.spec.ts':
        data = (overlay / 'tenka-hojo-transport-probe-e4-v3.spec.ts').read_bytes()
        expected = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if digest != expected:
        mismatches.append({'path': name, 'expected': expected, 'actual': digest})

pixi = runtime / 'node_modules/pixi.js'
pixi_hashes = {}
for path in sorted(pixi.rglob('*')):
    if path.is_file():
        pixi_hashes[str(path.relative_to(pixi))] = hashlib.sha256(path.read_bytes()).hexdigest()
fingerprint = {
    'revision': manifest['revision'],
    'phase': phase,
    'checked': len(manifest['entries']),
    'mismatches': mismatches,
    'pixiFiles': len(pixi_hashes),
    'pixiSha256': pixi_hashes,
    'probeSha256': hashlib.sha256((overlay / 'tenka-hojo-transport-probe-e4-v3.spec.ts').read_bytes()).hexdigest() if phase.startswith('probe-') else None,
}
target = overlay / f'{phase}-fingerprint.json'
with target.open('x') as output:
    json.dump(fingerprint, output, sort_keys=True)
    output.write('\n')
print(json.dumps({'phase': phase, 'revision': manifest['revision'],
                  'checked': len(manifest['entries']), 'mismatches': mismatches,
                  'pixiFiles': len(pixi_hashes), 'fingerprint': str(target)}))
assert not mismatches

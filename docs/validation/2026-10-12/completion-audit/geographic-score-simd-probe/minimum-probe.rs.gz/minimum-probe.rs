fn main() {
    for (a,b) in [(0.0_f64,-0.0_f64),(-0.0,0.0),(f64::NAN,1.0),(1.0,f64::NAN)] {
        println!("{:016x} {:016x}", a.minimum(b).to_bits(), a.maximum(b).to_bits());
    }
}

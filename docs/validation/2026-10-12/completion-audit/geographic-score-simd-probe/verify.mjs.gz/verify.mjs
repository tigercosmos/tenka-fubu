import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const bytes=readFileSync(new URL('probe.wasm',import.meta.url));
const {instance}=await WebAssembly.instantiate(bytes);const {scalar,lanes}=instance.exports;
const view=new DataView(new ArrayBuffer(8));
const bits=x=>{view.setFloat64(0,x,false);return view.getBigUint64(0,false).toString(16).padStart(16,'0')};
const same=(a,b)=>Number.isNaN(a)&&Number.isNaN(b)||bits(a)===bits(b);
const original=(ax,ay,aw,ah,bx,by,bw,bh,p)=>Math.max(0,Math.min(ax+aw+p,bx+bw+p)-Math.max(ax-p,bx-p))*Math.max(0,Math.min(ay+ah+p,by+bh+p)-Math.max(ay-p,by-p));
const coordinates=[-0,0,-Number.MIN_VALUE,Number.MIN_VALUE,-1e-308,1e-308,-1,-1+Number.EPSILON,1-Number.EPSILON,1,1+Number.EPSILON,-48,48,-1e308,1e308,-Number.MAX_VALUE,Number.MAX_VALUE,-Infinity,Infinity,NaN];
const sizes=[-0,0,Number.MIN_VALUE,1e-308,Number.EPSILON,1,8,1e308,Number.MAX_VALUE,Infinity,NaN];
const rows=[];for(const x of coordinates)for(const w of sizes){rows.push([x,-x,w,w]);rows.push([x,x,w,0]);rows.push([-x,x,0,w]);}
let count=0,nans=0,zeros=0,negativeZeros=0;const digest=createHash('sha256');
for(const a of rows)for(const b of rows)for(const p of [0,2]){
 const args=[...a,...b,p],expected=original(...args),old=scalar(...args),simd=lanes(...args);
 if(!same(expected,old)||!same(expected,simd))throw new Error(JSON.stringify({args:args.map(bits),expected:bits(expected),old:bits(old),simd:bits(simd)}));
 digest.update(args.map(bits).join('')+(Number.isNaN(expected)?'nan':bits(expected))+'\n');
 count++;if(Number.isNaN(expected))nans++;if(expected===0){zeros++;if(Object.is(expected,-0))negativeZeros++;}
}
const summary={scope:'Standalone overlap-only arithmetic parity; not game integration, browser compatibility or performance',node:process.version,sha256:createHash('sha256').update(bytes).digest('hex'),wasmBytes:bytes.length,rows:rows.length,cases:count,nans,zeros,negativeZeros,resultStreamSha256:digest.digest('hex'),allEqual:true};
writeFileSync(new URL('summary.json',import.meta.url),JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));

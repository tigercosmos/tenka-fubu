# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coast-surface-layout.spec.ts >> native display-only coastal surface >> waits for the mounted renderer after the strategy screen becomes visible
- Location: e2e/coast-surface-layout.spec.ts:102:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "pending"
Received: "rejected"
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e5]:
    - group [ref=e6]:
      - generic "戰略圖層 · 一般地圖" [ref=e7] [cursor=pointer]
  - banner [ref=e8]:
    - group "金錢、兵糧、兵力、威信" [ref=e9]:
      - generic [ref=e10]:
        - group "織田家" [ref=e11]
        - time [ref=e13]: 1561年3月1日
        - generic [ref=e14]:
          - generic [ref=e15]:
            - img [ref=e16]
            - generic [ref=e19]: 金錢
          - strong [ref=e22]: 3,000
        - generic [ref=e23]:
          - generic [ref=e24]:
            - img [ref=e25]
            - generic [ref=e27]: 兵糧
          - generic [ref=e28]:
            - strong [ref=e30]: 26,306
            - generic "兵糧可支撐6個月" [ref=e31]:
              - text: 兵糧可支撐
              - strong [ref=e32]: "6"
              - text: 個月
        - generic [ref=e33]:
          - generic [ref=e34]:
            - img [ref=e35]
            - generic [ref=e39]: 兵力
          - generic [ref=e41]:
            - strong [ref=e42]: 5,200
            - generic [ref=e43]: /3,000
        - generic [ref=e44]:
          - generic [ref=e45]:
            - img [ref=e46]
            - generic [ref=e48]: 威信
          - strong [ref=e51]: "300"
    - generic [ref=e52]:
      - generic [ref=e53]:
        - button "暫停" [pressed] [ref=e54] [cursor=pointer]:
          - img [ref=e55]
        - button "一倍速" [ref=e57] [cursor=pointer]:
          - img [ref=e58]
        - button "二倍速" [ref=e60] [cursor=pointer]:
          - img [ref=e61]
        - button "五倍速" [ref=e63] [cursor=pointer]:
          - img [ref=e64]
      - button "系統選單" [ref=e66] [cursor=pointer]:
        - img [ref=e67]
  - navigation "內政" [ref=e70]:
    - button "地圖一覽" [ref=e71] [cursor=pointer]:
      - img [ref=e72]
      - generic [ref=e75]:
        - generic [ref=e76]: 地圖
        - generic [ref=e77]: 一覽
    - button "織田家 （本城）" [ref=e78] [cursor=pointer]:
      - img [ref=e79]
      - generic "織田家" [ref=e84]: 織田
    - generic [ref=e86]: 軍政
    - button "軍事" [ref=e87] [cursor=pointer]:
      - img [ref=e88]
      - text: 軍事
    - button "內政" [ref=e90] [cursor=pointer]:
      - img [ref=e91]
      - text: 內政
    - button "武將" [ref=e93] [cursor=pointer]:
      - img [ref=e94]
      - text: 武將
    - generic [ref=e99]: 交涉
    - button "外交" [ref=e100] [cursor=pointer]:
      - img [ref=e101]
      - text: 外交
    - button "調略" [ref=e103] [cursor=pointer]:
      - img [ref=e104]
      - text: 調略
    - generic [ref=e108]: 國策
    - button "政策" [ref=e109] [cursor=pointer]:
      - img [ref=e110]
      - text: 政策
    - button "軍團" [ref=e112] [cursor=pointer]:
      - img [ref=e113]
      - text: 軍團
    - button "大命" [ref=e115] [cursor=pointer]:
      - img [ref=e116]
      - text: 大命
  - generic [ref=e119]:
    - generic [ref=e120]:
      - generic [ref=e121]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e122] [cursor=pointer]:
        - img [ref=e123]
    - generic [ref=e126]:
      - generic [ref=e128]:
        - img "兵力 800" [ref=e129]:
          - generic [ref=e130]: 兵力 800
        - img "兵糧 6,916" [ref=e133]:
          - generic [ref=e134]: 兵糧 6,916
        - img "耐久 1,000" [ref=e137]:
          - generic [ref=e138]: 耐久 1,000
        - img "士氣 80" [ref=e141]:
          - generic [ref=e142]: 士氣 80
      - generic [ref=e145]:
        - button "城面板" [ref=e146] [cursor=pointer]
        - button "出陣" [ref=e147] [cursor=pointer]
        - button "輸送" [ref=e148] [cursor=pointer]
  - img "全國小地圖" [ref=e149]
  - generic:
    - button "通報 1 則" [ref=e153] [cursor=pointer]:
      - img [ref=e154]
    - generic "通報 1 則" [ref=e156]:
      - alert [ref=e157]:
        - generic [ref=e158]:
          - img [ref=e160]
          - generic [ref=e162]:
            - strong [ref=e163]: 駿府城遭織田家包圍！
            - time [ref=e164]: 1561年3月1日
          - button "關閉通知" [ref=e166] [cursor=pointer]:
            - img [ref=e167]
    - button "報告中心" [ref=e169] [cursor=pointer]
```

# Test source

```ts
  36  |   polygons.some((polygon) => inside(point, points(polygon.points)));
  37  | function localTurns(polygons: Polygon[]) {
  38  |   const polygon = points(polygons.find((entry) => entry.id === 'honshu')!.points);
  39  |   return polygon.flatMap((p, index) => {
  40  |     if (Math.hypot(p.x - target.x, p.y - target.y) > 24) return [];
  41  |     const previous = polygon[(index + polygon.length - 1) % polygon.length]!,
  42  |       next = polygon[(index + 1) % polygon.length]!;
  43  |     const ax = p.x - previous.x,
  44  |       ay = p.y - previous.y,
  45  |       bx = next.x - p.x,
  46  |       by = next.y - p.y;
  47  |     if (Math.hypot(ax, ay) === 0 || Math.hypot(bx, by) === 0) return [];
  48  |     return [
  49  |       {
  50  |         point: p,
  51  |         degrees: (Math.abs(Math.atan2(ax * by - ay * bx, ax * bx + ay * by)) * 180) / Math.PI,
  52  |       },
  53  |     ];
  54  |   });
  55  | }
  56  | function distanceToEdges(p: Point, polygon: Point[]) {
  57  |   return Math.min(
  58  |     ...polygon.map((a, index) => {
  59  |       const b = polygon[(index + 1) % polygon.length]!,
  60  |         dx = b.x - a.x,
  61  |         dy = b.y - a.y;
  62  |       const t = Math.max(
  63  |         0,
  64  |         Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy || 1)),
  65  |       );
  66  |       return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
  67  |     }),
  68  |   );
  69  | }
  70  | async function idle(page: Page) {
  71  |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.waitMapIdle(3));
  72  | }
  73  | async function waitForMapReady(page: Page) {
  74  |   await idle(page);
  75  | }
  76  | async function observe(page: Page) {
  77  |   return page.evaluate(() => (window as DebugWindow).__tenka.debug.getMapDiagnostics()) as Promise<
  78  |     ReturnType<TenkaDebugApi['getMapDiagnostics']> & {
  79  |       coastRendering: { displayPolygons: Polygon[]; groundClipPolygons: Polygon[] };
  80  |     }
  81  |   >;
  82  | }
  83  | async function scale(page: Page, value: 1 | 1.5) {
  84  |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  85  |   await page.getByRole('button', { name: '設定', exact: true }).click();
  86  |   const dialog = page.getByRole('dialog'),
  87  |     slider = dialog.getByRole('slider', { name: '介面縮放', exact: true });
  88  |   await slider.press(value === 1.5 ? 'End' : 'Home');
  89  |   if (value === 1) for (let index = 0; index < 4; index++) await slider.press('ArrowRight');
  90  |   await expect(slider).toHaveValue(String(value));
  91  |   await dialog.getByRole('button', { name: '返回', exact: true }).click();
  92  |   await page.getByRole('button', { name: '回到遊戲', exact: true }).click();
  93  | }
  94  | 
  95  | test.describe('native display-only coastal surface', () => {
  96  |   test.use({
  97  |     viewport: { width: 1280, height: 720 },
  98  |     deviceScaleFactor: 1,
  99  |     contextOptions: { reducedMotion: 'reduce' },
  100 |   });
  101 | 
  102 |   test('waits for the mounted renderer after the strategy screen becomes visible', async ({
  103 |     page,
  104 |   }) => {
  105 |     await page.addInitScript(() => {
  106 |       const originalLoad = document.fonts.load.bind(document.fonts);
  107 |       let release!: () => void;
  108 |       const gate = new Promise<void>((resolve) => {
  109 |         release = resolve;
  110 |       });
  111 |       Object.defineProperty(window, '__releaseMapFontLoad', { value: release });
  112 |       document.fonts.load = (font, text) => gate.then(() => originalLoad(font, text));
  113 |     });
  114 |     await page.goto('/?debug=visual-map');
  115 |     await expect(page.getByTestId('screen-strategy')).toBeVisible();
  116 |     await page.evaluate(() => document.fonts.ready);
  117 |     const unmounted = await page.evaluate(async () => {
  118 |       try {
  119 |         await (window as DebugWindow).__tenka.debug.waitMapIdle(1);
  120 |         return false;
  121 |       } catch (error) {
  122 |         return (
  123 |           error instanceof Error && error.message.includes('__TENKA_DEBUG__: map renderer 尚未掛載')
  124 |         );
  125 |       }
  126 |     });
  127 |     expect(unmounted).toBe(true);
  128 |     const waiting = waitForMapReady(page);
  129 |     const beforeRelease = await Promise.race([
  130 |       waiting.then(
  131 |         () => 'resolved',
  132 |         () => 'rejected',
  133 |       ),
  134 |       page.waitForTimeout(200).then(() => 'pending'),
  135 |     ]);
> 136 |     expect(beforeRelease).toBe('pending');
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  137 |     await page.evaluate(() => {
  138 |       const release = (window as Window & { __releaseMapFontLoad?: () => void })
  139 |         .__releaseMapFontLoad;
  140 |       if (release === undefined) throw new Error('map font gate was not installed');
  141 |       release();
  142 |     });
  143 |     await waiting;
  144 |     await idle(page);
  145 |   });
  146 | 
  147 |   test('the named Ise inlet removes its abrupt turn while actual ground clipping, river anchors and gameplay stay aligned', async ({
  148 |     page,
  149 |   }, info) => {
  150 |     const pageErrors: string[] = [];
  151 |     page.on('pageerror', (error) => pageErrors.push(error.message));
  152 |     await page.goto('/?debug=visual-map');
  153 |     await expect(page.getByTestId('screen-strategy')).toBeVisible();
  154 |     await page.evaluate(() => document.fonts.ready);
  155 |     await waitForMapReady(page);
  156 |     await idle(page);
  157 |     const game = await page.evaluate(() => (window as DebugWindow).__tenka.debug.getState()),
  158 |       before = JSON.stringify(game),
  159 |       hashes = sourceHashes();
  160 |     const observations: Awaited<ReturnType<typeof observe>>[] = [];
  161 |     for (const value of [1, 1.5] as const) {
  162 |       await scale(page, value);
  163 |       for (const view of ['sunpu', 'ise-inlet']) {
  164 |         await page.evaluate(() =>
  165 |           (window as DebugWindow).__tenka.debug.setMapCameraPreset('close'),
  166 |         );
  167 |         if (view === 'ise-inlet') {
  168 |           const minimap = page.getByTestId('minimap-frame'),
  169 |             bounds = await minimap.boundingBox();
  170 |           expect(bounds).not.toBeNull();
  171 |           await minimap.click({
  172 |             position: { x: (2040 / 4096) * bounds!.width, y: (3000 / 4096) * bounds!.height },
  173 |           });
  174 |         }
  175 |         await idle(page);
  176 |         const current = await observe(page);
  177 |         observations.push(current);
  178 |         // Raw geometry and the same-view image precede improvement assertions.
  179 |         await info.attach(`coast-raw-${view}-${value}`, {
  180 |           body: JSON.stringify({
  181 |             current,
  182 |             canonicalTurns: localTurns(canonical.polygons),
  183 |             displayTurns: localTurns(current.coastRendering.displayPolygons),
  184 |           }),
  185 |           contentType: 'application/json',
  186 |         });
  187 |         await page.screenshot({ path: info.outputPath(`coast-${view}-${value}.png`) });
  188 |       }
  189 |     }
  190 |     expect(observations).toHaveLength(4);
  191 |     for (const current of observations) {
  192 |       const coast = current.coastRendering;
  193 |       const turns = localTurns(coast.displayPolygons);
  194 |       expect(turns.length).toBeGreaterThan(0);
  195 |       expect(
  196 |         Math.max(...turns.map((turn) => turn.degrees)),
  197 |         'actual emitted inlet curve has no abrupt local turn within24world of2055,2953',
  198 |       ).toBeLessThanOrEqual(30);
  199 |       expect(coast.groundClipPolygons).toEqual(coast.displayPolygons);
  200 |       expect(coast.displayPolygons).toEqual(observations[0]!.coastRendering.displayPolygons);
  201 |       const surface = coast.surface;
  202 |       expect(surface, 'actual national coastline admits its owned material').not.toBeNull();
  203 |       expect(surface!.ownedTextures).toBe(1);
  204 |       expect(surface!.ownedSources).toBe(1);
  205 |       expect(surface!.ownedGeometries).toBe(2);
  206 |       expect(surface!.atlasWidth).toBe(128);
  207 |       expect(surface!.atlasHeight).toBe(4);
  208 |       expect(surface!.rgbaBytes).toBe(2_048);
  209 |       expect(surface!.seaWidth).toBe(12);
  210 |       expect(surface!.landWidth).toBe(3);
  211 |       expect(surface!.inputVertices).toBe(
  212 |         coast.displayPolygons.reduce((sum, polygon) => sum + polygon.points.length / 2, 0),
  213 |       );
  214 |       expect(surface!.inputVertices).toBeLessThanOrEqual(4_096);
  215 |       expect(surface!.seaVertices).toBeGreaterThan(0);
  216 |       expect(surface!.landVertices).toBeGreaterThan(0);
  217 |       expect(surface!.seaIndices).toBeGreaterThan(0);
  218 |       expect(surface!.landIndices).toBeGreaterThan(0);
  219 |       // Two Float32 XY/UV attributes plus Uint32 triangle indices, measured
  220 |       // buffers rather than browser heap or an imported allocation helper.
  221 |       expect(surface!.geometryBytes).toBe(
  222 |         (surface!.seaVertices + surface!.landVertices) * 16 +
  223 |           (surface!.seaIndices + surface!.landIndices) * 4,
  224 |       );
  225 |       expect(surface!.geometryBytes).toBeLessThanOrEqual(1_212_416);
  226 |       expect(surface).toEqual(observations[0]!.coastRendering.surface);
  227 |       expect(current.resources.ownedCoastTextures).toBe(surface!.ownedTextures);
  228 |       expect(current.resources.ownedCoastSources).toBe(surface!.ownedSources);
  229 |       expect(current.resources.ownedCoastGeometries).toBe(surface!.ownedGeometries);
  230 |       expect(current.resources.coastRgbaBytes).toBe(surface!.rgbaBytes);
  231 |       expect(current.resources.coastGeometryBytes).toBe(surface!.geometryBytes);
  232 |     }
  233 |     const display = observations[0]!.coastRendering.displayPolygons;
  234 |     const rawHonshu = points(canonical.polygons.find((entry) => entry.id === 'honshu')!.points),
  235 |       displayHonshu = points(display.find((entry) => entry.id === 'honshu')!.points);
  236 |     for (const [a, b] of [
```
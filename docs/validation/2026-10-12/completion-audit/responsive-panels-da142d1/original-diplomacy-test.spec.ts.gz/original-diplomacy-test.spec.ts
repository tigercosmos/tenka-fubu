import { writeFile } from 'node:fs/promises';
import type { Locator, Page } from '@playwright/test';
import { test, expect } from './fixtures';

const VIEWPORT = { width: 1280, height: 720 };
const ENDPOINTS = [0.8, 1, 1.5] as const;

async function boot(page: Page, scale: number) {
  await page.setViewportSize(VIEWPORT);
  await page.goto('/?debug=1&seed=42');
  await page.getByTestId('title-settings').click();
  const settings = page.getByRole('dialog');
  const slider = settings.getByRole('slider', { name: '介面縮放', exact: true });
  await slider.press('Home');
  for (let index = 0; index < Math.round((scale - 0.8) / 0.05); index++)
    await slider.press('ArrowRight');
  await expect(slider).toHaveValue(String(scale));
  await settings.getByRole('button', { name: '返回', exact: true }).click();
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('newgame-start').click();
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await page.getByTestId('speed-pause').click();
  await page.keyboard.press('F3');
  await expect(page.getByTestId('diplomacy-panel')).toBeVisible();
}

async function targetGeometry(target: Locator, label: string) {
  await target.scrollIntoViewIfNeeded();
  await expect(target).toBeVisible();
  const actual = await target.evaluate((element) => {
    const rect = element.getBoundingClientRect();
    const clip = { left: 0, top: 0, right: innerWidth, bottom: innerHeight };
    let ancestor = element.parentElement;
    while (ancestor !== null) {
      const style = getComputedStyle(ancestor);
      if (/auto|scroll|hidden|clip/.test(`${style.overflowX} ${style.overflowY}`)) {
        const bounds = ancestor.getBoundingClientRect();
        clip.left = Math.max(clip.left, bounds.left);
        clip.top = Math.max(clip.top, bounds.top);
        clip.right = Math.min(clip.right, bounds.right);
        clip.bottom = Math.min(clip.bottom, bounds.bottom);
      }
      ancestor = ancestor.parentElement;
    }
    return {
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      clip,
      visibleWidth: Math.max(0, Math.min(rect.right, clip.right) - Math.max(rect.left, clip.left)),
      visibleHeight: Math.max(0, Math.min(rect.bottom, clip.bottom) - Math.max(rect.top, clip.top)),
    };
  });
  expect(actual.visibleWidth, `${label}: reachable width`).toBeGreaterThanOrEqual(32);
  expect(actual.visibleHeight, `${label}: reachable height`).toBeGreaterThanOrEqual(32);
  expect(actual.rect.width, `${label}: physical width`).toBeGreaterThanOrEqual(32);
  expect(actual.rect.height, `${label}: physical height`).toBeGreaterThanOrEqual(32);
  return { label, ...actual };
}

async function textBounds(target: Locator, label: string) {
  await target.scrollIntoViewIfNeeded();
  const actual = await target.evaluate((element) => {
    const host = element.getBoundingClientRect();
    const text = [...element.childNodes].filter((node) => node.nodeType === Node.TEXT_NODE);
    const rects = text.flatMap((node) => {
      const range = document.createRange();
      range.selectNodeContents(node);
      return [...range.getClientRects()].map((rect) => ({ left: rect.left, right: rect.right }));
    });
    return { host: { left: host.left, right: host.right }, rects };
  });
  expect(actual.rects.length, `${label}: measured visible text`).toBeGreaterThan(0);
  for (const rect of actual.rects) {
    expect(rect.left, `${label}: text left`).toBeGreaterThanOrEqual(actual.host.left - 1);
    expect(rect.right, `${label}: text right`).toBeLessThanOrEqual(actual.host.right + 1);
  }
  return { label, ...actual };
}

for (const scale of ENDPOINTS) {
  test(`diplomacy tabs and actions remain reachable at 1280×720 uiScale ${scale}`, async ({
    page,
  }, info) => {
    await boot(page, scale);
    const panel = page.getByTestId('diplomacy-panel');
    const close = panel.getByRole('button', { name: '外交', exact: true });
    const active = panel.getByRole('tab', { name: '勢力', exact: true });
    const entryFocus: string[] = [];
    let keyboardEntered = await active.evaluate((node) => document.activeElement === node);
    for (let index = 0; index < 60 && !keyboardEntered; index++) {
      await page.keyboard.press('Tab');
      entryFocus.push(
        await page.evaluate(() => {
          const node = document.activeElement;
          return `${node?.tagName ?? 'none'}:${node?.getAttribute('aria-label') ?? ''}:${node?.textContent?.trim().slice(0, 40) ?? ''}`;
        }),
      );
      keyboardEntered = await active.evaluate((node) => document.activeElement === node);
    }
    await writeFile(
      info.outputPath(`diplomacy-entry-focus-${scale}.json`),
      JSON.stringify(entryFocus),
    );
    expect(keyboardEntered, 'F3 keyboard path reaches diplomacy tabs').toBe(true);
    const geometry: unknown[] = [await targetGeometry(close, 'panel close')];
    const text: unknown[] = [];
    const initial = page.getByRole('tabpanel');
    await expect(panel.getByRole('tab', { name: '勢力', exact: true })).toHaveAttribute(
      'aria-selected',
      'true',
    );
    const roster = initial.locator('button[aria-pressed]');
    expect(await roster.count()).toBeGreaterThan(1);
    geometry.push(await targetGeometry(roster.first(), 'first clan'));
    geometry.push(await targetGeometry(roster.last(), 'last clan'));
    await roster.last().click();
    await expect(roster.last()).toHaveAttribute('aria-pressed', 'true');
    const against = initial.getByRole('combobox', { name: '援軍對抗勢力', exact: true });
    geometry.push(await targetGeometry(against, 'reinforce target'));
    await against.selectOption({ index: 1 });
    for (const name of [
      '締結同盟',
      '締結婚姻同盟',
      '停戰交涉',
      '要求對方稱臣',
      '向對方稱臣',
      '請求援軍',
    ]) {
      const action = initial.getByRole('button', { name, exact: true });
      geometry.push(await targetGeometry(action, name));
      if (await action.isDisabled())
        expect(
          (await action.getAttribute('title'))?.length,
          `${name}: disabled reason`,
        ).toBeGreaterThan(0);
    }
    await page.screenshot({ path: info.outputPath(`diplomacy-勢力-${scale}.png`) });
    await active.focus();
    for (const [name, command] of [
      ['朝廷', '請求下一階官位'],
      ['幕府', '請求下一階役職'],
    ] as const) {
      await page.keyboard.press('ArrowRight');
      const tab = panel.getByRole('tab', { name, exact: true });
      await expect(tab).toHaveAttribute('aria-selected', 'true');
      geometry.push(await targetGeometry(tab, `${name} tab`));
      const pane = panel.getByRole('tabpanel');
      const heading = pane.getByRole('heading', { name, exact: true });
      text.push(await textBounds(heading, `${name} heading`));
      const action = pane.getByRole('button', { name: command, exact: true });
      geometry.push(await targetGeometry(action, command));
      if (await action.isDisabled())
        expect(
          (await action.getAttribute('title'))?.length,
          `${command}: disabled reason`,
        ).toBeGreaterThan(0);
      const finalCell = pane.locator('table tbody tr').last().locator('td').last();
      text.push(await textBounds(finalCell, `${name} final effect`));
      await page.screenshot({ path: info.outputPath(`diplomacy-${name}-${scale}.png`) });
    }
    const metrics = await page.evaluate(() => {
      const canvas = document.querySelector('canvas');
      const gl = canvas?.getContext('webgl2') ?? canvas?.getContext('webgl');
      const ext = gl?.getExtension('WEBGL_debug_renderer_info');
      return {
        viewport: [innerWidth, innerHeight],
        documentWidth: document.documentElement.scrollWidth,
        documentHeight: document.documentElement.scrollHeight,
        glVendor: ext && gl ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : null,
        glRenderer: ext && gl ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : null,
      };
    });
    expect(metrics.documentWidth, 'no page-level horizontal overflow').toBeLessThanOrEqual(1281);
    await close.scrollIntoViewIfNeeded();
    await close.click();
    await expect(panel).toHaveCount(0);
    const raw = JSON.stringify({ scale, geometry, text, metrics });
    await writeFile(info.outputPath(`diplomacy-endpoint-${scale}.json`), raw);
    await info.attach(`diplomacy-endpoint-${scale}`, {
      body: raw,
      contentType: 'application/json',
    });
  });
}

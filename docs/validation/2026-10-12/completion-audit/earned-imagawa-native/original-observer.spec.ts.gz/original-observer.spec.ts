import assert from 'node:assert/strict';
import { it } from 'vitest';
import { writeFile } from 'node:fs/promises';
import { loadS1560Scenario,loadS1560EventCatalog } from '../../src/data/scenarios/s1560';
import { buildGameStateFromScenario } from '../../src/core/state/builder';
import { validateState } from '../../src/core/state/invariants';
import { validateCommand } from '../../src/core/commands/validate';
import { stateHash } from '../../src/core/state/serialize';
import { getPlotSuccessRate } from '../../src/core/systems/plots';
import { loadScenarioEventEngine } from '../../src/app/events/scenarioEventEngine';
import { dispatchCommand, initializeBridgeSession,runOneDay,exportCommandLog,resetBridgeForTests } from '../../src/app/bridge';
import { setGame,store,resetGameStoreForTests } from '../../src/app/store';
import { uiStore } from '../../src/ui/hooks/uiStore';

it('ordinary Imagawa rumor and poach diagnostic',async()=>{
 const seed=Number(process.env.IMAGAWA_SEED??42);resetBridgeForTests();resetGameStoreForTests(null);uiStore.getState().actions.reset();
 const actor='clan.miyoshi',enemy='clan.imagawa';
 const game=buildGameStateFromScenario(await loadS1560Scenario(),{appVersion:'0.0.0',seed,playerClanId:actor as any,difficulty:'normal',startDay:0});
 const engine=await loadScenarioEventEngine('s1560');const catalog=loadS1560EventCatalog();setGame(game);initializeBridgeSession(game,[],{eventEngine:engine});store.getState().actions.setScreen('main');
 const initial=structuredClone(game),submitted:any[]=[],events:any[]=[],days:any[]=[],months:any[]=[];
 const pairs=[['off.matsunaga-hisahide','off.miura-masatoshi'],['off.miyoshi-nagayoshi','off.ichinomiya-muneyoshi'],['off.shinohara-nagafusa','off.yui-masanobu']];
 const output=`/tmp/tenka-imagawa-natural-${seed}.json`;
 function submit(command:any){assert.equal(validateCommand(game,command,undefined,{eventEngine:engine}).ok,true);const h=stateHash(game);assert.equal(dispatchCommand(command).ok,true);assert.equal(stateHash(game),h);submitted.push({day:game.time.day,command:structuredClone(command),targetLoyalty:command.targetOfficerId?game.officers[command.targetOfficerId].loyalty:null,successRate:command.type==='startPlot'?getPlotSuccessRate(game,command):null});}
 async function persist(error?:string){await writeFile(output,JSON.stringify({seed,initial,state:game,submitted,events,days,months,log:exportCommandLog(),error}));}
 try{
 for(let tick=0;tick<449;tick++){
  const id=game.events.pendingChoiceEventId;if(id!==null){const a=catalog.find(e=>e.id===id)!;const c=a.choices.map((_,choiceIndex)=>({type:'resolveEventChoice',clanId:actor,eventId:id,choiceIndex})).find(c=>validateCommand(game,c as any,undefined,{eventEngine:engine}).ok);assert.ok(c);submit(c);}
  for(const p of game.diplomacy.pendingProposals.filter(p=>p.toClanId===actor))submit({type:'respondPact',clanId:actor,proposalId:p.id,accept:false});
  for(const p of Object.values(game.proposals).filter(p=>p.clanId===actor&&p.status==='pending'))submit({type:'resolveProposal',clanId:actor,proposalId:p.id,accept:false});
  for(const [executor,targetId]of pairs){const target=game.officers[targetId];if(target.clanId!==enemy||target.status!=='serving')continue;
   if(game.diplomacy.plots.some(p=>p.officerId===executor))continue;
   const command={type:'startPlot',clanId:actor,executorId:executor,targetClanId:enemy,targetOfficerId:targetId,targetCastleId:null,kind:target.loyalty<30?'poach':'rumor',investGold:target.loyalty<30?1000:0};
   if(validateCommand(game,command as any).ok)submit(command);
  }
  const emitted=runOneDay();events.push(structuredClone(emitted));days.push({day:game.time.day,hash:stateHash(game),rng:structuredClone(game.rng)});
  assert.equal(game.time.day,tick+1);assert.deepEqual(validateState(game),[]);assert.equal(store.getState().session.fatalError,null);assert.deepEqual(emitted.filter(e=>e.type==='command.rejected'),[]);
  if(game.time.day%30===0){months.push(structuredClone(game));console.log(JSON.stringify({day:game.time.day,targets:pairs.map(([_,id])=>({id,clan:game.officers[id].clanId,status:game.officers[id].status,loyalty:game.officers[id].loyalty})),plots:game.diplomacy.plots.filter(p=>p.ownerClanId===actor),result:emitted.filter(e=>e.type.startsWith('plot.')||e.type==='officer.recruited')}));await persist();}
  if(events.flat().some(e=>e.type==='officer.recruited'&&e.source==='poach'&&pairs.some(([_,id])=>id===e.officerId))){await persist();return;}
 }
 await persist();assert.fail('No natural Imagawa poach succeeded before unresolved day450 boundary');
 }catch(e){await persist(String(e));throw e;}
},120000);

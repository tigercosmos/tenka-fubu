import growth,collections,json
h=growth.a;b=growth.b
parent={0:None};q=collections.deque([0]);edge={}
while q:
 i=q.popleft()
 for typ,name,target in h.edges(i):
  if typ=='weak' or target in parent:continue
  parent[target]=i;edge[target]=(typ,name);q.append(target)
def path(i):
 out=[]
 while i in parent and parent[i] is not None:
  p=parent[i];t,n=edge[i];out.append(dict(fromId=h.value(p,'id'),fromName=h.name(p),edgeType=t,edgeName=n,toId=h.value(i,'id'),toName=h.name(i)));i=p
 return list(reversed(out)) if i==0 else None
families={}
for name in ['i','st','Object','Array','PerformanceLongAnimationFrameTiming','PerformanceScriptTiming']:
 groups=collections.defaultdict(list)
 for i in range(len(h.starts)):
  if h.name(i)!=name or h.value(i,'id') in b.ids:continue
  props=[(t,n,h.name(j)) for t,n,j in h.edges(i) if t in ['property','internal']]
  k=tuple(props) if name not in ['Object','Array'] else tuple(n for t,n,j in props)
  groups[k].append(i)
 rows=[]
 for k,indices in sorted(groups.items(),key=lambda x:len(x[1]),reverse=True)[:12]:
  i=indices[0];rows.append(dict(count=len(indices),id=h.value(i,'id'),selfSize=h.value(i,'self_size'),properties=k,rootPath=path(i)))
 families[name]=rows
(growth.root/'object-roots.json').write_text(json.dumps(dict(scope='after-only node IDs grouped by shape; shortest strong paths, NOT retained sizes or allocation sites',families=families),indent=2)+'\n')
for name,rows in families.items():
 print(name)
 for r in rows[:4]:print(r['count'],r['properties'],[(p['fromName'],p['edgeName']) for p in (r['rootPath'] or [])])

import gzip,json,pathlib,sys,collections
root=pathlib.Path(__file__).parent
sys.path.insert(0,str(root));import growth
out=[]
for label,h in [('before',growth.b),('after',growth.a)]:
 properties={}
 for i in range(len(h.starts)):
  if h.typ(i)=='object':properties[i]={name:target for typ,name,target in h.edges(i) if typ=='property'}
 managers={i:p for i,p in properties.items() if all(k in p for k in ['items','_renderer','_onUnload','name'])}
 callbacks=[]
 for i,p in properties.items():
  manager=p.get('context')
  if manager not in managers or 'fn' not in p or h.name(p['fn'])!='remove':continue
  m=managers[manager];callbacks.append(dict(listenerId=h.value(i,'id'),managerId=h.value(manager,'id'),managerName=h.name(m['name']),rendererTargetName=h.name(m['_renderer']),onUnloadTargetName=h.name(m['_onUnload'])))
 counts=collections.Counter((r['managerName'],r['rendererTargetName']) for r in callbacks)
 out.append(dict(snapshot=label,scope='property-shape GCManagedHash managers and EventEmitter remove/context callbacks; null renderer target directly recorded, not retained bytes',managers=len(managers),callbacks=len(callbacks),groups=[dict(name=n,renderer=r,count=c) for (n,r),c in counts.most_common()],rows=callbacks))
(root/'managed-listener-counts.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k!='rows'} for r in out],indent=2))

import json,pathlib,collections
root=pathlib.Path(__file__).parent
class Heap:
 def __init__(self,label):
  s=json.loads((root/(label+'.heapsnapshot')).read_text());self.s=s;m=s['snapshot']['meta'];self.nf=m['node_fields'];self.ef=m['edge_fields'];self.nw=len(self.nf);self.ew=len(self.ef);self.nt=m['node_types'][self.nf.index('type')];self.et=m['edge_types'][self.ef.index('type')];self.ns=s['nodes'];self.es=s['edges'];self.starts=[];cursor=0
  for n in range(0,len(self.ns),self.nw):self.starts.append(cursor);cursor+=self.ns[n+self.nf.index('edge_count')]*self.ew
  assert cursor==len(self.es)
  self.ids={self.value(i,'id'):i for i in range(len(self.starts))}
 def value(self,i,f):return self.ns[i*self.nw+self.nf.index(f)]
 def name(self,i):return self.s['strings'][self.value(i,'name')]
 def typ(self,i):return self.nt[self.value(i,'type')]
 def edges(self,i):
  for e in range(self.starts[i],self.starts[i]+self.value(i,'edge_count')*self.ew,self.ew):
   t=self.et[self.es[e+self.ef.index('type')]];v=self.es[e+self.ef.index('name_or_index')];yield t,str(v) if t in ['hidden','element'] else self.s['strings'][v],self.es[e+self.ef.index('to_node')]//self.nw
 def groups(self):
  d=collections.defaultdict(lambda:[0,0])
  for i in range(len(self.starts)):
   k=(self.typ(i),self.name(i));d[k][0]+=1;d[k][1]+=self.value(i,'self_size')
  return d
b=Heap('before');a=Heap('after');bg=b.groups();ag=a.groups();rows=[]
for typ,name in bg.keys()|ag.keys():
 bc,bs=bg[(typ,name)];ac,asz=ag[(typ,name)];rows.append(dict(type=typ,name=name,beforeCount=bc,afterCount=ac,countDelta=ac-bc,beforeSelfSize=bs,afterSelfSize=asz,selfSizeDelta=asz-bs))
rows.sort(key=lambda r:r['selfSizeDelta'],reverse=True)
bytype=collections.defaultdict(lambda:dict(beforeCount=0,afterCount=0,beforeSelfSize=0,afterSelfSize=0))
for r in rows:
 for k in ['beforeCount','afterCount','beforeSelfSize','afterSelfSize']:bytype[r['type']][k]+=r[k]
for r in bytype.values():r['countDelta']=r['afterCount']-r['beforeCount'];r['selfSizeDelta']=r['afterSelfSize']-r['beforeSelfSize']
# Closure code ownership is a bounded direct edge comparison, not retained size or allocation attribution.
changes=[]
for ident,ai in a.ids.items():
 bi=b.ids.get(ident)
 if bi is None or a.typ(ai)!='closure':continue
 def code(h,i):
  cs=[n for t,k,n in h.edges(i) if t=='internal' and k=='code']
  if len(cs)!=1:return None
  c=cs[0];ins=[n for t,k,n in h.edges(c) if h.name(n)=='system / InstructionStream']
  return dict(codeId=h.value(c,'id'),instructions=[dict(id=h.value(n,'id'),bytes=h.value(n,'self_size')) for n in ins])
 bc=code(b,bi);ac=code(a,ai)
 if bc and ac and bc!=ac:changes.append(dict(closureId=ident,name=a.name(ai),before=bc,after=ac))
result=dict(scope='same-run chronological post-GC snapshots; self-size and direct stable closure/code edge comparison, NOT retained size, allocation age, optimization tier, or leak verdict',beforeNodes=len(b.starts),afterNodes=len(a.starts),beforeSelfSize=sum(r['beforeSelfSize'] for r in rows),afterSelfSize=sum(r['afterSelfSize'] for r in rows),byType=bytype,deltas=rows,stableClosureCodeChanges=changes)
(root/'growth.json').write_text(json.dumps(result,indent=2)+'\n')
r=json.loads((root/'retainers.json').read_text());print(json.dumps(dict(beforeCounts=r['before']['counts'],afterCounts=r['after']['counts'],beforeCaches=r['before']['cacheCandidates'],afterCaches=r['after']['cacheCandidates'],candidates=r['candidates'],byType=bytype,topDeltas=rows[:18],stableClosureCodeChanges=len(changes)),indent=2))

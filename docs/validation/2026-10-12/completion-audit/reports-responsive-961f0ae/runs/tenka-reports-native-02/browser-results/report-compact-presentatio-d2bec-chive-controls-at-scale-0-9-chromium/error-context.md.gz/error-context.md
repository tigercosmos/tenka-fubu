# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: report-compact-presentation.spec.ts >> compact native reports preserve readable content and archive controls at scale 0.9
- Location: e2e/report-compact-presentation.spec.ts:6:3

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 56
Received:    57.65625
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [active] [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from './fixtures';
  2   | 
  3   | const SCALES = Array.from({ length: 15 }, (_, index) => Number((0.8 + index * 0.05).toFixed(2)));
  4   | 
  5   | for (const scale of SCALES) {
  6   |   test(`compact native reports preserve readable content and archive controls at scale ${scale}`, async ({
  7   |     page,
  8   |   }, info) => {
  9   |     await page.setViewportSize({ width: 1280, height: 720 });
  10  |     await page.emulateMedia({ reducedMotion: 'reduce' });
  11  |     await page.goto('/?debug=visual-map');
  12  |     await expect(page.getByTestId('screen-strategy')).toBeVisible();
  13  |     await page.getByRole('button', { name: '系統選單', exact: true }).click();
  14  |     await page.getByRole('button', { name: '設定', exact: true }).click();
  15  |     const dialog = page.getByRole('dialog');
  16  |     const slider = dialog.getByRole('slider', { name: '介面縮放', exact: true });
  17  |     await slider.press('Home');
  18  |     for (let index = 0; index < Math.round((scale - 0.8) / 0.05); index++)
  19  |       await slider.press('ArrowRight');
  20  |     await expect(slider).toHaveValue(String(scale));
  21  |     await dialog.getByRole('button', { name: '返回', exact: true }).click();
  22  |     await page.getByRole('button', { name: '回到遊戲', exact: true }).click();
  23  |     await page.evaluate(() => document.fonts.ready);
  24  |     await page.evaluate(() => window.__tenka.debug.waitMapIdle(3));
  25  |     const before = await page.evaluate(() => ({
  26  |       core: JSON.stringify(window.__tenka.debug.getState()),
  27  |       commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
  28  |     }));
  29  |     const list = page.getByTestId('report-toast-list');
  30  |     await expect(list).toBeVisible();
  31  |     const titles = await list.locator('strong').allTextContents();
  32  |     expect(titles.length).toBeGreaterThan(0);
  33  |     const seals = list.locator('[data-category]');
  34  |     expect(
  35  |       await page.evaluate(() => window.__tenka.debug.getState().reports.map((r) => r.event.type)),
  36  |     ).toContain('siege.started');
  37  |     await expect(seals).toHaveCount(titles.length);
  38  |     for (const seal of await seals.all()) {
  39  |       await expect(seal).toHaveAttribute('data-category', 'military');
  40  |       await expect(seal).toHaveAttribute('aria-hidden', 'true');
  41  |       await expect(seal.locator('svg path')).toHaveAttribute(
  42  |         'd',
  43  |         'M5 19l10-10m-7 6l-3 3 1 1 3-3M14 4l6-1-1 6-3 3-5-5z',
  44  |       );
  45  |     }
  46  |     const observations = await list.evaluate((root) => {
  47  |       const rem = parseFloat(getComputedStyle(document.documentElement).fontSize);
  48  |       return {
  49  |         rem,
  50  |         cards: [...root.children].map((node) => {
  51  |           const card = node as HTMLElement;
  52  |           const box = card.getBoundingClientRect();
  53  |           const texts = [...card.querySelectorAll<HTMLElement>('strong, p, time')].map((text) => {
  54  |             const range = document.createRange();
  55  |             range.selectNodeContents(text);
  56  |             return {
  57  |               text: text.textContent,
  58  |               font: parseFloat(getComputedStyle(text).fontSize),
  59  |               rects: [...range.getClientRects()].map((rect) => ({
  60  |                 width: rect.width,
  61  |                 height: rect.height,
  62  |                 contained:
  63  |                   rect.left >= box.left &&
  64  |                   rect.right <= box.right &&
  65  |                   rect.top >= box.top &&
  66  |                   rect.bottom <= box.bottom,
  67  |               })),
  68  |             };
  69  |           });
  70  |           return {
  71  |             height: box.height,
  72  |             bodyless: card.querySelector('p') === null,
  73  |             width: box.width,
  74  |             overflow: card.scrollWidth > card.clientWidth,
  75  |             texts,
  76  |             close: [...card.querySelectorAll('button')].map((button) => {
  77  |               const rect = button.getBoundingClientRect();
  78  |               return { width: rect.width, height: rect.height };
  79  |             }),
  80  |           };
  81  |         }),
  82  |       };
  83  |     });
  84  |     await info.attach('native-report-density', {
  85  |       body: JSON.stringify({ scale, titles, observations }),
  86  |       contentType: 'application/json',
  87  |     });
  88  |     expect(observations.cards.some((card) => card.bodyless)).toBe(true);
  89  |     for (const card of observations.cards) {
  90  |       if (card.bodyless)
> 91  |         expect(card.height).toBeLessThanOrEqual(Math.max(56, observations.rem * 3.5));
      |                             ^ Error: expect(received).toBeLessThanOrEqual(expected)
  92  |       expect(card.overflow).toBe(false);
  93  |       for (const text of card.texts) {
  94  |         expect(text.font).toBeGreaterThanOrEqual(12);
  95  |         expect(text.rects.length).toBeGreaterThan(0);
  96  |         for (const rect of text.rects) {
  97  |           expect(rect.width).toBeGreaterThan(0);
  98  |           expect(rect.height).toBeGreaterThan(0);
  99  |           expect(rect.contained, text.text ?? '').toBe(true);
  100 |         }
  101 |       }
  102 |       for (const close of card.close) {
  103 |         expect(close.width).toBeGreaterThanOrEqual(32);
  104 |         expect(close.height).toBeGreaterThanOrEqual(32);
  105 |       }
  106 |     }
  107 |     await page.screenshot({ path: info.outputPath(`compact-reports-${scale}.png`) });
  108 |     const archive = page.getByTestId('reports-open');
  109 |     await archive.focus();
  110 |     await page.keyboard.press('Enter');
  111 |     await expect(list).toBeHidden();
  112 |     await expect(page.getByTestId('reports-panel')).toBeVisible();
  113 |     await page.keyboard.press('Escape');
  114 |     await expect(list).toBeVisible();
  115 |     expect(await list.locator('strong').allTextContents()).toEqual(titles);
  116 |     await archive.focus();
  117 |     await page.keyboard.press('Enter');
  118 |     const panel = page.getByTestId('reports-panel');
  119 |     const rows = panel.locator('li');
  120 |     const count = await rows.count();
  121 |     expect(count).toBeGreaterThan(0);
  122 |     const measurements = [];
  123 |     for (const control of await panel.locator('button, input, select').all()) {
  124 |       await control.scrollIntoViewIfNeeded();
  125 |       const observed = await control.evaluate((node) => {
  126 |         const box = node.getBoundingClientRect();
  127 |         const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
  128 |         return {
  129 |           name: node.getAttribute('aria-label') ?? node.textContent,
  130 |           tag: node.tagName,
  131 |           width: box.width,
  132 |           height: box.height,
  133 |           left: box.left,
  134 |           right: box.right,
  135 |           top: box.top,
  136 |           bottom: box.bottom,
  137 |           hit: hit === node || node.contains(hit),
  138 |         };
  139 |       });
  140 |       measurements.push(observed);
  141 |     }
  142 |     await info.attach('report-center-controls', {
  143 |       body: JSON.stringify({ scale, measurements }),
  144 |       contentType: 'application/json',
  145 |     });
  146 |     for (const observed of measurements) {
  147 |       expect(observed.width, observed.name ?? '').toBeGreaterThanOrEqual(32);
  148 |       expect(observed.height, observed.name ?? '').toBeGreaterThanOrEqual(32);
  149 |       expect(observed.left).toBeGreaterThanOrEqual(0);
  150 |       expect(observed.right).toBeLessThanOrEqual(1280);
  151 |       expect(observed.top).toBeGreaterThanOrEqual(0);
  152 |       expect(observed.bottom).toBeLessThanOrEqual(720);
  153 |       expect(observed.hit, observed.name ?? '').toBe(true);
  154 |     }
  155 |     const military = panel.getByRole('checkbox', { name: '軍事', exact: true });
  156 |     await military.focus();
  157 |     await page.keyboard.press('Space');
  158 |     await expect(rows).toHaveCount(0);
  159 |     await page.keyboard.press('Space');
  160 |     await expect(rows).toHaveCount(count);
  161 |     for (const label of ['開始年月', '結束年月']) {
  162 |       const select = panel.getByLabel(label, { exact: true });
  163 |       await select.selectOption({ index: 1 });
  164 |       await expect(rows).toHaveCount(count);
  165 |     }
  166 |     const textMeasurements = [];
  167 |     for (const row of await rows.all()) {
  168 |       await row.scrollIntoViewIfNeeded();
  169 |       const observed = await row.locator('p').evaluate((node) => {
  170 |         const box = node.getBoundingClientRect();
  171 |         const range = document.createRange();
  172 |         range.selectNodeContents(node);
  173 |         return {
  174 |           text: node.textContent,
  175 |           font: parseFloat(getComputedStyle(node).fontSize),
  176 |           overflow: node.scrollWidth > node.clientWidth,
  177 |           contained: [...range.getClientRects()].every(
  178 |             (rect) => rect.left >= box.left - 1 && rect.right <= box.right + 1,
  179 |           ),
  180 |         };
  181 |       });
  182 |       textMeasurements.push(observed);
  183 |     }
  184 |     await info.attach('report-center-text', {
  185 |       body: JSON.stringify({ scale, textMeasurements }),
  186 |       contentType: 'application/json',
  187 |     });
  188 |     for (const observed of textMeasurements) {
  189 |       expect(observed.font).toBeGreaterThanOrEqual(12);
  190 |       expect(observed.overflow).toBe(false);
  191 |       expect(observed.contained, observed.text ?? '').toBe(true);
```
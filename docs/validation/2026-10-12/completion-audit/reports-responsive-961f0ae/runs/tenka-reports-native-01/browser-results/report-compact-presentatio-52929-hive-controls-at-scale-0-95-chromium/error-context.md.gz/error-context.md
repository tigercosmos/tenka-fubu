# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: report-compact-presentation.spec.ts >> compact native reports preserve readable content and archive controls at scale 0.95
- Location: e2e/report-compact-presentation.spec.ts:6:3

# Error details

```
Error: expect(received).not.toEqual(expected) // deep equality

Expected: not undefined


Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  105 |       }
  106 |     }
  107 |     await page.screenshot({ path: info.outputPath(`compact-reports-${scale}.png`) });
  108 |     const archive = page.getByTestId('reports-open');
  109 |     await archive.focus();
  110 |     await page.keyboard.press('Enter');
  111 |     await expect(list).toBeHidden();
  112 |     await expect(page.getByTestId('reports-panel')).toBeVisible();
  113 |     await page.keyboard.press('Escape');
  114 |     await expect(list).toBeVisible();
  115 |     expect(await list.locator('strong').allTextContents()).toEqual(titles);
  116 |     await archive.focus();
  117 |     await page.keyboard.press('Enter');
  118 |     const panel = page.getByTestId('reports-panel');
  119 |     const rows = panel.locator('li');
  120 |     const count = await rows.count();
  121 |     expect(count).toBeGreaterThan(0);
  122 |     const measurements = [];
  123 |     for (const control of await panel.locator('button, input, select').all()) {
  124 |       await control.scrollIntoViewIfNeeded();
  125 |       const observed = await control.evaluate((node) => {
  126 |         const box = node.getBoundingClientRect();
  127 |         const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
  128 |         return {
  129 |           name: node.getAttribute('aria-label') ?? node.textContent,
  130 |           tag: node.tagName,
  131 |           width: box.width,
  132 |           height: box.height,
  133 |           left: box.left,
  134 |           right: box.right,
  135 |           top: box.top,
  136 |           bottom: box.bottom,
  137 |           hit: hit === node || node.contains(hit),
  138 |         };
  139 |       });
  140 |       measurements.push(observed);
  141 |     }
  142 |     await info.attach('report-center-controls', {
  143 |       body: JSON.stringify({ scale, measurements }),
  144 |       contentType: 'application/json',
  145 |     });
  146 |     for (const observed of measurements) {
  147 |       expect(observed.width, observed.name ?? '').toBeGreaterThanOrEqual(32);
  148 |       expect(observed.height, observed.name ?? '').toBeGreaterThanOrEqual(32);
  149 |       expect(observed.left).toBeGreaterThanOrEqual(0);
  150 |       expect(observed.right).toBeLessThanOrEqual(1280);
  151 |       expect(observed.top).toBeGreaterThanOrEqual(0);
  152 |       expect(observed.bottom).toBeLessThanOrEqual(720);
  153 |       expect(observed.hit, observed.name ?? '').toBe(true);
  154 |     }
  155 |     const military = panel.getByRole('checkbox', { name: '軍事', exact: true });
  156 |     await military.focus();
  157 |     await page.keyboard.press('Space');
  158 |     await expect(rows).toHaveCount(0);
  159 |     await page.keyboard.press('Space');
  160 |     await expect(rows).toHaveCount(count);
  161 |     for (const label of ['開始年月', '結束年月']) {
  162 |       const select = panel.getByLabel(label, { exact: true });
  163 |       await select.selectOption({ index: 1 });
  164 |       await expect(rows).toHaveCount(count);
  165 |     }
  166 |     const textMeasurements = [];
  167 |     for (const row of await rows.all()) {
  168 |       await row.scrollIntoViewIfNeeded();
  169 |       const observed = await row.locator('p').evaluate((node) => {
  170 |         const box = node.getBoundingClientRect();
  171 |         const range = document.createRange();
  172 |         range.selectNodeContents(node);
  173 |         return {
  174 |           text: node.textContent,
  175 |           font: parseFloat(getComputedStyle(node).fontSize),
  176 |           overflow: node.scrollWidth > node.clientWidth,
  177 |           contained: [...range.getClientRects()].every(
  178 |             (rect) => rect.left >= box.left - 1 && rect.right <= box.right + 1,
  179 |           ),
  180 |         };
  181 |       });
  182 |       textMeasurements.push(observed);
  183 |     }
  184 |     await info.attach('report-center-text', {
  185 |       body: JSON.stringify({ scale, textMeasurements }),
  186 |       contentType: 'application/json',
  187 |     });
  188 |     for (const observed of textMeasurements) {
  189 |       expect(observed.font).toBeGreaterThanOrEqual(12);
  190 |       expect(observed.overflow).toBe(false);
  191 |       expect(observed.contained, observed.text ?? '').toBe(true);
  192 |     }
  193 |     if ([0.8, 1, 1.5].includes(scale))
  194 |       await panel.screenshot({ path: info.outputPath(`report-center-${scale}.png`) });
  195 |     const camera = await page.evaluate(
  196 |       () => window.__tenka.debug.getMapPublishedViewSnapshot().camera,
  197 |     );
  198 |     const goto = panel.getByRole('button', { name: '前往', exact: true }).first();
  199 |     await expect(goto).toBeEnabled();
  200 |     await goto.focus();
  201 |     await page.keyboard.press('Enter');
  202 |     await expect(panel).toHaveCount(0);
  203 |     await expect
  204 |       .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().camera))
> 205 |       .not.toEqual(camera);
      |            ^ Error: expect(received).not.toEqual(expected) // deep equality
  206 |     expect(
  207 |       await page.evaluate(() => ({
  208 |         core: JSON.stringify(window.__tenka.debug.getState()),
  209 |         commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
  210 |       })),
  211 |     ).toEqual(before);
  212 |   });
  213 | }
  214 | 
```
import pathlib,json,hashlib,shutil,gzip
r=pathlib.Path('/tmp/tenka-yfirst-native-current23-20261012');o=pathlib.Path('/tmp/tenka-yfirst-native-current23-evidence')
files={'npmci.log':'/tmp/tenka-yfirst-native-current23-npmci.log','build-final.log':'/tmp/tenka-yfirst-native-current23-build.log','published.log':'/tmp/tenka-yfirst-native-current23-published.log','published.raw.json':'/tmp/tenka-national120-published-yfirst-native-current23.json','observer.mjs':str(r/'national120-published.mjs'),'fps-control.spec.ts':str(r/'e2e/national120-map-perf.spec.ts'),'fixtures.ts':str(r/'e2e/fixtures.ts'),'playwright.config.ts':str(r/'playwright.config.ts'),'patch-manifest.json':str(r/'tools/dependencies/pixi-8.19-patch.json'),'patch-applier.mjs':str(r/'tools/dependencies/pixi-8.19-patch.mjs'),'wasm-manifest.json':str(r/'public/wasm/manifest.json'),'tenka_engine.wasm':str(r/'public/wasm/tenka_engine.wasm'),'proof.py':'/tmp/sim3-yfirst-native-current23-proof.py'}
# Actual artifact manifest path is discovered only from frozen tracked paths.
for name,path in list(files.items()):
 if pathlib.Path(path).exists():shutil.copyfile(path,o/name)
fresh=[]
for p in (r/'dist').rglob('*'):
 if p.is_file():
  b=p.read_bytes();fresh.append({'path':str(p.relative_to(r)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mtimeNs':p.stat().st_mtime_ns})
(o/'build-artifact-proof.json').write_text(json.dumps({'files':fresh,'buildLogMtimeNs':pathlib.Path('/tmp/tenka-yfirst-native-current23-build.log').stat().st_mtime_ns,'sourceTransferTarMtimeNs':pathlib.Path('/tmp/sim3-yfirst-native-current23-source.tar.gz').stat().st_mtime_ns},indent=2))
for camera in ['overview','operational','close']:
 shutil.copyfile('/tmp/tenka-yfirst-native-current23-'+camera+'.log',o/(camera+'.log'))
 a=list(pathlib.Path('/tmp/tenka-yfirst-native-current23-'+camera+'-results').rglob('national-'+camera+'-frames.json'));assert len(a)==1;shutil.copyfile(a[0],o/(camera+'.raw.json'))
print(str(o))

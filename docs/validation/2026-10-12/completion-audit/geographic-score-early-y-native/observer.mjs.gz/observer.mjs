import {chromium} from '@playwright/test';
import {writeFileSync,openSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const phase=process.argv[2];
const preview=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4173'],{stdio:['ignore',openSync('/tmp/tenka-national120-published-'+phase+'-preview.log','w'),'ignore']});
let browser;
try {
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:4173')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
 const context=await browser.newContext({viewport:{width:1920,height:1080},reducedMotion:'no-preference'});const page=await context.newPage();
 const wasmResponses=[],wasmPending=[];page.on('response',response=>{if(new URL(response.url()).pathname.includes('/wasm/')&&new URL(response.url()).pathname.endsWith('.wasm')){const pending=(async()=>{try{const bytes=await response.body();wasmResponses.push({url:response.url(),status:response.status(),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),proof:'actual response.body bytes'});}catch(error){wasmResponses.push({url:response.url(),status:response.status(),bodyError:String(error),proof:'observed requested URL; actual response body unavailable'});}})();wasmPending.push(pending);}});
 await page.goto('http://127.0.0.1:4173/?debug=1&seed=15600519');
 await page.getByTestId('title-newgame').click();await page.getByTestId('scenario-pick-s1560').click();await page.getByTestId('clan-pick-clan.oda').click();await page.getByTestId('newgame-start').click();await page.getByTestId('screen-strategy').waitFor();await page.getByTestId('speed-pause').click();
 const preparation=await page.evaluate(()=>window.__tenka.debug.prepareLiveNationalMapWorkload(120));

 const gpuCapture=async(name)=>{const gpu=await page.evaluate(()=>[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return{width:canvas.width,height:canvas.height,context:null};const ext=gl.getExtension('WEBGL_debug_renderer_info');return{width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',contextLost:gl.isContextLost(),renderer:String(gl.getParameter(ext?ext.UNMASKED_RENDERER_WEBGL:gl.RENDERER)),vendor:String(gl.getParameter(ext?ext.UNMASKED_VENDOR_WEBGL:gl.VENDOR))};}));writeFileSync('/tmp/tenka-yfirst-native-current23-gpu-'+name+'.json',JSON.stringify(gpu));const active=gpu.find(g=>g.context);if(!active||!active.renderer.includes('RTX 5070 Ti')||!active.renderer.includes('Vulkan')||active.contextLost)throw Error('Actual RTX Vulkan GPU guard failed');};
 await gpuCapture('before');
 const snapshots=[];
 for(let day=0;day<3;day++){
  if(day)await page.evaluate(async()=>{window.__tenka.debug.stepDays(1);await window.__tenka.debug.waitSimulationIdle();});
  for(const camera of ['overview','operational','close']){
   await page.evaluate(async(camera)=>{await document.fonts.ready;await window.__tenka.debug.setMapCameraPreset(camera);await window.__tenka.debug.waitMapIdle(3);},camera);
   const snapshot=await page.evaluate(()=>{
    const diagnostics=window.__tenka.debug.getMapDiagnostics();
    const {runs:armyRuns,...plates}=diagnostics.armyPlateLayout;
    const {runs:labelRuns,placementCache,...geographic}=diagnostics.geographicLabelLayout;
    const {runs:ribbonRuns,...ribbons}=diagnostics.castleRibbonLayout;
    return{day:window.__tenka.debug.getState().time.day,canonicalJSON:JSON.stringify(window.__tenka.debug.getState()),published:window.__tenka.debug.getMapPublishedViewSnapshot(),plates,geographic,ribbons,castleRendering:diagnostics.castleRendering,elevation:diagnostics.elevationRendering,settlements:diagnostics.settlementRendering,excludedCounters:{armyRuns,labelRuns,placementCache,ribbonRuns}};
   });
   if(snapshot.day!==day || snapshot.published.day!==day)throw Error('Unsettled canonical/publication day');
   snapshot.canonicalSHA256=createHash('sha256').update(snapshot.canonicalJSON).digest('hex');delete snapshot.canonicalJSON;delete snapshot.excludedCounters;
   snapshots.push({camera,...snapshot});
  }
 }
 await gpuCapture('after-functional');
 const driver=await page.evaluate(()=>window.__tenka.debug.getLiveNationalMapWorkload());
 writeFileSync('/tmp/tenka-national120-published-'+phase+'.json',JSON.stringify({scope:'functionalGeometryParity/notFPS',preparation,driver,excludedNonvisualCounters:['armyPlateLayout.runs','geographicLabelLayout.runs','geographicLabelLayout.placementCache','castleRibbonLayout.runs'],snapshots}));
 console.log(JSON.stringify({phase,snapshots:snapshots.length,days:snapshots.map(s=>s.day),driverTicks:driver.ticks}));
 await Promise.all(wasmPending);
 const separatelyServed=[];for(const url of [...new Set(wasmResponses.map(r=>r.url))]){const response=await fetch(url);const bytes=Buffer.from(await response.arrayBuffer());separatelyServed.push({url,status:response.status,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),proof:'observed requested URL + separately served frozen bytes; not original response body'});}
 if(!wasmResponses.length||wasmResponses.some(r=>!new URL(r.url).pathname.endsWith('/tenka_engine.wasm'))||separatelyServed.some(r=>r.status!==200||r.bytes!==90122||r.sha256!=='e22f559b4b9d6f6348709e028cecdbc2c6f567db2483fa845b48df0554d7bc7d')||wasmResponses.some(r=>r.sha256&&r.sha256!=='e22f559b4b9d6f6348709e028cecdbc2c6f567db2483fa845b48df0554d7bc7d'))throw Error('Actual observed scalar URL/served artifact proof RED');
 writeFileSync('/tmp/tenka-yfirst-native-current23-published-wasm-responses.json',JSON.stringify({scope:'collector repair retained from earlier campaign; requested URLs observed by page; separately fetched served byte hashes outside CPU/FPS windows',observed:wasmResponses,separatelyServed}));
}finally{await browser?.close();preview.kill('SIGTERM');}

import pathlib,json,gzip,hashlib,shutil
r=pathlib.Path('/tmp/tenka-yfirst-native-local');p=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-score-early-y-native');p.mkdir(exist_ok=True);base=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-preparation-native');h=lambda b:hashlib.sha256(b).hexdigest()
def read(n):return json.loads(gzip.decompress((r/(n+'.gz')).read_bytes()))
fps=[]
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');m=q['measurement'];b=json.loads(gzip.decompress((base/(c+'.raw.json.gz')).read_bytes()))['measurement'];fps.append(dict(camera=c,**{k:m[k] for k in ['averageFps','slowFrameFps','frameTimeP95','durationMs','frames','completedFrames']},baselineAverageFps=b['averageFps'],baselineFrameTimeP95=b['frameTimeP95'],observedAveragePercent=(m['averageFps']/b['averageFps']-1)*100,originalStrict60Pass=False,actualRTXVulkanGuard=True))
artifacts=[]
for f in sorted(r.glob('*.gz')):
 z=f.read_bytes();b=gzip.decompress(z);shutil.copyfile(f,p/f.name);artifacts.append(dict(path=f.name,gzipBytes=len(z),gzipSHA256=h(z),rawBytes=len(b),rawSHA256=h(b),remoteOriginal='/tmp/tenka-yfirst-native-current23-evidence/'+f.name[:-3]))
s=dict(scope='Frozen5bc1 finite-domain scalar overlap early-Y-zero candidate; single original native campaign',frozenCommit='5bc1f58628b6c18381b4dce8b6a9b10ee88d4ad8',retentionDecision='pending parent review',baselineCommit='feab20cc9c207f37afae7a2f372c437b93232a07',baselineEvidence='44c3b30',sourceFiles=1528,dependencyFiles=14765,installedPatchTargets=23,selectedVariant='scalar',scalar=dict(bytes=90122,sha256='e22f559b4b9d6f6348709e028cecdbc2c6f567db2483fa845b48df0554d7bc7d'),simd=dict(bytes=89972,sha256='48bed258011b162196ebd4fdf8b9e9dc94081df139d1f1af4294ffcdcc5882a0'),functionalParity=read('parity-proof.json'),fps=fps,nativeSix=dict(passed=6,reportedDurationSeconds=42.3,scope='Original full-state/log native worker including60/120daycoldwarm/save/reload/cancel/x5',rawManifest='native-six-raw-manifest.json.gz'),cpuProfileExecuted=False,allJobsTerminal=True,retries=0,baselineRerun=False,bodyCollector='Previously authorized nonthrowing instrumentation repair retained; unavailable-body rows preserve failure text, separately served fetch is not original response body',limitations=['Single unreplicated windows; +2.419% close gain is small and does not establish repeatable overall benefit.','All original strict60 controls RED; threshold unchanged.','No CPUprofile or attribution measurement.'],artifacts=artifacts)
(p/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
(p/'README.md').write_text('''# Scalar early-Y-zero native campaign

Frozen runtime5bc1f58628b6c18381b4dce8b6a9b10ee88d4ad8 was measured once on sim3 with the same current23 dependency cohort:14,765 files and23 installed patches. All1,528 frozen source/config/fixture/public files match at before/after/final checkpoints; public files are copied. Production default remains scalar. Actual observed scalar URL and four response bodies match90,122bytes/e22f559b4b…; one unavailable-body error is preserved. A separately served fetch also matches and is explicitly distinguished from original response bodies. SIMD89,972bytes/48bed25801… is frozen but unselected.

The original nine complete settled published payloads match af4ddbc9… byte for byte with precisely the original four nonvisual counter exclusions. Original120-army1920×1080 controls each ran once for30seconds, serially on actual RTX5070Ti Vulkan. No baseline rerun, threshold change, or retry occurred.

| Camera | FPS | Accepted feab baseline | Change | p95 ms | Strict60 |
|---|---:|---:|---:|---:|---|
'''+''.join(f"| {x['camera']} | {x['averageFps']:.4f} | {x['baselineAverageFps']:.4f} | {x['observedAveragePercent']:+.3f}% | {x['frameTimeP95']:.3f} | RED |\n" for x in fps)+'''
These single windows show a small close gain; they do not establish repeatability or clear overall benefit. Overview fails the original slow-frame requirement despite averageFPS above60. All original RED logs and frame arrays remain. Canonical state and renderer resource objects match before/after each control.

The original six Worker tests subsequently passed in42.3seconds, including full60/120daycold+warm state/log comparisons, save/reload, cancellation and paced×5. Three unique full JSON rows and duplicate-attachment aliases/hashes are retained. No CPUprofile ran. All jobs are terminal and final source/dependency proofs pass.

Every gzip artifact has byte counts and compressed/raw SHA256 in summary.json. Run `python3 verify.py <package-directory>`. Existing collector repair is carried over from the prior campaign; this campaign has one functional observation attempt, with an unavailable-body row handled and preserved rather than an observer retry. No newsetup failure occurred.
''')
print(len(artifacts),sum(x['gzipBytes'] for x in artifacts))

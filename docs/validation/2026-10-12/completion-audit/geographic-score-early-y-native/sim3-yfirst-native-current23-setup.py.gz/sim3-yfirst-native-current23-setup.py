import pathlib,tarfile,shutil,hashlib
r=pathlib.Path('/tmp/tenka-yfirst-native-current23-20261012');assert not r.exists();r.mkdir()
with tarfile.open('/tmp/sim3-yfirst-native-current23-source.tar.gz') as t:t.extractall(r,filter='data')
(r/'node_modules').symlink_to('/tmp/tenka-national120-current23-20261012/node_modules')
for a,b in [('national120-published.mjs','national120-published.mjs'),('yfirst-native-current23-profile.mjs','yfirst-native-current23-profile.mjs'),('yfirst-native-current23-profile-analysis.mjs','yfirst-native-current23-profile-analysis.mjs'),('sim3-yfirst-native-profile-attribution.mjs','profile-attribution.mjs')]:shutil.copyfile('/tmp/tenka-yfirst-native-templates/'+a,r/b)
assert hashlib.sha256((r/'e2e/national120-map-perf.spec.ts').read_bytes()).hexdigest()=='2d39ba643aa3c0aa7a242d0e93d081806fe54bd64b650f1ab78cbf67d4f567e4'
import json
m=json.loads(pathlib.Path('/tmp/sim3-yfirst-native-current23-expected.json').read_text())
assert m['commit']=='5bc1f58628b6c18381b4dce8b6a9b10ee88d4ad8'
for name,sha,size in [('tenka_engine.wasm','e22f559b4b9d6f6348709e028cecdbc2c6f567db2483fa845b48df0554d7bc7d',90122),('tenka_engine.simd.wasm','48bed258011b162196ebd4fdf8b9e9dc94081df139d1f1af4294ffcdcc5882a0',89972)]:
 b=(r/'public/wasm'/name).read_bytes();assert len(b)==size and hashlib.sha256(b).hexdigest()==sha
artifacts=[f for f in m['files'] if f['path'].startswith('public/wasm/')]
for f in artifacts:
 b=(r/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print('Fresh full frozen source/public/fixtures, original FPS spec and actual scalar/SIMD/manifest hashes PASS')

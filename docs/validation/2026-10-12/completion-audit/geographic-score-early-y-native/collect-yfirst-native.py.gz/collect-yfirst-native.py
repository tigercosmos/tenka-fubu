import pathlib,shutil,hashlib,json,gzip
out=pathlib.Path('/tmp/tenka-yfirst-native-current23-evidence');r=pathlib.Path('/tmp/tenka-yfirst-native-current23-20261012')
for src,name in [(r/'public/wasm/tenka_engine.simd.wasm','simd.wasm'),(r/'e2e/worker-simulation.spec.ts','native-six.spec.ts'),(pathlib.Path('/tmp/tenka-yfirst-native-current23-native-six.log'),'native-six.log'),(pathlib.Path('/tmp/tenka-yfirst-native-current23-published-wasm-responses.json'),'selected-wasm-url-bytes.json'),(pathlib.Path('/tmp/yfirst-transfer-proof.json'),'transfer-proof.json'),(pathlib.Path('/tmp/sim3-yfirst-native-current23-expected.json'),'expected-source.json')]:shutil.copyfile(src,out/name)
for stage in ['before','after-functional']:shutil.copyfile('/tmp/tenka-yfirst-native-current23-gpu-'+stage+'.json',out/('gpu-'+stage+'.json'))
for p in pathlib.Path('/tmp/tenka-yfirst-native-templates').glob('*'):
 if p.is_file() and p.name.endswith('.py'):shutil.copyfile(p,out/p.name)
manifest=[];seen={}
root=pathlib.Path('/tmp/tenka-yfirst-native-current23-native-six-results')
for p in sorted(root.rglob('*.json')):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();name=seen.get(h)
 if name is None:name='native-six-'+p.name;seen[h]=name;(out/name).write_bytes(b)
 manifest.append(dict(path=str(p),artifact=name,bytes=len(b),sha256=h))
(out/'native-six-raw-manifest.json').write_text(json.dumps(manifest,indent=2))
for stage in ['setup','proof-before','build','published','proof-after','controls-driver','native-six','proof-final','collect','state-proof']:
 p=pathlib.Path('/tmp/tenka-yfirst-native-current23-'+stage+'.log');shutil.copyfile(p,out/('driver-'+stage+'.log'))
for p in out.iterdir():
 if p.is_file() and not p.name.endswith('.gz'): (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
print('Collected existing terminal bytes only',flush=True)

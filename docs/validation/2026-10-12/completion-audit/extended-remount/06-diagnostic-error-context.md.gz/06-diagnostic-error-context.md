# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual.spec.ts >> M6-V11 visual quality gates >> zoom cycles and renderer remount preserve resource counts without context loss
- Location: e2e/visual.spec.ts:97:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 16
+ Received  + 16

@@ -1,29 +1,29 @@
  Object {
-   "canopyBufferBytes": 50220,
+   "canopyBufferBytes": 0,
    "coastGeometryBytes": 966184,
    "coastRgbaBytes": 2048,
-   "elevatedBufferBytes": 1966080,
+   "elevatedBufferBytes": 0,
    "eventListeners": 13,
-   "foothillBufferBytes": 792600,
+   "foothillBufferBytes": 0,
    "mountainShadeRgbaBytes": 0,
-   "ownedCanopyBuffers": 20,
-   "ownedCanopyGeometries": 10,
-   "ownedCanopyMeshes": 10,
+   "ownedCanopyBuffers": 0,
+   "ownedCanopyGeometries": 0,
+   "ownedCanopyMeshes": 0,
    "ownedCoastGeometries": 2,
    "ownedCoastSources": 1,
    "ownedCoastTextures": 1,
-   "ownedElevatedBuffers": 2,
-   "ownedElevatedGeometries": 1,
-   "ownedElevatedMeshes": 1,
-   "ownedElevatedPrograms": 1,
-   "ownedElevatedShaders": 1,
-   "ownedFoothillBuffers": 2,
-   "ownedFoothillGeometries": 1,
-   "ownedFoothillMeshes": 1,
-   "ownedFoothillPrograms": 1,
-   "ownedFoothillShaders": 1,
+   "ownedElevatedBuffers": 0,
+   "ownedElevatedGeometries": 0,
+   "ownedElevatedMeshes": 0,
+   "ownedElevatedPrograms": 0,
+   "ownedElevatedShaders": 0,
+   "ownedFoothillBuffers": 0,
+   "ownedFoothillGeometries": 0,
+   "ownedFoothillMeshes": 0,
+   "ownedFoothillPrograms": 0,
+   "ownedFoothillShaders": 0,
    "ownedMountainShadeSources": 0,
    "ownedMountainShadeTextures": 0,
    "ownedRiverDisplayGraphics": 10,
    "ownedRiverMaskGraphics": 10,
    "ownedRiverSources": 10,

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 勢力圖" [ref=e8] [cursor=pointer]
    - status [ref=e9]:
      - strong [ref=e10]: 圖例 · 勢力圖
      - generic [ref=e11]: 領域色表示所屬勢力；勢力名稱標示領土中心。
  - banner [ref=e12]:
    - group "金錢、兵糧、兵力、威信" [ref=e13]:
      - generic [ref=e14]:
        - group "織田家" [ref=e15]
        - time [ref=e17]: 1561年3月1日
        - generic [ref=e18]:
          - generic [ref=e19]:
            - img [ref=e20]
            - generic [ref=e23]: 金錢
          - strong [ref=e26]: 3,000
        - generic [ref=e27]:
          - generic [ref=e28]:
            - img [ref=e29]
            - generic [ref=e31]: 兵糧
          - generic [ref=e32]:
            - strong [ref=e34]: 26,306
            - generic "兵糧可支撐6個月" [ref=e35]:
              - text: 兵糧可支撐
              - strong [ref=e36]: "6"
              - text: 個月
        - generic [ref=e37]:
          - generic [ref=e38]:
            - img [ref=e39]
            - generic [ref=e43]: 兵力
          - generic [ref=e45]:
            - strong [ref=e46]: 5,200
            - generic [ref=e47]: /3,000
        - generic [ref=e48]:
          - generic [ref=e49]:
            - img [ref=e50]
            - generic [ref=e52]: 威信
          - strong [ref=e55]: "300"
    - generic [ref=e56]:
      - generic [ref=e57]:
        - button "暫停" [pressed] [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "一倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "二倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
        - button "五倍速" [ref=e67] [cursor=pointer]:
          - img [ref=e68]
      - button "系統選單" [ref=e70] [cursor=pointer]:
        - img [ref=e71]
  - navigation "內政" [ref=e74]:
    - button "地圖一覽" [ref=e75] [cursor=pointer]:
      - img [ref=e76]
      - generic [ref=e79]:
        - generic [ref=e80]: 地圖
        - generic [ref=e81]: 一覽
    - button "織田家 （本城）" [ref=e82] [cursor=pointer]:
      - img [ref=e83]
      - generic "織田家" [ref=e88]: 織田
    - generic [ref=e90]: 軍政
    - button "軍事" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 軍事
    - button "內政" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 內政
    - button "武將" [ref=e97] [cursor=pointer]:
      - img [ref=e98]
      - text: 武將
    - generic [ref=e103]: 交涉
    - button "外交" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 外交
    - button "調略" [ref=e107] [cursor=pointer]:
      - img [ref=e108]
      - text: 調略
    - generic [ref=e112]: 國策
    - button "政策" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 政策
    - button "軍團" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 軍團
    - button "大命" [ref=e119] [cursor=pointer]:
      - img [ref=e120]
      - text: 大命
  - generic [ref=e123]:
    - generic [ref=e124]:
      - generic [ref=e125]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e126] [cursor=pointer]:
        - img [ref=e127]
    - generic [ref=e130]:
      - generic [ref=e132]:
        - img "兵力 800" [ref=e133]:
          - generic [ref=e134]: 兵力 800
        - img "兵糧 6,916" [ref=e137]:
          - generic [ref=e138]: 兵糧 6,916
        - img "耐久 1,000" [ref=e141]:
          - generic [ref=e142]: 耐久 1,000
        - img "士氣 80" [ref=e145]:
          - generic [ref=e146]: 士氣 80
      - generic [ref=e149]:
        - button "城面板" [ref=e150] [cursor=pointer]
        - button "出陣" [ref=e151] [cursor=pointer]
        - button "輸送" [ref=e152] [cursor=pointer]
  - img "全國小地圖" [ref=e153]
  - generic:
    - button "通報 1 則" [ref=e157] [cursor=pointer]:
      - img [ref=e158]
    - generic "通報 1 則" [ref=e160]:
      - alert [ref=e161]:
        - generic [ref=e162]:
          - img [ref=e164]
          - generic [ref=e166]:
            - strong [ref=e167]: 駿府城遭織田家包圍！
            - time [ref=e168]: 1561年3月1日
          - button "關閉通知" [ref=e170] [cursor=pointer]:
            - img [ref=e171]
    - button "報告中心" [ref=e173] [cursor=pointer]
```

# Test source

```ts
  96  | 
  97  |   test('zoom cycles and renderer remount preserve resource counts without context loss', async ({
  98  |     page,
  99  |   }, testInfo) => {
  100 |     if (process.env.VISUAL_HEAP === '1') test.setTimeout(180_000);
  101 |     await bootMap(page);
  102 |     const control = page.getByTestId('layer-control');
  103 |     await control.locator('summary').click();
  104 |     await control.locator('input[value="faction"]').check();
  105 |     await page.evaluate(() => window.__tenka.debug.waitMapIdle());
  106 |     const cdp = await page.context().newCDPSession(page);
  107 |     const heapSamples: number[] = [];
  108 |     const sampleHeap = async () => {
  109 |       await cdp.send('HeapProfiler.collectGarbage');
  110 |       heapSamples.push((await cdp.send('Runtime.getHeapUsage')).usedSize);
  111 |     };
  112 |     const snapshotHeap = async (name: string) => {
  113 |       const chunks: string[] = [];
  114 |       const collect = ({ chunk }: { chunk: string }) => chunks.push(chunk);
  115 |       cdp.on('HeapProfiler.addHeapSnapshotChunk', collect);
  116 |       try {
  117 |         await cdp.send('HeapProfiler.takeHeapSnapshot', { reportProgress: false });
  118 |         const source = chunks.join('');
  119 |         if (process.env.VISUAL_HEAP === '1')
  120 |           await writeFile(testInfo.outputPath(`${name}.heapsnapshot`), source);
  121 |         const snapshot = JSON.parse(source) as {
  122 |           snapshot: { meta: { node_fields: string[]; edge_fields: string[] } };
  123 |           nodes: number[];
  124 |           edges: number[];
  125 |           strings: string[];
  126 |         };
  127 |         const fields = snapshot.snapshot.meta.node_fields;
  128 |         const nameIndex = fields.indexOf('name');
  129 |         let fontAtlasCanvases = 0;
  130 |         let canvas2dContexts = 0;
  131 |         let bitmapTexts = 0;
  132 |         const edgeFields = snapshot.snapshot.meta.edge_fields;
  133 |         const edgeCountIndex = fields.indexOf('edge_count');
  134 |         const edgeNameIndex = edgeFields.indexOf('name_or_index');
  135 |         const edgeTargetIndex = edgeFields.indexOf('to_node');
  136 |         let edgeOffset = 0;
  137 |         for (let index = 0; index < snapshot.nodes.length; index += fields.length) {
  138 |           const nodeName = snapshot.strings[snapshot.nodes[index + nameIndex]!];
  139 |           if (nodeName === '<canvas width="512" height="512">') fontAtlasCanvases += 1;
  140 |           if (nodeName === 'CanvasRenderingContext2D') canvas2dContexts += 1;
  141 |           for (let edge = 0; edge < snapshot.nodes[index + edgeCountIndex]!; edge += 1) {
  142 |             const offset = edgeOffset + edge * edgeFields.length;
  143 |             const target = snapshot.edges[offset + edgeTargetIndex]!;
  144 |             if (
  145 |               snapshot.strings[snapshot.edges[offset + edgeNameIndex]!] === 'renderPipeId' &&
  146 |               snapshot.strings[snapshot.nodes[target + nameIndex]!] === 'bitmapText'
  147 |             )
  148 |               bitmapTexts += 1;
  149 |           }
  150 |           edgeOffset += snapshot.nodes[index + edgeCountIndex]! * edgeFields.length;
  151 |         }
  152 |         return { fontAtlasCanvases, canvas2dContexts, bitmapTexts };
  153 |       } finally {
  154 |         cdp.off('HeapProfiler.addHeapSnapshotChunk', collect);
  155 |       }
  156 |     };
  157 |     await page.evaluate(() => {
  158 |       const target = window as Window & { __contextLosses?: number };
  159 |       target.__contextLosses = 0;
  160 |       document.addEventListener(
  161 |         'webglcontextlost',
  162 |         () => {
  163 |           target.__contextLosses! += 1;
  164 |         },
  165 |         true,
  166 |       );
  167 |     });
  168 |     const before = await page.evaluate(
  169 |       () => (window as DebugWindow).__tenka.debug.getMapDiagnostics().resources,
  170 |     );
  171 |     for (let cycle = 0; cycle < 10; cycle += 1) {
  172 |       await page.evaluate(async () => {
  173 |         await (window as DebugWindow).__tenka.debug.setMapCameraPreset('overview');
  174 |         await (window as DebugWindow).__tenka.debug.setMapCameraPreset('close');
  175 |       });
  176 |     }
  177 |     {
  178 |       const warmupCount = process.env.VISUAL_HEAP === '1' ? 10 : 2;
  179 |       for (let cycle = 0; cycle < warmupCount; cycle += 1) {
  180 |         await page.evaluate(() => window.__tenka.debug.remountMap());
  181 |         await page.evaluate(() => window.__tenka.debug.setMapCameraPreset('close'));
  182 |       }
  183 |     }
  184 |     const cacheBefore = await snapshotHeap('before-remounts');
  185 |     await sampleHeap();
  186 |     const remountCount = process.env.VISUAL_HEAP === '1' ? 120 : 10;
  187 |     for (let cycle = 0; cycle < remountCount; cycle += 1) {
  188 |       await page.evaluate(() => (window as DebugWindow).__tenka.debug.remountMap());
  189 |       await page.evaluate(() => window.__tenka.debug.setMapCameraPreset('close'));
  190 |       await appendFile(testInfo.outputPath('cycle-diagnostics.jsonl'), JSON.stringify({ cycle, diagnostics: await page.evaluate(() => window.__tenka.debug.getMapDiagnostics()), heap: await cdp.send('Runtime.getHeapUsage') }) + '\n');
  191 |       await expect(page.getByTestId('map-canvas-host').locator('canvas')).toHaveCount(1);
  192 |       await expect
  193 |         .poll(() =>
  194 |           page.evaluate(() => (window as DebugWindow).__tenka.debug.getMapDiagnostics().resources),
  195 |         )
> 196 |         .toEqual(before);
      |          ^ Error: expect(received).toEqual(expected) // deep equality
  197 |       await sampleHeap();
  198 |     }
  199 |     const cacheAfter = await snapshotHeap('after-remounts');
  200 |     expect(cacheAfter, 'Global font atlas and canvas caches stay bounded across remounts').toEqual(
  201 |       cacheBefore,
  202 |     );
  203 |     const heapPath = testInfo.outputPath('remount-heap-samples.json');
  204 |     await writeFile(
  205 |       heapPath,
  206 |       JSON.stringify(
  207 |         { mode: 'faction', resources: before, cacheBefore, cacheAfter, usedHeapBytes: heapSamples },
  208 |         null,
  209 |         2,
  210 |       ),
  211 |     );
  212 |     await testInfo.attach('remount-heap-samples.json', {
  213 |       path: heapPath,
  214 |       contentType: 'application/json',
  215 |     });
  216 |     await cdp.detach();
  217 |     expect(
  218 |       await page.evaluate(() => (window as Window & { __contextLosses: number }).__contextLosses),
  219 |     ).toBe(0);
  220 |   });
  221 | 
  222 |   test('analysis modes render visible overlays without changing GameState', async ({
  223 |     page,
  224 |   }, testInfo) => {
  225 |     await bootMap(page);
  226 |     const before = await page.evaluate(() => JSON.stringify(window.__tenka.debug.getState()));
  227 |     const control = page.getByTestId('layer-control');
  228 |     await control.locator('summary').click();
  229 |     const feedback: { mode: string; durationMs: number }[] = [];
  230 |     for (const mode of ['faction', 'supply', 'roadCapacity', 'terrainAdvantage', 'castleDefense']) {
  231 |       const durationMs = await page.evaluate(async (nextMode) => {
  232 |         const input = document.querySelector<HTMLInputElement>(
  233 |           `[data-testid="layer-control"] input[value="${nextMode}"]`,
  234 |         );
  235 |         if (!input) throw new Error(`Missing mode radio: ${nextMode}`);
  236 |         const started = performance.now();
  237 |         input.click();
  238 |         while (window.__tenka.debug.getMapDiagnostics().analysisMode !== nextMode) {
  239 |           if (performance.now() - started > 1000)
  240 |             throw new Error(`Mode feedback timed out: ${nextMode}`);
  241 |           await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
  242 |         }
  243 |         return performance.now() - started;
  244 |       }, mode);
  245 |       feedback.push({ mode, durationMs });
  246 |       if (process.env.VISUAL_PERF === '1')
  247 |         expect(durationMs, `${mode}: feedback latency`).toBeLessThan(100);
  248 |       await page.evaluate(() => window.__tenka.debug.waitMapIdle());
  249 |       const diagnostics = await page.evaluate(() => window.__tenka.debug.getMapDiagnostics());
  250 |       expect(diagnostics.analysisMode).toBe(mode);
  251 |       expect(diagnostics.layers.analysisOverlay?.visibleDrawables).toBeGreaterThan(0);
  252 |       await expect(page.getByTestId('analysis-legend')).toBeVisible();
  253 |     }
  254 |     await control.locator('input[value="none"]').check();
  255 |     await expect(page.getByTestId('analysis-legend')).toHaveCount(0);
  256 |     expect(await page.evaluate(() => JSON.stringify(window.__tenka.debug.getState()))).toBe(before);
  257 |     const feedbackPath = testInfo.outputPath('analysis-feedback.json');
  258 |     await writeFile(feedbackPath, JSON.stringify(feedback, null, 2));
  259 |     await testInfo.attach('analysis-feedback.json', {
  260 |       path: feedbackPath,
  261 |       contentType: 'application/json',
  262 |     });
  263 |   });
  264 | 
  265 |   test('grayscale readability artifact for manual shape and line-style review', async ({
  266 |     page,
  267 |   }, testInfo) => {
  268 |     await bootMap(page);
  269 |     await page.evaluate(() => window.__tenka.debug.setMapCameraPreset('operational'));
  270 |     await page.getByTestId('screen-strategy').evaluate((element) => {
  271 |       (element as HTMLElement).style.filter = 'grayscale(1)';
  272 |     });
  273 |     const artifact = testInfo.outputPath('strategy-operational-grayscale.png');
  274 |     await page.screenshot({ path: artifact, animations: 'disabled' });
  275 |     await testInfo.attach('grayscale-readability', { path: artifact, contentType: 'image/png' });
  276 |   });
  277 | 
  278 |   test('HUD keyboard focus is visible and enabled buttons have readable contrast', async ({
  279 |     page,
  280 |   }) => {
  281 |     await bootMap(page);
  282 |     await page.locator('button:enabled').first().focus();
  283 |     await page.keyboard.press('Tab');
  284 |     const focus = await page.evaluate(() => {
  285 |       const element = document.activeElement;
  286 |       if (!(element instanceof HTMLElement)) return null;
  287 |       const style = getComputedStyle(element);
  288 |       return {
  289 |         tag: element.tagName,
  290 |         outline: style.outlineStyle,
  291 |         width: parseFloat(style.outlineWidth),
  292 |         shadow: style.boxShadow,
  293 |       };
  294 |     });
  295 |     expect(focus?.tag).toBe('BUTTON');
  296 |     expect(
```
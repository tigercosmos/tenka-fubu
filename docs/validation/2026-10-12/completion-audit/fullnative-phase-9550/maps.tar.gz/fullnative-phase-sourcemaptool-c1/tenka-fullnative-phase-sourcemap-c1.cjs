/** Resolve selected CDP call frames against the exact production build maps. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { TraceMap, originalPositionFor } = require('/tmp/tenka-fullnative-phase-9550-c1/node_modules/@jridgewell/trace-mapping');

const assets = '/tmp/tenka-fullnative-phase-9550-c1/dist/assets';
const picks = [
  ['vendor-pixi-BP0uNPQ-', 301, 39541, 'Pixi canvas blend detection'],
  ['vendor-pixi-BP0uNPQ-', 671, 786, 'Pixi bitmap font kerning'],
  ['index-BS-1vWIf', 16, 283787, 'settlement geometry'],
  ['index-BS-1vWIf', 103, 1831, 'protected terrain cells'],
  ['index-BS-1vWIf', 16, 370830, 'river surface pixels'],
  ['index-BS-1vWIf', 16, 418658, 'terrain topography'],
  ['index-BS-1vWIf', 16, 203519, 'territory grid lookup'],
];
const maps = new Map();
const rows = [];
for (const [bundle, lineZero, column, label] of picks) {
  if (!maps.has(bundle)) {
    const filename = path.join(assets, `${bundle}.js.map`);
    const bytes = fs.readFileSync(filename);
    maps.set(bundle, {
      map: new TraceMap(JSON.parse(bytes.toString('utf8'))),
      sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
      size: bytes.length,
    });
  }
  const item = maps.get(bundle);
  rows.push({
    label,
    bundle,
    generatedLineZeroBased: lineZero,
    generatedColumnZeroBased: column,
    sourceMapSha256: item.sha256,
    sourceMapSize: item.size,
    original: originalPositionFor(item.map, { line: lineZero + 1, column }),
  });
}
console.log(JSON.stringify(rows, null, 2));

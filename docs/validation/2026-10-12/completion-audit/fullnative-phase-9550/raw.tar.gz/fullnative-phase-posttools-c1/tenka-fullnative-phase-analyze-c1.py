#!/usr/bin/env python3
"""Attribute one captured CDP CPU profile to the recorded native case phases."""
import collections
import glob
import json
from pathlib import Path

run = Path('/tmp/tenka-fullnative-phase-native-c2/browser-results')
profile_path = Path(glob.glob(str(run / '*/cpu-profile.json'))[0])
marks_path = profile_path.with_name('phase-census.json')
profile = json.loads(profile_path.read_text())['profile']
marks = json.loads(marks_path.read_text())
nodes = {node['id']: node for node in profile['nodes']}
labels = [mark['label'] for mark in marks]
offsets = [(mark['timeMs'] - marks[0]['timeMs']) * 1000 for mark in marks]
phase_time = [collections.Counter() for _ in range(len(offsets)-1)]
phase_nodes = [collections.Counter() for _ in range(len(offsets)-1)]
cumulative = 0
for node_id, delta in zip(profile['samples'], profile['timeDeltas']):
    midpoint = cumulative + delta // 2
    cumulative += delta
    for index in range(len(phase_time)):
        if offsets[index] <= midpoint < offsets[index+1]:
            node = nodes[node_id]['callFrame']
            name = node['functionName']
            category = 'idle' if name == '(idle)' else ('program' if name == '(program)' else ('gc' if name == '(garbage collector)' else 'other'))
            phase_time[index][category] += delta
            phase_nodes[index][node_id] += delta
            break

def node_rows(counter, count=8):
    return [dict(us=us, id=node_id, **nodes[node_id]['callFrame']) for node_id, us in counter.most_common(count)]

result = {
    'profilePath': str(profile_path),
    'marksPath': str(marks_path),
    'profileDurationUs': profile['endTime'] - profile['startTime'],
    'sampleDurationUs': cumulative,
    'caseDurationUs': offsets[-1],
    'alignmentLimit': 'Profile started in beforeEach just before case-start; offsets are approximate and phase boundaries may differ by a few ms.',
    'phases': [],
}
for index, counts in enumerate(phase_time):
    result['phases'].append({
        'name': f'{labels[index]} to {labels[index+1]}',
        'wallMs': (offsets[index+1]-offsets[index])/1000,
        'sampleMs': sum(counts.values())/1000,
        'idleMs': counts['idle']/1000,
        'programMs': counts['program']/1000,
        'gcMs': counts['gc']/1000,
        'otherMs': counts['other']/1000,
        'topSelf': node_rows(phase_nodes[index]),
    })
print(json.dumps(result, ensure_ascii=False, indent=2))

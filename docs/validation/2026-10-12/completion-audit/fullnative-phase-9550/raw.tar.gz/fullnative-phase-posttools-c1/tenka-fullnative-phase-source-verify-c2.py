#!/usr/bin/env python3
"""Check every scoped Git input and the sole diagnostic extra in sim4 runtime."""
import hashlib
import json
import os
from pathlib import Path

payload = Path('/tmp/tenka-battle-79682cd/runs/fullnative-phase-9550-payload-c1')
runtime = Path('/tmp/tenka-fullnative-phase-9550-c1')
manifest = json.loads((payload / 'manifest.json').read_text())
assert manifest['revision'] == '9550e397568ff448689bc5904ec0651b04bfe717'
entries = manifest['entries']
assert len(entries) == 1648
for name, metadata in entries.items():
    raw = (runtime / name).read_bytes()
    oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert oid == metadata['gitBlob'], name

actual = set()
for root, dirs, files in os.walk(runtime, followlinks=False):
    dirs[:] = [directory for directory in dirs if directory not in {'node_modules', 'dist'}]
    for name in files:
        actual.add(str((Path(root) / name).relative_to(runtime)))
expected_extra = {'e2e/nonpolicy-phase-census.spec.ts'}
assert actual - set(entries) == expected_extra, sorted(actual - set(entries))
assert set(entries) - actual == set(), sorted(set(entries) - actual)
assert (runtime / 'e2e/nonpolicy-phase-census.spec.ts').read_bytes() == (payload / 'nonpolicy-phase-census.spec.ts').read_bytes()
assert (runtime / 'node_modules').is_symlink()
assert hashlib.sha256((runtime / 'package-lock.json').read_bytes()).hexdigest() == '63f021d39b353a70831accbfc50b714a09767b900ce23157fbf4ecce1dda7be1'
assert (runtime / 'dist/index.html').is_file()
print(json.dumps({'distIndexSha256':hashlib.sha256((runtime / 'dist/index.html').read_bytes()).hexdigest(),'revision':manifest['revision'],'matchedGitBlobs':len(entries),
                  'extra':sorted(expected_extra),'packageLockSha256':hashlib.sha256((runtime / 'package-lock.json').read_bytes()).hexdigest()}))

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nonpolicy-phase-census.spec.ts >> officer table remains usable at uiScale 1.5
- Location: e2e/nonpolicy-phase-census.spec.ts:93:3

# Error details

```
Error: page.goto: net::ERR_HTTP_RESPONSE_CODE_FAILURE at http://localhost:4173/?debug=1&seed=42
Call log:
  - navigating to "http://localhost:4173/?debug=1&seed=42", waiting until "load"

```

```
Error: 偵測到 console error／pageerror：
[console.error] Failed to load resource: the server responded with a status of 404 ()

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "[console.error] Failed to load resource: the server responded with a status of 404 ()",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e6]:
    - heading "This localhost page can’t be found" [level=1] [ref=e7]:
      - generic [ref=e8]: This localhost page can’t be found
    - paragraph [ref=e9]:
      - text: "No webpage was found for the web address:"
      - strong [ref=e10]: http://localhost:4173/?debug=1&seed=42
    - generic [ref=e11]: HTTP ERROR 404
  - button "Reload" [ref=e14] [cursor=pointer]
```

# Test source

```ts
  1  | // Playwright smoke 共用前置（規格：plan/17-testing.md §3.8 開頭：
  2  | // 「共用前置：監聽 console 的 error 與 pageerror，出現即該條失敗」）。
  3  | // 每條 smoke（P1…）一律 import 本檔的 `test`／`expect`，而非直接用 '@playwright/test'，
  4  | // 以確保此前置對全部案例一致生效（不得每條各自重複接線）。
  5  | import { test as base, expect } from '@playwright/test';
  6  | 
  7  | export const test = base.extend<{ consoleErrorGuard: void }>({
  8  |   consoleErrorGuard: [
  9  |     async ({ page }, use) => {
  10 |       const problems: string[] = [];
  11 |       page.on('console', (msg) => {
  12 |         if (msg.type() === 'error') {
  13 |           problems.push(`[console.error] ${msg.text()}`);
  14 |         }
  15 |       });
  16 |       page.on('pageerror', (err) => {
  17 |         problems.push(`[pageerror] ${err.message}`);
  18 |       });
  19 | 
  20 |       await use();
  21 | 
> 22 |       expect(problems, `偵測到 console error／pageerror：\n${problems.join('\n')}`).toEqual([]);
     |                                                                                ^ Error: 偵測到 console error／pageerror：
  23 |     },
  24 |     { auto: true },
  25 |   ],
  26 | });
  27 | 
  28 | export { expect };
  29 | 
```
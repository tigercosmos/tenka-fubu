#!/usr/bin/env python3
"""Verify every installed pinned Pixi target and the runtime lockfile."""
import hashlib
import json
from pathlib import Path

runtime = Path('/tmp/tenka-fullnative-phase-9550-c1')
manifest = json.loads((runtime / 'tools/dependencies/pixi-8.19-patch.json').read_text())
pixi = (runtime / 'node_modules/pixi.js').resolve()
rows = []
for target in manifest['targets']:
    path = pixi / target['path']
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == target['patchedSha256'], target['path']
    rows.append({'path': target['path'], 'sha256': digest})
assert len(rows) == 29
print(json.dumps({'pixiTargetCount': len(rows), 'pixiTargets': rows,
                  'lockSha256': hashlib.sha256((runtime / 'package-lock.json').read_bytes()).hexdigest()}, indent=2))

#!/usr/bin/env python3
"""Add observation only to the exact nonpolicy responsive test source."""
from pathlib import Path
import subprocess

repo = Path('/Users/tigercosmos/tenka-fubu')
revision = '9550e397568ff448689bc5904ec0651b04bfe717'
source = subprocess.check_output(['git', 'show', f'{revision}:e2e/nonpolicy-responsive.spec.ts'], cwd=repo).decode()

def replace(old, new):
    global source
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new, 1)

replace("import type { Locator, Page } from '@playwright/test';", "import type { CDPSession, Locator, Page } from '@playwright/test';")
replace("const VIEWPORT = { width: 1280, height: 720 };", """const VIEWPORT = { width: 1280, height: 720 };
const PHASES: Array<{ label: string; timeMs: number }> = [];
let cpuSession: CDPSession | null = null;
function mark(label: string): void { PHASES.push({ label, timeMs: Date.now() }); }
test.beforeEach(async ({ page }) => {
  cpuSession = await page.context().newCDPSession(page);
  await cpuSession.send('Profiler.enable');
  await cpuSession.send('Profiler.start');
  mark('case-start');
});
test.afterEach(async ({ page }, info) => {
  void page;
  mark('case-end');
  const session = cpuSession;
  if (session) {
    const profile = await session.send('Profiler.stop');
    await writeFile(info.outputPath('cpu-profile.json'), JSON.stringify(profile));
    await session.send('Profiler.disable');
    await session.detach();
  }
  await writeFile(info.outputPath('phase-census.json'), JSON.stringify(PHASES, null, 2));
  console.log('PHASE_CENSUS', JSON.stringify(PHASES));
});""")
replace("  await page.goto('/?debug=1&seed=42');", "  mark('before-goto');\n  await page.goto('/?debug=1&seed=42');\n  mark('after-goto');")
replace("  await settings.getByRole('button', { name: '返回', exact: true }).click();\n  await page.getByTestId('title-newgame').click();", "  await settings.getByRole('button', { name: '返回', exact: true }).click();\n  mark('after-settings');\n  await page.getByTestId('title-newgame').click();")
replace("  await page.getByTestId('clan-pick-clan.oda').click();\n  await completeNewGameWizard(page);", "  await page.getByTestId('clan-pick-clan.oda').click();\n  mark('after-clan-pick');\n  await completeNewGameWizard(page);")
replace("  await expect(page.getByTestId('screen-strategy')).toBeVisible();\n  await page.getByTestId('speed-pause').click();", "  await expect(page.getByTestId('screen-strategy')).toBeVisible();\n  mark('after-wizard');\n  await page.getByTestId('speed-pause').click();")
replace("  await page.evaluate(() => window.__tenka.debug.waitMapIdle());\n}", "  await page.evaluate(() => window.__tenka.debug.waitMapIdle());\n  mark('after-map-idle');\n}")

out = Path('/tmp/tenka-fullnative-phase-derivative-c1')
out.mkdir(exist_ok=False)
(out / 'nonpolicy-phase-census.spec.ts').write_text(source)
print(out / 'nonpolicy-phase-census.spec.ts')

import { writeFile } from 'node:fs/promises';
import { test, expect } from './fixtures';

test('observe untouched native proposal monthly handoff', async ({ page }, info) => {
  test.setTimeout(90_000);
  const observations: Record<string, unknown> = {};
  const capture = async (name: string) => {
    observations[name] = await page.evaluate(() => ({
      state: window.__tenka.debug.getState(),
      log: window.__tenka.debug.exportCommandLog(),
      dialogs: [...document.querySelectorAll('[role="dialog"]')].map(n => n.textContent),
      speed: document.querySelector('[data-testid="speed-pause"]')?.getAttribute('aria-pressed'),
    }));
    await writeFile(info.outputPath('earned-proposal-observations.json'), JSON.stringify(observations, null, 2));
  };
  await page.goto('/?debug=1&seed=42');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('newgame-start').click();
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await page.getByTestId('speed-pause').click();
  await capture('initial');
  await page.getByTestId('speed-1').click();
  await expect(page.getByTestId('proposal-inbox')).toBeVisible({timeout:45_000});
  await capture('generated');
  await page.getByTestId('proposal-inbox').getByRole('button',{name:'採納',exact:true}).click();
  await capture('adoptionQueued');
  await page.getByRole('dialog').getByRole('button',{name:'全部駁回',exact:true}).click();
  await expect(page.getByTestId('month-summary')).toBeVisible();
  await capture('summary');
  await page.getByTestId('month-summary-continue').click();
  await expect.poll(()=>page.evaluate(()=>window.__tenka.debug.getState().time.day),{intervals:[50]}).toBeGreaterThan(30);
  await page.getByTestId('speed-pause').click();
  await capture('settled');
});

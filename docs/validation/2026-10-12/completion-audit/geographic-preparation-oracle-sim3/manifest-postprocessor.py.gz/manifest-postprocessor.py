import pathlib,json,hashlib
p=pathlib.Path('/tmp/geographic-preparation-original-js-20261012');frames=steps=misses=hits=errors=0;seq=set()
with (p/'full-original-js-preparation.raw.jsonl').open() as f:
 for line in f:
  j=json.loads(line);frames+=1;seq.add(j['sequence']);r=j['originalJS']['result']
  if 'undefined' in r:errors+=1;continue
  for s in r['steps']:steps+=1;misses+=s['scored'];hits+=not s['scored']
rows=[]
for x in p.iterdir():
 if x.is_file():
  h=hashlib.sha256()
  with x.open('rb') as f:
   while b:=f.read(1024*1024):h.update(b)
  rows.append({'path':str(x),'bytes':x.stat().st_size,'sha256':h.hexdigest()})
m={'frozenProductionCommit':'fc464a42f7d8b4fda97ea87f3e42cd5a7685730c','frozenProductionSHA256':'fbf127f31dbb5d8318acdf1ff1dd8bc56b77e808ba23247b779ad74ed28c3bdd','frozenReferenceSHA256':'bda5b757e2bd8a2e82c5a42fde825ebe9c846337b8a578f8413938624899d9b2','productionPrepMatchesReferenceByteExact':True,'originalProductionAndReferenceEveryCapturedFrameBitExact':True,'seedScenes':320,'randomValuesPerSeed':87,'frames':frames,'candidateSteps':steps,'scoreMisses':misses,'cacheHits':hits,'errorFrames':errors,'sequenceCount':len(seq),'numberEncoding':'originalJSfloat64littleendianbits and NaN/±Infinity/-0 classes, undefined distinct, signature exact original JSON string','newRustLoaded':False,'originalProducerTerminalExit':1,'terminalFailure':'After all raw records, bounded fixture and stream end completed: readFileSync(import.meta.url string) ENOENT while producing source-copy/manifest; no golden mismatch','postprocess':'manifest derived from retained original raw rows without rerunning any scene','files':rows}
(p/'manifest.json').write_text(json.dumps(m,indent=2));print(json.dumps(m,indent=2))

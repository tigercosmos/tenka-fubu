import sys,pathlib,json,gzip,hashlib
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text())
for r in s['artifacts']:
 z=p/r['path'];h=hashlib.file_digest(z.open('rb'),'sha256').hexdigest();assert h==r['gzipSHA256'] and z.stat().st_size==r['gzipBytes'];raw=hashlib.sha256();size=0
 with gzip.open(z,'rb') as f:
  while b:=f.read(1024*1024):raw.update(b);size+=len(b)
 assert raw.hexdigest()==r['rawSHA256'] and size==r['rawBytes']
frames=steps=misses=hits=errors=0
with gzip.open(p/'full-original-js-preparation.raw.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line);frames+=1;j=r['originalJS']['result']
  if 'undefined' in j:errors+=1;continue
  for step in j['steps']:
   steps+=1;misses+=step['scored'];hits+=not step['scored'];assert len(step['firstOffsets'])==7;assert isinstance(step['signature'],str)
assert (frames,steps,misses,hits,errors)==(1964,5482,3025,2457,1);assert s['newRustLoaded'] is False and s['originalProducerTerminalExit']==1;print('PASS: original raw255263393bytes dualSHA, source/producer pins,1964actualframes/5482steps/3025misses/2457hits/1expectedinvalidrect; original packagingRED preserved')

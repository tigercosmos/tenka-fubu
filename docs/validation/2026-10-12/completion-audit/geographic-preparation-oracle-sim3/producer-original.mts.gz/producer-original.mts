import {readFileSync,writeFileSync,mkdirSync,createWriteStream} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createGeographicPreparationOracle,GEOGRAPHIC_PREPARATION_ORACLE_SOURCES} from '/Users/tigercosmos/tenka-fubu/tests/helpers/geographicPreparationOracle.ts';
const repo='/Users/tigercosmos/tenka-fubu';const out='/tmp/geographic-preparation-original-js-20261012';mkdirSync(out,{recursive:true});
const source=execFileSync('git',['show','fc464a4:src/ui/map/geographicLabelLayout.ts'],{cwd:repo,encoding:'utf8'});const reference=readFileSync(repo+'/tests/helpers/geographicWasmReference.ts','utf8');
const prep=(s:string)=>s.slice(s.indexOf('  obstacles.forEach(validate);'),s.indexOf('    let best = { x: 0, y: 0 },'));
if(prep(source)!==prep(reference))throw Error('Frozen production/reference preparation blocks differ');
writeFileSync(out+'/frozen-production-geographicLabelLayout.ts',source);writeFileSync(out+'/frozen-reference-geographicWasmReference.ts',reference);writeFileSync(out+'/frozen-roadLabelCapsules.ts',readFileSync(repo+'/src/ui/map/roadLabelCapsules.ts'));
const hash=(s:Buffer|string)=>createHash('sha256').update(s).digest('hex');
function encode(v:unknown):unknown{
 if(typeof v==='number'){const b=Buffer.allocUnsafe(8);b.writeDoubleLE(v);return {f64le:b.toString('hex'),class:Number.isNaN(v)?'NaN':v===Infinity?'+Infinity':v===-Infinity?'-Infinity':Object.is(v,-0)?'-0':'finite'};}
 if(v===undefined)return {undefined:true};if(v===null||typeof v!=='object')return v;
 if(Object.prototype.toString.call(v)==='[object Map]')return {map:[...(v as Map<unknown,unknown>)].map(([k,x])=>[encode(k),encode(x)])};
 if(Array.isArray(v))return v.map(encode);return Object.fromEntries(Object.keys(v).map(k=>[k,encode((v as Record<string,unknown>)[k]) ]));
}
const output=createWriteStream(out+'/full-original-js-preparation.raw.jsonl');const bitsHash=createHash('sha256');let frames=0,candidates=0,misses=0,hits=0;const bounded:unknown[]=[];
function runSequence(name:string,sequence:{labels:any[];primary:any[];hard:any[]}[]){const a=createGeographicPreparationOracle(source);const b=createGeographicPreparationOracle();
 for(let i=0;i<sequence.length;i++){
  const frame=sequence[i]!;let actual:unknown,expected:unknown,errorA:unknown,errorB:unknown;
  try{actual=a.layout(frame.labels,frame.primary,frame.hard);}catch(e){errorA={name:(e as Error).name,message:(e as Error).message};}
  try{expected=b.layout(frame.labels,frame.primary,frame.hard);}catch(e){errorB={name:(e as Error).name,message:(e as Error).message};}
  const sa=JSON.stringify(encode({result:actual,error:errorA})),sb=JSON.stringify(encode({result:expected,error:errorB}));if(sa!==sb)throw Error('Frozen oracle difference '+name+'/'+i);
  const row={sequence:name,frame:i,input:encode(frame),originalJS:encode({result:actual,error:errorA})};const line=JSON.stringify(row)+'\n';output.write(line);bitsHash.update(line);frames++;
  if(actual){const steps=(actual as any).steps;candidates+=steps.length;misses+=steps.filter((x:any)=>x.scored).length;hits+=steps.filter((x:any)=>!x.scored).length;
   if(bounded.length<12&&i===0)bounded.push(row);
  }
 }
}
let state=0x7e691755;const random=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/0x100000000;};
for(let seed=0;seed<320;seed++){
 const labels=Array.from({length:3},(_,i)=>({id:['😀','\uE000','a'][i],kind:i===0?'province':i===1?'road':'district',rect:{x:random()*180-90,y:random()*100-50,width:random()*70,height:random()*25},...(i===1?{roadLine:{normal:{x:random()-.5,y:random()-.5},slack:random()*30},roadCapsules:[{a:{x:-60,y:-20},b:{x:100,y:60},radius:2}]}:{})}));
 const primary=Array.from({length:18},()=>({x:random()*300-150,y:random()*240-120,width:random()*60,height:random()*35}));const hard=primary.filter((_,i)=>i%5===0).reverse();
 const changed=structuredClone(primary);changed[0]!.x+=1/8;const road=structuredClone(labels);road[1]!.roadLine!.slack+=1/16;const rect=structuredClone(road);rect[0]!.rect.width+=1/32;
 runSequence('seed'+seed,[{labels,primary,hard},{labels:structuredClone(labels),primary:structuredClone(primary),hard:structuredClone(hard)},{labels,primary:changed,hard},{labels:road,primary:changed,hard},{labels:rect,primary:changed,hard},{labels:rect.slice(1),primary:changed,hard}]);
}
const label=(id='a',rect={x:0,y:0,width:20,height:10})=>({id,kind:'district',rect});
for(const epsilon of [-(2**-40),-0,0,2**-40]){
 const labels=[label('signed',{x:-0,y:-0,width:20,height:10})];const primary=Array.from({length:25},(_,i)=>({x:(i%2?-1:1)*(i+1)+epsilon,y:(i%2?1:-1)*(i+1),width:20,height:10,tag:'r'+i}));primary.push({x:68+epsilon,y:0,width:0,height:0,tag:'edge'},{x:-52+epsilon,y:-0,width:0,height:0,tag:'edge2'});runSequence('epsilon'+Object.is(epsilon,-0)+'/'+epsilon,[{labels,primary,hard:primary.slice(0,4)},{labels,primary:[...primary].reverse(),hard:[...primary.slice(0,4)].reverse()}]);
}
for(const magnitude of [1e16,1e100,1e308])for(const sign of [-1,1])for(const size of [0,magnitude]){const rect={x:sign*magnitude,y:sign*magnitude,width:size,height:size};if(![rect.x+rect.width+4,rect.y+rect.height+4].every(Number.isFinite))continue;const labels=[label('extreme',rect)],primary=[rect,{x:-sign*magnitude,y:-sign*magnitude,width:0,height:0}];runSequence('extreme/'+sign+'/'+magnitude+'/'+size,[{labels,primary,hard:primary},{labels:structuredClone(labels),primary:structuredClone(primary),hard:structuredClone(primary)}]);}
const metadata=[{x:10,y:-0,width:10,height:10,tag:'first',more:{value:1},omit:undefined},{x:10,y:-0,width:10,height:10,tag:'second',more:{value:2}}];const changedMeta=structuredClone(metadata);changedMeta[0]!.more.value=3;runSequence('metadataAndKeyOrder',[{labels:[label()],primary:metadata,hard:[]},{labels:[label()],primary:changedMeta,hard:[]},{labels:[label()],primary:[...changedMeta].reverse(),hard:[]},{labels:[],primary:[],hard:[]},{labels:[label()],primary:metadata,hard:[]}]);
const capsules=Array.from({length:256},()=>({a:{x:-100,y:-100},b:{x:100,y:100},radius:2}));runSequence('capsuleStates',[{labels:[label()],primary:[],hard:[]},{labels:[{...label(),roadCapsules:null}],primary:[],hard:[]},{labels:[{...label(),roadCapsules:[]}],primary:[],hard:[]},{labels:[{...label(),roadCapsules:capsules}],primary:[],hard:[]}]);
runSequence('invalidRoadNumbers',[{labels:[{...label(),roadLine:{normal:{x:NaN,y:-0},slack:0}}],primary:[],hard:[]},{labels:[{...label(),roadLine:{normal:{x:0,y:1},slack:Infinity}}],primary:[],hard:[]}]);
const far=Array.from({length:8192},(_,i)=>({x:i%2?-20:20,y:1e6+i,width:30,height:10,tag:'far'+i}));runSequence('largeFar8192',[{labels:[label()],primary:far,hard:[]},{labels:[label()],primary:structuredClone(far),hard:[]}]);
runSequence('invalidOverflowRect',[{labels:[label('invalid',{x:1e308,y:0,width:1e308,height:1})],primary:[],hard:[]}]);
await new Promise<void>((resolve,reject)=>{output.on('error',reject);output.end(resolve);});
writeFileSync(out+'/bounded-first12-original-js.json',JSON.stringify(bounded));writeFileSync(out+'/producer.mts',readFileSync(import.meta.url));
writeFileSync(out+'/manifest.json',JSON.stringify({sources:GEOGRAPHIC_PREPARATION_ORACLE_SOURCES,producerSHA256:hash(readFileSync(import.meta.url)),helperSHA256:hash(readFileSync(repo+'/tests/helpers/geographicPreparationOracle.ts')),productionPrepMatchesReferenceByteExact:true,seed:0x7e691755,randomValuesPerSeed:87,seedScenes:320,frames,candidates,misses,hits,rawSHA256:bitsHash.digest('hex'),rawBytes:readFileSync(out+'/full-original-js-preparation.raw.jsonl').length,numberEncoding:'every number is original JS float64 little-endian hex plus NaN/Infinity/-0 class; undefined represented distinctly; actual JSON cache signature string retained verbatim',newRustLoaded:false},null,2));
console.log(readFileSync(out+'/manifest.json','utf8'));

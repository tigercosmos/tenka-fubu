import os,pathlib,subprocess,json,datetime
r=pathlib.Path('/tmp/tenka-fused-current23-20261012');out=pathlib.Path('/tmp/tenka-fused-current23-evidence');env=os.environ.copy();env['PATH']='/home/anchi/.nvm/versions/node/v22.23.3/bin:'+env['PATH'];env.update(VISUAL_GPU='1',VISUAL_PERF='1',CI='1');status=[]
for camera in ['overview','operational','close']:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();log=pathlib.Path('/tmp/tenka-fused-current23-'+camera+'.log');folder=pathlib.Path('/tmp/tenka-fused-current23-'+camera+'-results')
 argv=['npx','playwright','test','e2e/national120-map-perf.spec.ts','--project=chromium','--workers=1','--retries=0','--grep',camera+':','--output='+str(folder)]
 with log.open('wb') as f:code=subprocess.run(argv,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 raws=list(folder.rglob('national-'+camera+'-frames.json'));gpu=None;guard=False
 if len(raws)==1:
  gpu=json.loads(raws[0].read_text())['environment'];guard='RTX 5070 Ti' in gpu['renderer'] and 'Vulkan' in gpu['renderer'] and 'NVIDIA' in gpu['renderer']
 status.append({'camera':camera,'argv':argv,'startedUTC':started,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminalExit':code,'log':str(log),'raw':str(raws[0]) if len(raws)==1 else None,'actualControlGPU':gpu,'actualRTXVulkanGuard':guard})
 (out/'fps-driver-status.json').write_text(json.dumps(status,indent=2))
 if not guard:raise RuntimeError('Actual control GPU guard RED: STOP without retry')
 print(json.dumps(status[-1]),flush=True)

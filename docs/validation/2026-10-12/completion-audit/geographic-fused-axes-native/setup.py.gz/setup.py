from pathlib import Path
import tarfile,shutil
r=Path('/tmp/tenka-fused-current23-20261012');r.mkdir(exist_ok=True)
with tarfile.open('/tmp/sim3-fused-current23-source.tar.gz') as t:t.extractall(r,filter='data')
if not (r/'node_modules').exists():(r/'node_modules').symlink_to('/tmp/tenka-national120-current23-20261012/node_modules')
(r/'e2e').mkdir(exist_ok=True)
for n in ['fixtures.ts','national120-map-perf.spec.ts']:shutil.copyfile('/tmp/tenka-national120-current23-20261012/e2e/'+n,r/'e2e'/n)
p=Path('/tmp/tenka-national120-current23-20261012/national120-published.mjs').read_text()
capture="""
 const gpuCapture=async(name)=>{const gpu=await page.evaluate(()=>[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return{width:canvas.width,height:canvas.height,context:null};const ext=gl.getExtension('WEBGL_debug_renderer_info');return{width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',contextLost:gl.isContextLost(),renderer:String(gl.getParameter(ext?ext.UNMASKED_RENDERER_WEBGL:gl.RENDERER)),vendor:String(gl.getParameter(ext?ext.UNMASKED_VENDOR_WEBGL:gl.VENDOR))};}));writeFileSync('/tmp/tenka-fused-current23-gpu-'+name+'.json',JSON.stringify(gpu));const active=gpu.find(g=>g.context);if(!active||!active.renderer.includes('RTX 5070 Ti')||!active.renderer.includes('Vulkan')||active.contextLost)throw Error('Actual RTX Vulkan GPU guard failed');};
 await gpuCapture('before');
"""
p=p.replace(' const snapshots=[];',capture+' const snapshots=[];').replace(' const driver=await page.evaluate'," await gpuCapture('after-functional');\n const driver=await page.evaluate")
(r/'national120-published.mjs').write_text(p)
p=Path('/tmp/tenka-castle-current23-20261012/castle-current23-profile.mjs').read_text().replace('tenka-castle-current23','tenka-fused-current23')
p=p.replace(' const before=await page.evaluate',capture.replace("'before'","'before-profile'")+' const before=await page.evaluate').replace(' const after=await page.evaluate'," await gpuCapture('after-profile');\n const after=await page.evaluate")
(r/'fused-current23-profile.mjs').write_text(p)
p=Path('/tmp/tenka-castle-current23-20261012/diagnostics/main-profile-analysis.mjs').read_text()
p=p.replace("JSON.parse(readFileSync('/tmp/tenka-worker-batch-hardware-sim3-evidence/main-cpu-profile.json','utf8')).profile","JSON.parse(readFileSync('/tmp/tenka-fused-current23-close.cpuprofile','utf8'))")
p=p.replace('/tmp/tenka-worker-batch-hardware-sim3-evidence/main-profile-analysis.json','/tmp/tenka-fused-current23-close-profile-source-summary.json').replace('oneNativeWorker120BatchMainCPUProfile/notAcceptanceFPS','separate10secondcloseProfile/notAcceptanceFPS')
(r/'fused-current23-profile-analysis.mjs').write_text(p)

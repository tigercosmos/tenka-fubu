import sys,pathlib,json,gzip,hashlib
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text())
def read(n):return json.loads(gzip.decompress((p/(n+'.gz')).read_bytes()))
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert hashlib.sha256(z).hexdigest()==a['gzipSHA256'];assert hashlib.sha256(b).hexdigest()==a['rawSHA256']
for phase in ['before','after','final']:
 q=read('source-'+phase+'-proof.json');assert q['allMatch'] and len(q['files'])==1405 and not q['extras'] and not q['publicSymlinks']
 q=read('dependency-'+phase+'-proof.json');assert len(q['files'])==14765 and len(q['patches'])==23 and all(r['match'] for r in q['files']+q['patches'])
published=gzip.decompress((p/'published.raw.json.gz').read_bytes());assert hashlib.sha256(published).hexdigest()=='af4ddbc9c9232041f23b3cd37fdb802681d1ffce7a4709eaa7dc5031f6cebe29'
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');assert 'RTX 5070 Ti' in q['environment']['renderer'] and 'Vulkan' in q['environment']['renderer'];assert q['measurement']['resourcesBefore']==q['measurement']['resourcesAfter'];assert '1 failed' in gzip.decompress((p/(c+'.log.gz')).read_bytes()).decode()
for q in read('state-resource-proof.json'):assert q['canonicalByteEqual'] and q['resourceObjectsEqual'] and q['canonicalBeforeSha256']==q['canonicalAfterSha256']
q=read('close-profile-summary.json');assert q['canonicalStateByteEqual'] and q['driver']['ticks']==0 and q['canonicalBeforeSha256']==q['canonicalAfterSha256'] and q['resourceBeforeSha256']==q['resourceAfterSha256']
for n in ['gpu-before','gpu-after-functional','gpu-before-profile','gpu-after-profile']:
 q=next(r for r in read(n+'.json') if r['context']);assert 'RTX 5070 Ti' in q['renderer'] and 'Vulkan' in q['renderer'] and not q['contextLost']
assert read('setup-original-red-status.json')['terminalExit']==127 and s['candidateStatus']=='withdrawn';print('PASS: all dual hashes, three full source/dependency checkpoints, exact9payload, three original strict60REDs, RTX guards, exact canonical/resource proofs, original setupRED, withdrawn scope')

import{e as s,r as e,s as a,t}from"./vendor-pixi-tMCd1M7V.js";s.add(e,a);s.add(t);
//# sourceMappingURL=webworkerAll-y0dQvs9x.js.map

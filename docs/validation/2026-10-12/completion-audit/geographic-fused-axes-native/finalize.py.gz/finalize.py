import pathlib,hashlib,json,shutil
r=pathlib.Path('/tmp/tenka-fused-current23-20261012');o=pathlib.Path('/tmp/tenka-fused-current23-evidence');h=lambda b:hashlib.sha256(b).hexdigest()
for name,p in {'close.cpuprofile':'/tmp/tenka-fused-current23-close.cpuprofile','close-profile-summary.json':'/tmp/tenka-fused-current23-close-profile-summary.json','close-profile-source-summary.json':'/tmp/tenka-fused-current23-close-profile-source-summary.json','profile.log':'/tmp/tenka-fused-current23-profile.log','profile-analysis.log':'/tmp/tenka-fused-current23-profile-analysis.log','profile.mjs':str(r/'fused-current23-profile.mjs'),'profile-analysis.mjs':str(r/'fused-current23-profile-analysis.mjs'),'collect.py':'/tmp/sim3-fused-current23-collect.py','state-proof.py':'/tmp/sim3-fused-current23-state-proof.py','setup.py':'/tmp/sim3-fused-current23-setup.py','fps-driver.py':'/tmp/sim3-fused-run-controls.py','setup-original-red.log':'/tmp/sim3-fused-shell-setup-original-red.log','setup-original-red-status.json':'/tmp/sim3-fused-shell-setup-original-red-status.json'}.items():shutil.copyfile(p,o/name)
for p in pathlib.Path('/tmp').glob('tenka-fused-current23-gpu-*.json'):shutil.copyfile(p,o/p.name.replace('tenka-fused-current23-',''))
source=['src/ui/map/geographicLabelLayout.ts','src/ui/map/wasmGeographicScorer.ts','src/ui/map/wasmCastleRibbonPlanner.ts','src/ui/map/MapRenderer.ts','src/ui/map/MapCanvasHost.tsx','rust/engine/src/geographic.rs','rust/engine/src/lib.rs','tools/wasm/artifact.ts']
for n in source:shutil.copyfile(r/n,o/n.replace('/','__'))
# Preserve all served JS and corresponding maps for actual current-profile location verification.
bundles=[]
for p in (r/'dist').rglob('*'):
 if p.is_file() and (p.name.endswith('.js') or p.name.endswith('.js.map')):
  b=p.read_bytes();name=str(p.relative_to(r)).replace('/','__');shutil.copyfile(p,o/name);bundles.append({'sourcePath':str(p),'artifact':name,'bytes':len(b),'sha256':h(b)})
(o/'actual-js-bundle-manifest.json').write_text(json.dumps(bundles,indent=2))
env=json.load(open('/tmp/tenka-castle-current23-evidence/environment.json'));env['replica']=str(r);env['sourceCommit']='5224c06';env['driverHashes']=[]
for p in [r/'playwright.config.ts',r/'e2e/fixtures.ts',r/'e2e/national120-map-perf.spec.ts',r/'national120-published.mjs',r/'fused-current23-profile.mjs',pathlib.Path('/home/anchi/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome')]:
 b=p.read_bytes();env['driverHashes'].append({'path':str(p),'bytes':len(b),'sha256':h(b)})
(o/'environment.json').write_text(json.dumps(env,indent=2));(o/'gpu-driver-hashes.json').write_bytes(pathlib.Path('/tmp/tenka-castle-current23-evidence/gpu-driver-hashes.json').read_bytes())
t=pathlib.Path('/tmp/sim3-fused-current23-source.tar.gz');(o/'transfer-proof.json').write_text(json.dumps({'path':str(t),'bytes':t.stat().st_size,'sha256':h(t.read_bytes()),'frozenCommit':'5224c06','scope':'all frozen src/public/rust/tools/tests and root code/config; external drivers copied separately'},indent=2))
print(len(list(o.iterdir())))

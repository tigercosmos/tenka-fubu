import json,pathlib,collections
root=pathlib.Path(__file__).parent
rows=[]
for label in ['before','after']:
 s=json.loads((root/(label+'.heapsnapshot')).read_text());m=s['snapshot']['meta'];nf=m['node_fields'];ef=m['edge_fields'];nw=len(nf);ew=len(ef);ns=s['nodes'];es=s['edges'];strings=s['strings'];nt=m['node_types'][nf.index('type')];et=m['edge_types'][ef.index('type')];cursor=0;groups=[]
 for i in range(0,len(ns),nw):
  end=cursor+ns[i+nf.index('edge_count')]*ew
  if nt[ns[i+nf.index('type')]]=='object':
   props={strings[es[e+ef.index('name_or_index')]]:es[e+ef.index('to_node')] for e in range(cursor,end,ew) if et[es[e+ef.index('type')]]=='property'}
   if all(k in props for k in ['resources','_dirty','_key']):
    get=lambda k:strings[ns[props[k]+nf.index('name')]]
    groups.append(dict(id=ns[i+nf.index('id')],name=strings[ns[i+nf.index('name')]],resourcesTargetName=get('resources'),keyTargetName=get('_key')))
  cursor=end
 counts=collections.Counter((r['name'],r['resourcesTargetName']) for r in groups)
 rows.append(dict(snapshot=label,scope='property-shape bind-group candidates; resources target names, not retained sizes, allocation ages or renderer ownership',count=len(groups),nullResources=sum(r['resourcesTargetName']=='null' for r in groups),groups=[dict(name=n,resources=r,count=c) for (n,r),c in counts.most_common()],rows=groups))
(root/'group-counts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='rows'} for r in rows],indent=2))

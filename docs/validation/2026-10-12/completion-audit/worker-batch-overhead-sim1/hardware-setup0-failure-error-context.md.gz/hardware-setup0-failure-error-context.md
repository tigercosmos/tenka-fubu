# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: worker120-hardware.spec.ts >> one RTX-controlled profiled120 warm Worker batch with full native parity and transport observations
- Location: diagnostics/worker120-hardware.spec.ts:139:1

# Error details

```
Error: browserType.launch: Executable doesn't exist at /home/anchi/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```
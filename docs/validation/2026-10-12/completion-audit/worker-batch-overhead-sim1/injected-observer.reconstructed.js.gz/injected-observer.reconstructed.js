(() => {
    const evidence = {
      created: 0,
      sent: [],
      received: [],
      longTasks: []
    };
    window.__workerEvidence = evidence;
    const NativeWorker = window.Worker;
    window.Worker = new Proxy(NativeWorker, {
      construct(target, argumentsList) {
        const worker = Reflect.construct(target, argumentsList);
        const postMessage = worker.postMessage.bind(worker);
        evidence.created++;
        Object.defineProperty(worker, 'postMessage', {
          value: (...args) => {
            var _data$kind, _data$requestId, _data$epoch, _data$beforeStateVers;
            const data = args[0];
            const observation = {
              kind: (_data$kind = data === null || data === void 0 ? void 0 : data.kind) !== null && _data$kind !== void 0 ? _data$kind : null,
              requestId: (_data$requestId = data === null || data === void 0 ? void 0 : data.requestId) !== null && _data$requestId !== void 0 ? _data$requestId : null,
              epoch: (_data$epoch = data === null || data === void 0 ? void 0 : data.epoch) !== null && _data$epoch !== void 0 ? _data$epoch : null,
              beforeStateVersion: (_data$beforeStateVers = data === null || data === void 0 ? void 0 : data.beforeStateVersion) !== null && _data$beforeStateVers !== void 0 ? _data$beforeStateVers : null,
              postedAt: performance.now(),
              returnedAt: 0
            };
            evidence.sent.push(observation);
            Reflect.apply(postMessage, worker, args);
            observation.returnedAt = performance.now();
          }
        });
        worker.addEventListener('message', event => {
          var _data$state$ai$clans, _data$state, _data$kind2, _data$requestId2, _data$backend, _data$epoch2, _data$computeMs, _data$beforeStateVers2;
          const receivedAt = performance.now();
          const data = event.data;
          const inconsistentThreatTotals = Object.entries((_data$state$ai$clans = (_data$state = data.state) === null || _data$state === void 0 ? void 0 : _data$state.ai.clans) !== null && _data$state$ai$clans !== void 0 ? _data$state$ai$clans : {}).filter(([, clan]) => clan.threatCache !== null).map(([clanId, clan]) => ({
            clanId,
            total: clan.threatCache.totalThreat,
            sum: clan.threatCache.entries.reduce((sum, entry) => sum + entry.threat, 0)
          })).filter(entry => Math.abs(entry.total - entry.sum) > 1e-9);
          evidence.received.push({
            kind: (_data$kind2 = data === null || data === void 0 ? void 0 : data.kind) !== null && _data$kind2 !== void 0 ? _data$kind2 : null,
            requestId: (_data$requestId2 = data === null || data === void 0 ? void 0 : data.requestId) !== null && _data$requestId2 !== void 0 ? _data$requestId2 : null,
            backend: (_data$backend = data === null || data === void 0 ? void 0 : data.backend) !== null && _data$backend !== void 0 ? _data$backend : null,
            epoch: (_data$epoch2 = data === null || data === void 0 ? void 0 : data.epoch) !== null && _data$epoch2 !== void 0 ? _data$epoch2 : null,
            computeMs: (_data$computeMs = data === null || data === void 0 ? void 0 : data.computeMs) !== null && _data$computeMs !== void 0 ? _data$computeMs : null,
            beforeStateVersion: (_data$beforeStateVers2 = data === null || data === void 0 ? void 0 : data.beforeStateVersion) !== null && _data$beforeStateVers2 !== void 0 ? _data$beforeStateVers2 : null,
            receivedAt,
            inconsistentThreatTotals
          });
        });
        return worker;
      }
    });
    new PerformanceObserver(list => {
      for (const entry of list.getEntries()) evidence.longTasks.push({
        startTime: entry.startTime,
        duration: entry.duration
      });
    }).observe({
      type: 'longtask',
      buffered: true
    });
  })(undefined)
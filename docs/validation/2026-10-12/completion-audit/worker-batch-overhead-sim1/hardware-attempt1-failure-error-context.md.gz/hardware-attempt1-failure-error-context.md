# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: worker120-hardware.spec.ts >> one RTX-controlled profiled120 warm Worker batch with full native parity and transport observations
- Location: diagnostics/worker120-hardware.spec.ts:139:1

# Error details

```
TypeError: expect(received).toMatch(expected)

Matcher error: received value must be a string

Received has value: undefined
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1560年1月2日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 2,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 11,986
            - generic "兵糧可支撐26個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "26"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 4,517
            - generic [ref=e44]: /4,662
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "250"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic:
    - generic:
      - generic:
        - button:
          - img
  - img "全國小地圖" [ref=e119]
  - button "報告中心" [ref=e122] [cursor=pointer]
```

# Test source

```ts
  64  |             backend?: unknown;
  65  |             epoch?: unknown;
  66  |             computeMs?: unknown;
  67  |             beforeStateVersion?: unknown;
  68  |             state?: GameState;
  69  |           };
  70  |           const inconsistentThreatTotals = Object.entries(data.state?.ai.clans ?? {})
  71  |             .filter(([, clan]) => clan.threatCache !== null)
  72  |             .map(([clanId, clan]) => ({
  73  |               clanId,
  74  |               total: clan.threatCache!.totalThreat,
  75  |               sum: clan.threatCache!.entries.reduce((sum, entry) => sum + entry.threat, 0),
  76  |             }))
  77  |             .filter((entry) => Math.abs(entry.total - entry.sum) > 1e-9);
  78  |           evidence.received.push({
  79  |             kind: data?.kind ?? null,
  80  |             requestId: data?.requestId ?? null,
  81  |             backend: data?.backend ?? null,
  82  |             epoch: data?.epoch ?? null,
  83  |             computeMs: data?.computeMs ?? null,
  84  |             beforeStateVersion: data?.beforeStateVersion ?? null,
  85  |             receivedAt,
  86  |             inconsistentThreatTotals,
  87  |           });
  88  |         });
  89  |         return worker;
  90  |       },
  91  |     });
  92  |     new PerformanceObserver((list) => {
  93  |       for (const entry of list.getEntries())
  94  |         evidence.longTasks.push({ startTime: entry.startTime, duration: entry.duration });
  95  |     }).observe({ type: 'longtask', buffered: true });
  96  |   });
  97  | }
  98  | 
  99  | async function snapshot(page: Page): Promise<GameState> {
  100 |   return JSON.parse(
  101 |     await page.evaluate<string>(
  102 |       `(${encodeFullSnapshot.toString()})(window.__tenka.debug.getState())`,
  103 |     ),
  104 |   ) as GameState;
  105 | }
  106 | 
  107 | function synchronousReference(
  108 |   initial: GameState,
  109 |   commands: readonly Command[],
  110 |   days: number,
  111 |   loaded = false,
  112 | ) {
  113 |   const state = structuredClone(initial);
  114 |   const queue = new CommandQueue(state.meta.lastAppliedCmdSeq + 1);
  115 |   for (const command of commands) queue.enqueue(command, state.time.day);
  116 |   const catalog = zCanonicalEventsFile.parse(
  117 |     JSON.parse(
  118 |       readFileSync(new URL('../src/data/scenarios/s1560/events.json', import.meta.url), 'utf8'),
  119 |     ),
  120 |   );
  121 |   const engine = createRuntimeEventEngine(catalog.events);
  122 |   const recorder = new CommandLogRecorder();
  123 |   if (loaded) recorder.reset({ incompleteReason: 'loadedGame' });
  124 |   for (let day = 0; day < days; day++) {
  125 |     enqueuePendingAiOrders(state, queue);
  126 |     const submitted = queue.drain();
  127 |     const result = advanceDay(state, submitted, { eventEngine: engine });
  128 |     recorder.recordTick(result.appliedCommands, {
  129 |       ...(result.appliedCommands.length === submitted.length
  130 |         ? {}
  131 |         : { incompleteReason: 'hardRejection' as const }),
  132 |     });
  133 |   }
  134 |   return { state, log: recorder.export(state) };
  135 | }
  136 | 
  137 | // Independent observer experiment: exactly one profiled120-day Worker batch.
  138 | // Accepted six-case suite, production source and browser flags stay unchanged.
  139 | test('one RTX-controlled profiled120 warm Worker batch with full native parity and transport observations', async ({ page }, info) => {
  140 |   const http: { url: string; status: number }[] = [];
  141 |   page.on('response', (response) => {
  142 |     if (new URL(response.url()).pathname.endsWith('/wasm/tenka_engine.wasm'))
  143 |       http.push({url: response.url(), status:response.status()});
  144 |   });
  145 |   await observeWorkerTraffic(page);
  146 |   await nativeGame(page);
  147 |   await page.evaluate(() => window.__tenka.debug.waitMapIdle(2));
  148 |   const freshInitial = await snapshot(page);
  149 |   const initialLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  150 |   await page.evaluate(() => window.__tenka.debug.stepDaysAsync(1));
  151 |   await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  152 |   const warmInitial = await snapshot(page);
  153 |   const warmLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  154 |   const before = await page.evaluate(() => ({ simulation:window.__tenka.debug.getSimulationDiagnostics(), map:window.__tenka.debug.getMapDiagnostics() }));
  155 |   const captureGpu = async () => {
  156 |     const identity=await page.evaluate(()=>({canvases:[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return {width:canvas.width,height:canvas.height,context:null};const extension=gl.getExtension('WEBGL_debug_renderer_info');return {width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',contextLost:gl.isContextLost(),unmaskedVendor:extension?gl.getParameter(extension.UNMASKED_VENDOR_WEBGL):null,unmaskedRenderer:extension?gl.getParameter(extension.UNMASKED_RENDERER_WEBGL):null};})}));
  157 |     const browserSession=await page.context().browser()!.newBrowserCDPSession();
  158 |     const system=await browserSession.send('SystemInfo.getInfo');await browserSession.detach();
  159 |     return {identity,system};
  160 |   };
  161 |   const beforeGpu=await captureGpu();
  162 |   await writeFile('/tmp/tenka-04c7b60-worker-batch-hardware-evidence/hardware-preflight.json',JSON.stringify({beforeGpu,freshInitial,initialLog,warmInitial,warmLog,before}));
  163 |   const activeGpu=beforeGpu.identity.canvases.find(canvas=>canvas.context!==null);
> 164 |   expect(activeGpu?.unmaskedRenderer).toMatch(/NVIDIA.*RTX|RTX/);
      |                                       ^ TypeError: expect(received).toMatch(expected)
  165 |   expect(activeGpu?.unmaskedRenderer).not.toMatch(/SwiftShader|llvmpipe/i);
  166 |   expect(activeGpu?.contextLost).toBe(false);
  167 |   const cdp=await page.context().newCDPSession(page);
  168 |   await cdp.send('Profiler.enable');
  169 |   await cdp.send('Profiler.start');
  170 |   let profile: unknown;
  171 |   let measurement: unknown;
  172 |   try {
  173 |     measurement=await page.evaluate(async () => {
  174 |       const tasks:{startTime:number;duration:number}[]=[];
  175 |       const frames:number[]=[];
  176 |       const observer=new PerformanceObserver(list=>{for(const entry of list.getEntries())tasks.push({startTime:entry.startTime,duration:entry.duration});});
  177 |       observer.observe({type:'longtask'});
  178 |       let frame=0;
  179 |       const onFrame=()=>{frames.push(performance.now());frame=requestAnimationFrame(onFrame);};
  180 |       frame=requestAnimationFrame(onFrame);
  181 |       await new Promise(resolve=>setTimeout(resolve,50));
  182 |       const initialDay=window.__tenka.debug.getState().time.day;
  183 |       const stepStart=performance.now();
  184 |       await window.__tenka.debug.stepDaysAsync(120);
  185 |       const stepEnd=performance.now();
  186 |       const idleStart=performance.now();
  187 |       await window.__tenka.debug.waitSimulationIdle();
  188 |       const idleEnd=performance.now();
  189 |       await new Promise(resolve=>setTimeout(resolve,50));
  190 |       await new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
  191 |       cancelAnimationFrame(frame);observer.disconnect();
  192 |       return { requestedDays:120,completedDays:window.__tenka.debug.getState().time.day-initialDay,stepStart,stepEnd,idleStart,idleEnd,stepMs:stepEnd-stepStart,idleMs:idleEnd-idleStart,totalMs:idleEnd-stepStart,frames,frameGapsMs:frames.slice(1).map((x,i)=>x-frames[i]!),longTasks:tasks.filter(t=>t.startTime<idleEnd&&t.startTime+t.duration>stepStart),simulation:window.__tenka.debug.getSimulationDiagnostics() };
  193 |     });
  194 |   } finally {
  195 |     profile=await cdp.send('Profiler.stop');
  196 |     await cdp.detach();
  197 |     await writeFile('/tmp/tenka-04c7b60-worker-batch-hardware-evidence/main-cpu-profile.json',JSON.stringify(profile));
  198 |   }
  199 |   const afterGpu=await captureGpu();
  200 |   await writeFile('/tmp/tenka-04c7b60-worker-batch-hardware-evidence/hardware-postflight.json',JSON.stringify(afterGpu));
  201 |   const actual=await snapshot(page);
  202 |   const actualLog=await page.evaluate(()=>window.__tenka.debug.exportCommandLog());
  203 |   const after=await page.evaluate(()=>({simulation:window.__tenka.debug.getSimulationDiagnostics(),map:window.__tenka.debug.getMapDiagnostics(),traffic:(window as unknown as {__workerEvidence:unknown}).__workerEvidence}));
  204 |   const reference=synchronousReference(freshInitial,[],121);
  205 |   const warmReference=synchronousReference(freshInitial,[],1);
  206 |   const observation={beforeGpu,afterGpu,freshInitial,initialLog,warmInitial,warmLog,before,measurement,actual,actualLog,after,reference,warmReference,http};
  207 |   await writeFile('/tmp/tenka-04c7b60-worker-batch-hardware-evidence/observation.json',JSON.stringify(observation));
  208 |   await info.attach('worker120-observation',{body:JSON.stringify(observation),contentType:'application/json'});
  209 |   const afterActiveGpu=afterGpu.identity.canvases.find(canvas=>canvas.context!==null);
  210 |   expect(afterActiveGpu?.unmaskedRenderer).toMatch(/NVIDIA.*RTX|RTX/);
  211 |   expect(afterActiveGpu?.unmaskedRenderer).not.toMatch(/SwiftShader|llvmpipe/i);
  212 |   expect(afterActiveGpu?.contextLost).toBe(false);
  213 |   expect(warmInitial).toEqual(warmReference.state);
  214 |   expect(warmLog).toEqual(warmReference.log);
  215 |   expect(actual.time.day).toBe(121);
  216 |   expect(validateState(actual)).toEqual([]);
  217 |   expect(actual).toEqual(reference.state);
  218 |   expect(actualLog).toEqual(reference.log);
  219 | });
  220 | 
```
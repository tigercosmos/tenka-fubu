import type { Page } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
import { test, expect } from '../e2e/fixtures';
async function nativeGame(page: Page) {
  await page.goto('/?debug=1&seed=1');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('newgame-start').click();
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
}

test('read only current GL identity under the same default headless setup', async ({page})=>{
 await nativeGame(page);
 await page.evaluate(()=>window.__tenka.debug.waitMapIdle(2));
 const identity=await page.evaluate(()=>({userAgent:navigator.userAgent,canvases:[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return {width:canvas.width,height:canvas.height,context:null};const extension=gl.getExtension('WEBGL_debug_renderer_info');return {width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',vendor:gl.getParameter(gl.VENDOR),renderer:gl.getParameter(gl.RENDERER),version:gl.getParameter(gl.VERSION),unmaskedVendor:extension?gl.getParameter(extension.UNMASKED_VENDOR_WEBGL):null,unmaskedRenderer:extension?gl.getParameter(extension.UNMASKED_RENDERER_WEBGL):null};})}));
 const cdp=await page.context().browser()!.newBrowserCDPSession();
 const system=await cdp.send('SystemInfo.getInfo');await cdp.detach();
 await writeFile('/tmp/tenka-04c7b60-worker-batch-evidence/current-gpu-identity.json',JSON.stringify({identity,system,note:'separate read-only new page, not retrospective identity proof of the prior profile context; no timing/profile/benchmark'}));
 expect(identity.canvases.some(c=>c.context!==null)).toBe(true);
});

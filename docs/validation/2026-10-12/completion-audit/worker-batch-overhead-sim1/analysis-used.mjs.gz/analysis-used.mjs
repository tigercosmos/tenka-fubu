import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {parse} from '/Users/tigercosmos/tenka-fubu/node_modules/@babel/parser/lib/index.js';
const root='/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit/worker-batch-overhead-sim1';
const read=name=>gunzipSync(readFileSync(`${root}/${name}`));
const profile=JSON.parse(read('default-main-cpu-profile.json.gz')).profile;
const transformed=read('default-actual-playwright-transformed-diagnostic.js.gz').toString();
let observer;
function walk(node){if(!node||typeof node!=='object')return;if(node.type==='CallExpression'&&node.callee.type==='MemberExpression'&&node.callee.property.name==='addInitScript')observer=transformed.slice(node.arguments[0].start,node.arguments[0].end);for(const value of Object.values(node)){if(Array.isArray(value))value.forEach(walk);else if(value&&typeof value==='object')walk(value);}}
walk(parse(transformed,{sourceType:'unambiguous'}));if(!observer)throw Error('missing observer');
const injected=`(${observer})(undefined)`;writeFileSync(`${root}/injected-observer.reconstructed.js`,injected);
const key=f=>JSON.stringify([f.functionName,f.url,f.lineNumber,f.columnNumber]);
const nodes=new Map(profile.nodes.map(n=>[n.id,n]));const parent=new Map();for(const n of profile.nodes)for(const child of n.children??[])parent.set(child,n.id);
const totals=new Map();
for(let i=0;i<profile.samples.length;i++){const n=nodes.get(profile.samples[i]);const k=key(n.callFrame);let row=totals.get(k);if(!row){row={...n.callFrame,selfSampleUs:0,inclusiveSampleUs:0,samples:0};totals.set(k,row);}row.selfSampleUs+=profile.timeDeltas[i];row.samples++;}
for(let i=0;i<profile.samples.length;i++){let id=profile.samples[i];const seen=new Set();while(nodes.has(id)){const f=nodes.get(id).callFrame,k=key(f);if(!seen.has(k)){let r=totals.get(k);if(!r){r={...f,selfSampleUs:0,inclusiveSampleUs:0,samples:0};totals.set(k,r);}r.inclusiveSampleUs+=profile.timeDeltas[i];seen.add(k);}if(!parent.has(id))break;id=parent.get(id);}}
const rows=[...totals.values()].sort((a,b)=>b.selfSampleUs-a.selfSampleUs).slice(0,35);
for(const row of rows){let text,raw,source;if(row.url.startsWith('http://localhost:4173/')){source='bundle-'+row.url.slice('http://localhost:4173/'.length).replaceAll('/','__')+'.gz';raw=read(source);text=raw.toString();}else if(row.scriptId==='6'&&row.lineNumber>=0){source='injected-observer.reconstructed.js';raw=Buffer.from(injected);text=injected;row.sourceStatus='reconstructed from actual Playwright transformed cache and evaluationScript function wrapper; not Debugger.getScriptSource';}
if(text){const line=text.split('\n')[row.lineNumber];if(line!==undefined){row.locationUnits='zero-based V8 line/UTF-16 column; JavaScript String.slice';row.sourceFile=source;row.sourceSha256=createHash('sha256').update(raw).digest('hex');row.locationSnippet=line.slice(Math.max(0,row.columnNumber-60),row.columnNumber+450);}}}
const result={profileDurationMs:(profile.endTime-profile.startTime)/1000,sampleDurationMs:profile.timeDeltas.reduce((a,b)=>a+b,0)/1000,sampleCount:profile.samples.length,frames:rows,note:'Self/inclusive sample weights; inclusive same-frame recursion counted once per stack. Program lacks JS URL/location; no GPU attribution.'};
writeFileSync(`${root}/cpu-attribution.json`,JSON.stringify(result,null,2)+'\n');
for(const r of rows.slice(0,12))process.stdout.write(`${r.functionName||'<anonymous>'} ${(r.selfSampleUs/1000).toFixed(2)}ms ${r.locationSnippet?.slice(0,110)??''}\n`);

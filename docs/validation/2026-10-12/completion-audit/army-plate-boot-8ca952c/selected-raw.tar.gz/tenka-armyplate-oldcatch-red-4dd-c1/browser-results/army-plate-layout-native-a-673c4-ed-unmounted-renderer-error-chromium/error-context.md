# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: army-plate-layout.spec.ts >> native army number-plate placement >> boot retries only the documented unmounted renderer error
- Location: e2e/army-plate-layout.spec.ts:143:3

# Error details

```
Error: expect(received).rejects.toThrow()

Received promise resolved instead of rejected
Resolved to value: undefined
```

# Test source

```ts
  61  |     .sort((a, b) => a - b);
  62  |   let area = 0;
  63  |   for (let i = 1; i < xs.length; i++)
  64  |     for (let j = 1; j < ys.length; j++) {
  65  |       const x = (xs[i - 1]! + xs[i]!) / 2,
  66  |         y = (ys[j - 1]! + ys[j]!) / 2;
  67  |       if (!hud.some((r) => x > r.x && x < r.x + r.width && y > r.y && y < r.y + r.height))
  68  |         area += (xs[i]! - xs[i - 1]!) * (ys[j]! - ys[j - 1]!);
  69  |     }
  70  |   return area;
  71  | }
  72  | 
  73  | function overlap(data: Awaited<ReturnType<typeof layout>>, baseline: boolean): number {
  74  |   let area = 0;
  75  |   data.plates.forEach((plate, index) => {
  76  |     const rect = baseline ? plate.baseline : plate.rect;
  77  |     for (const castle of data.castles) area += intersection(rect, castle.rect);
  78  |     for (const other of data.plates.slice(index + 1))
  79  |       area += intersection(rect, baseline ? other.baseline : other.rect);
  80  |   });
  81  |   return area;
  82  | }
  83  | 
  84  | async function mapIdleOrRetry(page: Page): Promise<boolean> {
  85  |   return page.evaluate(async () => {
  86  |     try {
  87  |       await (window as DebugWindow).__tenka.debug.waitMapIdle();
  88  |       return true;
  89  |     } catch {
  90  |       return false;
  91  |     }
  92  |   });
  93  | }
  94  | 
  95  | async function boot(page: Page) {
  96  |   await page.goto('/?debug=visual-map');
  97  |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  98  |   await page.evaluate(() => document.fonts.ready);
  99  |   await expect.poll(() => mapIdleOrRetry(page)).toBe(true);
  100 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  101 | }
  102 | 
  103 | async function setScale(page: Page, scale: 0.8 | 1 | 1.5) {
  104 |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  105 |   await page.getByRole('button', { name: '設定', exact: true }).click();
  106 |   const dialog = page.getByRole('dialog');
  107 |   const slider = dialog.getByRole('slider', { name: '介面縮放', exact: true });
  108 |   await slider.press(scale === 1.5 ? 'End' : 'Home');
  109 |   if (scale === 1) for (let step = 0; step < 4; step++) await slider.press('ArrowRight');
  110 |   await expect(slider).toHaveValue(String(scale));
  111 |   await expect
  112 |     .poll(() => page.evaluate(() => getComputedStyle(document.documentElement).fontSize))
  113 |     .toBe(`${16 * scale}px`);
  114 |   await dialog.getByRole('button', { name: '返回', exact: true }).click();
  115 |   await page.getByRole('button', { name: '回到遊戲', exact: true }).click();
  116 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  117 | }
  118 | 
  119 | async function nearCastle(page: Page, id: 'castle.sunpu' | 'castle.narumi') {
  120 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.setMapCameraPreset('close'));
  121 |   if (id === 'castle.narumi') {
  122 |     const position = await page.evaluate(() => {
  123 |       const game = (window as DebugWindow).__tenka.debug.getState();
  124 |       return Object.values(game.castles).find((castle) => castle.id === 'castle.narumi')!.pos;
  125 |     });
  126 |     const mini = page.getByTestId('minimap-frame');
  127 |     const box = await mini.boundingBox();
  128 |     expect(box).not.toBeNull();
  129 |     await mini.click({
  130 |       position: { x: (position.x / 4096) * box!.width, y: (position.y / 4096) * box!.height },
  131 |     });
  132 |   }
  133 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.waitMapIdle(3));
  134 | }
  135 | 
  136 | test.describe('native army number-plate placement', () => {
  137 |   test.use({
  138 |     viewport: { width: 1280, height: 720 },
  139 |     deviceScaleFactor: 1,
  140 |     contextOptions: { reducedMotion: 'reduce' },
  141 |   });
  142 | 
  143 |   test('boot retries only the documented unmounted renderer error', async ({ page }) => {
  144 |     await page.goto('about:blank');
  145 |     await page.evaluate(() => {
  146 |       Object.assign(window, { __idleCalls: 0 });
  147 |       Object.defineProperty(window, '__tenka', {
  148 |         configurable: true,
  149 |         value: {
  150 |           debug: {
  151 |             waitMapIdle() {
  152 |               const state = window as unknown as { __idleCalls: number };
  153 |               if (++state.__idleCalls === 1)
  154 |                 return Promise.reject(new Error('unexpected idle failure'));
  155 |               return Promise.resolve();
  156 |             },
  157 |           },
  158 |         },
  159 |       });
  160 |     });
> 161 |     await expect(expect.poll(() => mapIdleOrRetry(page)).toBe(true)).rejects.toThrow(
      |                                                                              ^ Error: expect(received).rejects.toThrow()
  162 |       'unexpected idle failure',
  163 |     );
  164 |     expect(
  165 |       await page.evaluate(() => (window as unknown as { __idleCalls: number }).__idleCalls),
  166 |     ).toBe(1);
  167 |     await page.evaluate(() => {
  168 |       Object.assign(window, { __idleCalls: 0 });
  169 |       Object.defineProperty(window, '__tenka', {
  170 |         configurable: true,
  171 |         value: {
  172 |           debug: {
  173 |             waitMapIdle() {
  174 |               const state = window as unknown as { __idleCalls: number };
  175 |               if (++state.__idleCalls === 1)
  176 |                 return Promise.reject(
  177 |                   new Error(
  178 |                     '__TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）',
  179 |                   ),
  180 |                 );
  181 |               return Promise.resolve();
  182 |             },
  183 |           },
  184 |         },
  185 |       });
  186 |     });
  187 |     await expect.poll(() => mapIdleOrRetry(page)).toBe(true);
  188 |     expect(
  189 |       await page.evaluate(() => (window as unknown as { __idleCalls: number }).__idleCalls),
  190 |     ).toBe(2);
  191 |   });
  192 | 
  193 |   test('the independent tether oracle detects interiors but excludes edge and corner touches', () => {
  194 |     const rect = { x: 0, y: 0, width: 10, height: 10 };
  195 |     for (const [start, end, expected] of [
  196 |       [{ x: -5, y: 5 }, { x: 15, y: 5 }, true],
  197 |       [{ x: 5, y: -5 }, { x: 5, y: 15 }, true],
  198 |       [{ x: -5, y: -5 }, { x: 15, y: 15 }, true],
  199 |       [{ x: -5, y: 5 }, { x: 5, y: -5 }, false],
  200 |       [{ x: -5, y: 0 }, { x: 15, y: 0 }, false],
  201 |       [{ x: 5, y: 5 }, { x: 15, y: 5 }, true],
  202 |       [{ x: 5, y: 5 }, { x: 5, y: 5 }, false],
  203 |       [{ x: -5, y: 5 }, { x: 0, y: 5 }, false],
  204 |     ] as const) {
  205 |       expect(crossesInterior(start, end, rect)).toBe(expected);
  206 |       expect(crossesInterior(end, start, rect)).toBe(expected);
  207 |     }
  208 |   });
  209 | 
  210 |   test('the reserved-HUD visibility oracle clips and subtracts overlapping rectangles once', () => {
  211 |     const rect = { x: 0, y: 0, width: 10, height: 10 };
  212 |     expect(
  213 |       visibleArea(rect, rect, [
  214 |         { x: 0, y: 0, width: 6, height: 10 },
  215 |         { x: 4, y: 0, width: 4, height: 10 },
  216 |       ]),
  217 |     ).toBe(20);
  218 |     expect(visibleArea(rect, { x: 5, y: 5, width: 10, height: 10 }, [])).toBe(25);
  219 |     expect(visibleArea(rect, rect, [rect])).toBe(0);
  220 |     expect(visibleArea(rect, rect, [{ x: 10, y: 0, width: 10, height: 10 }])).toBe(100);
  221 |   });
  222 | 
  223 |   test('actual Sunpu/Narumi plate bounds reduce overlap at three real UI scales without core mutation', async ({
  224 |     page,
  225 |   }, info) => {
  226 |     await boot(page);
  227 |     // Existing synthetic visual fixture, unchanged: this is presentation/input
  228 |     // evidence, not an earned campaign or normal-day gameplay proof.
  229 |     const core = await page.evaluate(() =>
  230 |       JSON.stringify((window as DebugWindow).__tenka.debug.getState()),
  231 |     );
  232 |     const observations = [];
  233 |     for (const scale of [0.8, 1, 1.5] as const) {
  234 |       await setScale(page, scale);
  235 |       for (const castleId of ['castle.sunpu', 'castle.narumi'] as const) {
  236 |         await nearCastle(page, castleId);
  237 |         const data = await layout(page);
  238 |         expect(data.plates.length).toBeGreaterThan(0);
  239 |         expect(data.castles.some((castle) => castle.id === castleId)).toBe(true);
  240 |         for (const plate of data.plates) {
  241 |           expect(
  242 |             plate.fontSizeCss,
  243 |             'number text retains a readable camera-independent size',
  244 |           ).toBeCloseTo(14, 8);
  245 |           expect(Object.values(plate.rect).every(Number.isFinite)).toBe(true);
  246 |           // Runtime information plates opt into 80 CSS px; legacy pure callers
  247 |           // retain their separate 48 px contract. Bodies and anchors never move.
  248 |           expect(Math.hypot(plate.offset.x, plate.offset.y)).toBeLessThanOrEqual(80 + 1e-7);
  249 |           expect(plate.rect.width).toBe(plate.baseline.width);
  250 |           expect(plate.rect.height).toBe(plate.baseline.height);
  251 |           expect(plate.rect.x).toBeCloseTo(plate.baseline.x + plate.offset.x, 8);
  252 |           expect(plate.rect.y).toBeCloseTo(plate.baseline.y + plate.offset.y, 8);
  253 |         }
  254 |         const before = overlap(data, true),
  255 |           after = overlap(data, false);
  256 |         expect(before, `${castleId} at UI ${scale} has a real baseline collision`).toBeGreaterThan(
  257 |           0,
  258 |         );
  259 |         expect(after, `${castleId} at UI ${scale} reduces actual rectangle overlap`).toBeLessThan(
  260 |           before,
  261 |         );
```
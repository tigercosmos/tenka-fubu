#!/usr/bin/env bash
set -euo pipefail
MODE=$1
RUN_DIR=$2
RUNTIME=/tmp/tenka-armyplate-4dd-c1
NODE_BIN=/home/anchi/.nvm/versions/node/v25.9.0/bin
BROWSERS=/tmp/tenka-20261012-sim2-browser/runtime/browsers
test -x "$NODE_BIN/node"
test -x "$NODE_BIN/npm"
test -x "$BROWSERS/chromium-1228/chrome-linux64/chrome"
test -x "$RUNTIME/node_modules/.bin/playwright"
export PATH="$NODE_BIN:/usr/local/bin:/usr/bin:/bin"
export PLAYWRIGHT_BROWSERS_PATH="$BROWSERS"
export VISUAL_GPU=1 CI=1
unset VISUAL_PERF VISUAL_HEAP UPDATE_VISUAL SIMULATION_PROFILE
FILE='e2e/army-plate-layout\.spec\.ts$'
TITLE='boot retries only the documented unmounted renderer error'
if [[ "$MODE" == list-control ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium --grep "$TITLE" --list
fi
if [[ "$MODE" == control ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" --browser -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium --grep "$TITLE"
fi
if [[ "$MODE" == list-all ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium --list
fi
if [[ "$MODE" == all ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" --browser -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium
fi
exit 2

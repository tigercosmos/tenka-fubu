from pathlib import Path
import difflib
import hashlib

candidate = Path('/tmp/tenka-armyplate-candidate-4dd-c1.spec.ts').read_text()
old = '''    } catch (error) {
      if (
        error instanceof Error &&
        error.message ===
          '__TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）'
      )
        return false;
      throw error;
    }'''
new = '''    } catch {
      return false;
    }'''
assert candidate.count(old) == 1
control = candidate.replace(old, new)
path = Path('/tmp/tenka-armyplate-oldcatch-4dd-c1.spec.ts')
path.write_text(control)
Path('/tmp/tenka-armyplate-oldcatch-4dd-c1.diff').write_text(''.join(difflib.unified_diff(candidate.splitlines(True), control.splitlines(True), fromfile='candidate', tofile='old-catch-control')))
print({'candidateSha256': hashlib.sha256(candidate.encode()).hexdigest(), 'oldCatchSha256': hashlib.sha256(control.encode()).hexdigest()})

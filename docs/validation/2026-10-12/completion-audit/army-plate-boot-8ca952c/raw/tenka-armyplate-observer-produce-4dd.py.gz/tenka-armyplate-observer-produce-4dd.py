from pathlib import Path
import difflib
import hashlib

source = Path('/Users/tigercosmos/tenka-fubu/e2e/army-plate-layout.spec.ts').read_text()
target = Path('/tmp/tenka-armyplate-observed-4dd-c1.spec.ts')
old = '''async function boot(page: Page) {
  await page.goto('/?debug=visual-map');
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
  await expect
    .poll(async () =>
      page.evaluate(async () => {
        try {
          await (window as DebugWindow).__tenka.debug.waitMapIdle();
          return true;
        } catch {
          return false;
        }
      }),
    )
    .toBe(true);
  await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
}'''
new = '''async function boot(page: Page, info?: { outputPath(name: string): string }) {
  await page.goto('/?debug=visual-map');
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
  const attempts: unknown[] = [];
  try {
    await expect
      .poll(async () => {
        const observation = await page.evaluate(async () => {
          const start = performance.now();
          const debug = (window as DebugWindow).__tenka?.debug;
          let readiness: unknown;
          try {
            readiness = debug.getMapDiagnostics().ready;
          } catch (error) {
            readiness = { error: error instanceof Error ? error.message : String(error) };
          }
          const canvas = document.querySelector<HTMLCanvasElement>('[data-testid="map-canvas-host"] canvas');
          const canvasCount = document.querySelectorAll('[data-testid="map-canvas-host"] canvas').length;
          try {
            await debug.waitMapIdle();
            let gpu: string | null = null;
            if (readiness === true) try {
              const gl = canvas?.getContext('webgl2') as WebGL2RenderingContext | null;
              const rendererInfo = gl?.getExtension('WEBGL_debug_renderer_info');
              gpu = gl && rendererInfo ? String(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL)) : null;
            } catch { /* GPU observation cannot change idle success. */ }
            return { success: true, start, end: performance.now(), readiness, canvasCount, gpu };
          } catch (error) {
            return { success: false, start, end: performance.now(), readiness, canvasCount,
              error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error) };
          }
        });
        attempts.push(observation);
        return observation.success;
      })
      .toBe(true);
  } finally {
    if (info) await writeFile(info.outputPath('boot-attempts.json'), JSON.stringify(attempts, null, 2));
  }
  await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
}'''
assert source.count(old) == 1
candidate = source.replace(old, new).replace('    await boot(page);', '    await boot(page, info);', 1)
target.write_text(candidate)
Path('/tmp/tenka-armyplate-observer-4dd-c1.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True), candidate.splitlines(True), fromfile='original', tofile='observed')))
print({'originalSha256': hashlib.sha256(source.encode()).hexdigest(), 'observedSha256': hashlib.sha256(candidate.encode()).hexdigest(), 'diff': '/tmp/tenka-armyplate-observer-4dd-c1.diff'})

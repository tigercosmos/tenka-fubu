from pathlib import Path
import hashlib
import json
import tarfile

base = Path('/tmp')
dest = base / 'tenka-armyplate-evidence-8ca952c-c1'
dest.mkdir(exist_ok=False)
runs = [
    'tenka-armyplate-original-4dd-c1',
    'tenka-armyplate-observed-4dd-c1',
    'tenka-armyplate-oldcatch-red-4dd-c1',
    'tenka-armyplate-candidate-all6-4dd-c1',
]
paths = []
traces = []
for run in runs:
    root = base / run
    for name in ['command.json', 'process.json', 'result.json', 'stdout-stderr.log', 'report.json']:
        paths.append(root / name)
    for path in (root / 'browser-results').rglob('boot-attempts.json'):
        paths.append(path)
    for path in (root / 'browser-results').rglob('error-context.md'):
        paths.append(path)
    for path in (root / 'browser-results').rglob('trace.zip'):
        data = path.read_bytes()
        traces.append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
items = []
with tarfile.open(dest / 'selected-raw.tar.gz', 'x:gz') as tar:
    for path in paths:
        assert path.is_file(), path
        data = path.read_bytes()
        relative = path.relative_to(base).as_posix()
        items.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        tar.add(path, arcname=relative, recursive=False)
(dest / 'manifest.json').write_text(json.dumps({'items': items, 'remoteTraces': traces}, indent=2) + '\n')
print(json.dumps({'selectedFiles': len(items), 'tracePaths': len(traces), 'tarBytes': (dest / 'selected-raw.tar.gz').stat().st_size}))

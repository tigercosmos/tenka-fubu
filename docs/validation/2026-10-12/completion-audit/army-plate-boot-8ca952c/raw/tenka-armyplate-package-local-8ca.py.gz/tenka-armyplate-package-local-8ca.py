from pathlib import Path
import gzip
import hashlib
import json

root = Path('/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit/army-plate-boot-8ca952c')
out = root / 'raw'
out.mkdir(exist_ok=False)
paths = []
for directory in sorted(Path('/tmp').glob('tenka-armyplate-*')):
    if not directory.is_dir() or directory == root:
        continue
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix not in {'.tar', '.zip', '.gz'}:
            paths.append(path)
for path in sorted(Path('/tmp').glob('tenka-armyplate-*')):
    if path.is_file() and path.suffix in {'.py', '.sh', '.ts', '.json', '.diff'}:
        paths.append(path)
entries = []
for path in paths:
    data = path.read_bytes()
    name = path.relative_to('/tmp').as_posix().replace('/', '__') + '.gz'
    target = out / name
    assert not target.exists(), name
    compressed = gzip.compress(data, mtime=0)
    target.write_bytes(compressed)
    entries.append({'source': str(path), 'file': str(target.relative_to(root)),
                    'rawBytes': len(data), 'rawSha256': hashlib.sha256(data).hexdigest(),
                    'gzipBytes': len(compressed), 'gzipSha256': hashlib.sha256(compressed).hexdigest()})
(root / 'local-raw-manifest.json').write_text(json.dumps({'items': entries}, indent=2) + '\n')
print(json.dumps({'localItems': len(entries), 'gzipBytes': sum(x['gzipBytes'] for x in entries)}))

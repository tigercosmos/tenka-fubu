import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createGeographicPreparationOracle } from '../tests/helpers/geographicPreparationOracle.ts';
const bits=(v:number)=>{if(Number.isNaN(v))return 'NaN';const b=Buffer.alloc(8);b.writeDoubleLE(v);return b.toString('hex');};
const make=(file:string)=>{const bytes=readFileSync(file);const e=new WebAssembly.Instance(new WebAssembly.Module(bytes),{env:{path_node_cost(){throw new Error('Unexpected path evaluation');}}}).exports as any;return {e,sha:createHash('sha256').update(bytes).digest('hex')};};
const baseline=make('evidence/baseline.wasm'),candidate=make('evidence/prototype.wasm');
function evaluate(e:any,f:number[],road:number[],mutate?:[number,number]) {
 const cap=62+2*f[2]!+2*f[3]!+f[4]!;
 const fp=e.engine_alloc(f.length),pp=e.engine_alloc(cap),rp=e.engine_alloc(road.length);
 new Float64Array(e.memory.buffer,fp,f.length).set(f);
 new Float64Array(e.memory.buffer,rp,road.length).set(road);
 const n=e.geo_prepare(fp,f.length,pp,cap);
 if(n<0)throw new Error('prepare '+n);
 const before=Array.from(new Float64Array(e.memory.buffer,pp,n));
 if(mutate)new Float64Array(e.memory.buffer,pp,n)[mutate[0]]=mutate[1];
 const winner=e.geo_score_prepared(fp,f.length,pp,n,rp,road.length);
 const after=Array.from(new Float64Array(e.memory.buffer,pp,n));
 e.engine_free(fp,f.length);e.engine_free(pp,cap);e.engine_free(rp,road.length);
 return {n,winner,before:before.map(bits),after:after.map(bits)};
}
const observations:any[]=[];
let seed=42;const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/0xffffffff;};
const oracle=createGeographicPreparationOracle();
for(let scene=0;scene<320;scene++) {
 const primary=Array.from({length:16},()=>({x:next()*240-120,y:next()*160-80,width:next()*32,height:next()*20}));
 const hard=Array.from({length:8},()=>({x:next()*240-120,y:next()*160-80,width:next()*20,height:next()*20}));
 const labels=Array.from({length:6},(_,i)=>({id:`${scene}-${i}`,kind:(['province','district','road'] as const)[i%3]!,rect:{x:next()*100-50,y:next()*100-50,width:next()*30,height:next()*14},...(i%3===2?{roadLine:{normal:{x:0,y:1},slack:4},roadCapsules:i===5?[{a:{x:-60,y:3},b:{x:60,y:3},radius:2}]:undefined}: {})}));
 for(const s of oracle.layout(labels,primary,hard).steps) {
  const r=s.rect;const f=[1,scene+1,s.primary.length,s.hard.length,s.placed.length,s.placed.length,r.x,r.y,r.width,r.height,observations.length+1,0,0,0,0,0];
  for(const row of [...s.primary,...s.hard,...s.placed])f.push(row.x,row.y,row.width,row.height);
  const cs=s.roadCapsules;const road=[1,s.roadLine?1:0,s.roadLine?.normal.x??0,s.roadLine?.normal.y??0,s.roadLine?.slack??0,cs===undefined?0:cs===null?1:2,cs?.length??0,0];
  for(const c of cs??[])road.push(c.a.x,c.a.y,c.b.x,c.b.y,c.radius);
  const a=evaluate(baseline.e,f,road),b=evaluate(candidate.e,f,road);
  if(JSON.stringify(a)!==JSON.stringify(b))throw new Error(`ABI mismatch ${scene} ${s.id}`);
  observations.push({scene,id:s.id,frame:f.map(bits),road:road.map(bits),result:a});
 }
}
for(const value of [NaN,Infinity,-Infinity,-0,Number.MIN_VALUE]) {
 const f=[1,4294967296,0,0,0,0,0,0,8,8,4294967296,0,0,0,0,0],r=[1,0,0,0,0,0,0,0];
 const a=evaluate(baseline.e,f,r,[16,value]),b=evaluate(candidate.e,f,r,[16,value]);
 if(JSON.stringify(a)!==JSON.stringify(b))throw new Error(`derived mismatch ${bits(value)}`);
 observations.push({derivedFirstX:bits(value),frame:f.map(bits),road:r.map(bits),result:a});
}
const validRects=[
 [-0,-0,0,0], [Number.MIN_VALUE,-Number.MIN_VALUE,Number.MIN_VALUE,0],
 [0,0,1e200,1e200], [1e200,1e200,1e200,1e200],
 [-Number.MAX_VALUE,-Number.MAX_VALUE,Number.MAX_VALUE,Number.MAX_VALUE],
 [Number.MAX_VALUE,Number.MAX_VALUE,0,0], [8-1e-8,8+1e-8,4,4],
];
const extraRoads=[[1,0,0,0,0,0,0,0],[1,0,0,0,0,1,0,0],[1,0,0,0,0,2,0,0],[1,1,NaN,0,0,0,0,0]];
let extremeCases=0;
for(const rect of validRects)for(const blocker of validRects)for(const road of extraRoads) {
 for(const row of [rect,blocker])if(![...row,row[0]!+row[2]!+4,row[1]!+row[3]!+4].every(Number.isFinite)||row[2]!<0||row[3]!<0)throw new Error('not valid extreme');
 const f=[1,9007199254740991,1,1,1,1,...rect,9007199254740991,0,0,0,0,0,...blocker,...blocker,...blocker];
 const a=evaluate(baseline.e,f,road),b=evaluate(candidate.e,f,road);
 if(JSON.stringify(a)!==JSON.stringify(b))throw new Error('extreme ABI mismatch');
 observations.push({validExtreme:true,frame:f.map(bits),road:road.map(bits),result:a});extremeCases++;
}
const summary={scope:'Compiled scalar-baseline/SIMD-prototype parity, not performance',baseline:baseline.sha,candidate:candidate.sha,cases:observations.length,validExtremeCases:extremeCases,classification:'NaN class, every other f64 exact LE bits',allEqual:true};
writeFileSync('evidence/simd-parity.raw.json',JSON.stringify({summary,observations})+'\n');
console.log(JSON.stringify(summary,null,2));

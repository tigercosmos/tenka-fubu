import {chromium} from '@playwright/test';
import {writeFileSync,openSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const log=openSync('/tmp/tenka-prep-current23-close-profile-preview.log','w');
const preview=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4173'],{stdio:['ignore',log,log]});
let browser;
try {
 for(let i=0;i<100;i++){try{const r=await fetch('http://127.0.0.1:4173');if(r.ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
 const context=await browser.newContext({viewport:{width:1920,height:1080},reducedMotion:'no-preference'});
 const page=await context.newPage();
 await page.goto('http://127.0.0.1:4173/?debug=1&seed=15600519');
 await page.getByTestId('title-newgame').click(); await page.getByTestId('scenario-pick-s1560').click(); await page.getByTestId('clan-pick-clan.oda').click(); await page.getByTestId('newgame-start').click(); await page.getByTestId('screen-strategy').waitFor(); await page.getByTestId('speed-pause').click();
 const preparation=await page.evaluate(()=>window.__tenka.debug.prepareLiveNationalMapWorkload(120));
 await page.evaluate(async()=>{await document.fonts.ready;await window.__tenka.debug.setMapCameraPreset('close');await window.__tenka.debug.waitMapIdle(3);});

 const gpuCapture=async(name)=>{const gpu=await page.evaluate(()=>[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return{width:canvas.width,height:canvas.height,context:null};const ext=gl.getExtension('WEBGL_debug_renderer_info');return{width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',contextLost:gl.isContextLost(),renderer:String(gl.getParameter(ext?ext.UNMASKED_RENDERER_WEBGL:gl.RENDERER)),vendor:String(gl.getParameter(ext?ext.UNMASKED_VENDOR_WEBGL:gl.VENDOR))};}));writeFileSync('/tmp/tenka-prep-current23-gpu-'+name+'.json',JSON.stringify(gpu));const active=gpu.find(g=>g.context);if(!active||!active.renderer.includes('RTX 5070 Ti')||!active.renderer.includes('Vulkan')||active.contextLost)throw Error('Actual RTX Vulkan GPU guard failed');};
 await gpuCapture('before-profile');
 const before=await page.evaluate(()=>JSON.stringify(window.__tenka.debug.getState()));
 const cacheBefore=await page.evaluate(()=>window.__tenka.debug.getMapDiagnostics().geographicLabelLayout.placementCache);
 const client=await context.newCDPSession(page); await client.send('Profiler.enable');await client.send('Profiler.setSamplingInterval',{interval:1000});await client.send('Profiler.start');
 const measurement=await page.evaluate(()=>window.__tenka.debug.measureNationalMapFrames('close',10000));
 const {profile}=await client.send('Profiler.stop');
 await gpuCapture('after-profile');
 const after=await page.evaluate(()=>JSON.stringify(window.__tenka.debug.getState()));
 const cacheAfter=await page.evaluate(()=>window.__tenka.debug.getMapDiagnostics().geographicLabelLayout.placementCache);
 const driver=await page.evaluate(()=>window.__tenka.debug.getLiveNationalMapWorkload());
 writeFileSync('/tmp/tenka-prep-current23-close.cpuprofile',JSON.stringify(profile));
 const hash=(s)=>createHash('sha256').update(s).digest('hex');
 const sortedResources=(o)=>JSON.stringify(Object.fromEntries(Object.entries(o).sort(([a],[b])=>a<b?-1:a>b?1:0)));
 writeFileSync('/tmp/tenka-prep-current23-close-profile-summary.json',JSON.stringify({scope:'separateCPUProfile/notAcceptanceFPS',preparation,driver,cacheBefore,cacheAfter,canonicalStateByteEqual:before===after,canonicalBeforeSha256:hash(before),canonicalAfterSha256:hash(after),resourceBeforeSha256:hash(sortedResources(measurement.resourcesBefore)),resourceAfterSha256:hash(sortedResources(measurement.resourcesAfter)),measurement},null,2));
 if(before!==after||driver.ticks!==0)throw Error('Profile mutated canonical state');
 console.log(JSON.stringify({nodes:profile.nodes.length,samples:profile.samples.length,canonicalStateByteEqual:true,driverTicks:driver.ticks}));
} finally {await browser?.close();preview.kill('SIGTERM');}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: color-vision-map.spec.ts >> actual three-owner map achromatopsia artifacts preserve original cameras and state
- Location: e2e/color-vision-map.spec.ts:73:3

# Error details

```
Error: restoring none must recover exact RGBA pixels

expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 293
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  47  |       canvas: { x: box.x, y: box.y, width: box.width, height: box.height },
  48  |     };
  49  |   });
  50  | }
  51  | 
  52  | function difference(a: Buffer, b: Buffer) {
  53  |   const left = PNG.sync.read(a),
  54  |     right = PNG.sync.read(b);
  55  |   expect({ width: right.width, height: right.height }).toEqual({
  56  |     width: left.width,
  57  |     height: left.height,
  58  |   });
  59  |   let pixels = 0;
  60  |   for (let i = 0; i < left.data.length; i += 4) {
  61  |     if (
  62  |       left.data[i] !== right.data[i] ||
  63  |       left.data[i + 1] !== right.data[i + 1] ||
  64  |       left.data[i + 2] !== right.data[i + 2] ||
  65  |       left.data[i + 3] !== right.data[i + 3]
  66  |     )
  67  |       pixels++;
  68  |   }
  69  |   return pixels;
  70  | }
  71  | 
  72  | for (const mode of modes) {
  73  |   test(`actual three-owner map ${mode} artifacts preserve original cameras and state`, async ({
  74  |     page,
  75  |   }, info) => {
  76  |     await page.setViewportSize({ width: 1280, height: 720 });
  77  |     await page.emulateMedia({ reducedMotion: 'reduce' });
  78  |     await page.goto('/?debug=visual-map');
  79  |     await expect(page.getByTestId('screen-strategy')).toBeVisible();
  80  |     await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  81  |     await page.evaluate(() => document.fonts.ready);
  82  |     await page.mouse.move(1270, 710);
  83  |     const initial = await observe(page);
  84  |     writeFileSync(info.outputPath('initial-preflight.json'), JSON.stringify(initial, null, 2));
  85  |     expect(validateState(initial.state)).toEqual([]);
  86  |     expect(
  87  |       [...new Set(Object.values(initial.state.armies).map((army) => army.clanId))].sort(),
  88  |     ).toEqual(['clan.imagawa', 'clan.oda', 'clan.saito']);
  89  |     const session = await page.context().newCDPSession(page);
  90  |     try {
  91  |       for (const camera of cameras) {
  92  |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  93  |         await page.evaluate((preset) => window.__tenka.debug.setMapCameraPreset(preset), camera);
  94  |         let prior = '',
  95  |           stable = 0;
  96  |         await expect
  97  |           .poll(async () => {
  98  |             const value = invariantPresentation((await observe(page)).diagnostics);
  99  |             const current = JSON.stringify(value);
  100 |             stable = current === prior ? stable + 1 : 0;
  101 |             prior = current;
  102 |             return stable;
  103 |           })
  104 |           .toBeGreaterThanOrEqual(3);
  105 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  106 |         // Prime the CDP transition before capturing the reference. Baseline and
  107 |         // restored captures now have identical mode-to-none transition history.
  108 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: mode });
  109 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  110 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  111 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  112 |         const baseline = await observe(page);
  113 |         writeFileSync(
  114 |           info.outputPath(`${camera}-none-observation.json`),
  115 |           JSON.stringify(baseline, null, 2),
  116 |         );
  117 |         expect(baseline.diagnostics.lodStage).toBe(
  118 |           { overview: 'far', operational: 'mid', close: 'near' }[camera],
  119 |         );
  120 |         const none = await page.screenshot({ path: info.outputPath(`${camera}-none.png`) });
  121 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: mode });
  122 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  123 |         const emulated = await observe(page);
  124 |         writeFileSync(
  125 |           info.outputPath(`${camera}-${mode}-raw-observation.json`),
  126 |           JSON.stringify(emulated, null, 2),
  127 |         );
  128 |         const changed = await page.screenshot({ path: info.outputPath(`${camera}-${mode}.png`) });
  129 |         const changedPixels = difference(none, changed);
  130 |         expect(
  131 |           changedPixels,
  132 |           'the CDP mode must actually change the captured framebuffer',
  133 |         ).toBeGreaterThan(0);
  134 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  135 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  136 |         const restored = await observe(page);
  137 |         writeFileSync(
  138 |           info.outputPath(`${camera}-restored-observation.json`),
  139 |           JSON.stringify(restored, null, 2),
  140 |         );
  141 |         const restoredPixels = await page.screenshot({
  142 |           path: info.outputPath(`${camera}-restored.png`),
  143 |         });
  144 |         expect(
  145 |           difference(none, restoredPixels),
  146 |           'restoring none must recover exact RGBA pixels',
> 147 |         ).toBe(0);
      |           ^ Error: restoring none must recover exact RGBA pixels
  148 |         for (const actual of [baseline, emulated, restored]) {
  149 |           expect(actual.state).toEqual(initial.state);
  150 |           expect(actual.commands).toEqual(initial.commands);
  151 |           expect(validateState(actual.state)).toEqual([]);
  152 |           expect(actual.canvas).toEqual(baseline.canvas);
  153 |           expect(invariantPresentation(actual.diagnostics)).toEqual(
  154 |             invariantPresentation(baseline.diagnostics),
  155 |           );
  156 |         }
  157 |         const visibleSignals = baseline.diagnostics.armyRendering.signals
  158 |           .filter((signal) => {
  159 |             const rect = signal.rect;
  160 |             return (
  161 |               signal.visible &&
  162 |               rect !== null &&
  163 |               [rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) &&
  164 |               rect.width > 0 &&
  165 |               rect.height > 0 &&
  166 |               rect.x < baseline.canvas.width &&
  167 |               rect.y < baseline.canvas.height &&
  168 |               rect.x + rect.width > 0 &&
  169 |               rect.y + rect.height > 0
  170 |             );
  171 |           })
  172 |           .map((signal) => {
  173 |             const army = baseline.state.armies[signal.id as keyof typeof baseline.state.armies]!;
  174 |             return {
  175 |               signal,
  176 |               clanId: army.clanId,
  177 |               leaderId: army.leaderId,
  178 |               status: army.status,
  179 |               morale: army.morale,
  180 |               relation:
  181 |                 army.clanId === 'clan.oda'
  182 |                   ? 'friendly'
  183 |                   : army.clanId === 'clan.imagawa'
  184 |                     ? 'enemy'
  185 |                     : 'neutral',
  186 |             };
  187 |           });
  188 |         expect(visibleSignals.length).toBeGreaterThan(0);
  189 |         if (camera !== 'overview') {
  190 |           expect(visibleSignals.some((army) => army.signal.painted)).toBe(true);
  191 |           expect(visibleSignals.some((army) => army.status === 'routed')).toBe(true);
  192 |         }
  193 |         writeFileSync(
  194 |           info.outputPath(`${camera}-${mode}-observation.json`),
  195 |           JSON.stringify(
  196 |             {
  197 |               scope: 'unchanged visual-map, three actual owners; NOT forty-clan perceived coverage',
  198 |               nearNeutral:
  199 |                 'deferred: retained Sunpu cameras do not guarantee near Saito visibility',
  200 |               noncolorCuesToReview: [
  201 |                 'friendly double rings',
  202 |                 'enemy pointed tail',
  203 |                 'neutral hollow diamond',
  204 |                 'routed droop and chevron',
  205 |                 'siege hook',
  206 |                 'castle warning glyph',
  207 |                 'supply bag and triangle',
  208 |               ],
  209 |               // These records prove emitted bounds/state, not glyph visibility through
  210 |               // HUD occlusion or successful human recognition under a deficiency.
  211 |               visibleSignals,
  212 |               warningFramesScope:
  213 |                 'all emitted fixture warning frames, including offscreen; not positive visibility proof',
  214 |               warningFrames: baseline.diagnostics.castleRendering.nodes.filter(
  215 |                 (node) => node.warning !== null,
  216 |               ),
  217 |               changedPixels,
  218 |               baseline,
  219 |               emulated,
  220 |               restored,
  221 |             },
  222 |             null,
  223 |             2,
  224 |           ),
  225 |         );
  226 |       }
  227 |     } finally {
  228 |       try {
  229 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  230 |       } finally {
  231 |         await session.detach();
  232 |       }
  233 |     }
  234 |   });
  235 | }
  236 | 
```
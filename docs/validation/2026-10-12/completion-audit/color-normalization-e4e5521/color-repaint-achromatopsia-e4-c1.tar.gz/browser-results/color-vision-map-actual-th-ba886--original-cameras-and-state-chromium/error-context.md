# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: color-vision-map.spec.ts >> actual three-owner map achromatopsia artifacts preserve original cameras and state
- Location: e2e/color-vision-map.spec.ts:129:3

# Error details

```
Error: no-CDP repaint control remains exact

expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 385
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  78  |     const owners = [header, rail];
  79  |     const saved = owners.map((node) => ({
  80  |       node,
  81  |       styleAttribute: node.getAttribute('style'),
  82  |       value: node.style.getPropertyValue('visibility'),
  83  |       priority: node.style.getPropertyPriority('visibility'),
  84  |     }));
  85  |     const frame = () => new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
  86  |     try {
  87  |       for (const node of owners) node.style.setProperty('visibility', 'hidden');
  88  |       await frame();
  89  |       await frame();
  90  |     } finally {
  91  |       for (const { node, styleAttribute, value, priority } of saved) {
  92  |         if (value) node.style.setProperty('visibility', value, priority);
  93  |         else node.style.removeProperty('visibility');
  94  |         if (styleAttribute === null) node.removeAttribute('style');
  95  |         else node.setAttribute('style', styleAttribute);
  96  |       }
  97  |     }
  98  |     await frame();
  99  |     await frame();
  100 |   });
  101 |   await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  102 | }
  103 | 
  104 | async function chromePaintState(page: Page) {
  105 |   return page.evaluate(() => {
  106 |     const header = document.querySelector('[data-testid="hud-resources"]')?.parentElement;
  107 |     const rail = document.querySelector('[data-testid="rail-realm"]')?.closest('nav');
  108 |     if (!(header instanceof HTMLElement) || !(rail instanceof HTMLElement))
  109 |       throw new Error('HUD/rail paint owners missing');
  110 |     const describe = (node: HTMLElement) => ({
  111 |       styleAttribute: node.getAttribute('style'),
  112 |       inlineValue: node.style.getPropertyValue('visibility'),
  113 |       inlinePriority: node.style.getPropertyPriority('visibility'),
  114 |       computedVisibility: getComputedStyle(node).visibility,
  115 |       computedDisplay: getComputedStyle(node).display,
  116 |       opacity: getComputedStyle(node).opacity,
  117 |       rect: node.getBoundingClientRect().toJSON(),
  118 |       text: node.innerText,
  119 |     });
  120 |     return {
  121 |       header: describe(header),
  122 |       rail: describe(rail),
  123 |       focus: document.activeElement?.getAttribute('data-testid') ?? document.activeElement?.tagName,
  124 |     };
  125 |   });
  126 | }
  127 | 
  128 | for (const mode of modes) {
  129 |   test(`actual three-owner map ${mode} artifacts preserve original cameras and state`, async ({
  130 |     page,
  131 |   }, info) => {
  132 |     await page.setViewportSize({ width: 1280, height: 720 });
  133 |     await page.emulateMedia({ reducedMotion: 'reduce' });
  134 |     await page.goto('/?debug=visual-map');
  135 |     await expect(page.getByTestId('screen-strategy')).toBeVisible();
  136 |     await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  137 |     await page.evaluate(() => document.fonts.ready);
  138 |     await page.mouse.move(1270, 710);
  139 |     const initial = await observe(page);
  140 |     writeFileSync(info.outputPath('initial-preflight.json'), JSON.stringify(initial, null, 2));
  141 |     expect(validateState(initial.state)).toEqual([]);
  142 |     expect(
  143 |       [...new Set(Object.values(initial.state.armies).map((army) => army.clanId))].sort(),
  144 |     ).toEqual(['clan.imagawa', 'clan.oda', 'clan.saito']);
  145 |     const session = await page.context().newCDPSession(page);
  146 |     try {
  147 |       for (const camera of cameras) {
  148 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  149 |         await page.evaluate((preset) => window.__tenka.debug.setMapCameraPreset(preset), camera);
  150 |         let prior = '',
  151 |           stable = 0;
  152 |         await expect
  153 |           .poll(async () => {
  154 |             const value = invariantPresentation((await observe(page)).diagnostics);
  155 |             const current = JSON.stringify(value);
  156 |             stable = current === prior ? stable + 1 : 0;
  157 |             prior = current;
  158 |             return stable;
  159 |           })
  160 |           .toBeGreaterThanOrEqual(3);
  161 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  162 |         await repaintChrome(page);
  163 |         const visible = await chromePaintState(page);
  164 |         expect(visible.header.computedVisibility).toBe('visible');
  165 |         expect(visible.rail.computedVisibility).toBe('visible');
  166 |         const baseline = await observe(page);
  167 |         writeFileSync(
  168 |           info.outputPath(`${camera}-none-observation.json`),
  169 |           JSON.stringify(baseline, null, 2),
  170 |         );
  171 |         expect(baseline.diagnostics.lodStage).toBe(
  172 |           { overview: 'far', operational: 'mid', close: 'near' }[camera],
  173 |         );
  174 |         const none = await page.screenshot({ path: info.outputPath(`${camera}-none.png`) });
  175 |         await repaintChrome(page);
  176 |         expect(await chromePaintState(page)).toEqual(visible);
  177 |         const noCdpAgain = await page.screenshot({ path: info.outputPath(`${camera}-none-again.png`) });
> 178 |         expect(difference(none, noCdpAgain), 'no-CDP repaint control remains exact').toBe(0);
      |                                                                                      ^ Error: no-CDP repaint control remains exact
  179 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: mode });
  180 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  181 |         await repaintChrome(page);
  182 |         expect(await chromePaintState(page)).toEqual(visible);
  183 |         const emulated = await observe(page);
  184 |         writeFileSync(
  185 |           info.outputPath(`${camera}-${mode}-raw-observation.json`),
  186 |           JSON.stringify(emulated, null, 2),
  187 |         );
  188 |         const changed = await page.screenshot({ path: info.outputPath(`${camera}-${mode}.png`) });
  189 |         const changedPixels = difference(none, changed);
  190 |         expect(
  191 |           changedPixels,
  192 |           'the CDP mode must actually change the captured framebuffer',
  193 |         ).toBeGreaterThan(0);
  194 |         await session.send('Emulation.setEmulatedVisionDeficiency', { type: 'none' });
  195 |         await page.evaluate(() => window.__tenka.debug.waitMapIdle(5));
  196 |         await repaintChrome(page);
  197 |         expect(await chromePaintState(page)).toEqual(visible);
  198 |         const restored = await observe(page);
  199 |         writeFileSync(
  200 |           info.outputPath(`${camera}-restored-observation.json`),
  201 |           JSON.stringify(restored, null, 2),
  202 |         );
  203 |         const restoredPixels = await page.screenshot({
  204 |           path: info.outputPath(`${camera}-restored.png`),
  205 |         });
  206 |         expect(
  207 |           difference(none, restoredPixels),
  208 |           'restoring none must recover exact RGBA pixels',
  209 |         ).toBe(0);
  210 |         for (const actual of [baseline, emulated, restored]) {
  211 |           expect(actual.state).toEqual(initial.state);
  212 |           expect(actual.commands).toEqual(initial.commands);
  213 |           expect(validateState(actual.state)).toEqual([]);
  214 |           expect(actual.canvas).toEqual(baseline.canvas);
  215 |           expect(invariantPresentation(actual.diagnostics)).toEqual(
  216 |             invariantPresentation(baseline.diagnostics),
  217 |           );
  218 |         }
  219 |         const visibleSignals = baseline.diagnostics.armyRendering.signals
  220 |           .filter((signal) => {
  221 |             const rect = signal.rect;
  222 |             return (
  223 |               signal.visible &&
  224 |               rect !== null &&
  225 |               [rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) &&
  226 |               rect.width > 0 &&
  227 |               rect.height > 0 &&
  228 |               rect.x < baseline.canvas.width &&
  229 |               rect.y < baseline.canvas.height &&
  230 |               rect.x + rect.width > 0 &&
  231 |               rect.y + rect.height > 0
  232 |             );
  233 |           })
  234 |           .map((signal) => {
  235 |             const army = baseline.state.armies[signal.id as keyof typeof baseline.state.armies]!;
  236 |             return {
  237 |               signal,
  238 |               clanId: army.clanId,
  239 |               leaderId: army.leaderId,
  240 |               status: army.status,
  241 |               morale: army.morale,
  242 |               relation:
  243 |                 army.clanId === 'clan.oda'
  244 |                   ? 'friendly'
  245 |                   : army.clanId === 'clan.imagawa'
  246 |                     ? 'enemy'
  247 |                     : 'neutral',
  248 |             };
  249 |           });
  250 |         expect(visibleSignals.length).toBeGreaterThan(0);
  251 |         if (camera !== 'overview') {
  252 |           expect(visibleSignals.some((army) => army.signal.painted)).toBe(true);
  253 |           expect(visibleSignals.some((army) => army.status === 'routed')).toBe(true);
  254 |         }
  255 |         writeFileSync(
  256 |           info.outputPath(`${camera}-${mode}-observation.json`),
  257 |           JSON.stringify(
  258 |             {
  259 |               scope: 'unchanged visual-map, three actual owners; NOT forty-clan perceived coverage',
  260 |               nearNeutral:
  261 |                 'deferred: retained Sunpu cameras do not guarantee near Saito visibility',
  262 |               noncolorCuesToReview: [
  263 |                 'friendly double rings',
  264 |                 'enemy pointed tail',
  265 |                 'neutral hollow diamond',
  266 |                 'routed droop and chevron',
  267 |                 'siege hook',
  268 |                 'castle warning glyph',
  269 |                 'supply bag and triangle',
  270 |               ],
  271 |               // These records prove emitted bounds/state, not glyph visibility through
  272 |               // HUD occlusion or successful human recognition under a deficiency.
  273 |               visibleSignals,
  274 |               warningFramesScope:
  275 |                 'all emitted fixture warning frames, including offscreen; not positive visibility proof',
  276 |               warningFrames: baseline.diagnostics.castleRendering.nodes.filter(
  277 |                 (node) => node.warning !== null,
  278 |               ),
```
import json,pathlib,collections,re
r=pathlib.Path('/tmp/tenka-prep-local/tenka-prep-current23-evidence');p=json.loads((r/'close.cpuprofile').read_text());m=json.loads((r/'profile-caller-attribution.json').read_text());ns={n['id']:n for n in p['nodes']};labels={n['id']:n for n in m['mappedNodes']};parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])};rows={}
for id,dt in zip(p['samples'],p['timeDeltas']):
 n=ns[id];f=n['callFrame'];cur=id;caller=None
 while cur is not None:
  l=labels[cur]
  if l['source'].endswith('/wasmGeographicPreparation.ts') and l['name'] in ['prepare','scorePrepared']:caller=l['name'];break
  cur=parents.get(cur)
 if caller!='scorePrepared' or not f['url'].startswith('wasm:'):continue
 key=(f['functionName'],f['lineNumber'],f['columnNumber']);row=rows.setdefault(key,dict(function=f['functionName'],lineNumber=f['lineNumber'],columnNumber=f['columnNumber'],selfUs=0,selfSamples=0));row['selfUs']+=dt;row['selfSamples']+=1
out=sorted(rows.values(),key=lambda r:-r['selfUs']);total=sum(r['selfUs'] for r in out)
for r in out:r['percentOfScorePreparedWasmExclusive']=r['selfUs']/total*100
print(json.dumps({'totalSelfUs':total,'samples':sum(r['selfSamples'] for r in out),'rows':out},indent=2));pathlib.Path('/tmp/prep-internal-leaves.json').write_text(json.dumps({'totalSelfUs':total,'samples':sum(r['selfSamples'] for r in out),'rows':out},indent=2))

import pathlib,json
b=pathlib.Path('/tmp/tenka-prep-local/tenka-prep-current23-evidence/tenka_engine.wasm').read_bytes();i=8
def u():
 global i
 v=s=0
 while True:
  x=b[i];i+=1;v+=(x&127)<<s
  if not x&128:return v
  s+=7
def text():
 global i
 n=u();s=b[i:i+n].decode();i+=n;return s
custom=[];names={}
while i<len(b):
 section=b[i];i+=1;n=u();end=i+n
 if section==0:
  title=text();custom.append(title)
  if title=='name':
   while i<end:
    sub=b[i];i+=1;l=u();se=i+l
    if sub==1:
     for _ in range(u()):
      idx=u();names[idx]=text()
    i=se
 i=end
print(json.dumps({'customSections':custom,'functionNames':names},indent=2));pathlib.Path('/tmp/prep-wasm-names.json').write_text(json.dumps({'customSections':custom,'functionNames':names},indent=2))

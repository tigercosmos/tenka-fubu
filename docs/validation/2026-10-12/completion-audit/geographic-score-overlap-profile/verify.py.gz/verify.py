import pathlib,json,gzip,hashlib,sys,re,subprocess,collections
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):return gzip.decompress((p/(n+'.gz')).read_bytes())
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
v=json.loads(raw('provenance.json'))
for a in v['inputs']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
for a in v['sourcePins']:
 b=raw(a['artifact'][:-3]);assert h(b)==a['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==a['gitBlob']
parts=re.split(r'\n(?=[0-9a-f]{8} <)',raw('feab-wasm-disassembly.txt').decode())[1:]
assert len(parts)==143 and '<CODE>' in parts[0]
for i in [25,26,27,29,33,44,51,58]:assert parts[i].encode()==raw('feab-function-'+str(i)+'.txt')
assert '<geo_score_prepared>' in parts[58] and 'call\t33' in parts[58]
assert json.loads(raw('prep-wasm-names.json'))=={'customSections':[],'functionNames':{}}
profile=json.loads(gzip.decompress((p/'../geographic-preparation-native/close.cpuprofile.gz').read_bytes()));labels={n['id']:n for n in json.loads(gzip.decompress((p/'../geographic-preparation-native/profile-caller-attribution.json.gz').read_bytes()))['mappedNodes']};ns={n['id']:n for n in profile['nodes']};par={c:n['id'] for n in profile['nodes'] for c in n.get('children',[])};rows=collections.defaultdict(lambda:[0,0]);parents=collections.defaultdict(lambda:[0,0])
for id,dt in zip(profile['samples'],profile['timeDeltas']):
 n=ns[id];cur=id;caller=None
 while cur is not None:
  l=labels[cur]
  if l['source'].endswith('/wasmGeographicPreparation.ts') and l['name'] in ['prepare','scorePrepared']:caller=l['name'];break
  cur=par.get(cur)
 if caller!='scorePrepared' or not n['callFrame']['url'].startswith('wasm:'):continue
 k=n['callFrame']['functionName'];rows[k][0]+=dt;rows[k][1]+=1
 if k=='wasm-function[44]':q=ns[par[id]]['callFrame']['functionName'];parents[q][0]+=dt;parents[q][1]+=1
r=json.loads(raw('prep-internal-leaves.json'));assert sum(v[0] for v in rows.values())==r['totalSelfUs']==2335044
for a in r['rows']:assert rows[a['function']]==[a['selfUs'],a['selfSamples']]
for k,a in r['overlap44ByImmediateParentInScore'].items():assert parents['wasm-function['+k+']']==[a['selfUs'],a['samples']]
print('PASS: dual hashes, pinned parent inputs/source Git blobs, disassembly snippets, exact existing-profile leaf/caller counts; inferred symbols remain unproven')

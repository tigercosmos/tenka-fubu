import pathlib,json,gzip,hashlib,subprocess,sys,re
out=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-score-overlap-profile');out.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest();raw=pathlib.Path('/tmp/score-overlap-raw');raw.mkdir(exist_ok=True)
(raw/'package-producer.py').write_bytes(pathlib.Path(__file__).read_bytes())
files=['prep-internal-leaves.json','prep-internal-leaves.py','prep-wasm-names.py','prep-wasm-names.json','feab-wasm-disassembly.txt']+['feab-function-'+str(i)+'.txt' for i in [25,26,27,29,33,44,51,58]]
for n in files:(raw/n).write_bytes((pathlib.Path('/tmp')/n).read_bytes())
head='feab20cc9c207f37afae7a2f372c437b93232a07';sources=[]
for name in ['geographic.rs','geographic_preparation.rs']:
 path='rust/engine/src/'+name;b=subprocess.check_output(['git','show',head+':'+path]);(raw/name).write_bytes(b);sources.append(dict(path=path,artifact=name+'.gz',gitBlob=subprocess.check_output(['git','rev-parse',head+':'+path],text=True).strip(),sha256=h(b)))
version=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/llvm-objdump','--version']);(raw/'llvm-objdump-version.txt').write_bytes(version)
provenance=dict(scope='offline analysis of the already captured unique feab close profile; no new GPU/testing/timing/source modification',frozenSourceCommit=head,parentEvidenceCommit='44c3b30',parentPackage='../geographic-preparation-native',inputs=[],sourcePins=sources,tools=dict(python=sys.version,llvmVersion='Homebrew LLVM22.1.6',llvmObjdumpPath='/opt/homebrew/opt/llvm/bin/llvm-objdump',llvmObjdumpSHA256=h(pathlib.Path('/opt/homebrew/opt/llvm/bin/llvm-objdump').read_bytes()),sourceMappingLibrary='@jridgewell/trace-mapping0.3.31',mappingProof='parent package profile-attribution.mjs + mappedNodes +14765 dependency manifests'),commands=['llvm-objdump -d <parent tenka_engine.wasm> > feab-wasm-disassembly.txt','python3 /tmp/prep-wasm-names.py','python3 /tmp/prep-internal-leaves.py'],nameStatus='Actual binary has zero custom sections, so no retained name/DWARF symbol mapping; source names are strong arithmetic and callsite inference only',snippetExtraction='Split the complete llvm-objdump output at newline before eight-hex-digit function headings; section CODE has142definedfunctions plus1 importedfunction0; split item0 is CODE header so itemN matches functionindexN, confirmed by actual exports58/56')
parent=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-preparation-native')
for n in ['tenka_engine.wasm','close.cpuprofile','profile-caller-attribution.json','close-profile-source-summary.json']:
 z=(parent/(n+'.gz')).read_bytes();b=gzip.decompress(z);provenance['inputs'].append(dict(path='../geographic-preparation-native/'+n+'.gz',rawBytes=len(b),rawSHA256=h(b),gzipBytes=len(z),gzipSHA256=h(z)))
(raw/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
verifier='''import pathlib,json,gzip,hashlib,sys,re,subprocess,collections
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):return gzip.decompress((p/(n+'.gz')).read_bytes())
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
v=json.loads(raw('provenance.json'))
for a in v['inputs']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
for a in v['sourcePins']:
 b=raw(a['artifact'][:-3]);assert h(b)==a['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\\0'+b).hexdigest()==a['gitBlob']
parts=re.split(r'\\n(?=[0-9a-f]{8} <)',raw('feab-wasm-disassembly.txt').decode())[1:]
assert len(parts)==143 and '<CODE>' in parts[0]
for i in [25,26,27,29,33,44,51,58]:assert parts[i].encode()==raw('feab-function-'+str(i)+'.txt')
assert '<geo_score_prepared>' in parts[58] and 'call\\t33' in parts[58]
assert json.loads(raw('prep-wasm-names.json'))=={'customSections':[],'functionNames':{}}
profile=json.loads(gzip.decompress((p/'../geographic-preparation-native/close.cpuprofile.gz').read_bytes()));labels={n['id']:n for n in json.loads(gzip.decompress((p/'../geographic-preparation-native/profile-caller-attribution.json.gz').read_bytes()))['mappedNodes']};ns={n['id']:n for n in profile['nodes']};par={c:n['id'] for n in profile['nodes'] for c in n.get('children',[])};rows=collections.defaultdict(lambda:[0,0]);parents=collections.defaultdict(lambda:[0,0])
for id,dt in zip(profile['samples'],profile['timeDeltas']):
 n=ns[id];cur=id;caller=None
 while cur is not None:
  l=labels[cur]
  if l['source'].endswith('/wasmGeographicPreparation.ts') and l['name'] in ['prepare','scorePrepared']:caller=l['name'];break
  cur=par.get(cur)
 if caller!='scorePrepared' or not n['callFrame']['url'].startswith('wasm:'):continue
 k=n['callFrame']['functionName'];rows[k][0]+=dt;rows[k][1]+=1
 if k=='wasm-function[44]':q=ns[par[id]]['callFrame']['functionName'];parents[q][0]+=dt;parents[q][1]+=1
r=json.loads(raw('prep-internal-leaves.json'));assert sum(v[0] for v in rows.values())==r['totalSelfUs']==2335044
for a in r['rows']:assert rows[a['function']]==[a['selfUs'],a['selfSamples']]
for k,a in r['overlap44ByImmediateParentInScore'].items():assert parents['wasm-function['+k+']']==[a['selfUs'],a['samples']]
print('PASS: dual hashes, pinned parent inputs/source Git blobs, disassembly snippets, exact existing-profile leaf/caller counts; inferred symbols remain unproven')
'''
(raw/'verify.py').write_text(verifier)
s=dict(scope=provenance['scope'],target='overlap-like function44 is53.4895% of scorePrepared-context exclusive WASM sampled leaf time; unknown symbolic mapping',results=json.loads((raw/'prep-internal-leaves.json').read_text()),artifacts=[])
for f in sorted(raw.iterdir()):
 b=f.read_bytes();z=gzip.compress(b,mtime=0);(out/(f.name+'.gz')).write_bytes(z);s['artifacts'].append(dict(path=f.name+'.gz',rawBytes=len(b),rawSHA256=h(b),gzipBytes=len(z),gzipSHA256=h(z)))
(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
(out/'README.md').write_text('''# Existing geographic score profile: overlap target

This package analyzes the unique frozen feab close profile already preserved in `../geographic-preparation-native` (commit44c3b30). It adds no GPU workload, tests or timing. Parent profile, binary, mapped nodes and source-summary files are linked with both compressed and raw hashes; they are not duplicated here.

The actual binary has no custom/name/DWARF sections. Internal Rust names below are strong inferences from exact instruction bodies and frozen source patterns, not retained symbol proof. Full LLVM22.1.6 disassembly and exact function snippets are preserved.

| Score-context sampled WASM leaf | Own µs | Own samples | Share |
|---|---:|---:|---:|
| function44, overlap-like | 1,249,004 | 1,188 | 53.49% |
| function51, capsule-clearance-like | 451,088 | 429 | 19.32% |
| function33, internal score body | 232,396 | 221 | 9.95% |
| function27, padding2 fold-like | 169,217 | 161 | 7.25% |
| function26, padding0 fold-like | 127,229 | 121 | 5.45% |

These shares use 2,335,044 µs of exclusive WASM sampled leaf time under the mapped TS scorePrepared caller (2,221 samples). They do not use flat export-frame totals. Actual export58 invokes internal33. Function44 reads two four-f64 rectangles, performs padding-aware endpoint arithmetic with NaN/signed-zero-aware min/max, clips X/Y extents and multiplies them, matching frozen `geographic::overlap`. Function51 checks the five-word capsule limit/finite inputs and contains capsule distance arithmetic matching `clears_capsules` with inlined distance helpers.

Function26 iterates indexed rows and sums function44 with padding0; function27 does the same with padding2. Their callsites and frozen score source strongly suggest primary and reserved folds. Function44 own samples split by immediate parent:27 539,195 µs/513 samples;26 397,334/378;33 306,182/291;25 5,241/5;63 1,052/1. Adding disjoint helper-own samples gives 708,412 µs (30.34%) for27 and its44 child, and 524,563 µs (22.46%) for26 and its44 child. These are existing CPU samples, not isolated loop benchmarks.

Overlap-family dominance is supported. Hard-only or reserved-only dominance is not established. Direct33 overlap samples cannot distinguish hard checks from baseline/other inlined callsites; no instruction-PC distribution or symbolic debug provenance exists. LTO and inline/merged bodies limit Rust-name attribution. Inclusive parents overlap children and must not be added to these exclusive totals.

`summary.json` records byte counts and raw/gzip SHA256 for every artifact. `provenance.json.gz` pins the frozen source Git blobs, parent artifacts, LLVM executable/version and trace-mapping0.3.31 library. Decompress `verify.py.gz` and run it with this package path to verify hashes, source blobs, exact snippet extraction and all leaf/caller counts using the existing profile.
''')
print(len(s['artifacts']),sum(x['gzipBytes'] for x in s['artifacts']))

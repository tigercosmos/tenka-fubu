import { writeFile } from 'node:fs/promises';
import { test, expect } from '@playwright/test';

test('observe all wizard text at scale 0.8', async ({ page }, info) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.goto('/?debug=1&seed=42');
  await page.getByTestId('title-settings').click();
  const slider = page.getByRole('dialog').getByRole('slider', { name: '介面縮放', exact: true });
  await slider.press('Home');
  await expect(slider).toHaveValue('0.8');
  await page.getByRole('dialog').getByRole('button', { name: '返回', exact: true }).click();
  await page.getByTestId('title-newgame').click();

  const samples: Record<string, unknown> = {};
  async function observe(step: string, testid: string) {
    await expect(page.getByTestId(testid)).toBeVisible();
    samples[step] = await page.getByTestId(testid).evaluate((root) => {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      const rows = [];
      let node: Node | null;
      while ((node = walker.nextNode())) {
        const value = node.textContent?.trim();
        const parent = node.parentElement;
        if (!value || !parent) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rects = [...range.getClientRects()].map((rect) => ({
          x: rect.x,
          y: rect.y,
          width: rect.width,
          height: rect.height,
          withinViewport: rect.x >= 0 && rect.y >= 0 && rect.right <= 1280 && rect.bottom <= 720,
        }));
        if (!rects.some((rect) => rect.width > 0 && rect.height > 0)) continue;
        const style = getComputedStyle(parent);
        if (style.visibility === 'hidden' || style.display === 'none') continue;
        rows.push({
          text: value,
          parentTag: parent.tagName.toLowerCase(),
          parentClass: parent.className,
          parentTestId: parent.getAttribute('data-testid'),
          parentRole: parent.getAttribute('role'),
          fontPx: Number.parseFloat(style.fontSize),
          rects,
        });
      }
      return { count: rows.length, below12: rows.filter((row) => row.fontPx < 12), rows };
    });
    await page.screenshot({ path: info.outputPath(`font-${step}.png`) });
  }

  await observe('scenario', 'screen-scenario-select');
  await page.getByTestId('scenario-pick-s1560').click();
  await observe('daimyo-unselected', 'screen-daimyo-select');
  await page.getByTestId('clan-pick-clan.oda').click();
  await observe('daimyo-selected', 'screen-daimyo-select');
  await page.getByTestId('daimyo-next').click();
  await observe('difficulty', 'screen-difficulty-select');
  await page.getByTestId('difficulty-next').click();
  await observe('seed-valid', 'screen-seed-select');
  await page.getByTestId('newgame-seed').fill('');
  await observe('seed-invalid', 'screen-seed-select');
  await writeFile(info.outputPath('font-audit.json'), JSON.stringify(samples, null, 2));
});

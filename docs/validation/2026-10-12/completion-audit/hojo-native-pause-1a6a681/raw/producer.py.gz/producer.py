import base64, hashlib, json, shutil, subprocess, tarfile
from pathlib import Path

root=Path('/Users/tigercosmos/tenka-fubu')
pack=root/'docs/validation/2026-10-12/completion-audit/hojo-native-pause-1a6a681'
pack.mkdir(exist_ok=False)
raw=pack/'raw'; raw.mkdir()
shutil.copy2('/tmp/tenka-hojo-remote-download-4dd-c1/tenka-hojo-capture-bundle-4dd-c1.tar.gz',raw/'remote-captures.tar.gz')
local_names=['tenka-hojo-host-readiness-4dd-c1','tenka-hojo-baseline-source-proof-4dd-c1','tenka-hojo-delta-create-4dd-c1','tenka-hojo-runtime-clone-4dd-c1','tenka-hojo-overlay-apply-4dd-c1','tenka-hojo-source-before-outer-4dd-c1','tenka-hojo-source-after-outer-4dd-c1','tenka-hojo-typecheck-4dd-c1','tenka-hojo-format-check-4dd-c1','tenka-hojo-build-outer-4dd-c1','tenka-hojo-list-outer-4dd-c1','tenka-hojo-case-outer-4dd-c1','tenka-hojo-postprocess-4dd-c1','tenka-hojo-remote-inventory-4dd-c1','tenka-hojo-candidate-summary-4dd-c1','tenka-hojo-testtrace-read-4dd-c1','tenka-hojo-error-context-4dd-c1','tenka-hojo-remote-bundle-4dd-c1','tenka-hojo-remote-copy-4dd-c1']
with tarfile.open(raw/'local-captures.tar.gz','w:gz') as t:
 for name in local_names:
  p=Path('/tmp')/name
  if not p.exists(): raise RuntimeError(f'missing {p}')
  t.add(p,arcname=name)
shutil.copy2('/tmp/tenka-hojo-candidate-summary-4dd-c1/stdout-stderr.log',raw/'candidate-summary.json')
# Store the authoritative old trace events as a small lossless subset with exact parent SHA.
events=[]
for line in Path('/tmp/tenka-hojo-testtrace-read-4dd-c1/stdout-stderr.log').read_text().splitlines():
 try:d=json.loads(line)
 except json.JSONDecodeError: continue
 if d.get('callId') in {f'pw:api@{i}' for i in range(154,160)}:
  events.append({k:v for k,v in d.items() if k in ('type','callId','title','startTime','endTime','params','result')})
(raw/'original-trace-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
with (raw/'source.patch.gz').open('wb') as f:
 p=subprocess.run(['git','show','--format=','--binary','1a6a681','--','e2e/earned-hojo-aid.spec.ts'],cwd=root,stdout=subprocess.PIPE,check=True)
 import gzip
 f.write(gzip.compress(p.stdout,mtime=0))
(raw/'remote-retention.json').write_text(json.dumps({
 'candidateReport':{'host':'sim4','path':'/tmp/tenka-hojo-case-4dd-c1/report.json','size':170619281,'sha256':'c1f2e42973e7cde9f3fc3808a8425c08f50ca39e733803c67180d428e1f53174'},
 'originalTrace':{'host':'sim4','path':'/tmp/tenka-fullnative-9550-full-c1/browser-results/earned-hojo-aid-earned-Hoj-a4dd6-march-and-ordinary-movement-chromium/trace.zip','size':73572668,'sha256':'f2058ab0eaa88cc3f74177e9de351594dcf8577042b20e0329ad6c55f42d35aa'},
 'oldFullReport':{'path':'docs/validation/2026-10-12/completion-audit/fullnative-current-9550/report.json.gz'},
},indent=2)+'\n')
manifest={p.relative_to(pack).as_posix():{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(raw.iterdir())}
(pack/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(pack)
print(json.dumps(manifest,indent=2))

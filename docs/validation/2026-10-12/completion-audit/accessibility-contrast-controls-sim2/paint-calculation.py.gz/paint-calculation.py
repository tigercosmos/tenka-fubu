import gzip,json,re,sys
from pathlib import Path
from collections import Counter
from PIL import Image
root=Path(sys.argv[1])
data=json.loads(gzip.decompress((root/'probe--geometry-and-colors.json.gz').read_bytes()))
def luminance(rgb):
 linear=[c/255 for c in rgb]
 linear=[v/12.92 if v<=0.04045 else ((v+0.055)/1.055)**2.4 for v in linear]
 return sum(a*b for a,b in zip(linear,(0.2126,0.7152,0.0722)))
for row in data['rows']:
 ancestors=row['settled']['ancestors']
 foreground=tuple(map(int,re.findall(r'\d+',ancestors[0]['color'])))
 background=tuple(map(int,re.findall(r'\d+',next(a['background'] for a in ancestors if a['background'].startswith('rgb(')))))
 assert all(float(a['opacity'])==1 for a in ancestors)
 counts=Counter(Image.open(root/f"probe--{row['motion']}-status-paint.png").convert('RGB').getdata())
 assert counts[foreground]>0 and counts[background]>0
 lights=sorted((luminance(foreground),luminance(background)))
 ratio=(lights[1]+0.05)/(lights[0]+0.05)
 print(row['motion'],foreground,background,counts[foreground],counts[background],ratio)
 assert ratio>=4.5

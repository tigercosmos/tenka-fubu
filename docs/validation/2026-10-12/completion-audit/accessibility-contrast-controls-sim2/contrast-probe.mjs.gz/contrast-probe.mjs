import { chromium, expect } from '/tmp/tenka-a11y-e65fbbc/node_modules/@playwright/test/index.mjs';
import axe from '/tmp/tenka-a11y-e65fbbc/node_modules/axe-core/axe.js';
import { mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { createWriteStream } from 'node:fs';
const out='/tmp/tenka-a11y-contrast-probe';await mkdir(out,{recursive:true});
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4173','--strictPort'],{cwd:'/tmp/tenka-a11y-e65fbbc',detached:true,stdio:['ignore','pipe','pipe']});
const log=createWriteStream(`${out}/preview.log`);server.stdout.pipe(log);server.stderr.pipe(log);
let ready=false;for(let i=0;i<60;i++){try{if((await fetch('http://127.0.0.1:4173')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}
if(!ready){process.kill(-server.pid,'SIGTERM');throw Error('Preview unavailable');}
const browser=await chromium.launch({headless:true,channel:'chromium',args:['--enable-gpu','--use-angle=vulkan']});
const rows=[];
try{
 for(const motion of ['no-preference','reduce']){
  const context=await browser.newContext({viewport:{width:1280,height:720},reducedMotion:motion});const page=await context.newPage();
  await page.goto('http://127.0.0.1:4173/?debug=1');await page.getByTestId('title-newgame').click();await page.getByTestId('scenario-pick-s1560').click();await page.getByTestId('clan-pick-clan.oda').click();await page.getByTestId('newgame-start').click();await expect(page.getByTestId('screen-strategy')).toBeVisible();await page.getByTestId('speed-pause').click();await page.evaluate(async()=>{await window.__tenka.debug.waitSimulationIdle();await window.__tenka.debug.waitMapIdle();});await page.addScriptTag({content:axe.source});
  await page.getByRole('button',{name:'系統選單',exact:true}).click();await page.getByRole('button',{name:'讀檔',exact:true}).click();await expect(page.getByTestId('save-load-panel')).toHaveAttribute('aria-busy','false');
  const sample=async()=>await page.getByTestId('save-slot-manual:1').locator('span').first().evaluate(el=>{
   const ancestors=[];let p=el;while(p){const s=getComputedStyle(p);ancestors.push({tag:p.tagName,class:p.className,color:s.color,background:s.backgroundColor,opacity:s.opacity,animation:s.animationName,transform:s.transform});p=p.parentElement;}
   const bounds=el.getBoundingClientRect();return {ancestors,bounds:{x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height},disabled:el.closest('button')?.disabled??false,animations:document.getAnimations().map(a=>({state:a.playState,target:a.effect?.target?.className,name:a.animationName,time:a.currentTime}))};
  });
  const before=await sample();const immediate=await page.evaluate(()=>window.axe.run());await writeFile(`${out}/${motion}-immediate-axe.json`,JSON.stringify(immediate,null,2)+'\n');
  await page.getByRole('dialog').evaluate(async el=>{await Promise.all(el.parentElement.getAnimations({subtree:true}).map(a=>a.finished.catch(()=>{})));});
  const settled=await sample();const stable=await page.evaluate(()=>window.axe.run());await writeFile(`${out}/${motion}-settled-axe.json`,JSON.stringify(stable,null,2)+'\n');
  const span=page.getByTestId('save-slot-manual:1').locator('span').first();await span.screenshot({path:`${out}/${motion}-status-paint.png`});await page.screenshot({path:`${out}/${motion}-settled-page.png`});
  rows.push({motion,before,settled,immediate:immediate.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})),stable:stable.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length}))});await context.close();
 }
 await writeFile(`${out}/geometry-and-colors.json`,JSON.stringify({browser:browser.version(),rows},null,2)+'\n');console.log(JSON.stringify(rows));
}finally{await browser.close();process.kill(-server.pid,'SIGTERM');log.end();}

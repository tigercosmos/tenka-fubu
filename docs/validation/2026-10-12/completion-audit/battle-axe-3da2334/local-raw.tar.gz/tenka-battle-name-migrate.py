"""Replace only the three old exact Battle speed names in listed E2E files."""

import pathlib
import sys

root = pathlib.Path('/Users/tigercosmos/tenka-fubu')
names = {'一倍速': '一倍速 ×1', '二倍速': '二倍速 ×2', '五倍速': '五倍速 ×5'}
total = 0
for argument in sys.argv[1:]:
    path = root / argument
    assert path.parent == root / 'e2e' and path.suffix == '.ts', path
    original = path.read_text()
    updated = original
    for old, new in names.items():
        needle = f"'{old}'"
        count = updated.count(needle)
        updated = updated.replace(needle, f"'{new}'")
        total += count
    assert updated != original, path
    path.write_text(updated)
    print(f'{argument}: changed')
print(f'REPLACEMENTS: {total}')

"""Find unmigrated exact Battle speed accessible names in source/test consumers."""

import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/Users/tigercosmos/tenka-fubu')
pattern = re.compile(r"(?P<quote>['\"])(?P<name>一倍速|二倍速|五倍速)(?P=quote)")
total = 0
for directory in ('src', 'tests', 'e2e'):
    base = root / directory
    if not base.exists():
        continue
    for path in sorted(base.rglob('*')):
        if path.suffix not in ('.ts', '.tsx') or 'i18n' in path.parts:
            continue
        for line_number, line in enumerate(path.read_text().splitlines(), 1):
            for match in pattern.finditer(line):
                print(f'{path.relative_to(root)}:{line_number} -- old Battle speed name {match.group("name")}')
                total += 1
print('EXCLUDED: src/i18n translation definitions, generated and vendored files')
print(f'VIOLATIONS: {total}')

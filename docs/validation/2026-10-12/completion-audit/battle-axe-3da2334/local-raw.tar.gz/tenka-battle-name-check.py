"""Find old Battle speed accessible names in E2E consumers only."""

import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/Users/tigercosmos/tenka-fubu')
pattern = re.compile(r"(?P<quote>['\"])(?P<name>一倍速|二倍速|五倍速)(?P=quote)")
total = 0
for path in sorted((root / 'e2e').glob('*.ts')):
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        for match in pattern.finditer(line):
            print(f'{path.relative_to(root)}:{line_number} -- old Battle speed name {match.group("name")}')
            total += 1
print('EXCLUDED: src/i18n, src/ui, tests, generated and vendored files')
print(f'VIOLATIONS: {total}')

import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { resolve, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';

const repo = process.cwd();
const pixi = resolve(repo, 'node_modules/pixi.js');
const require = createRequire(resolve(pixi, 'package.json'));
const manifest = JSON.parse(readFileSync(resolve(repo, 'tools/dependencies/pixi-8.19-patch.json')));
const baselineManifest = JSON.parse(gunzipSync(readFileSync(resolve(repo, 'docs/validation/2026-10-12/completion-audit/gpu-cache-key-local/baseline-23-manifest.json.gz'))));
const EventEmitter = require('eventemitter3');
const Module = require('node:module');

function original(relative) {
  const target = manifest.targets.find((item) => item.path === relative);
  assert(target, relative);
  let source = readFileSync(resolve(pixi, relative), 'utf8');
  for (const { from, to } of [...target.replacements].reverse()) {
    if (!to && from.startsWith('//# sourceMappingURL=')) source += from;
    else source = source.replace(to, from);
  }
  return source;
}
function compile(relative, source) {
  const file = resolve(pixi, relative);
  const mod = new Module(file);
  mod.filename = file;
  mod.paths = Module._nodeModulePaths(dirname(file));
  mod._compile(source, file);
  return mod.exports;
}
const cjsRendererPath = 'lib/rendering/renderers/shared/system/AbstractRenderer.js';
const cjsHashPath = 'lib/utils/data/GCManagedHash.js';
const oldRenderer = compile(cjsRendererPath, original(cjsRendererPath)).AbstractRenderer;
const oldHash = compile(cjsHashPath, original(cjsHashPath)).GCManagedHash;
const baselineTarget = baselineManifest.targets.find((item) => item.path === cjsHashPath);
assert(baselineTarget);
let baselineSource = original(cjsHashPath);
for (const { from, to } of baselineTarget.replacements) {
  assert.equal(baselineSource.split(from).length, 2);
  baselineSource = baselineSource.replace(from, to);
}
const baselineHash = compile(cjsHashPath, baselineSource).GCManagedHash;
const fixedRenderer = require(resolve(pixi, cjsRendererPath)).AbstractRenderer;
const fixedHash = require(resolve(pixi, cjsHashPath)).GCManagedHash;
const { AbstractRenderer: esmRenderer } = await import(pathToFileURL(resolve(pixi, cjsRendererPath.replace(/\.js$/, '.mjs'))));
const { GCManagedHash: esmHash } = await import(pathToFileURL(resolve(pixi, cjsHashPath.replace(/\.js$/, '.mjs'))));

function renderer(Ctor) {
  const instance = new Ctor({ type: 1, name: 'control', runners: [], systems: [], renderPipes: [], renderPipeAdaptors: [] });
  instance.gc = { now: 1, addResourceHash() {} };
  return instance;
}
function cycle(Hash, Renderer, count) {
  const item = new EventEmitter();
  item.uid = 1;
  item._gpuData = Object.create(null);
  let unload = 0;
  let destroyed = 0;
  const ids = [];
  for (let i = 0; i < count; i++) {
    const owner = renderer(Renderer);
    ids.push(owner.uid);
    const managed = new Hash({ renderer: owner, type: 'resource', name: 'control', onUnload() { unload++; } });
    item._gpuData[owner.uid] = { destroy() { destroyed++; } };
    assert.equal(managed.add(item), true);
    managed.removeAll();
    if (Hash !== oldHash) assert.equal(item.listenerCount('unload'), 0);
    managed.destroy();
    owner.destroy();
  }
  assert.equal(new Set(ids).size, count);
  return { keys: Object.keys(item._gpuData).length,
           unloadListeners: item.listenerCount('unload'), unload, destroyed,
           firstId: ids[0], lastId: ids.at(-1) };
}
const red = cycle(oldHash, oldRenderer, 130);
const baseline23 = cycle(baselineHash, oldRenderer, 130);
const cjs = cycle(fixedHash, fixedRenderer, 130);
const esm = cycle(esmHash, esmRenderer, 130);
assert.equal(red.keys, 130);
assert.equal(baseline23.keys, 130);
assert.equal(cjs.keys, 0);
assert.equal(esm.keys, 0);
assert.equal(red.unloadListeners, 130);
assert.equal(baseline23.unloadListeners, 0);
assert.equal(cjs.unloadListeners, 0);
assert.equal(esm.unloadListeners, 0);
for (const row of [red, baseline23, cjs, esm]) {
  assert.equal(row.unload, 130);
  assert.equal(row.destroyed, 130);
}
assert(red.firstId >= 0 && cjs.firstId < 0 && esm.firstId < 0);
const indexed = [];
indexed[cjs.firstId] = 1;
assert.equal(indexed.length, 0);

function shared(Hash, Renderer) {
  const first = renderer(Renderer), second = renderer(Renderer);
  const item = new EventEmitter();
  item.uid = 2;
  item._gpuData = Object.create(null);
  let firstDead = 0, secondDead = 0;
  item._gpuData[first.uid] = { destroy() { firstDead++; } };
  item._gpuData[second.uid] = { destroy() { secondDead++; } };
  const a = new Hash({ renderer: first, type: 'resource', name: 'first' });
  const b = new Hash({ renderer: second, type: 'resource', name: 'second' });
  a.add(item); b.add(item);
  a.destroy();
  assert.equal(firstDead, 1);
  assert.equal(secondDead, 0);
  assert.equal(Object.hasOwn(item._gpuData, second.uid), true);
  item._gpuData[first.uid] = { destroy() { firstDead++; } };
  const recreated = new Hash({ renderer: first, type: 'resource', name: 'recreated' });
  recreated.add(item); recreated.remove(item); recreated.destroy();
  b.destroy();
  assert.equal(item.listenerCount('unload'), 0);
  assert.deepEqual(Object.keys(item._gpuData), []);
  first.destroy(); second.destroy();
  return { firstDead, secondDead, keys: Object.keys(item._gpuData).length };
}
const result = { pristine: red, baseline23, cjs, esm, sharedCjs: shared(fixedHash, fixedRenderer),
                 sharedEsm: shared(esmHash, esmRenderer) };
console.log(JSON.stringify(result, null, 2));

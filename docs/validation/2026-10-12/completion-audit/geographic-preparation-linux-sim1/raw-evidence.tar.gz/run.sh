#!/usr/bin/env bash
set -u
set -o pipefail
cd /tmp/tenka-feab20c-preparation-linux-sim1-20261012
export PATH=/tmp/tenka-20261012-sim1-core/node-v22.23.3-linux-x64/bin:$HOME/.cargo/bin:$PATH
mkdir -p evidence
ln -s /tmp/tenka-04c7b60-worker-ready-sim1/node_modules node_modules
cp public/wasm/tenka_engine.wasm evidence/frozen-mac.wasm
cp public/wasm/manifest.json evidence/frozen-mac-manifest.json
set -x
uname -srm
node --version
npm --version
rustc +1.97.1 --version
cargo +1.97.1 --version
sha256sum package.json package-lock.json /tmp/tenka-04c7b60-worker-ready-sim1/package-lock.json
python3 evidence/snapshot.py before
npm run wasm:build > evidence/build.log 2>&1
build_status=$?
cat evidence/build.log
printf '%s\n' "$build_status" > evidence/build-exit.txt
python3 evidence/snapshot.py after
cmp public/wasm/tenka_engine.wasm evidence/frozen-mac.wasm
binary_status=$?
cmp public/wasm/manifest.json evidence/frozen-mac-manifest.json
manifest_status=$?
printf 'binary_cmp=%s\nmanifest_cmp=%s\n' "$binary_status" "$manifest_status" > evidence/comparison.txt
node evidence/abi.cjs > evidence/abi.json
sha256sum public/wasm/tenka_engine.wasm public/wasm/manifest.json evidence/frozen-mac.wasm evidence/frozen-mac-manifest.json
exit "$build_status"

const fs = require('node:fs');
const bytes = fs.readFileSync('public/wasm/tenka_engine.wasm');
const moduleBytes = new WebAssembly.Module(bytes);
const instance = new WebAssembly.Instance(moduleBytes, { env: { path_node_cost() { throw new Error('unexpected pathfinding'); } } });
const versions = {};
for (const name of ['engine_abi_version','geographic_abi_version','castle_ribbon_abi_version','geographic_preparation_abi_version']) versions[name] = instance.exports[name]();
console.log(JSON.stringify({bytes:bytes.length,exports:WebAssembly.Module.exports(moduleBytes),imports:WebAssembly.Module.imports(moduleBytes),versions},null,2));

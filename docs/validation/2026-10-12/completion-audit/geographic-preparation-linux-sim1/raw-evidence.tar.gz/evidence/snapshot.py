import hashlib,json,sys
from pathlib import Path
paths=[]
for folder in ['rust','tools','src']:
 paths.extend(p for p in Path(folder).rglob('*') if p.is_file() and 'target' not in p.parts)
paths.extend(Path(p) for p in ['package.json','package-lock.json','tsconfig.json','tsconfig.core.json','vite.config.ts','vitest.workspace.ts'])
rows=[]
for p in sorted(paths):
 raw=p.read_bytes();rows.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
Path('evidence/'+sys.argv[1]+'-source.json').write_text(json.dumps(rows,indent=2)+'\n')
print('source files',len(rows),'AppleDouble',len([p for p in paths if p.name.startswith('._')]))

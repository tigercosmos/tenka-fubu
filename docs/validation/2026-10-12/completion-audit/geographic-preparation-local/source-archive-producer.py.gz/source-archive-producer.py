from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,sys
base=Path('docs/validation/2026-10-12/completion-audit/geographic-preparation-local')
commit=sys.argv[1]
resolved=subprocess.check_output(['git','rev-parse',commit],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==resolved
paths=set(subprocess.check_output(['git','diff','--name-only','fc464a4',resolved],text=True).splitlines())
paths={p for p in paths if p.startswith(('src/','rust/','tools/','tests/')) and p.endswith(('.ts','.rs','.toml','.lock'))}
paths.update(['public/wasm/manifest.json','public/wasm/tenka_engine.wasm','rust/engine/Cargo.toml','rust/engine/Cargo.lock','rust/engine/rust-toolchain.toml','rust/engine/src/castle_ribbon.rs','rust/engine/src/castle_ribbon_tests.rs','tools/wasm/build.ts','tests/helpers/geographicWasmReference.ts','src/ui/map/roadLabelCapsules.ts','package.json','package-lock.json','tsconfig.json','tsconfig.core.json','vite.config.ts','vitest.workspace.ts'])
source=[]
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w') as tar:
 for p in sorted(paths):
  raw=subprocess.check_output(['git','show',f'{resolved}:{p}'])
  member=tarfile.TarInfo(p);member.size=len(raw);member.mode=0o644;member.mtime=0
  tar.addfile(member,io.BytesIO(raw))
  source.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':subprocess.check_output(['git','rev-parse',f'{resolved}:{p}'],text=True).strip()})
(base/'fixed-source.tar.gz').write_bytes(gzip.compress(archive.getvalue(),mtime=0))
(base/'source-index.json').write_text(json.dumps({'commit':resolved,'sources':source},indent=2)+'\n')
print('Archived',len(source),'committed source blobs for',resolved)

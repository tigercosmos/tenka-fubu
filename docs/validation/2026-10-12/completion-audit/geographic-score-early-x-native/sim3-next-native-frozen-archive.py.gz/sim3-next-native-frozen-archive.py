"""Prepare once AFTER explicit root freeze. No browser/build/SSH execution."""
import pathlib,subprocess,sys,tarfile,hashlib,json,io
head=sys.argv[1];prefix=pathlib.Path(sys.argv[2]);prefix.parent.mkdir(parents=True,exist_ok=True)
full=subprocess.check_output(['git','rev-parse',head],text=True).strip();assert full==head,'Require full authoritative frozen SHA'
roots={'.prettierrc.json','eslint.config.js','index.html','milestone.json','package-lock.json','package.json','playwright.cold-load.config.ts','playwright.config.ts','playwright.soak.config.ts','tsconfig.core.json','tsconfig.json','vite.config.ts','vitest.workspace.ts'}
entries=[]
for record in subprocess.check_output(['git','ls-tree','-r','-z',head]).split(b'\0'):
 if not record:continue
 info,name=record.split(b'\t',1);mode,kind,blob=info.decode().split();name=name.decode()
 if name in roots or name.split('/')[0] in ['src','public','rust','tools','tests','e2e']:
  assert kind=='blob' and mode in ['100644','100755'],('Unexpected source entry',mode,name)
  entries.append((name,mode,blob))
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);rows=[]
def exactly(n):
 parts=[]
 while n:
  b=proc.stdout.read(n);assert b,'Unexpected gitblob stream EOF';parts.append(b);n-=len(b)
 return b''.join(parts)
with tarfile.open(str(prefix)+'-source.tar.gz','w:gz') as tar:
 for name,mode,blob in entries:
  proc.stdin.write((blob+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().split();assert header[0]==blob and header[1]=='blob';data=exactly(int(header[2]));assert exactly(1)==b'\n';entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=int(mode,8)&0o777;tar.addfile(entry,io.BytesIO(data));rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),gitBlob=blob))
proc.stdin.close();assert proc.wait()==0
pathlib.Path(str(prefix)+'-expected.json').write_text(json.dumps(dict(commit=head,files=rows),indent=2)+'\n');print(json.dumps(dict(commit=head,sourceFiles=len(rows),archive=str(prefix)+'-source.tar.gz')))

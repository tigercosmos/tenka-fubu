import pathlib,tarfile,shutil,hashlib
r=pathlib.Path('/tmp/tenka-overlap-zero-native-current23-20261012');assert not r.exists();r.mkdir()
with tarfile.open('/tmp/sim3-overlap-zero-native-current23-source.tar.gz') as t:t.extractall(r,filter='data')
(r/'node_modules').symlink_to('/tmp/tenka-national120-current23-20261012/node_modules')
for a,b in [('national120-published.mjs','national120-published.mjs'),('overlap-zero-native-current23-profile.mjs','overlap-zero-native-current23-profile.mjs'),('overlap-zero-native-current23-profile-analysis.mjs','overlap-zero-native-current23-profile-analysis.mjs'),('sim3-overlap-zero-native-profile-attribution.mjs','profile-attribution.mjs')]:shutil.copyfile('/tmp/tenka-overlap-zero-native-templates/'+a,r/b)
assert hashlib.sha256((r/'e2e/national120-map-perf.spec.ts').read_bytes()).hexdigest()=='2d39ba643aa3c0aa7a242d0e93d081806fe54bd64b650f1ab78cbf67d4f567e4'
import json
m=json.loads(pathlib.Path('/tmp/sim3-overlap-zero-native-current23-expected.json').read_text())
assert m['commit']=='3633c61ba6608d32fc6c110e972b7fb0d9b12f7c'
for name,sha,size in [('tenka_engine.wasm','4935459682fdb5a509d72793518ce1343b49d8c07e041300b9262e6ca8acd759',90122),('tenka_engine.simd.wasm','f33324b483918c6671bbe368cd9065368403ae83ebfa27c36cb49053fd9fce77',89972)]:
 b=(r/'public/wasm'/name).read_bytes();assert len(b)==size and hashlib.sha256(b).hexdigest()==sha
artifacts=[f for f in m['files'] if f['path'].startswith('public/wasm/')]
for f in artifacts:
 b=(r/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print('Fresh full frozen source/public/fixtures, original FPS spec and actual scalar/SIMD/manifest hashes PASS')

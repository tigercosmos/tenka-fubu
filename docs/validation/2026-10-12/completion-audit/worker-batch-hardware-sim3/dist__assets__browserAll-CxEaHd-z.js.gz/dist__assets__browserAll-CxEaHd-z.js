import{e as a,A as e,C as i,a as s,D as t,E as n,F as d}from"./vendor-pixi-tMCd1M7V.js";import"./webworkerAll-y0dQvs9x.js";a.add(e);a.mixin(i,s);a.add(t);a.add(n);a.mixin(i,d);
//# sourceMappingURL=browserAll-CxEaHd-z.js.map

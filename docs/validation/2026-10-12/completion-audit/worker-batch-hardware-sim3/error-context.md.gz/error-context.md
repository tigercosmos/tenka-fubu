# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: worker120-hardware.spec.ts >> one RTX-controlled profiled120 warm Worker batch with full native parity and transport observations
- Location: diagnostics/worker120-hardware.spec.ts:143:1

# Error details

```
Test timeout of 60000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e3]:
    - region "戰略圖層" [ref=e6]:
      - group [ref=e7]:
        - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
    - banner [ref=e9]:
      - group "金錢、兵糧、兵力、威信" [ref=e10]:
        - generic [ref=e11]:
          - group "織田家" [ref=e12]
          - time [ref=e14]: 1560年5月2日
          - generic [ref=e15]:
            - generic [ref=e16]:
              - img [ref=e17]
              - generic [ref=e20]: 金錢
            - strong [ref=e23]: 1,653
          - generic [ref=e24]:
            - generic [ref=e25]:
              - img [ref=e26]
              - generic [ref=e28]: 兵糧
            - generic [ref=e29]:
              - strong [ref=e31]: 10,174
              - generic "兵糧可支撐24個月" [ref=e32]:
                - text: 兵糧可支撐
                - strong [ref=e33]: "24"
                - text: 個月
          - generic [ref=e34]:
            - generic [ref=e35]:
              - img [ref=e36]
              - generic [ref=e40]: 兵力
            - generic [ref=e42]:
              - strong [ref=e43]: 4,085
              - generic [ref=e44]: /4,362
          - generic [ref=e45]:
            - generic [ref=e46]:
              - img [ref=e47]
              - generic [ref=e49]: 威信
            - strong [ref=e52]: "250"
      - generic [ref=e53]:
        - generic [ref=e54]:
          - button "暫停" [disabled] [pressed]:
            - img
          - button "一倍速" [disabled]:
            - img
          - button "二倍速" [disabled]:
            - img
          - button "五倍速" [disabled]:
            - img
        - button "系統選單" [ref=e55] [cursor=pointer]:
          - img [ref=e56]
    - navigation "內政" [ref=e59]:
      - button "地圖一覽" [ref=e60] [cursor=pointer]:
        - img [ref=e61]
        - generic [ref=e64]:
          - generic [ref=e65]: 地圖
          - generic [ref=e66]: 一覽
      - button "織田家 （本城）" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
        - generic "織田家" [ref=e73]: 織田
      - generic [ref=e75]: 軍政
      - button "軍事" [ref=e76] [cursor=pointer]:
        - img [ref=e77]
        - text: 軍事
      - button "內政" [ref=e79] [cursor=pointer]:
        - img [ref=e80]
        - text: 內政
      - button "武將" [ref=e82] [cursor=pointer]:
        - img [ref=e83]
        - text: 武將
      - generic [ref=e88]: 交涉
      - button "外交" [ref=e89] [cursor=pointer]:
        - img [ref=e90]
        - text: 外交
      - button "調略" [ref=e92] [cursor=pointer]:
        - img [ref=e93]
        - text: 調略
      - generic [ref=e97]: 國策
      - button "政策" [ref=e98] [cursor=pointer]:
        - img [ref=e99]
        - text: 政策
      - button "軍團" [ref=e101] [cursor=pointer]:
        - img [ref=e102]
        - text: 軍團
      - button "大命" [ref=e104] [cursor=pointer]:
        - img [ref=e105]
        - text: 大命
    - generic:
      - generic:
        - generic:
          - button:
            - img
    - img "全國小地圖" [ref=e107]
    - generic:
      - button "通報 2 則" [ref=e111] [cursor=pointer]:
        - img [ref=e112]
      - generic "通報 2 則" [ref=e114]:
        - status [ref=e115] [cursor=pointer]:
          - generic [ref=e116]:
            - img [ref=e118]
            - generic [ref=e120]:
              - strong [ref=e121]: 待處理具申 6件
              - time [ref=e122]: 1560年5月2日
        - alert [ref=e123]:
          - generic [ref=e124]:
            - img [ref=e126]
            - generic [ref=e128]:
              - strong [ref=e129]: 那古野城遭北畠家包圍！
              - time [ref=e130]: 1560年3月30日
            - button "關閉通知" [ref=e132] [cursor=pointer]:
              - img [ref=e133]
      - button "報告中心" [ref=e135] [cursor=pointer]
  - dialog "具申 ─ 1,560年5月（6件）" [ref=e137]:
    - heading "具申 ─ 1,560年5月（6件）" [level=2] [ref=e138]
    - article [ref=e140]:
      - heading "柴田勝家・家老呈報" [level=3] [ref=e141]
      - generic [ref=e142]: 出陣具申
      - paragraph [ref=e143]: 出陣具申
      - generic [ref=e144]:
        - paragraph [ref=e145]: 由清洲城向田丸城出陣，撥出1,664人及兵糧1,996石。
        - paragraph [ref=e146]: 大將：柴田勝家・副將：無
      - paragraph [ref=e147]: 預估費用 0貫・功績報酬 30
      - paragraph [ref=e148]: 尚可裁決 29日
      - paragraph [ref=e149]: 採納：具申者忠誠＋2；駁回：忠誠－2；逾期：忠誠－1。
      - generic [ref=e150]:
        - button "拒絕" [ref=e152] [cursor=pointer]
        - button "採納" [ref=e154] [cursor=pointer]
      - paragraph [ref=e155]: 尚有6件具申
    - contentinfo [ref=e156]:
      - button "全部駁回" [ref=e157] [cursor=pointer]
```
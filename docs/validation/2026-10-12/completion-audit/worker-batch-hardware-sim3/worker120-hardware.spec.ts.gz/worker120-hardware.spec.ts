import type { Page } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { GameState } from '../src/core/state/gameState';
import type { Command } from '../src/core/commands/types';
import { CommandQueue, enqueuePendingAiOrders } from '../src/core/commands/queue';
import { CommandLogRecorder, type CommandLogFile } from '../src/core/replay/commandLog';
import { advanceDay } from '../src/core/systems';
import { createRuntimeEventEngine } from '../src/core/systems/events/runtime';
import { zCanonicalEventsFile } from '../src/data/schemas/eventDefinitions';
import { validateState } from '../src/core/state/invariants';
import { RANK_VALUES } from '../src/core/state/enums';
import { encodeFullSnapshot } from '../e2e/full-snapshot-transport';
import { test, expect } from '../e2e/fixtures';

async function nativeGame(page: Page) {
  await page.goto('/?debug=1&seed=1');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('newgame-start').click();
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
}

async function observeWorkerTraffic(page: Page) {
  await page.addInitScript(() => {
    const evidence = {
      created: 0,
      sent: [] as { kind: unknown; requestId: unknown; epoch: unknown; beforeStateVersion: unknown; postedAt: number; returnedAt: number }[],
      received: [] as {
        kind: unknown;
        requestId: unknown;
        backend: unknown;
        epoch: unknown;
        computeMs: unknown;
        beforeStateVersion: unknown;
        receivedAt: number;
        fullReply: unknown;
        replyKeys: string[];
        inconsistentThreatTotals: { clanId: string; total: number; sum: number }[];
      }[],
      longTasks: [] as { startTime: number; duration: number }[],
    };
    (window as unknown as { __workerEvidence: typeof evidence }).__workerEvidence = evidence;
    const NativeWorker = window.Worker;
    window.Worker = new Proxy(NativeWorker, {
      construct(target, argumentsList) {
        const worker = Reflect.construct(target, argumentsList) as Worker;
        const postMessage = worker.postMessage.bind(worker);
        evidence.created++;
        Object.defineProperty(worker, 'postMessage', {
          value: (...args: unknown[]) => {
            const data = args[0] as { kind?: unknown; requestId?: unknown; epoch?: unknown; beforeStateVersion?: unknown };
            const observation = { kind: data?.kind ?? null, requestId: data?.requestId ?? null, epoch: data?.epoch ?? null, beforeStateVersion: data?.beforeStateVersion ?? null, postedAt: performance.now(), returnedAt: 0 };
            evidence.sent.push(observation);
            Reflect.apply(postMessage, worker, args);
            observation.returnedAt = performance.now();
          },
        });
        worker.addEventListener('message', (event: MessageEvent) => {
          const receivedAt = performance.now();
          const data = event.data as {
            kind?: unknown;
            requestId?: unknown;
            backend?: unknown;
            epoch?: unknown;
            computeMs?: unknown;
            beforeStateVersion?: unknown;
            state?: GameState;
          };
          const inconsistentThreatTotals = Object.entries(data.state?.ai.clans ?? {})
            .filter(([, clan]) => clan.threatCache !== null)
            .map(([clanId, clan]) => ({
              clanId,
              total: clan.threatCache!.totalThreat,
              sum: clan.threatCache!.entries.reduce((sum, entry) => sum + entry.threat, 0),
            }))
            .filter((entry) => Math.abs(entry.total - entry.sum) > 1e-9);
          evidence.received.push({
            kind: data?.kind ?? null,
            requestId: data?.requestId ?? null,
            backend: data?.backend ?? null,
            epoch: data?.epoch ?? null,
            computeMs: data?.computeMs ?? null,
            beforeStateVersion: data?.beforeStateVersion ?? null,
            receivedAt,
            fullReply: structuredClone(data),
            replyKeys: Object.keys(data),
            inconsistentThreatTotals,
          });
        });
        return worker;
      },
    });
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries())
        evidence.longTasks.push({ startTime: entry.startTime, duration: entry.duration });
    }).observe({ type: 'longtask', buffered: true });
  });
}

async function snapshot(page: Page): Promise<GameState> {
  return JSON.parse(
    await page.evaluate<string>(
      `(${encodeFullSnapshot.toString()})(window.__tenka.debug.getState())`,
    ),
  ) as GameState;
}

function synchronousReference(
  initial: GameState,
  commands: readonly Command[],
  days: number,
  loaded = false,
) {
  const state = structuredClone(initial);
  const queue = new CommandQueue(state.meta.lastAppliedCmdSeq + 1);
  for (const command of commands) queue.enqueue(command, state.time.day);
  const catalog = zCanonicalEventsFile.parse(
    JSON.parse(
      readFileSync(new URL('../src/data/scenarios/s1560/events.json', import.meta.url), 'utf8'),
    ),
  );
  const engine = createRuntimeEventEngine(catalog.events);
  const recorder = new CommandLogRecorder();
  if (loaded) recorder.reset({ incompleteReason: 'loadedGame' });
  for (let day = 0; day < days; day++) {
    enqueuePendingAiOrders(state, queue);
    const submitted = queue.drain();
    const result = advanceDay(state, submitted, { eventEngine: engine });
    recorder.recordTick(result.appliedCommands, {
      ...(result.appliedCommands.length === submitted.length
        ? {}
        : { incompleteReason: 'hardRejection' as const }),
    });
  }
  return { state, log: recorder.export(state) };
}

// Independent observer experiment: exactly one profiled120-day Worker batch.
// Accepted six-case suite, production source and browser flags stay unchanged.
test('one RTX-controlled profiled120 warm Worker batch with full native parity and transport observations', async ({ page }, info) => {
  const http: { url: string; status: number }[] = [];
  page.on('response', (response) => {
    if (new URL(response.url()).pathname.endsWith('/wasm/tenka_engine.wasm'))
      http.push({url: response.url(), status:response.status()});
  });
  await observeWorkerTraffic(page);
  await nativeGame(page);
  await page.evaluate(() => window.__tenka.debug.waitMapIdle(2));
  const freshInitial = await snapshot(page);
  const initialLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  await page.evaluate(() => window.__tenka.debug.stepDaysAsync(1));
  await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  const warmInitial = await snapshot(page);
  const warmLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  const before = await page.evaluate(() => ({ simulation:window.__tenka.debug.getSimulationDiagnostics(), map:window.__tenka.debug.getMapDiagnostics() }));
  const captureGpu = async () => {
    const identity=await page.evaluate(()=>({canvases:[...document.querySelectorAll('canvas')].map(canvas=>{const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');if(!gl)return {width:canvas.width,height:canvas.height,context:null};const extension=gl.getExtension('WEBGL_debug_renderer_info');return {width:canvas.width,height:canvas.height,context:gl instanceof WebGL2RenderingContext?'webgl2':'webgl',contextLost:gl.isContextLost(),unmaskedVendor:extension?gl.getParameter(extension.UNMASKED_VENDOR_WEBGL):null,unmaskedRenderer:extension?gl.getParameter(extension.UNMASKED_RENDERER_WEBGL):null};})}));
    const browserSession=await page.context().browser()!.newBrowserCDPSession();
    const system=await browserSession.send('SystemInfo.getInfo');await browserSession.detach();
    return {identity,system};
  };
  const beforeGpu=await captureGpu();
  await writeFile('/tmp/tenka-worker-batch-hardware-sim3-evidence/hardware-preflight.json',JSON.stringify({beforeGpu,freshInitial,initialLog,warmInitial,warmLog,before}));
  const activeGpu=beforeGpu.identity.canvases.find(canvas=>canvas.context!==null);
  expect(activeGpu?.unmaskedRenderer).toMatch(/NVIDIA.*RTX|RTX/);
  expect(activeGpu?.unmaskedRenderer).not.toMatch(/SwiftShader|llvmpipe/i);
  expect(activeGpu?.contextLost).toBe(false);
  expect(activeGpu?.unmaskedRenderer).toContain('RTX 5070 Ti');
  expect(activeGpu?.unmaskedRenderer).toContain('Vulkan');
  const cdp=await page.context().newCDPSession(page);
  await cdp.send('Profiler.enable');
  await cdp.send('Profiler.start');
  let profile: unknown;
  let measurement: unknown;
  try {
    measurement=await page.evaluate(async () => {
      const tasks:{startTime:number;duration:number}[]=[];
      const frames:number[]=[];
      const observer=new PerformanceObserver(list=>{for(const entry of list.getEntries())tasks.push({startTime:entry.startTime,duration:entry.duration});});
      observer.observe({type:'longtask'});
      let frame=0;
      const onFrame=()=>{frames.push(performance.now());frame=requestAnimationFrame(onFrame);};
      frame=requestAnimationFrame(onFrame);
      await new Promise(resolve=>setTimeout(resolve,50));
      const initialDay=window.__tenka.debug.getState().time.day;
      const stepStart=performance.now();
      await window.__tenka.debug.stepDaysAsync(120);
      const stepEnd=performance.now();
      const idleStart=performance.now();
      await window.__tenka.debug.waitSimulationIdle();
      const idleEnd=performance.now();
      await new Promise(resolve=>setTimeout(resolve,50));
      await new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
      cancelAnimationFrame(frame);observer.disconnect();
      return { requestedDays:120,completedDays:window.__tenka.debug.getState().time.day-initialDay,stepStart,stepEnd,idleStart,idleEnd,stepMs:stepEnd-stepStart,idleMs:idleEnd-idleStart,totalMs:idleEnd-stepStart,frames,frameGapsMs:frames.slice(1).map((x,i)=>x-frames[i]!),longTasks:tasks.filter(t=>t.startTime<idleEnd&&t.startTime+t.duration>stepStart),simulation:window.__tenka.debug.getSimulationDiagnostics() };
    });
  } finally {
    profile=await cdp.send('Profiler.stop');
    await cdp.detach();
    await writeFile('/tmp/tenka-worker-batch-hardware-sim3-evidence/main-cpu-profile.json',JSON.stringify(profile));
  }
  const afterGpu=await captureGpu();
  await writeFile('/tmp/tenka-worker-batch-hardware-sim3-evidence/hardware-postflight.json',JSON.stringify(afterGpu));
  const actual=await snapshot(page);
  const actualLog=await page.evaluate(()=>window.__tenka.debug.exportCommandLog());
  const after=await page.evaluate(()=>({simulation:window.__tenka.debug.getSimulationDiagnostics(),map:window.__tenka.debug.getMapDiagnostics(),traffic:(window as unknown as {__workerEvidence:unknown}).__workerEvidence}));
  const fullTrafficJSON=await page.evaluate<string>(`(${encodeFullSnapshot.toString()})(window.__workerEvidence)`);
  await writeFile('/tmp/tenka-worker-batch-hardware-sim3-evidence/full-worker-traffic.raw.json',fullTrafficJSON);
  const reference=synchronousReference(freshInitial,[],121);
  const warmReference=synchronousReference(freshInitial,[],1);
  const observation={beforeGpu,afterGpu,freshInitial,initialLog,warmInitial,warmLog,before,measurement,actual,actualLog,after,reference,warmReference,http};
  await writeFile('/tmp/tenka-worker-batch-hardware-sim3-evidence/observation.json',JSON.stringify(observation));
  await info.attach('worker120-observation',{body:JSON.stringify(observation),contentType:'application/json'});
  const afterActiveGpu=afterGpu.identity.canvases.find(canvas=>canvas.context!==null);
  expect(afterActiveGpu?.unmaskedRenderer).toMatch(/NVIDIA.*RTX|RTX/);
  expect(afterActiveGpu?.unmaskedRenderer).not.toMatch(/SwiftShader|llvmpipe/i);
  expect(afterActiveGpu?.contextLost).toBe(false);
  expect(afterActiveGpu?.unmaskedRenderer).toContain('RTX 5070 Ti');
  expect(afterActiveGpu?.unmaskedRenderer).toContain('Vulkan');
  expect(warmInitial).toEqual(warmReference.state);
  expect(warmLog).toEqual(warmReference.log);
  expect(actual.time.day).toBe(121);
  expect(validateState(actual)).toEqual([]);
  expect(actual).toEqual(reference.state);
  expect(actualLog).toEqual(reference.log);
});

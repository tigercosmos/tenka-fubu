import pathlib,json,zipfile,hashlib,shutil
out=pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-evidence');trace=next((out/'original-test-results').rglob('trace.zip'));manifest=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,b,origin):
 (out/name).write_bytes(b);manifest.append({'name':name,'origin':origin,'bytes':len(b),'sha256':sha(b)})
def decode(x,refs):
 if 'ref' in x:return refs[x['ref']]
 for k in ['s','n','b']:
  if k in x:return x[k]
 if 'v' in x:
  if x['v']=='null':return None
  if x['v']=='undefined':return {'__playwrightUndefined':True}
  raise ValueError(x)
 if 'o' in x:
  d={};refs[x['id']]=d
  for p in x['o']:d[p['k']]=decode(p['v'],refs)
  return d
 if 'a' in x:
  a=[];refs[x['id']]=a;a.extend(decode(v,refs) for v in x['a']);return a
 raise ValueError(str(x)[:100])
with zipfile.ZipFile(trace) as z:
 for name in z.namelist():
  if not name.endswith('.trace'):continue
  for line in z.open(name):
   j=json.loads(line)
   if j.get('type')!='after' or j.get('callId') not in ['call@28','call@30','call@36','call@38','call@56','call@70','call@72','call@74','call@76']:continue
   cid=j['callId'];v=j.get('result',{}).get('value',{})
   if not v:continue
   # Preserve exact serialized Playwright result line bytes before any decoding.
   write('trace-result-'+cid.replace('@','-')+'.raw.jsonl',line,str(trace)+'#'+name+'#'+cid)
   if cid in ['call@28','call@36','call@70','call@76']:
    n={'call@28':'actual-initial-state.raw.json','call@36':'actual-warm-state.raw.json','call@70':'actual-final-state.raw.json','call@76':'actual-full-worker-traffic.raw.json'}[cid]
    write(n,v['s'].encode(),str(trace)+'#'+cid+'#exact-value.s')
   elif cid=='call@74':
    # The huge exact serialized callback line stays on the immutable trace; its metadata hash is enough.
    pass
   else:
    n={'call@30':'actual-initial-log.decoded.json','call@38':'actual-warm-log.decoded.json','call@56':'step-idle-boundaries.decoded.json','call@72':'actual-final-log.decoded.json'}[cid]
    b=json.dumps(decode(v,{}),separators=(',',':'),ensure_ascii=False).encode();write(n,b,str(trace)+'#'+cid+'#decoded-Playwright-value')
meta={'tracePath':str(trace),'traceSHA256':sha(trace.read_bytes()),'traceBytes':trace.stat().st_size,'traceType':'application/zip','terminalTestStatus':'RED timeout60000ms; original final parity assertions not reached','extracted':manifest}
(out/'trace-extraction-manifest.json').write_text(json.dumps(meta,indent=2))
print(json.dumps({'traceBytes':meta['traceBytes'],'extracted':[{k:r[k] for k in ['name','bytes']} for r in manifest]}))

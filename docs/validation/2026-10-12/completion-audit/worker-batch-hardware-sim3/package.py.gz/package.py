import pathlib,json,hashlib,shutil,tarfile,platform,subprocess,os
root=pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-evidence');o=pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-package');o.mkdir(exist_ok=True);r=pathlib.Path('/tmp/tenka-castle-current23-20261012');h=lambda b:hashlib.sha256(b).hexdigest();records=[]
for p in root.iterdir():
 if not p.is_file():continue
 local=p.stat().st_size<10_000_000
 b=p.read_bytes();records.append({'name':p.name,'remotePath':str(p),'bytes':len(b),'sha256':h(b),'included':local,'representation':'exact original bytes; decoded files explicitly named'})
 if local:shutil.copyfile(p,o/p.name)
trace=next((root/'original-test-results').rglob('trace.zip'));records.append({'name':'original-trace.zip','remotePath':str(trace),'bytes':trace.stat().st_size,'sha256':h(trace.read_bytes()),'type':'application/zip','included':False})
ctx=next((root/'original-test-results').rglob('error-context.md'));shutil.copyfile(ctx,o/'error-context.md');shutil.copyfile('/tmp/tenka-worker-batch-hardware-sim3.log',o/'original-terminal.log')
for p in [r/'diagnostics/worker120-hardware.spec.ts',r/'diagnostics/worker120-hardware.config.ts',r/'diagnostics/main-profile-analysis.mjs',r/'playwright.config.ts',r/'e2e/fixtures.ts',r/'e2e/full-snapshot-transport.ts',r/'public/wasm/manifest.json',r/'public/wasm/tenka_engine.wasm',pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-proof.py'),pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-extract.py'),pathlib.Path('/tmp/tenka-worker-batch-hardware-sim3-metadata.py')]:shutil.copyfile(p,o/p.name)
bundles=[]
for p in (r/'dist').rglob('*'):
 if p.is_file() and (p.name.endswith('.js') or p.name.endswith('.js.map')):
  b=p.read_bytes();n=str(p.relative_to(r)).replace('/','__');shutil.copyfile(p,o/n);bundles.append({'sourcePath':str(p),'artifact':n,'bytes':len(b),'sha256':h(b)})
(o/'actual-js-bundle-manifest.json').write_text(json.dumps(bundles,indent=2));(o/'remote-original-manifest.json').write_text(json.dumps(records,indent=2))
env=json.load(open('/tmp/tenka-castle-current23-evidence/environment.json'));env.update({'diagnosticScope':'external one profiled real native game120warm batch','viewport':{'width':1280,'height':720},'seed':1,'warmDays':1,'batchDays':120,'GPUOverrideTrue':True,'environmentFlags':{'VISUAL_GPU':'1','CI':'1','VISUAL_PERF':None},'arguments':['--enable-gpu','--use-angle=vulkan'],'retries':0,'testTimeoutMs':60000,'nodeVersion':subprocess.check_output(['/home/anchi/.nvm/versions/node/v22.23.3/bin/node','--version']).decode().strip()});(o/'environment.json').write_text(json.dumps(env,indent=2))
(o/'gpu-driver-hashes.json').write_bytes(pathlib.Path('/tmp/tenka-castle-current23-evidence/gpu-driver-hashes.json').read_bytes())
print(json.dumps({'packageFiles':len(list(o.iterdir())),'remoteLargeArtifacts':[f for f in records if not f['included']]}))

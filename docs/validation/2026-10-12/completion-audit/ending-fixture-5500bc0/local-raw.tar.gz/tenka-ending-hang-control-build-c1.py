import json
from pathlib import Path

source = Path('/Users/tigercosmos/tenka-fubu/e2e/earned-regional-ending.spec.ts').read_text()
start = source.index('const generatorArgs = [')
end = source.index('\n];', start) + len('\n];')
script = (
    "const { spawn } = require('node:child_process'); "
    "const child = spawn('sleep', ['120'], { stdio: 'ignore' }); "
    "process.stdout.write('HANG_CONTROL_LEADER=' + process.pid + "
    "' DESCENDANT=' + child.pid + '\\n'); "
    "setInterval(() => {}, 1000)"
)
replacement = 'const generatorArgs = ["-e", ' + json.dumps(script) + '];'
assert source.count('const generatorArgs = [') == 1
out = Path('/tmp/tenka-ending-controls-c1/earned-regional-hang-control-c2.spec.ts')
out.write_text(source[:start] + replacement + source[end:])

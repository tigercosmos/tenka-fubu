from pathlib import Path
import tarfile

root = Path('/tmp')
output = Path('/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit/ending-fixture-5500bc0/local-raw.tar.gz')
sources = sorted(
    path for path in root.glob('tenka-ending-*')
    if path.name != 'tenka-ending-initial-1.5.png'
    and path.resolve() != output.resolve()
)
with output.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as archive:
        for path in sources:
            archive.add(path, arcname=path.name)
print(len(sources), output, output.stat().st_size)

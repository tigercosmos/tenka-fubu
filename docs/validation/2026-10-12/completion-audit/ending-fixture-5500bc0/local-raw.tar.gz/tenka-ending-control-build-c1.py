from pathlib import Path

source = Path('/Users/tigercosmos/tenka-fubu/e2e/earned-regional-ending.spec.ts').read_text()
out = Path('/tmp/tenka-ending-controls-c1')
out.mkdir(exist_ok=False)

needle = "resolve('node_modules/vitest/vitest.mjs')"
assert source.count(needle) == 1
failure = source.replace(needle, "resolve('node_modules/vitest/missing-for-negative-control.mjs')")
(out / 'earned-regional-failure-control.spec.ts').write_text(failure)

needle = '  await earnedEnding(page, info, 1.5);'
assert source.count(needle) == 1
restart = source.replace(needle, needle + "\n  throw new Error('intentional worker restart control');")
(out / 'earned-regional-restart-control.spec.ts').write_text(restart)

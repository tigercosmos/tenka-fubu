from pathlib import Path

source = Path('/Users/tigercosmos/tenka-fubu/e2e/earned-regional-ending.spec.ts').read_text()
needle = "  const raw = await readFile(earnedArtifact.path, 'utf8');"
assert source.count(needle) == 1
control = source.replace(
    needle,
    "  await chmod(earnedArtifact.path, 0o644);\n"
    "  await writeFile(earnedArtifact.path, '{}');\n" + needle,
)
out = Path('/tmp/tenka-ending-controls-c1/earned-regional-corruption-control.spec.ts')
out.write_text(control)

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: earned-regional-failure-control.spec.ts >> earned ending at 1280×720 and 1.5 scale keeps its crest and actions reachable
- Location: e2e/earned-regional-failure-control.spec.ts:205:1

# Error details

```
Error: Earned regional route generator exited 1
```

# Test source

```ts
  1   | import { spawn } from 'node:child_process';
  2   | import { createHash } from 'node:crypto';
  3   | import { chmod, mkdir, open, readFile, writeFile } from 'node:fs/promises';
  4   | import { join, resolve } from 'node:path';
  5   | import type { Page, TestInfo } from '@playwright/test';
  6   | import type { SaveFile } from '../src/core/save/serialize';
  7   | import { test, expect } from './fixtures';
  8   | 
  9   | // The three independent browser workflows share one freshly earned save per
  10  | // worker. A failed test starts a new worker, which generates its own save.
  11  | test.describe.configure({ mode: 'default' });
  12  | 
  13  | const generatorSource = resolve('tests/app/earnedRegionalEndingJourney.spec.tsx');
  14  | const generatorArgs = [
  15  |   resolve('node_modules/vitest/missing-for-negative-control.mjs'),
  16  |   'run',
  17  |   '--project',
  18  |   'app',
  19  |   'tests/app/earnedRegionalEndingJourney.spec.tsx',
  20  |   '--minWorkers=1',
  21  |   '--maxWorkers=1',
  22  |   '-t',
  23  |   'loads the earned regional ending into actual App and continues without a phantom day or repeated victory',
  24  | ];
  25  | 
  26  | let earnedArtifact: { path: string; hash: string } | undefined;
  27  | 
  28  | // Playwright requires an object pattern even when this hook needs no fixture.
  29  | // eslint-disable-next-line no-empty-pattern
  30  | test.beforeAll(async ({}, info) => {
  31  |   const directory = join(info.project.outputDir, `earned-regional-worker-${info.workerIndex}`);
  32  |   await mkdir(info.project.outputDir, { recursive: true });
  33  |   await mkdir(directory); // Exclusive: a worker must never consume an earlier artifact.
  34  |   const artifactPath = join(directory, 'earned-regional-ending.tfusave');
  35  |   const generationLog = join(directory, 'earned-regional-route-generation.log');
  36  |   const output = await open(generationLog, 'wx');
  37  |   const startedAt = Date.now();
  38  |   let sourceHash: string;
  39  |   try {
  40  |     sourceHash = createHash('sha256')
  41  |       .update(await readFile(generatorSource))
  42  |       .digest('hex');
  43  |     const child = spawn(process.execPath, generatorArgs, {
  44  |       env: { ...process.env, REGIONAL_EARNED_ENDING_SAVE_PATH: artifactPath },
  45  |       stdio: ['ignore', output.fd, output.fd],
  46  |       detached: process.platform !== 'win32',
  47  |     });
  48  |     let closed = false;
  49  |     const stopChild = (signal: NodeJS.Signals) => {
  50  |       if (closed || child.pid === undefined) return;
  51  |       try {
  52  |         process.kill(process.platform === 'win32' ? child.pid : -child.pid, signal);
  53  |       } catch (error) {
  54  |         if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
  55  |       }
  56  |     };
  57  |     const onWorkerExit = () => stopChild('SIGKILL');
  58  |     process.once('exit', onWorkerExit);
  59  |     // Reap the owned process group at the existing Playwright hook deadline.
  60  |     // Vitest's own 5-second case limit remains unchanged.
  61  |     const remaining = Math.max(0, info.timeout - info.duration);
  62  |     const terminate = setTimeout(() => stopChild('SIGTERM'), Math.max(0, remaining - 1_000));
  63  |     const kill = setTimeout(() => stopChild('SIGKILL'), remaining);
  64  |     try {
  65  |       const exitCode = await new Promise<number>((resolveExit, reject) => {
  66  |         let spawnError: Error | undefined;
  67  |         child.once('error', (error) => {
  68  |           spawnError = error;
  69  |         });
  70  |         child.once('close', (code) => {
  71  |           if (spawnError) reject(spawnError);
  72  |           else resolveExit(code ?? -1);
  73  |         });
  74  |       });
  75  |       closed = true;
> 76  |       if (exitCode !== 0) throw new Error(`Earned regional route generator exited ${exitCode}`);
      |                                 ^ Error: Earned regional route generator exited 1
  77  |     } finally {
  78  |       clearTimeout(terminate);
  79  |       clearTimeout(kill);
  80  |       process.removeListener('exit', onWorkerExit);
  81  |       if (!closed) stopChild('SIGKILL');
  82  |     }
  83  |   } finally {
  84  |     await output.close();
  85  |     await info.attach('earned-regional-route-generation', {
  86  |       path: generationLog,
  87  |       contentType: 'text/plain',
  88  |     });
  89  |   }
  90  |   const raw = await readFile(artifactPath);
  91  |   const save = JSON.parse(raw.toString('utf8')) as SaveFile;
  92  |   assertEarnedSave(save);
  93  |   const hash = createHash('sha256').update(raw).digest('hex');
  94  |   await chmod(artifactPath, 0o444);
  95  |   await writeFile(
  96  |     join(directory, 'provenance.json'),
  97  |     JSON.stringify({
  98  |       workerIndex: info.workerIndex,
  99  |       retry: info.retry,
  100 |       startedAt,
  101 |       durationMs: Date.now() - startedAt,
  102 |       generatorSourceSha256: sourceHash,
  103 |       generatorArgs,
  104 |       saveSha256: hash,
  105 |       saveBytes: raw.byteLength,
  106 |     }),
  107 |     { flag: 'wx' },
  108 |   );
  109 |   earnedArtifact = { path: artifactPath, hash };
  110 | });
  111 | 
  112 | // Envelope and earned-route facts; the native import below also runs the full
  113 | // production save decoder and state validation in each browser context.
  114 | function assertEarnedSave(save: SaveFile) {
  115 |   expect(save.version).toBe(4);
  116 |   expect(Number.isSafeInteger(save.timestamp)).toBe(true);
  117 |   expect(save.meta).toBeTruthy();
  118 |   expect(save.state.meta.scenarioId).toBe('s1560');
  119 |   expect(save.state.time.day).toBe(373);
  120 |   expect(save.state.meta.gameOver).toEqual({ kind: 'victory', endingId: 'unification' });
  121 |   expect(Object.values(save.state.castles)).toHaveLength(9);
  122 |   expect(
  123 |     Object.values(save.state.castles).every((castle) => castle.ownerClanId === 'clan.takeda'),
  124 |   ).toBe(true);
  125 |   expect(save.pendingCommands).toEqual([]);
  126 |   expect(save.state.events.flags['victory.ack.unification']).toBeUndefined();
  127 | }
  128 | 
  129 | async function state(page: Page) {
  130 |   return page.evaluate(() => window.__tenka.debug.getState());
  131 | }
  132 | 
  133 | async function loadSlot(page: Page) {
  134 |   const panel = page.getByTestId('save-load-panel');
  135 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  136 |   await page
  137 |     .getByTestId('save-slot-manual:2')
  138 |     .getByRole('button', { name: '載入', exact: true })
  139 |     .click();
  140 |   await expect(page.getByTestId('screen-ending')).toBeVisible();
  141 | }
  142 | 
  143 | async function earnedEnding(page: Page, info: TestInfo, scale?: number) {
  144 |   if (!earnedArtifact) throw new Error('Earned regional route was not generated by this worker');
  145 |   const raw = await readFile(earnedArtifact.path, 'utf8');
  146 |   if (createHash('sha256').update(raw).digest('hex') !== earnedArtifact.hash)
  147 |     throw new Error('Earned regional route artifact hash changed after generation');
  148 |   const save = JSON.parse(raw) as SaveFile;
  149 |   assertEarnedSave(save);
  150 |   await page.goto('/?debug=1');
  151 |   if (scale !== undefined) {
  152 |     await page.getByTestId('title-settings').click();
  153 |     const settings = page.getByRole('dialog');
  154 |     const slider = settings.getByRole('slider', { name: '介面縮放', exact: true });
  155 |     await slider.press('Home');
  156 |     for (let step = 0; step < Math.round((scale - 0.8) / 0.05); step++)
  157 |       await slider.press('ArrowRight');
  158 |     await expect(slider).toHaveValue(String(scale));
  159 |     await settings.getByRole('button', { name: '返回', exact: true }).click();
  160 |   }
  161 |   await page.getByTestId('title-save-list').click();
  162 |   const panel = page.getByTestId('save-load-panel');
  163 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  164 |   const choosing = page.waitForEvent('filechooser');
  165 |   await panel.getByRole('button', { name: '匯入存檔', exact: true }).click();
  166 |   await (
  167 |     await choosing
  168 |   ).setFiles({
  169 |     name: 'earned-regional-ending.tenkafubu.json',
  170 |     mimeType: 'application/json',
  171 |     buffer: Buffer.from(raw),
  172 |   });
  173 |   await expect(panel.getByRole('heading', { name: '匯入預覽', exact: true })).toBeVisible();
  174 |   await panel.getByRole('combobox').selectOption('manual:2');
  175 |   await panel.getByRole('button', { name: '存入槽位', exact: true }).click();
  176 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: earned-regional-hang-control.spec.ts >> earned ending at 1280×720 and 1.5 scale keeps its crest and actions reachable
- Location: e2e/earned-regional-hang-control.spec.ts:195:1

# Error details

```
Error: Earned regional route generator exited 1
```

# Test source

```ts
  1   | import { spawn } from 'node:child_process';
  2   | import { createHash } from 'node:crypto';
  3   | import { chmod, mkdir, open, readFile, writeFile } from 'node:fs/promises';
  4   | import { join, resolve } from 'node:path';
  5   | import type { Page, TestInfo } from '@playwright/test';
  6   | import type { SaveFile } from '../src/core/save/serialize';
  7   | import { test, expect } from './fixtures';
  8   | 
  9   | // The three independent browser workflows share one freshly earned save per
  10  | // worker. A failed test starts a new worker, which generates its own save.
  11  | test.describe.configure({ mode: 'default' });
  12  | 
  13  | const generatorSource = resolve('tests/app/earnedRegionalEndingJourney.spec.tsx');
  14  | const generatorArgs = ["-e", "const { spawn } = require('node:child_process'); const child = spawn('sleep', ['120'], { stdio: 'ignore' }); process.stdout.write('HANG_CONTROL_LEADER=' + process.pid + ' DESCENDANT=' + child.pid + '\n'); setInterval(() => {}, 1000)"];
  15  | 
  16  | let earnedArtifact: { path: string; hash: string } | undefined;
  17  | 
  18  | // Playwright requires an object pattern even when this hook needs no fixture.
  19  | // eslint-disable-next-line no-empty-pattern
  20  | test.beforeAll(async ({}, info) => {
  21  |   const directory = join(info.project.outputDir, `earned-regional-worker-${info.workerIndex}`);
  22  |   await mkdir(info.project.outputDir, { recursive: true });
  23  |   await mkdir(directory); // Exclusive: a worker must never consume an earlier artifact.
  24  |   const artifactPath = join(directory, 'earned-regional-ending.tfusave');
  25  |   const generationLog = join(directory, 'earned-regional-route-generation.log');
  26  |   const output = await open(generationLog, 'wx');
  27  |   const startedAt = Date.now();
  28  |   let sourceHash: string;
  29  |   try {
  30  |     sourceHash = createHash('sha256')
  31  |       .update(await readFile(generatorSource))
  32  |       .digest('hex');
  33  |     const child = spawn(process.execPath, generatorArgs, {
  34  |       env: { ...process.env, REGIONAL_EARNED_ENDING_SAVE_PATH: artifactPath },
  35  |       stdio: ['ignore', output.fd, output.fd],
  36  |       detached: process.platform !== 'win32',
  37  |     });
  38  |     let closed = false;
  39  |     const stopChild = (signal: NodeJS.Signals) => {
  40  |       if (closed || child.pid === undefined) return;
  41  |       try {
  42  |         process.kill(process.platform === 'win32' ? child.pid : -child.pid, signal);
  43  |       } catch (error) {
  44  |         if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
  45  |       }
  46  |     };
  47  |     const onWorkerExit = () => stopChild('SIGKILL');
  48  |     process.once('exit', onWorkerExit);
  49  |     // Reap the owned process group at the existing Playwright hook deadline.
  50  |     // Vitest's own 5-second case limit remains unchanged.
  51  |     const remaining = Math.max(0, info.timeout - info.duration);
  52  |     const terminate = setTimeout(() => stopChild('SIGTERM'), Math.max(0, remaining - 1_000));
  53  |     const kill = setTimeout(() => stopChild('SIGKILL'), remaining);
  54  |     try {
  55  |       const exitCode = await new Promise<number>((resolveExit, reject) => {
  56  |         let spawnError: Error | undefined;
  57  |         child.once('error', (error) => {
  58  |           spawnError = error;
  59  |         });
  60  |         child.once('close', (code) => {
  61  |           if (spawnError) reject(spawnError);
  62  |           else resolveExit(code ?? -1);
  63  |         });
  64  |       });
  65  |       closed = true;
> 66  |       if (exitCode !== 0) throw new Error(`Earned regional route generator exited ${exitCode}`);
      |                                 ^ Error: Earned regional route generator exited 1
  67  |     } finally {
  68  |       clearTimeout(terminate);
  69  |       clearTimeout(kill);
  70  |       process.removeListener('exit', onWorkerExit);
  71  |       if (!closed) stopChild('SIGKILL');
  72  |     }
  73  |   } finally {
  74  |     await output.close();
  75  |     await info.attach('earned-regional-route-generation', {
  76  |       path: generationLog,
  77  |       contentType: 'text/plain',
  78  |     });
  79  |   }
  80  |   const raw = await readFile(artifactPath);
  81  |   const save = JSON.parse(raw.toString('utf8')) as SaveFile;
  82  |   assertEarnedSave(save);
  83  |   const hash = createHash('sha256').update(raw).digest('hex');
  84  |   await chmod(artifactPath, 0o444);
  85  |   await writeFile(
  86  |     join(directory, 'provenance.json'),
  87  |     JSON.stringify({
  88  |       workerIndex: info.workerIndex,
  89  |       retry: info.retry,
  90  |       startedAt,
  91  |       durationMs: Date.now() - startedAt,
  92  |       generatorSourceSha256: sourceHash,
  93  |       generatorArgs,
  94  |       saveSha256: hash,
  95  |       saveBytes: raw.byteLength,
  96  |     }),
  97  |     { flag: 'wx' },
  98  |   );
  99  |   earnedArtifact = { path: artifactPath, hash };
  100 | });
  101 | 
  102 | // Envelope and earned-route facts; the native import below also runs the full
  103 | // production save decoder and state validation in each browser context.
  104 | function assertEarnedSave(save: SaveFile) {
  105 |   expect(save.version).toBe(4);
  106 |   expect(Number.isSafeInteger(save.timestamp)).toBe(true);
  107 |   expect(save.meta).toBeTruthy();
  108 |   expect(save.state.meta.scenarioId).toBe('s1560');
  109 |   expect(save.state.time.day).toBe(373);
  110 |   expect(save.state.meta.gameOver).toEqual({ kind: 'victory', endingId: 'unification' });
  111 |   expect(Object.values(save.state.castles)).toHaveLength(9);
  112 |   expect(
  113 |     Object.values(save.state.castles).every((castle) => castle.ownerClanId === 'clan.takeda'),
  114 |   ).toBe(true);
  115 |   expect(save.pendingCommands).toEqual([]);
  116 |   expect(save.state.events.flags['victory.ack.unification']).toBeUndefined();
  117 | }
  118 | 
  119 | async function state(page: Page) {
  120 |   return page.evaluate(() => window.__tenka.debug.getState());
  121 | }
  122 | 
  123 | async function loadSlot(page: Page) {
  124 |   const panel = page.getByTestId('save-load-panel');
  125 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  126 |   await page
  127 |     .getByTestId('save-slot-manual:2')
  128 |     .getByRole('button', { name: '載入', exact: true })
  129 |     .click();
  130 |   await expect(page.getByTestId('screen-ending')).toBeVisible();
  131 | }
  132 | 
  133 | async function earnedEnding(page: Page, info: TestInfo, scale?: number) {
  134 |   if (!earnedArtifact) throw new Error('Earned regional route was not generated by this worker');
  135 |   const raw = await readFile(earnedArtifact.path, 'utf8');
  136 |   if (createHash('sha256').update(raw).digest('hex') !== earnedArtifact.hash)
  137 |     throw new Error('Earned regional route artifact hash changed after generation');
  138 |   const save = JSON.parse(raw) as SaveFile;
  139 |   assertEarnedSave(save);
  140 |   await page.goto('/?debug=1');
  141 |   if (scale !== undefined) {
  142 |     await page.getByTestId('title-settings').click();
  143 |     const settings = page.getByRole('dialog');
  144 |     const slider = settings.getByRole('slider', { name: '介面縮放', exact: true });
  145 |     await slider.press('Home');
  146 |     for (let step = 0; step < Math.round((scale - 0.8) / 0.05); step++)
  147 |       await slider.press('ArrowRight');
  148 |     await expect(slider).toHaveValue(String(scale));
  149 |     await settings.getByRole('button', { name: '返回', exact: true }).click();
  150 |   }
  151 |   await page.getByTestId('title-save-list').click();
  152 |   const panel = page.getByTestId('save-load-panel');
  153 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  154 |   const choosing = page.waitForEvent('filechooser');
  155 |   await panel.getByRole('button', { name: '匯入存檔', exact: true }).click();
  156 |   await (
  157 |     await choosing
  158 |   ).setFiles({
  159 |     name: 'earned-regional-ending.tenkafubu.json',
  160 |     mimeType: 'application/json',
  161 |     buffer: Buffer.from(raw),
  162 |   });
  163 |   await expect(panel.getByRole('heading', { name: '匯入預覽', exact: true })).toBeVisible();
  164 |   await panel.getByRole('combobox').selectOption('manual:2');
  165 |   await panel.getByRole('button', { name: '存入槽位', exact: true }).click();
  166 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
```
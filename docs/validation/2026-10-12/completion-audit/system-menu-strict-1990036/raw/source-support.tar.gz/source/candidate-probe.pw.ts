import { test, expect } from '@playwright/test';
import { waitForMapReady } from '../../e2e/map-ready';

test('synthetic visual fixture gear retains its owned system menu', async ({ page }, info) => {
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/?debug=visual-map');
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  await waitForMapReady(page);
  const target = await page.evaluate(async () => {
    await window.__tenka.debug.waitSimulationIdle();
    await window.__tenka.debug.waitMapIdle();
    const path = '/src/ui/map/debugMapBridge.ts';
    const bridge = (await import(/* @vite-ignore */ path)) as {
      getDebugMapRenderer(): {
        getPublishedViewSnapshot(): { districts?: Array<{ id: string; ikkiActive?: boolean }> };
        updateView(view: unknown): void;
        focusNode(id: string): void;
      } | null;
    };
    const renderer = bridge.getDebugMapRenderer();
    if (!renderer) throw new Error('Map renderer absent');
    const view = renderer.getPublishedViewSnapshot();
    const district = view.districts?.find((entry) => !entry.ikkiActive);
    if (!district) throw new Error('No inactive district');
    renderer.updateView({
      ...view,
      districts: view.districts!.map((entry) => ({
        ...entry,
        ikkiActive: entry.id === district.id,
      })),
    });
    renderer.focusNode(district.id);
    await window.__tenka.debug.waitMapIdle();
    return district.id;
  });
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  const coreBefore = JSON.stringify(await page.evaluate(() => window.__tenka.debug.getState()));
  const commandsBefore = JSON.stringify(
    await page.evaluate(() => window.__tenka.debug.exportCommandLog()),
  );

  await page.evaluate(async () => {
    const uiPath = '/src/ui/hooks/uiStore.ts';
    const appPath = '/src/app/store.ts';
    const { uiStore } = (await import(/* @vite-ignore */ uiPath)) as {
      uiStore: {
        getState(): {
          modal: { id: string } | null;
          modalQueue: Array<{ id: string }>;
          selection: { kind: string; id: string } | null;
        };
        subscribe(callback: () => void): () => void;
      };
    };
    const { store } = (await import(/* @vite-ignore */ appPath)) as {
      store: {
        getState(): { game: object | null; session: { screen: string }; tickSeq: number };
        subscribe(callback: () => void): () => void;
      };
    };
    const gameIdentity = store.getState().game;
    const records: Array<Record<string, unknown>> = [];
    const snap = (cause: string) => {
      if (records.length >= 160) return;
      const ui = uiStore.getState();
      const app = store.getState();
      records.push({
        at: performance.now(),
        cause,
        modal: ui.modal?.id ?? null,
        queue: ui.modalQueue.map((item) => item.id),
        selection: ui.selection,
        screen: app.session.screen,
        sameGameIdentity: app.game === gameIdentity,
        tickSeq: app.tickSeq,
        dialogs: Array.from(document.querySelectorAll('[role="dialog"]')).map((item) =>
          item.getAttribute('aria-label'),
        ),
      });
    };
    const event = (input: Event) => {
      const target = input.target;
      if (!(target instanceof Element)) return;
      const gear = target.closest('button[aria-label="系統選單"]');
      if (gear) snap(`${input.type}:${input.eventPhase}`);
    };
    for (const name of ['pointerdown', 'pointerup', 'click'])
      document.addEventListener(name, event, true);
    const stopUi = uiStore.subscribe(() => snap('ui-store'));
    const stopApp = store.subscribe(() => snap('app-store'));
    let dialogCount = document.querySelectorAll('[role="dialog"]').length;
    const observer = new MutationObserver(() => {
      const next = document.querySelectorAll('[role="dialog"]').length;
      if (next !== dialogCount) {
        dialogCount = next;
        snap('dialog-dom');
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    snap('before-click');
    const global = window as typeof window & { __systemMenuOwnerProbe?: () => typeof records };
    global.__systemMenuOwnerProbe = () => {
      observer.disconnect();
      stopUi();
      stopApp();
      for (const name of ['pointerdown', 'pointerup', 'click'])
        document.removeEventListener(name, event, true);
      snap('after-click');
      return records;
    };
  });

  await page.getByRole('button', { name: '系統選單', exact: true }).click();
  const menu = page.getByRole('dialog', { name: '系統選單', exact: true });
  let visible = true;
  try {
    await expect(menu).toBeVisible({ timeout: 5_000 });
  } catch {
    visible = false;
  }
  const records = await page.evaluate(() => {
    const global = window as typeof window & { __systemMenuOwnerProbe?: () => unknown };
    if (!global.__systemMenuOwnerProbe) throw new Error('Owner probe absent');
    return global.__systemMenuOwnerProbe();
  });
  expect(visible).toBe(true);
  await page.getByRole('button', { name: '設定', exact: true }).click();
  const settings = page.getByRole('dialog', { name: '設定', exact: true });
  await expect(settings).toBeVisible();
  const effects = settings.getByRole('switch', { name: '地圖特效', exact: true });
  await expect(effects).toBeChecked();
  await effects.uncheck();
  await expect(effects).not.toBeChecked();
  const effectsOffSamples: Array<{
    active: boolean;
    visible: boolean;
    separated: boolean;
    renderer: string | null;
  }> = [];
  for (let i = 0; i < 6; i++) {
    await page.waitForTimeout(250);
    effectsOffSamples.push(await page.evaluate(async (targetId) => {
      const path = '/src/ui/map/debugMapBridge.ts';
      const bridge = (await import(/* @vite-ignore */ path)) as {
        getDebugMapRenderer(): {
          getApp(): { canvas: HTMLCanvasElement } | null;
          getPublishedViewSnapshot(): { districts?: Array<{ id: string; ikkiActive?: boolean }> };
          nodeParts: Map<string, { part: { container: {
            label: string; visible: boolean; children: Array<{ visible: boolean }>;
          } } }>;
        } | null;
      };
      const renderer = bridge.getDebugMapRenderer();
      if (!renderer) throw new Error('Map renderer absent');
      const active = renderer.getPublishedViewSnapshot().districts?.find((entry) => entry.id === targetId);
      const district = renderer.nodeParts.get(targetId)?.part.container;
      if (!active || !district || district.label !== 'districtNode')
        throw new Error('Synthetic uprising target absent');
      const canvas = renderer.getApp()?.canvas;
      const gl = canvas?.getContext('webgl2');
      const ext = gl?.getExtension('WEBGL_debug_renderer_info');
      return {
        active: active.ikkiActive === true,
        visible: district.children[1]?.visible === true,
        separated: district.children.length === 2,
        renderer: gl && ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : null,
      };
    }, target));
  }
  expect(effectsOffSamples.every((sample) => sample.active && sample.visible && sample.separated)).toBe(true);
  const coreAfter = JSON.stringify(await page.evaluate(() => window.__tenka.debug.getState()));
  const commandsAfter = JSON.stringify(
    await page.evaluate(() => window.__tenka.debug.exportCommandLog()),
  );
  await info.attach('owner-transitions', {
    body: JSON.stringify({ visible, records, target, effectsOffSamples, coreUnchanged: coreAfter === coreBefore,
      commandsUnchanged: commandsAfter === commandsBefore }, null, 2),
    contentType: 'application/json',
  });
  expect(coreAfter).toBe(coreBefore);
  expect(commandsAfter).toBe(commandsBefore);
  expect(visible).toBe(true);
});

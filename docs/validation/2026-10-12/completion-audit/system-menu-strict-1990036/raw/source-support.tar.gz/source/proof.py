#!/usr/bin/env python3
import argparse
import gzip
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--manifest', required=True)
p.add_argument('--dependency-baseline', required=True)
p.add_argument('--overlay', action='append', default=[])
a = p.parse_args()
root = Path(a.root)
manifest = json.loads(Path(a.manifest).read_text())
with gzip.open(a.dependency_baseline, 'rt') as f:
    baseline = json.load(f)
expected = manifest['entries']
overlays = dict(item.split('=', 1) for item in a.overlay)
bad = []
for rel, entry in expected.items():
    file = root / rel
    if not file.is_file():
        bad.append([rel, 'missing'])
        continue
    data = file.read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if actual != entry['gitBlob'] and rel not in overlays:
        bad.append([rel, actual, entry['gitBlob']])
for rel, sha in overlays.items():
    file = root / rel
    if not file.is_file():
        bad.append([rel, 'missing overlay'])
    elif hashlib.sha256(file.read_bytes()).hexdigest() != sha:
        bad.append([rel, 'overlay SHA mismatch'])
allowed = set(expected) | set(overlays)
for first in ('src', 'e2e', 'tests', 'tools', 'public', 'assets', 'rust', 'plan', '.github'):
    directory = root / first
    if directory.exists():
        for file in directory.rglob('*'):
            if file.is_file() and str(file.relative_to(root)) not in allowed:
                bad.append([str(file.relative_to(root)), 'extra file'])
deps = []
for row in baseline['dependencies']:
    file = root / 'node_modules' / 'pixi.js' / row['path']
    actual = hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
    deps.append({'path': row['path'], 'actual': actual, 'expected': row['expected']})
    if actual != row['expected']:
        bad.append([row['path'], 'dependency mismatch'])
result = {
    'revision': manifest['revision'],
    'sourceCount': len(expected),
    'overlay': overlays,
    'dependencyCount': len(deps),
    'nodeModulesTarget': str((root / 'node_modules').resolve()),
    'bad': bad,
}
print(json.dumps(result, indent=2))
raise SystemExit(bool(bad))

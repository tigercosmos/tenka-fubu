#!/usr/bin/env bash
set -euo pipefail
MODE=$1
RUN_DIR=$2
RUNTIME=/tmp/tenka-system-menu-5feb-v1
NODE_BIN=/home/anchi/.nvm/versions/node/v25.9.0/bin
BROWSERS=/tmp/tenka-20261012-sim2-browser/runtime/browsers
[[ -x "$NODE_BIN/node" && -x "$BROWSERS/chromium-1228/chrome-linux64/chrome" && -x "$RUNTIME/node_modules/.bin/playwright" ]]
export PATH="$NODE_BIN:/usr/local/bin:/usr/bin:/bin"
export PLAYWRIGHT_BROWSERS_PATH="$BROWSERS"
export VISUAL_GPU=1
export CI=1
if [[ "$MODE" == list ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- "$RUNTIME/node_modules/.bin/playwright" test e2e/settings.spec.ts --config playwright.config.ts --project=chromium --grep 'system settings retain their owned pause, preserve the map viewport and confirm leaving' --list
fi
if [[ "$MODE" == native ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" --browser -- "$RUNTIME/node_modules/.bin/playwright" test e2e/settings.spec.ts --config playwright.config.ts --project=chromium --grep 'system settings retain their owned pause, preserve the map viewport and confirm leaving'
fi
exit 2

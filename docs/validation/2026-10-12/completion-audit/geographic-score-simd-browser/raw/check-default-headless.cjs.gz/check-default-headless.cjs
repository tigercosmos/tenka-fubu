const { chromium, firefox, webkit } = require('/Users/tigercosmos/tenka-fubu/node_modules/playwright');
const fs = require('node:fs');
const crypto = require('node:crypto');
const os = require('node:os');
const path = require('node:path');
(async () => {
  const base = __dirname;
  const bytes = fs.readFileSync('/tmp/tenka-simd-overlap-probe/probe.wasm');
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage();
    const cdp = await page.context().newCDPSession(page);
    const browserVersion = await cdp.send('Browser.getVersion');
    const result = await page.evaluate(async (input) => {
      const bytes = Uint8Array.from(input);
      const validate = WebAssembly.validate(bytes);
      if (!validate) throw new Error('Standalone strict SIMD probe failed capability validation');
      const {instance} = await WebAssembly.instantiate(bytes);
      const {scalar, lanes} = instance.exports;
      const view = new DataView(new ArrayBuffer(8));
      const bits = value => { view.setFloat64(0,value,false);return view.getBigUint64(0,false).toString(16).padStart(16,'0'); };
      const same = (a,b) => Number.isNaN(a)&&Number.isNaN(b)||bits(a)===bits(b);
      const original = (ax,ay,aw,ah,bx,by,bw,bh,p) => Math.max(0,Math.min(ax+aw+p,bx+bw+p)-Math.max(ax-p,bx-p))*Math.max(0,Math.min(ay+ah+p,by+bh+p)-Math.max(ay-p,by-p));
      const coordinates = [-0,0,Number.MIN_VALUE,-Number.MIN_VALUE,Number.EPSILON,1,-1,1e308,-1e308,Number.MAX_VALUE,-Number.MAX_VALUE,Infinity,-Infinity,NaN];
      const sizes = [-0,0,Number.MIN_VALUE,1,1e308,Number.MAX_VALUE,Infinity,NaN];
      const rows = [];
      for (const x of coordinates) for (const width of sizes) { rows.push([x,-x,width,width]);rows.push([x,x,width,0]); }
      let cases=0,nans=0,zeros=0,negativeZeros=0,finite=0,infinite=0;
      const controls=[];
      for(const a of rows)for(const b of rows)for(const padding of [0,2]) {
        const args=[...a,...b,padding];const expected=original(...args),s=scalar(...args),v=lanes(...args);
        if(!same(expected,s)||!same(expected,v))throw new Error(JSON.stringify({args:args.map(bits),expected:bits(expected),scalar:bits(s),simd:bits(v)}));
        cases++;if(Number.isNaN(expected))nans++;else if(Number.isFinite(expected))finite++;else infinite++;
        if(expected===0){zeros++;if(Object.is(expected,-0))negativeZeros++;}
        if(cases===1||cases===2||cases===30000||cases===100000)controls.push({case:cases,args:args.map(bits),expected:bits(expected),scalar:bits(s),simd:bits(v),nan:Number.isNaN(expected)});
      }
      const explicit = [
        [-0,-0,-0,-0,0,0,0,0,0],
        [0,0,8,8,4,4,8,8,0],
        [NaN,0,1,1,0,0,1,1,0],
        [0,0,0,Infinity,0,0,0,Infinity,0],
        [0,0,1e200,1e200,0,0,1e200,1e200,0]
      ].map(args=>{const e=original(...args),s=scalar(...args),v=lanes(...args);if(!same(e,s)||!same(e,v))throw new Error('Explicit parity failed');return{args:args.map(bits),expected:bits(e),scalar:bits(s),simd:bits(v),nan:Number.isNaN(e)};});
      return {userAgent:navigator.userAgent,platform:navigator.platform,validate,rows:rows.length,cases,nans,finite,infinite,zeros,negativeZeros,controls,explicit,allEqual:true,classification:'NaN class; every other f64 exact bits'};
    }, [...bytes]);
    const output={scope:'Headless installed Chromium standalone overlap probe only. No game integration, Safari/Firefox, GPU or performance claim.',host:{platform:process.platform,arch:process.arch,node:process.version,hostname:os.hostname()},playwright:require('/Users/tigercosmos/tenka-fubu/node_modules/playwright/package.json').version,browserVersion,probe:{path:'/tmp/tenka-simd-overlap-probe/probe.wasm',bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex')},installed:[chromium,firefox,webkit].map(type=>({name:type.name(),executable:type.executablePath(),exists:fs.existsSync(type.executablePath())})),result};
    fs.writeFileSync(path.join(base,'result.json'),JSON.stringify(output,null,2)+'\n');
    console.log(JSON.stringify(output,null,2));
  } finally { await browser.close(); }
})().catch(error=>{console.error(error);process.exitCode=1;});

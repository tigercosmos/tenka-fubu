import{readFileSync,writeFileSync,existsSync}from'node:fs';
import{TraceMap,originalPositionFor}from'@jridgewell/trace-mapping';
const profile=JSON.parse(readFileSync('/tmp/tenka-signal-candidate-profile-955-c1/close.cpuprofile','utf8'));
// Decode the actual export section to relate V8 wasm-function[index] frames to exports.
const wasmBytes=readFileSync('public/wasm/tenka_engine.wasm');
let cursor=8;const readU32=()=>{let value=0,shift=0;for(;;){const byte=wasmBytes[cursor++];value+=(byte&127)*2**shift;if(!(byte&128))return value;shift+=7;if(shift>35)throw Error('Invalid wasm u32');}};
const wasmExportMap=[];
while(cursor<wasmBytes.length){const section=wasmBytes[cursor++],size=readU32(),end=cursor+size;if(section===7){const count=readU32();for(let i=0;i<count;i++){const length=readU32(),name=wasmBytes.subarray(cursor,cursor+length).toString('utf8');cursor+=length;const kind=wasmBytes[cursor++],index=readU32();wasmExportMap.push({name,kind,index});}}cursor=end;}

const nodes=new Map(profile.nodes.map(n=>[n.id,n]));const parents=new Map();for(const n of nodes.values())for(const child of n.children??[])parents.set(child,n.id);
const maps=new Map();function label(n){const f=n.callFrame;let source=f.url,line=f.lineNumber+1,column=f.columnNumber,name=f.functionName;try{const u=new URL(source);const path='dist'+u.pathname+'.map';if(existsSync(path)){if(!maps.has(path))maps.set(path,new TraceMap(readFileSync(path,'utf8')));const o=originalPositionFor(maps.get(path),{line,column});if(o.source){source=o.source;line=o.line;column=o.column;name=o.name??name;}}}catch{}return{function:name,source,line,column};}
const sums=new Map();for(let i=0;i<profile.samples.length;i++){let id=profile.samples[i];const delta=profile.timeDeltas[i]??0;let self=true;const visited=new Set();while(id!==undefined){const n=nodes.get(id);if(!n)break;const l=label(n),key=JSON.stringify(l);let row=sums.get(key);if(!row){row={...l,selfUs:0,inclusiveUs:0,selfSamples:0};sums.set(key,row);}if(self){row.selfUs+=delta;row.selfSamples++;}if(!visited.has(key)){row.inclusiveUs+=delta;visited.add(key);}self=false;id=parents.get(id);}}
const rows=[...sums.values()];const result={scope:'separate10secondcloseProfile/notAcceptanceFPS',totalUs:profile.timeDeltas.reduce((a,b)=>a+b,0),samples:profile.samples.length,topSelf:rows.toSorted((a,b)=>b.selfUs-a.selfUs).slice(0,35),topInclusive:rows.toSorted((a,b)=>b.inclusiveUs-a.inclusiveUs).slice(0,35),mappedSourceRows:rows.filter(r=>r.source.includes('src/')).toSorted((a,b)=>b.selfUs-a.selfUs)};
result.allRows=rows.toSorted((a,b)=>b.selfUs-a.selfUs);
result.originalCallFrames=profile.nodes.map(n=>({id:n.id,callFrame:n.callFrame}));
result.wasmExportMap=wasmExportMap;
result.wasmRows=rows.filter(r=>r.source.startsWith('wasm:')).map(r=>{const match=r.function.match(/wasm-function\[(\d+)\]/);const index=match?Number(match[1]):wasmExportMap.find(e=>e.kind===0&&e.name===r.function)?.index;return{...r,wasmFunctionIndex:index,exports:wasmExportMap.filter(e=>e.kind===0&&e.index===index).map(e=>e.name)};}).toSorted((a,b)=>b.selfUs-a.selfUs);
result.jsPackingRows=result.mappedSourceRows.filter(r=>r.source.includes('wasmGeographicScorer.ts')||r.source.includes('wasmCastleRibbonPlanner.ts')||r.source.includes('wasmGeographicPreparation.ts'));
result.jsPackingSelfUs=result.jsPackingRows.reduce((sum,r)=>sum+r.selfUs,0);
result.wasmTotalSelfUs=result.wasmRows.reduce((sum,r)=>sum+r.selfUs,0);
const targetNames=new Set(['flushScreenLayouts','placeGeographicLabels','placeCastleRibbons','placeArmySignals','placeArmyPlates','layoutGeographicLabels','scorePrepared','layoutArmySignals']);
const parentChildren=new Map();
for(let i=0;i<profile.samples.length;i++){
  const delta=profile.timeDeltas[i]??0; const chain=[]; let id=profile.samples[i];
  while(id!==undefined){const node=nodes.get(id);if(!node)break;chain.push(node);id=parents.get(id)}
  chain.reverse();
  for(let j=0;j<chain.length;j++){
    const owner=label(chain[j]); if(!targetNames.has(owner.function)) continue;
    const ownerKey=`${owner.function} @ ${owner.source}:${owner.line}`;
    const child=j+1<chain.length?label(chain[j+1]):{function:'<self>',source:'',line:0};
    const childKey=`${child.function} @ ${child.source}:${child.line}`;
    let table=parentChildren.get(ownerKey);if(!table){table=new Map();parentChildren.set(ownerKey,table)}
    table.set(childKey,(table.get(childKey)??0)+delta);
  }
}
result.parentChildren=Object.fromEntries([...parentChildren].map(([owner,children])=>[owner,[...children].map(([child,us])=>({child,us})).sort((a,b)=>b.us-a.us)]));
writeFileSync('/tmp/tenka-signal-candidate-profile-955-c1/source-parent-attribution.json',JSON.stringify(result,null,2));console.log(JSON.stringify({totalUs:result.totalUs,topSelf:result.topSelf.slice(0,18)},null,2));

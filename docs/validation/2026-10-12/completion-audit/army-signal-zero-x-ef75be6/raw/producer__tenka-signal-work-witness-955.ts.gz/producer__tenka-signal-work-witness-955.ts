import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import ts from '/Users/tigercosmos/tenka-fubu/node_modules/typescript/lib/typescript.js';
const root='/Users/tigercosmos/tenka-fubu';
const pathOld=`${root}/tests/ui/fixtures/armySignalLayoutOriginal.ts`;
const pathNew=`${root}/src/ui/map/armySignalLayout.ts`;
const needle='if (++work > ARMY_SIGNAL_LAYOUT.overlapWork) throw EXHAUSTED;';
const dense=Array.from({length:256},(_,i)=>({id:`army.${i}`,priority:2,rect:{x:0,y:0,width:12,height:24}}));
const fixed=Array.from({length:1024},()=>({x:-100,y:-100,width:200,height:200}));
function run(path:string){
  const source=readFileSync(path,'utf8');
  if(source.split(needle).length!==2)throw Error('Expected unique untouched work guard');
  let observed=0;
  const instrumented=source.replace(needle,'if (++work > ARMY_SIGNAL_LAYOUT.overlapWork) { observe(work); throw EXHAUSTED; }');
  const js=ts.transpileModule(instrumented,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const exports:any={};new Function('exports','observe',js)(exports,(value:number)=>{observed=value});
  const offsets=exports.layoutArmySignals(dense,fixed);
  return {sha256:createHash('sha256').update(source).digest('hex'),witness:observed,size:offsets.size,outputSha256:createHash('sha256').update(JSON.stringify([...offsets])).digest('hex')};
}
const old=run(pathOld),candidate=run(pathNew);
if(old.witness!==1000001||candidate.witness!==1000001||old.outputSha256!==candidate.outputSha256)throw Error('Exhaustion/work/output mismatch');
console.log(JSON.stringify({old,candidate},null,2));

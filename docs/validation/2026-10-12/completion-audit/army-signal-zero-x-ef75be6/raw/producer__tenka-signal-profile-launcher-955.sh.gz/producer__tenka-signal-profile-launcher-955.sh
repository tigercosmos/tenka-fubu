#!/usr/bin/env bash
set -euo pipefail
RUNTIME=$1
RUN_DIR=$2
NODE_BIN=/home/anchi/.nvm/versions/node/v25.9.0/bin
BROWSERS=/tmp/tenka-20261012-sim2-browser/runtime/browsers
[[ -x "$NODE_BIN/node" && -x "$BROWSERS/chromium-1228/chrome-linux64/chrome" && -f "$RUNTIME/tenka-castle-clean-profile-955.mjs" ]]
export PATH="$NODE_BIN:/usr/local/bin:/usr/bin:/bin"
export PLAYWRIGHT_BROWSERS_PATH="$BROWSERS"
export VISUAL_GPU=1
export VISUAL_PERF=1
export CI=1
exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- \
  "$NODE_BIN/node" "$RUNTIME/tenka-castle-clean-profile-955.mjs" "$RUN_DIR"

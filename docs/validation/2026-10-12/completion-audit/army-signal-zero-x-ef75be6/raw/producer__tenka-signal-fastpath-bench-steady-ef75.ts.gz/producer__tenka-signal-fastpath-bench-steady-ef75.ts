import { layoutArmySignals as current } from '/Users/tigercosmos/tenka-fubu/src/ui/map/armySignalLayout.ts';
import { layoutArmySignals as original } from '/Users/tigercosmos/tenka-fubu/tests/ui/fixtures/armySignalLayoutOriginal.ts';
import type { ArmySignalCandidate, SignalRect } from '/Users/tigercosmos/tenka-fubu/src/ui/map/armySignalLayout.ts';
const median=(v:number[])=>{const s=[...v].sort((a,b)=>a-b);return s[Math.floor(s.length/2)]};
const scenes:[string,ArmySignalCandidate[],SignalRect[]][]=[
 ['sparse-120x300',Array.from({length:120},(_,i)=>({id:`army.${i}`,priority:i%3,rect:{x:(i%20)*72,y:Math.floor(i/20)*52,width:29,height:35}})),Array.from({length:300},(_,i)=>({x:(i%30)*51,y:Math.floor(i/30)*45,width:33,height:36}))],
 ['crowded-36x70',Array.from({length:36},(_,i)=>({id:`army.${i}`,priority:i%3,rect:{x:(i%6)*11,y:Math.floor(i/6)*9,width:28,height:34}})),Array.from({length:70},(_,i)=>({x:(i%10)*13,y:Math.floor(i/10)*12,width:32,height:36}))],
 ['dense-exhaustion-256x1024',Array.from({length:256},(_,i)=>({id:`army.${i}`,priority:2,rect:{x:0,y:0,width:12,height:24}})),Array.from({length:1024},()=>({x:-100,y:-100,width:200,height:200}))],
];
for(const [name,candidates,obstacles] of scenes){
 const a=original(candidates,obstacles),b=current(candidates,obstacles);
 if(JSON.stringify([...a])!==JSON.stringify([...b])) throw Error(`Output mismatch ${name}`);
 const oldTimes:number[]=[],newTimes:number[]=[];
 for(let i=0;i<100;i++){
   const order=i%2?[current,original]:[original,current];
   for(const fn of order){const t0=process.hrtime.bigint();fn(candidates,obstacles);const ms=Number(process.hrtime.bigint()-t0)/1e6;if(i>=60)(fn===original?oldTimes:newTimes).push(ms)}
 }
 console.log(JSON.stringify({name,candidates:candidates.length,obstacles:obstacles.length,rounds:oldTimes.length,originalMedianMs:median(oldTimes),currentMedianMs:median(newTimes),ratio:median(newTimes)/median(oldTimes),originalTimesMs:oldTimes,currentTimesMs:newTimes}));
}

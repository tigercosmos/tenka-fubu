import { chromium } from '@playwright/test';
import { createHash } from 'node:crypto';
import { closeSync, openSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';

const runDir = process.argv[2];
if (!runDir) throw new Error('Exclusive run directory required');
const sha = (value) => createHash('sha256').update(value).digest('hex');
const fd = openSync(`${runDir}/preview.stdout-stderr.log`, 'wx');
const preview = spawn(process.execPath,
  ['node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', '4173'],
  { stdio: ['ignore', fd, fd] });
closeSync(fd);
let browser;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) {
    try { ready = (await fetch('http://127.0.0.1:4173')).ok; if (ready) break; }
    catch { /* starting */ }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!ready) throw new Error('Preview did not start');
  browser = await chromium.launch({ channel: 'chromium', headless: true,
    args: ['--enable-gpu', '--use-angle=vulkan'] });
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 },
    reducedMotion: 'no-preference' });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4173/?debug=1&seed=15600519');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('screen-daimyo-select').waitFor();
  await page.getByTestId('daimyo-next').click();
  await page.getByTestId('screen-difficulty-select').waitFor();
  await page.getByRole('radio', { name: '中級', exact: true }).isChecked().then((checked) => {
    if (!checked) throw new Error('Default difficulty changed');
  });
  await page.getByTestId('difficulty-next').click();
  await page.getByTestId('screen-seed-select').waitFor();
  if ((await page.getByTestId('newgame-seed').getAttribute('aria-invalid')) !== 'false')
    throw new Error('Default seed invalid');
  await page.getByTestId('newgame-start').click();
  await page.getByTestId('screen-strategy').waitFor();
  await page.getByTestId('speed-pause').click();
  const preparation = await page.evaluate(() => window.__tenka.debug.prepareLiveNationalMapWorkload(120));
  if (preparation.count !== 120 || preparation.commands !== 120)
    throw new Error('Canonical workload changed');
  const gpu = async () => page.evaluate(() => {
    const gl = document.querySelector('canvas')?.getContext('webgl2') ??
      document.querySelector('canvas')?.getContext('webgl');
    if (!(gl instanceof WebGLRenderingContext || gl instanceof WebGL2RenderingContext))
      throw new Error('Actual WebGL required');
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    return { lost: gl.isContextLost(),
      renderer: String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER)) };
  });
  const gpuBefore = await gpu();
  if (gpuBefore.lost || !gpuBefore.renderer.includes('RTX 5070 Ti') ||
      !gpuBefore.renderer.includes('Vulkan')) throw new Error('GPU guard failed');
  const snapshots = [];
  for (let day = 0; day < 3; day++) {
    if (day) await page.evaluate(async () => {
      window.__tenka.debug.stepDays(1);
      await window.__tenka.debug.waitSimulationIdle();
    });
    for (const camera of ['overview', 'operational', 'close']) {
      await page.evaluate(async (preset) => {
        await document.fonts.ready;
        await window.__tenka.debug.setMapCameraPreset(preset);
        await window.__tenka.debug.waitMapIdle(3);
      }, camera);
      const snapshot = await page.evaluate(() => {
        const d = window.__tenka.debug.getMapDiagnostics();
        const { runs: armyRuns, ...plates } = d.armyPlateLayout;
        const { runs: labelRuns, placementCache, ...geographic } = d.geographicLabelLayout;
        const { runs: ribbonRuns, ...ribbons } = d.castleRibbonLayout;
        return {
          day: window.__tenka.debug.getState().time.day,
          canonicalJSON: JSON.stringify(window.__tenka.debug.getState()),
          commandsJSON: JSON.stringify(window.__tenka.debug.exportCommandLog()),
          resources: d.resources,
          published: window.__tenka.debug.getMapPublishedViewSnapshot(),
          plates, geographic, ribbons,
          castleRendering: d.castleRendering,
          elevation: d.elevationRendering,
          settlements: d.settlementRendering,
          signals: d.armyRendering.signals,
          excludedCounters: { armyRuns, labelRuns, placementCache, ribbonRuns },
        };
      });
      if (snapshot.day !== day || snapshot.published.day !== day)
        throw new Error(`Unsettled canonical/publication day ${day}/${camera}`);
      const canonicalSha256 = sha(snapshot.canonicalJSON);
      const commandsSha256 = sha(snapshot.commandsJSON);
      delete snapshot.canonicalJSON;
      delete snapshot.commandsJSON;
      delete snapshot.excludedCounters;
      snapshots.push({ camera, ...snapshot, canonicalSha256, commandsSha256 });
    }
  }
  const gpuAfter = await gpu();
  const driver = await page.evaluate(() => window.__tenka.debug.getLiveNationalMapWorkload());
  if (gpuAfter.lost || gpuAfter.renderer !== gpuBefore.renderer || driver.ticks !== 2)
    throw new Error(`GPU/driver control failed: ${JSON.stringify({ gpuBefore, gpuAfter, ticks: driver.ticks })}`);
  writeFileSync(`${runDir}/published.json`, JSON.stringify({
    scope: 'current955NinePublishedViewsPlusSignals/notFPS',
    preparation, driver, gpuBefore, gpuAfter,
    excludedNonvisualCounters: ['armyPlateLayout.runs', 'geographicLabelLayout.runs',
      'geographicLabelLayout.placementCache', 'castleRibbonLayout.runs'], snapshots,
  }), { flag: 'wx' });
  console.log(JSON.stringify({ snapshots: snapshots.length, days: snapshots.map((s) => s.day),
    renderer: gpuBefore.renderer, driverTicks: driver.ticks }));
} finally {
  await browser?.close();
  preview.kill('SIGTERM');
}

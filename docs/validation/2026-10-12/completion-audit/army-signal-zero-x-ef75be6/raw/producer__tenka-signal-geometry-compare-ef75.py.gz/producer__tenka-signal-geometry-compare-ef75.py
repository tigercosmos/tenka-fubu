#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
base=Path('/tmp/tenka-signal-evidence-download-ef75')
a=(base/'geometry-original/published.json').read_bytes()
b=(base/'geometry-candidate/published.json').read_bytes()
assert a==b, 'Full 9-view published payload changed'
d=json.loads(a)
assert d['excludedNonvisualCounters']==['armyPlateLayout.runs','geographicLabelLayout.runs','geographicLabelLayout.placementCache','castleRibbonLayout.runs']
assert len(d['snapshots'])==9
assert [x['day'] for x in d['snapshots']]==[0,0,0,1,1,1,2,2,2]
assert [x['camera'] for x in d['snapshots']]==['overview','operational','close']*3
assert d['driver']['ticks']==2
assert d['gpuBefore']==d['gpuAfter']
assert 'RTX 5070 Ti' in d['gpuBefore']['renderer'] and 'Vulkan' in d['gpuBefore']['renderer']
rows=[]
for s in d['snapshots']:
    serial=json.dumps(s,separators=(',',':')).encode()
    rows.append({'day':s['day'],'camera':s['camera'],'sha256':hashlib.sha256(serial).hexdigest(),'signals':len(s['signals']),'visibleSignals':sum(bool(x['visible']) for x in s['signals']),'canonicalSha256':s['canonicalSha256'],'commandsSha256':s['commandsSha256']})
out={'baselineBytes':len(a),'candidateBytes':len(b),'sha256':hashlib.sha256(a).hexdigest(),'exactBytesEqual':True,'views':rows,'gpu':d['gpuBefore'],'excluded':d['excludedNonvisualCounters'],'driverTicks':d['driver']['ticks']}
path=Path('/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit/army-signal-zero-x-ef75be6/geometry-comparison.json')
path.parent.mkdir(parents=True,exist_ok=True)
with path.open('x') as f: json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'exactBytesEqual':True,'sha256':out['sha256'],'views':len(rows),'visibleSignals':[(x['day'],x['camera'],x['visibleSignals']) for x in rows]}))

import {chromium} from '@playwright/test';
import {writeFileSync,openSync} from 'node:fs';
import {spawn} from 'node:child_process';
const log=openSync('/tmp/tenka-national120-optimized-profile-preview.log','w');
const preview=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4173'],{stdio:['ignore',log,log]});
let browser;
try {
 for(let i=0;i<100;i++){try{const r=await fetch('http://127.0.0.1:4173');if(r.ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
 const context=await browser.newContext({viewport:{width:1920,height:1080},reducedMotion:'no-preference'});
 const page=await context.newPage();
 await page.goto('http://127.0.0.1:4173/?debug=1&seed=15600519');
 await page.getByTestId('title-newgame').click(); await page.getByTestId('scenario-pick-s1560').click(); await page.getByTestId('clan-pick-clan.oda').click(); await page.getByTestId('newgame-start').click(); await page.getByTestId('screen-strategy').waitFor(); await page.getByTestId('speed-pause').click();
 const preparation=await page.evaluate(()=>window.__tenka.debug.prepareLiveNationalMapWorkload(120));
 await page.evaluate(async()=>{await document.fonts.ready;await window.__tenka.debug.setMapCameraPreset('overview');await window.__tenka.debug.waitMapIdle(3);});
 const before=await page.evaluate(()=>JSON.stringify(window.__tenka.debug.getState()));
 const client=await context.newCDPSession(page); await client.send('Profiler.enable');await client.send('Profiler.setSamplingInterval',{interval:1000});await client.send('Profiler.start');
 const measurement=await page.evaluate(()=>window.__tenka.debug.measureNationalMapFrames('overview',10000));
 const {profile}=await client.send('Profiler.stop');
 const after=await page.evaluate(()=>JSON.stringify(window.__tenka.debug.getState()));
 const driver=await page.evaluate(()=>window.__tenka.debug.getLiveNationalMapWorkload());
 writeFileSync('/tmp/tenka-national120-optimized-overview.cpuprofile',JSON.stringify(profile));
 writeFileSync('/tmp/tenka-national120-optimized-profile-summary.json',JSON.stringify({scope:'separateCPUProfile/notAcceptanceFPS',preparation,driver,canonicalStateByteEqual:before===after,measurement},null,2));
 if(before!==after||driver.ticks!==0)throw Error('Profile mutated canonical state');
 console.log(JSON.stringify({nodes:profile.nodes.length,samples:profile.samples.length,canonicalStateByteEqual:true,driverTicks:driver.ticks}));
} finally {await browser?.close();preview.kill('SIGTERM');}

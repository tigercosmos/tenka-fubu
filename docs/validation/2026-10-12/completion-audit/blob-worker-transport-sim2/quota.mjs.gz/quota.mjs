import { chromium, devices } from '/tmp/tenka-20261012-sim2-browser/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
const repo='/tmp/tenka-20261012-sim2-browser';
const out='/tmp/tenka-remount-discriminator';
mkdirSync(out,{recursive:true});
const urls=JSON.parse(readFileSync(`${out}/urls.json`));
const server=spawn(`${repo}/runtime/node-v22.23.3-linux-x64/bin/node`,[`${repo}/node_modules/vite/bin/vite.js`,'preview','--port','4174','--strictPort'],{cwd:repo,stdio:['ignore','pipe','pipe']});
let serverLog='';server.stdout.on('data',b=>serverLog+=b);server.stderr.on('data',b=>serverLog+=b);
try {
 for(let n=0;n<100;n++){try{if((await fetch('http://localhost:4174')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 for(const mode of ['blob-workers-gc','arraybuffer-blob-bitmap']) { const trace=false;const cache=true;
  const id=`quota-${mode}`;
  const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
  const context=await browser.newContext({...devices['Desktop Chrome']});
  if(trace)await context.tracing.start({screenshots:true,snapshots:true,sources:true});
  const page=await context.newPage();
  // Same origin and Vite preview, without starting the application's renderer.
  await page.goto('http://localhost:4174/assets/textures/terrain-ground-grass-v1.png');
  const cdp=await context.newCDPSession(page);
  const networkFailures=[];page.on('requestfailed',r=>networkFailures.push({url:r.url(),failure:r.failure()}));
  await page.evaluate(({urls,cache,mode})=>{
   const code=`self.onmessage=async(message)=>{try{const response=await fetch(message.data.url,${cache?'{}':"{cache:'no-store'}"});if(!response.ok)throw Error('HTTP '+response.status);${mode==='arraybuffer-only'?"const bytes=await response.arrayBuffer();self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:bytes.byteLength});":(mode==='blob-only'||mode==='blob-workers-gc')?"const blob=await response.blob();self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:blob.size});":"const blob=new Blob([await response.arrayBuffer()]);const bitmap=await createImageBitmap(blob);self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:blob.size,width:bitmap.width,height:bitmap.height,bitmap},[bitmap]);"}}catch(e){self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:false,error:String(e),stack:e.stack});}}`;
   const u=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
   window.probeWorkers=urls.map(()=>new Worker(u));URL.revokeObjectURL(u);
   window.probeUrls=urls;window.probeMode=mode;
  },{urls,cache,mode});
  const root=await browser.newBrowserCDPSession();
  const targets=await root.send('Target.getTargets'); console.log(id,'target types',targets.targetInfos.map(t=>t.type));
  const sessions=[]; const pending=new Map(); let commandId=0;
  root.on('Target.receivedMessageFromTarget',event=>{const message=JSON.parse(event.message);if(message.id){const key=event.sessionId+':'+message.id;pending.get(key)?.(message);pending.delete(key);}});
  if(mode==='blob-workers-gc')for(const t of targets.targetInfos.filter(t=>t.type==='worker')){const {sessionId}=await root.send('Target.attachToTarget',{targetId:t.targetId,flatten:false});sessions.push(sessionId);}
  console.log(id,'GC worker sessions',sessions.length);
  async function gcWorker(sessionId){const id=++commandId;const done=new Promise(resolve=>pending.set(sessionId+':'+id,resolve));await root.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id,method:'HeapProfiler.collectGarbage'})});const response=await done;if(response.error)throw Error(JSON.stringify(response.error));}
  const rows=[];
  for(let cycle=1;cycle<=70;cycle++) {
   const result=await page.evaluate(async cycle=>Promise.all(window.probeWorkers.map((w,i)=>new Promise(resolve=>{w.onmessage=e=>{const data=e.data;if(window.probeMode==='bitmap-close')data.bitmap?.close();delete data.bitmap;resolve(data);};w.postMessage({cycle,url:new URL('/assets/textures/'+window.probeUrls[i],location.href).href});}))),cycle);
   rows.push({cycle,result});await cdp.send('HeapProfiler.collectGarbage');for(const sessionId of sessions)await gcWorker(sessionId);
   if(cycle%10===0)console.log(id,'cycle',cycle,'failures',result.filter(r=>!r.ok).length);
  }
  const report={id,mode,workerGCSessions:sessions.length,trace,cache,cacheOffMethod:'fetch cache:no-store',headless:true,renderer:false,cycles:70,assetsPerCycle:urls.length,rows,networkFailures};
  writeFileSync(`${out}/${id}.json`,JSON.stringify(report,null,2));
  console.log(id,'DONE',rows.flatMap(r=>r.result).filter(r=>!r.ok).length);
  if(trace)await context.tracing.stop({path:`${out}/${id}.zip`});
  await browser.close();
 }
} finally {server.kill('SIGTERM');writeFileSync(`${out}/server.log`,serverLog);}

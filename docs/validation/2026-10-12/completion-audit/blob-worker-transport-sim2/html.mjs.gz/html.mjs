import { chromium, devices } from '/tmp/tenka-20261012-sim2-browser/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
const repo='/tmp/tenka-20261012-sim2-browser',out='/tmp/tenka-remount-discriminator';
const urls=JSON.parse(readFileSync(`${out}/urls.json`));
const server=spawn(`${repo}/runtime/node-v22.23.3-linux-x64/bin/node`,[`${repo}/node_modules/vite/bin/vite.js`,'preview','--port','4174','--strictPort'],{cwd:repo,stdio:'ignore'});
try {
 for(let n=0;n<100;n++){try{if((await fetch('http://localhost:4174')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
 const context=await browser.newContext({...devices['Desktop Chrome']});
 const page=await context.newPage();await page.goto('http://localhost:4174/assets/textures/terrain-ground-grass-v1.png');
 const cdp=await context.newCDPSession(page);const networkFailures=[];page.on('requestfailed',r=>networkFailures.push({url:r.url(),failure:r.failure()}));
 const rows=[];
 for(let cycle=1;cycle<=120;cycle++){
  const result=await page.evaluate(async({urls,cycle})=>Promise.all(urls.map(async name=>{
   const url=new URL('/assets/textures/'+name,location.href).href;
   try{
    const image=new Image();image.crossOrigin='anonymous';image.src=url;
    await image.decode();return {url,cycle,ok:true,width:image.naturalWidth,height:image.naturalHeight};
   }catch(e){return {url,cycle,ok:false,error:String(e)};}
  })),{urls,cycle});rows.push({cycle,result});await cdp.send('HeapProfiler.collectGarbage');
  if(cycle%10===0)console.log('html-image',cycle,'failures',result.filter(r=>!r.ok).length);
 }
 writeFileSync(`${out}/html-image.json`,JSON.stringify({mode:'HTMLImageElement decode',renderer:false,trace:false,cache:true,cycles:120,assetsPerCycle:28,rows,networkFailures},null,2));
 await browser.close();
}finally{server.kill('SIGTERM');}

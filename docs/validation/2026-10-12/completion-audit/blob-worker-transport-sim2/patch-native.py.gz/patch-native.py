from pathlib import Path
p=Path("src/ui/assets/loader.ts")
s=p.read_text();needle="import { ATLAS_FRAME_MAP } from './generated';";assert s.count(needle)==1
p.write_text(s.replace(needle,needle+"\n\nAssets.setPreferences({ preferWorkers: false });"))

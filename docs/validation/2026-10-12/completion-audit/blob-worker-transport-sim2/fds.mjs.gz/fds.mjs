import { chromium, devices } from '/tmp/tenka-20261012-sim2-browser/node_modules/playwright/index.mjs';
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, readlinkSync } from 'node:fs';
const repo='/tmp/tenka-20261012-sim2-browser';
const out='/tmp/tenka-remount-discriminator';
mkdirSync(out,{recursive:true});
const urls=JSON.parse(readFileSync(`${out}/urls.json`));
const server=spawn(`${repo}/runtime/node-v22.23.3-linux-x64/bin/node`,[`${repo}/node_modules/vite/bin/vite.js`,'preview','--port','4174','--strictPort'],{cwd:repo,stdio:['ignore','pipe','pipe']});
let serverLog='';server.stdout.on('data',b=>serverLog+=b);server.stderr.on('data',b=>serverLog+=b);
try {
 for(let n=0;n<100;n++){try{if((await fetch('http://localhost:4174')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 for(const mode of ['blob-only']) { const trace=false;const cache=true;
  const id=`fds-${mode}`;
  const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-gpu','--use-angle=vulkan']});
  const context=await browser.newContext({...devices['Desktop Chrome']});
  if(trace)await context.tracing.start({screenshots:true,snapshots:true,sources:true});
  const page=await context.newPage();
  // Same origin and Vite preview, without starting the application's renderer.
  await page.goto('http://localhost:4174/assets/textures/terrain-ground-grass-v1.png');
  const cdp=await context.newCDPSession(page);
  const networkFailures=[];page.on('requestfailed',r=>networkFailures.push({url:r.url(),failure:r.failure()}));
  await page.evaluate(({urls,cache,mode})=>{
   const code=`self.onmessage=async(message)=>{try{const response=await fetch(message.data.url,${cache?'{}':"{cache:'no-store'}"});if(!response.ok)throw Error('HTTP '+response.status);${mode==='arraybuffer-only'?"const bytes=await response.arrayBuffer();self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:bytes.byteLength});":mode==='blob-only'?"const blob=await response.blob();self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:blob.size});":"const blob=await response.blob();const bitmap=await createImageBitmap(blob);self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:true,bytes:blob.size,width:bitmap.width,height:bitmap.height,bitmap},[bitmap]);"}}catch(e){self.postMessage({cycle:message.data.cycle,url:message.data.url,ok:false,error:String(e),stack:e.stack});}}`;
   const u=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
   window.probeWorkers=urls.map(()=>new Worker(u));URL.revokeObjectURL(u);
   window.probeUrls=urls;window.probeMode=mode;
  },{urls,cache,mode});
  const rows=[];
  for(let cycle=1;cycle<=70;cycle++) {
   const result=await page.evaluate(async cycle=>Promise.all(window.probeWorkers.map((w,i)=>new Promise(resolve=>{w.onmessage=e=>{const data=e.data;if(window.probeMode==='bitmap-close')data.bitmap?.close();delete data.bitmap;resolve(data);};w.postMessage({cycle,url:new URL('/assets/textures/'+window.probeUrls[i],location.href).href});}))),cycle);
   const processes=[];
   for(const pid of readdirSync('/proc').filter(p=>/^\d+$/.test(p))){try{const command=readFileSync(`/proc/${pid}/cmdline`,'utf8').replaceAll('\0',' ');if(!command.includes('runtime/browsers/chromium-1228'))continue;const fds=readdirSync(`/proc/${pid}/fd`);const kinds={};for(const fd of fds){try{const target=readlinkSync(`/proc/${pid}/fd/${fd}`);const kind=target.startsWith('/tmp')?'tmp-file':target.split(':')[0];kinds[kind]=(kinds[kind]??0)+1;}catch{}}processes.push({pid,command,fdCount:fds.length,kinds,limit:readFileSync(`/proc/${pid}/limits`,'utf8').split('\n').find(l=>l.startsWith('Max open files'))});}catch{}}
   rows.push({cycle,result,processes});await cdp.send('HeapProfiler.collectGarbage');
   if(cycle%10===0)console.log(id,'cycle',cycle,'failures',result.filter(r=>!r.ok).length);
  }
  const report={id,mode,trace,cache,cacheOffMethod:'fetch cache:no-store',headless:true,renderer:false,cycles:70,assetsPerCycle:urls.length,rows,networkFailures};
  writeFileSync(`${out}/${id}.json`,JSON.stringify(report,null,2));
  console.log(id,'DONE',rows.flatMap(r=>r.result).filter(r=>!r.ok).length);
  if(trace)await context.tracing.stop({path:`${out}/${id}.zip`});
  await browser.close();
 }
} finally {server.kill('SIGTERM');writeFileSync(`${out}/server.log`,serverLog);}

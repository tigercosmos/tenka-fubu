import subprocess, pathlib, hashlib, json, sys
base=pathlib.Path(sys.argv[1]);output=pathlib.Path(sys.argv[2])
paths=subprocess.check_output(['git','ls-files','-z'],cwd=base).decode().split('\0')
paths=[p for p in paths if p and (p.startswith(('src/','tests/','tools/','e2e/','plan/','rust/')) or ('/' not in p and pathlib.Path(p).suffix in ('.json','.js','.mjs','.ts','.toml','.yaml','.yml'))) and not p.endswith(('.wasm','.png','.jpg','.woff2'))]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=base).decode().strip()
requests=''.join(f'{head}:{p}\n' for p in paths).encode()
raw=subprocess.check_output(['git','cat-file','--batch'],input=requests,cwd=base);offset=0;rows=[]
for p in paths:
 end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert len(header)==3 and header[1]=='blob',(p,header)
 size=int(header[2]);blob=raw[end+1:end+1+size];offset=end+2+size
 actual=(base/p).read_bytes();assert actual==blob,p
 rows.append({'path':p,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest()})
output.write_text(json.dumps({'head':head,'scope':'Tracked src/tests/tools/e2e/plan/rust and root config; excludes public/dependencies and binary outputs','files':rows},indent=2)+'\n')
print('fixed Git blob matched inputs',len(rows),'HEAD',head)

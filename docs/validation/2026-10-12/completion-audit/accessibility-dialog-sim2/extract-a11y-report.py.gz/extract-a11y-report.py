from pathlib import Path
import re,base64,zipfile,io,json,hashlib
source=Path('/tmp/tenka-a11y-e65fbbc/playwright-report/index.html');out=Path('/tmp/tenka-a11y-e65fbbc-preserved/report-attachments');out.mkdir(exist_ok=True)
m=re.search(r'data:application/zip;base64,([A-Za-z0-9+/=]+)</template>',source.read_text())
z=zipfile.ZipFile(io.BytesIO(base64.b64decode(m.group(1))));rows=[];seen=set()
for name in z.namelist():
 if not name.endswith('.json'):continue
 raw=z.read(name);d=json.loads(raw)
 def walk(x):
  if isinstance(x,dict):
   if x.get('contentType')=='application/json' and isinstance(x.get('body'),str):
    body=x['body'].encode(); key=(x['name'],hashlib.sha256(body).hexdigest())
    if key not in seen:
     seen.add(key);filename=re.sub(r'[^a-zA-Z0-9_-]','-',x['name'])+'.json';(out/filename).write_bytes(body)
     rows.append({'name':x['name'],'file':filename,'reportZipEntry':name,'bytes':len(body),'sha256':key[1]})
   for v in x.values():walk(v)
  if isinstance(x,list):
   for v in x:walk(v)
 walk(d)
(out/'extraction-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print('Extracted',len(rows),'exact UTF-8 attachment bodies')

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> production screens have no critical axe findings and dialogs preserve one page banner
- Location: e2e/accessibility.spec.ts:33:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 85

- Array []
+ Array [
+   Object {
+     "description": "Ensure the document has at most one banner landmark",
+     "help": "Document should not have more than one banner landmark",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.14/landmark-no-duplicate-banner?application=axeAPI",
+     "id": "landmark-no-duplicate-banner",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": null,
+             "id": "page-no-duplicate-banner",
+             "impact": "moderate",
+             "message": "Document has more than one banner landmark",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<header>",
+                 "target": Array [
+                   "._dialog_qv2fe_11 > header",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Document has more than one banner landmark",
+         "html": "<header class=\"_hud_1v1gg_7\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "._hud_1v1gg_7",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+   Object {
+     "description": "Ensure landmarks are unique",
+     "help": "Landmarks should have a unique role or role/label/title (i.e. accessible name) combination",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.14/landmark-unique?application=axeAPI",
+     "id": "landmark-unique",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "accessibleText": null,
+               "role": "banner",
+             },
+             "id": "landmark-is-unique",
+             "impact": "moderate",
+             "message": "The landmark must have a unique aria-label, aria-labelledby, or title to make landmarks distinguishable",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<header>",
+                 "target": Array [
+                   "._dialog_qv2fe_11 > header",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   The landmark must have a unique aria-label, aria-labelledby, or title to make landmarks distinguishable",
+         "html": "<header class=\"_hud_1v1gg_7\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "._hud_1v1gg_7",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+ ]
```

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 85

- Array []
+ Array [
+   Object {
+     "description": "Ensure the document has at most one banner landmark",
+     "help": "Document should not have more than one banner landmark",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.14/landmark-no-duplicate-banner?application=axeAPI",
+     "id": "landmark-no-duplicate-banner",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": null,
+             "id": "page-no-duplicate-banner",
+             "impact": "moderate",
+             "message": "Document has more than one banner landmark",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<header>",
+                 "target": Array [
+                   "._dialog_qv2fe_11 > header",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Document has more than one banner landmark",
+         "html": "<header class=\"_hud_1v1gg_7\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "._hud_1v1gg_7",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+   Object {
+     "description": "Ensure landmarks are unique",
+     "help": "Landmarks should have a unique role or role/label/title (i.e. accessible name) combination",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.14/landmark-unique?application=axeAPI",
+     "id": "landmark-unique",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "accessibleText": null,
+               "role": "banner",
+             },
+             "id": "landmark-is-unique",
+             "impact": "moderate",
+             "message": "The landmark must have a unique aria-label, aria-labelledby, or title to make landmarks distinguishable",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<header>",
+                 "target": Array [
+                   "._dialog_qv2fe_11 > header",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   The landmark must have a unique aria-label, aria-labelledby, or title to make landmarks distinguishable",
+         "html": "<header class=\"_hud_1v1gg_7\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "._hud_1v1gg_7",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+ ]
```

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('banner')
Expected: 1
Received: 2
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByRole('banner')
    14 × locator resolved to 2 elements
       - unexpected value "2"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - region "戰略圖層" [ref=e6]:
      - group [ref=e7]:
        - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
    - banner [ref=e9]:
      - group "金錢、兵糧、兵力、威信" [ref=e10]:
        - generic [ref=e11]:
          - group "織田家" [ref=e12]
          - time [ref=e14]: 1560年1月1日
          - generic [ref=e15]:
            - generic [ref=e16]:
              - img [ref=e17]
              - generic [ref=e20]: 金錢
            - strong [ref=e23]: 2,000
          - generic [ref=e24]:
            - generic [ref=e25]:
              - img [ref=e26]
              - generic [ref=e28]: 兵糧
            - generic [ref=e29]:
              - strong [ref=e31]: 12,000
              - generic "兵糧可支撐26個月" [ref=e32]:
                - text: 兵糧可支撐
                - strong [ref=e33]: "26"
                - text: 個月
          - generic [ref=e34]:
            - generic [ref=e35]:
              - img [ref=e36]
              - generic [ref=e40]: 兵力
            - generic [ref=e42]:
              - strong [ref=e43]: 4,517
              - generic [ref=e44]: /4,662
          - generic [ref=e45]:
            - generic [ref=e46]:
              - img [ref=e47]
              - generic [ref=e49]: 威信
            - strong [ref=e52]: "250"
      - generic [ref=e53]:
        - generic [ref=e54]:
          - button "暫停" [disabled] [pressed]:
            - img
          - button "一倍速" [disabled]:
            - img
          - button "二倍速" [disabled]:
            - img
          - button "五倍速" [disabled]:
            - img
        - button "系統選單" [ref=e55] [cursor=pointer]:
          - img [ref=e56]
    - navigation "內政" [ref=e59]:
      - button "地圖一覽" [ref=e60] [cursor=pointer]:
        - img [ref=e61]
        - generic [ref=e64]:
          - generic [ref=e65]: 地圖
          - generic [ref=e66]: 一覽
      - button "織田家 （本城）" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
        - generic "織田家" [ref=e73]: 織田
      - generic [ref=e75]: 軍政
      - button "軍事" [ref=e76] [cursor=pointer]:
        - img [ref=e77]
        - text: 軍事
      - button "內政" [ref=e79] [cursor=pointer]:
        - img [ref=e80]
        - text: 內政
      - button "武將" [ref=e82] [cursor=pointer]:
        - img [ref=e83]
        - text: 武將
      - generic [ref=e88]: 交涉
      - button "外交" [ref=e89] [cursor=pointer]:
        - img [ref=e90]
        - text: 外交
      - button "調略" [ref=e92] [cursor=pointer]:
        - img [ref=e93]
        - text: 調略
      - generic [ref=e97]: 國策
      - button "政策" [ref=e98] [cursor=pointer]:
        - img [ref=e99]
        - text: 政策
      - button "軍團" [ref=e101] [cursor=pointer]:
        - img [ref=e102]
        - text: 軍團
      - button "大命" [ref=e104] [cursor=pointer]:
        - img [ref=e105]
        - text: 大命
    - generic:
      - generic:
        - generic:
          - button:
            - img
    - img "全國小地圖" [ref=e107]
    - button "報告中心" [ref=e110] [cursor=pointer]
  - dialog "讀檔" [ref=e112]:
    - banner [ref=e113]:
      - heading "讀檔" [level=2] [ref=e114]
      - button "讀檔" [active] [ref=e115] [cursor=pointer]:
        - img [ref=e116]
    - generic [ref=e120]:
      - generic [ref=e121]:
        - heading "讀檔" [level=2] [ref=e122]
        - button "返回" [ref=e123] [cursor=pointer]
      - list [ref=e124]:
        - listitem [ref=e125]:
          - heading "手動 1" [level=3] [ref=e126]
          - generic [ref=e128]: （空）
          - generic [ref=e129]:
            - button "載入" [disabled] [ref=e130]
            - button "刪除" [disabled] [ref=e131]
            - button "匯出" [disabled] [ref=e132]
        - listitem [ref=e133]:
          - heading "手動 2" [level=3] [ref=e134]
          - generic [ref=e136]: （空）
          - generic [ref=e137]:
            - button "載入" [disabled] [ref=e138]
            - button "刪除" [disabled] [ref=e139]
            - button "匯出" [disabled] [ref=e140]
        - listitem [ref=e141]:
          - heading "手動 3" [level=3] [ref=e142]
          - generic [ref=e144]: （空）
          - generic [ref=e145]:
            - button "載入" [disabled] [ref=e146]
            - button "刪除" [disabled] [ref=e147]
            - button "匯出" [disabled] [ref=e148]
        - listitem [ref=e149]:
          - heading "手動 4" [level=3] [ref=e150]
          - generic [ref=e152]: （空）
          - generic [ref=e153]:
            - button "載入" [disabled] [ref=e154]
            - button "刪除" [disabled] [ref=e155]
            - button "匯出" [disabled] [ref=e156]
        - listitem [ref=e157]:
          - heading "手動 5" [level=3] [ref=e158]
          - generic [ref=e160]: （空）
          - generic [ref=e161]:
            - button "載入" [disabled] [ref=e162]
            - button "刪除" [disabled] [ref=e163]
            - button "匯出" [disabled] [ref=e164]
        - listitem [ref=e165]:
          - heading "手動 6" [level=3] [ref=e166]
          - generic [ref=e168]: （空）
          - generic [ref=e169]:
            - button "載入" [disabled] [ref=e170]
            - button "刪除" [disabled] [ref=e171]
            - button "匯出" [disabled] [ref=e172]
        - listitem [ref=e173]:
          - heading "手動 7" [level=3] [ref=e174]
          - generic [ref=e176]: （空）
          - generic [ref=e177]:
            - button "載入" [disabled] [ref=e178]
            - button "刪除" [disabled] [ref=e179]
            - button "匯出" [disabled] [ref=e180]
        - listitem [ref=e181]:
          - heading "手動 8" [level=3] [ref=e182]
          - generic [ref=e184]: （空）
          - generic [ref=e185]:
            - button "載入" [disabled] [ref=e186]
            - button "刪除" [disabled] [ref=e187]
            - button "匯出" [disabled] [ref=e188]
        - listitem [ref=e189]:
          - heading "手動 9" [level=3] [ref=e190]
          - generic [ref=e192]: （空）
          - generic [ref=e193]:
            - button "載入" [disabled] [ref=e194]
            - button "刪除" [disabled] [ref=e195]
            - button "匯出" [disabled] [ref=e196]
        - listitem [ref=e197]:
          - heading "手動 10" [level=3] [ref=e198]
          - generic [ref=e200]: （空）
          - generic [ref=e201]:
            - button "載入" [disabled] [ref=e202]
            - button "刪除" [disabled] [ref=e203]
            - button "匯出" [disabled] [ref=e204]
        - listitem [ref=e205]:
          - heading "自動 1" [level=3] [ref=e206]
          - generic [ref=e208]: （空）
          - generic [ref=e209]:
            - button "載入" [disabled] [ref=e210]
            - button "刪除" [disabled] [ref=e211]
            - button "匯出" [disabled] [ref=e212]
        - listitem [ref=e213]:
          - heading "自動 2" [level=3] [ref=e214]
          - generic [ref=e216]: （空）
          - generic [ref=e217]:
            - button "載入" [disabled] [ref=e218]
            - button "刪除" [disabled] [ref=e219]
            - button "匯出" [disabled] [ref=e220]
        - listitem [ref=e221]:
          - heading "自動 3" [level=3] [ref=e222]
          - generic [ref=e224]: （空）
          - generic [ref=e225]:
            - button "載入" [disabled] [ref=e226]
            - button "刪除" [disabled] [ref=e227]
            - button "匯出" [disabled] [ref=e228]
        - listitem [ref=e229]:
          - heading "快速存檔" [level=3] [ref=e230]
          - generic [ref=e232]: （空）
          - generic [ref=e233]:
            - button "載入" [disabled] [ref=e234]
            - button "刪除" [disabled] [ref=e235]
            - button "匯出" [disabled] [ref=e236]
      - button "匯出目前進度" [ref=e237] [cursor=pointer]
      - region "匯入存檔" [ref=e238]:
        - paragraph [ref=e239]: 將 .tenkafubu.json 檔案拖曳至此，或點擊選擇檔案
        - button "匯入存檔" [ref=e240] [cursor=pointer]
```

# Test source

```ts
  1   | import { writeFile } from 'node:fs/promises';
  2   | import axe, { type AxeResults } from 'axe-core';
  3   | import type { Page, TestInfo } from '@playwright/test';
  4   | import { test, expect } from './fixtures';
  5   | 
  6   | type AxeWindow = Window & { axe: typeof axe };
  7   | 
  8   | async function newPausedGame(page: Page): Promise<void> {
  9   |   await page.goto('/?debug=1');
  10  |   await page.getByTestId('title-newgame').click();
  11  |   await page.getByTestId('scenario-pick-s1560').click();
  12  |   await page.getByTestId('clan-pick-clan.oda').click();
  13  |   await page.getByTestId('newgame-start').click();
  14  |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  15  |   await page.getByTestId('speed-pause').click();
  16  |   await page.evaluate(async () => {
  17  |     await window.__tenka.debug.waitSimulationIdle();
  18  |     await window.__tenka.debug.waitMapIdle();
  19  |   });
  20  | }
  21  | 
  22  | async function audit(page: Page, info: TestInfo, name: string): Promise<AxeResults> {
  23  |   await page.evaluate(() => document.fonts.ready);
  24  |   const result = await page.evaluate(() => (window as unknown as AxeWindow).axe.run());
  25  |   const raw = JSON.stringify(result, null, 2);
  26  |   await writeFile(info.outputPath(`axe-${name}.json`), raw);
  27  |   await info.attach(`axe-${name}`, { body: raw, contentType: 'application/json' });
  28  |   // Preserve all default rules, violations and incomplete checks. M6-V11 requires no critical.
  29  |   expect.soft(result.violations.filter((violation) => violation.impact === 'critical')).toEqual([]);
  30  |   return result;
  31  | }
  32  | 
  33  | test('production screens have no critical axe findings and dialogs preserve one page banner', async ({
  34  |   page,
  35  | }, info) => {
  36  |   await page.goto('/?debug=1');
  37  |   await expect(page.getByTestId('title-newgame')).toBeVisible();
  38  |   await page.addScriptTag({ content: axe.source });
  39  |   await audit(page, info, 'title');
  40  |   await page.getByTestId('title-newgame').click();
  41  |   await expect(page.getByTestId('scenario-pick-s1560')).toBeVisible();
  42  |   await audit(page, info, 'new-game');
  43  |   await page.getByTestId('scenario-pick-s1560').click();
  44  |   await page.getByTestId('clan-pick-clan.oda').click();
  45  |   await page.getByTestId('newgame-start').click();
  46  |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  47  |   await page.getByTestId('speed-pause').click();
  48  |   await page.evaluate(async () => {
  49  |     await window.__tenka.debug.waitSimulationIdle();
  50  |     await window.__tenka.debug.waitMapIdle();
  51  |   });
  52  |   await audit(page, info, 'main');
  53  |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  54  |   await page.getByRole('button', { name: '設定', exact: true }).click();
  55  |   await expect(page.getByTestId('settings-panel')).toBeVisible();
  56  |   const settings = await audit(page, info, 'settings');
  57  |   await page.keyboard.press('Escape');
  58  |   await page.keyboard.press('Escape');
  59  |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  60  |   await page.getByRole('button', { name: '讀檔', exact: true }).click();
  61  |   await expect(page.getByTestId('save-load-panel')).toHaveAttribute('aria-busy', 'false');
  62  |   const saveLoad = await audit(page, info, 'save-load');
  63  |   for (const result of [settings, saveLoad]) {
  64  |     expect
  65  |       .soft(
  66  |         result.violations.filter((violation) =>
  67  |           ['landmark-no-duplicate-banner', 'landmark-unique'].includes(violation.id),
  68  |         ),
  69  |       )
  70  |       .toEqual([]);
  71  |   }
  72  |   const dialog = page.getByRole('dialog');
  73  |   await expect(dialog).toHaveAttribute('aria-modal', 'true');
  74  |   expect(
  75  |     await dialog.evaluate((element) => {
  76  |       const heading = document.getElementById(element.getAttribute('aria-labelledby') ?? '');
  77  |       return heading?.tagName === 'H2' && element.contains(heading);
  78  |     }),
  79  |   ).toBe(true);
> 80  |   await expect(page.getByRole('banner')).toHaveCount(1);
      |                                          ^ Error: expect(locator).toHaveCount(expected) failed
  81  | });
  82  | 
  83  | test('empty load registry remains reachable and scrollable with native keyboard input', async ({
  84  |   page,
  85  | }, info) => {
  86  |   await newPausedGame(page);
  87  |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  88  |   await page.getByRole('button', { name: '讀檔', exact: true }).click();
  89  |   const panel = page.getByTestId('save-load-panel');
  90  |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  91  |   const list = panel.locator('ol');
  92  |   expect(await list.locator('button:enabled').count()).toBe(0);
  93  |   const before = await list.evaluate((element) => ({
  94  |     scrollHeight: element.scrollHeight,
  95  |     clientHeight: element.clientHeight,
  96  |     scrollTop: element.scrollTop,
  97  |   }));
  98  |   expect(before.scrollHeight).toBeGreaterThan(before.clientHeight);
  99  |   await panel.getByRole('button', { name: '返回', exact: true }).focus();
  100 |   await page.keyboard.press('Tab');
  101 |   // Chromium exposes automatic scroll-container focus despite the absence of explicit tabindex.
  102 |   await expect(list).toBeFocused();
  103 |   const focus = await list.evaluate((element) => {
  104 |     const style = getComputedStyle(element);
  105 |     return {
  106 |       outline: style.outlineStyle,
  107 |       width: parseFloat(style.outlineWidth),
  108 |       shadow: style.boxShadow,
  109 |     };
  110 |   });
  111 |   expect((focus.outline !== 'none' && focus.width >= 2) || focus.shadow !== 'none').toBe(true);
  112 |   await page.keyboard.press('End');
  113 |   await expect
  114 |     .poll(() => list.evaluate((element) => element.scrollTop))
  115 |     .toBeGreaterThan(before.scrollTop);
  116 |   const after = await list.evaluate((element) => element.scrollTop);
  117 |   await info.attach('empty-registry-native-keyboard', {
  118 |     body: JSON.stringify({ before, after, focus }),
  119 |     contentType: 'application/json',
  120 |   });
  121 | });
  122 | 
```
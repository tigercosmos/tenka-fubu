import { chromium, expect } from '/tmp/tenka-a11y-e65fbbc/node_modules/@playwright/test/index.mjs';
import axe from '/tmp/tenka-a11y-e65fbbc/node_modules/axe-core/axe.js';
import { mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { createWriteStream } from 'node:fs';
const out='/tmp/tenka-a11y-e65fbbc-keyboard-probe';
await mkdir(out,{recursive:true});
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4173','--strictPort'],{cwd:'/tmp/tenka-a11y-e65fbbc',detached:true,stdio:['ignore','pipe','pipe']});
const serverLog=createWriteStream(`${out}/preview.log`);server.stdout.pipe(serverLog);server.stderr.pipe(serverLog);
let ready=false;for(let i=0;i<60;i++){try{const r=await fetch('http://127.0.0.1:4173');if(r.ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}
if(!ready){process.kill(-server.pid,'SIGTERM');throw new Error('Preview unavailable');}
const browser=await chromium.launch({headless:true,channel:'chromium',args:['--enable-gpu','--use-angle=vulkan']});
const context=await browser.newContext({viewport:{width:1280,height:720},reducedMotion:'reduce'});
await context.tracing.start({screenshots:true,snapshots:true,sources:true});
const page=await context.newPage();
const errors=[];page.on('pageerror',e=>errors.push({kind:'pageerror',message:e.message}));page.on('console',m=>{if(m.type()==='error')errors.push({kind:'console',message:m.text()});});
const summaries=[];
async function audit(name){
 await page.evaluate(()=>document.fonts.ready);
 const result=await page.evaluate(async()=>await window.axe.run());
 await writeFile(`${out}/axe-${name}.json`,JSON.stringify(result,null,2)+'\n');
 await page.screenshot({path:`${out}/${name}.png`});
 summaries.push({name,url:page.url(),violations:result.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})),incomplete:result.incomplete.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})),passes:result.passes.length});
 console.log(JSON.stringify(summaries.at(-1)));
}
try{
 await page.goto('http://127.0.0.1:4173/?debug=1');
 await expect(page.getByTestId('title-newgame')).toBeVisible();
 await page.addScriptTag({content:axe.source});
 await audit('title');
 await page.getByTestId('title-newgame').click();
 await expect(page.getByTestId('scenario-pick-s1560')).toBeVisible();
 await audit('new-game');
 await page.getByTestId('scenario-pick-s1560').click();
 await page.getByTestId('clan-pick-clan.oda').click();
 await page.getByTestId('newgame-start').click();
 await expect(page.getByTestId('screen-strategy')).toBeVisible();
 await page.getByTestId('speed-pause').click();
 await page.evaluate(async()=>{await window.__tenka.debug.waitSimulationIdle();await window.__tenka.debug.waitMapIdle();});
 await audit('main');
 await page.getByRole('button',{name:'系統選單',exact:true}).click();
 await page.getByRole('button',{name:'設定',exact:true}).click();
 await expect(page.getByTestId('settings-panel')).toBeVisible();
 await audit('settings');
 await page.keyboard.press('Escape');
 await page.keyboard.press('Escape');
 await page.getByRole('button',{name:'系統選單',exact:true}).click();
 await page.getByRole('button',{name:'讀檔',exact:true}).click();
 await expect(page.getByTestId('save-load-panel')).toHaveAttribute('aria-busy','false');
 await audit('save-load');
 const list=page.getByTestId('save-load-panel').locator('ol');
 const geometry=await list.evaluate(el=>({scrollHeight:el.scrollHeight,clientHeight:el.clientHeight,tabIndex:el.tabIndex,enabledChildren:el.querySelectorAll('button:not(:disabled)').length,style:getComputedStyle(el).overflow}));
 await page.getByTestId('save-load-panel').getByRole('button',{name:'返回',exact:true}).focus();
 const tabs=[];for(let i=0;i<10;i++){await page.keyboard.press('Tab');tabs.push(await page.evaluate(()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent?.trim().slice(0,50),outer:document.activeElement.outerHTML.slice(0,180)})));}
 await list.evaluate(el=>el.focus());
 const directFocus=await list.evaluate(el=>document.activeElement===el);
 const beforeScroll=await list.evaluate(el=>el.scrollTop);
 await page.keyboard.press('End');await page.waitForTimeout(300);
 const afterScroll=await list.evaluate(el=>el.scrollTop);
 await writeFile(`${out}/scroll-keyboard-probe.json`,JSON.stringify({geometry,tabs,directFocus,beforeScroll,afterScroll},null,2)+'\n');
 await writeFile(`${out}/summary.json`,JSON.stringify({source:'e65fbbc',browser:browser.version(),headless:true,profiler:false,axeVersion:axe.version,states:summaries,errors},null,2)+'\n');
 const critical=summaries.flatMap(s=>s.violations.filter(v=>v.impact==='critical').map(v=>({state:s.name,...v})));
 console.log(JSON.stringify({critical,errors}));
 if(critical.length||errors.length)process.exitCode=1;
}catch(e){await writeFile(`${out}/diagnostic-error.txt`,String(e.stack||e));process.exitCode=2;}
finally{await context.tracing.stop({path:`${out}/production-axe-trace.zip`});await browser.close();process.kill(-server.pid,'SIGTERM');serverLog.end();}

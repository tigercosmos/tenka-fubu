import pathlib,shutil,json,hashlib
r=pathlib.Path('/tmp/tenka-geographic-input-trace-current23-20261012');assert not r.exists();shutil.copytree('/tmp/tenka-simd-native-current23-20261012',r,symlinks=True)
t=pathlib.Path('/tmp/tenka-geographic-input-trace-local');p=json.loads((t/'source-proof.json').read_text())
assert hashlib.sha256((r/'src/ui/map/MapRenderer.ts').read_bytes()).hexdigest()==p['source'][0]['sha256']
for row in p['source'][1:]:shutil.copyfile(t/row['path'].replace('/','__'),r/row['path'])
shutil.copyfile(t/'MapRenderer.instrumented.ts',r/'src/ui/map/MapRenderer.ts');shutil.copyfile(t/'geographicLabelLayout.instrumented.ts',r/'src/ui/map/geographicLabelLayout.ts');shutil.copyfile(t/'observe.mjs',r/'geographic-input-trace.mjs');print('Isolated copy; shared14765deps symlink; only3defaultscalarpolicy files +bounded20-signature hook overlay')

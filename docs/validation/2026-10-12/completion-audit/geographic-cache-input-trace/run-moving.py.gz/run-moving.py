import pathlib,shutil,subprocess,os,json,datetime
r=pathlib.Path('/tmp/tenka-geographic-input-trace-current23-20261012');t=pathlib.Path('/tmp/tenka-geographic-input-trace-local');o=pathlib.Path('/tmp/tenka-geographic-input-trace-moving-evidence');o.mkdir(exist_ok=True);shutil.copyfile(r/'src/ui/map/MapRenderer.ts',o/'MapRenderer.before-moving-trace.ts');shutil.copyfile(t/'MapRenderer.moving-trace-instrumentation.ts',r/'src/ui/map/MapRenderer.ts');shutil.copyfile(t/'observe-moving.mjs',r/'geographic-input-moving-trace.mjs');env=os.environ.copy();env['PATH']='/home/anchi/.nvm/versions/node/v22.23.3/bin:'+env['PATH'];env.update(VISUAL_GPU='1',CI='1');rows=[]
for stage,args in [('build',['npm','run','build']),('observer',['node','geographic-input-moving-trace.mjs'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (o/(stage+'.log')).open('wb') as f:code=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(stage=stage,argv=args,startedUTC=start,finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),terminalExit=code));(o/'status.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 if code:raise RuntimeError('Stop movingdiagnostic without retry')

import pathlib,json,collections,struct,hashlib
r=pathlib.Path('/tmp/tenka-geographic-input-trace-local');p=r/'trace-moving.raw.json';q=json.loads(p.read_text());rows=q['records'];out=[];counts=collections.Counter();inner=collections.Counter();innerzero=collections.Counter();examples={};total=hits=miss=0
names=['rect','roadLine','capsulesUndefined','roadCapsules','first7','xs','ys','nearPrimary','nearHard','nearReserved']
def exact(v):return {'value':v,'f64LE':struct.pack('<d',float(v)).hex()} if isinstance(v,(float,int)) and not isinstance(v,bool) else v
def diff(a,b,path=''):
 if type(a)!=type(b) and not (isinstance(a,(int,float)) and isinstance(b,(int,float))):return [{'field':path,'before':a,'after':b}]
 if isinstance(a,dict):
  result=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:result.append({'field':path+'.'+k,'before':a.get(k),'after':b.get(k),'beforePresent':k in a,'afterPresent':k in b})
   else:result+=diff(a[k],b[k],path+'.'+k)
  return result
 if isinstance(a,list):
  if len(a)!=len(b):return [{'field':path+'.length','before':len(a),'after':len(b),'beforeValue':a,'afterValue':b}]
  return [z for i,(x,y) in enumerate(zip(a,b)) for z in diff(x,y,path+f'[{i}]')]
 return [] if a==b else [{'field':path,'before':exact(a),'after':exact(b)}]
for i in range(1,len(rows)):
 a=json.loads(rows[i-1]['signature']);b=json.loads(rows[i]['signature']);pair={'from':i-1,'to':i,'signatureEqual':rows[i-1]['signature']==rows[i]['signature'],'cameraDiff':diff(rows[i-1].get('camera'),rows[i].get('camera')),'candidates':[],'obstacles':[]}
 for category in ['candidates','obstacles']:
  key=lambda x:x['id'] if category=='candidates' else x['id']+'|'+x['kind'];aa={key(x):x for x in a[category]};bb={key(x):x for x in b[category]};pair[category+'Added']=sorted(bb.keys()-aa.keys());pair[category+'Removed']=sorted(aa.keys()-bb.keys());pair[category+'OrderChanged']=[key(x) for x in a[category]]!=[key(x) for x in b[category]]
  for k in sorted(aa.keys()&bb.keys()):
   changes=diff(aa[k],bb[k])
   if changes:
    item={'idKind':k,'changes':changes};pair[category].append(item)
    for d in changes:counts[(category,bb[k].get('kind','?'),d['field'])]+=1
 out.append(pair)
for fi,row in enumerate(rows):
 for label in row['labels']:
  total+=1
  if label['signature']==label['cachedSignature']:hits+=1;continue
  miss+=1
  if label['cachedSignature'] is None:inner['absent cache']+=1;continue
  a=json.loads(label['cachedSignature']);b=json.loads(label['signature']);parts=tuple(names[i] for i,(x,y) in enumerate(zip(a,b)) if x!=y);inner[parts]+=1
  zero=label['cachedOffset']=={'x':0,'y':0}
  if zero:innerzero[parts]+=1
  if parts not in examples:examples[parts]={'frame':fi,'id':label['id'],'cachedOffset':label['cachedOffset'],'changes':diff(a,b),'currentSignature':label['signature'],'cachedSignature':label['cachedSignature']}
report={'scope':'postprocess only TWOdistinctstatic/movingdiagnostics; nonewtrace/FPS','rawBytes':p.stat().st_size,'rawSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'records':len(rows),'distinctSignatures':len({x['signature'] for x in rows}),'layoutRuns':[x['layoutRuns'] for x in rows],'canonicalByteEqual':q['canonicalByteEqual'],'cameraBefore':q.get('cameraBefore'),'cameraAfter':q.get('cameraAfter'),'cacheBefore':q['before']['diagnostics']['geographicLabelLayout']['placementCache'],'cacheAfter':q['after']['diagnostics']['geographicLabelLayout']['placementCache'],'outerFieldChangeCounts':[{'category':k[0],'kind':k[1],'field':k[2],'count':v} for k,v in counts.most_common()],'innerLabels':total,'innerHits':hits,'innerMisses':miss,'innerChangedSections':[{'sections':list(k) if isinstance(k,tuple) else k,'misses':v,'cachedZeroOffsets':innerzero[k]} for k,v in inner.most_common()],'consecutiveFieldDiffs':out,'innerExamples':list(examples.values()),'limits':['Counts cover20callhook, widerbefore/aftercounters bracketfull1scontrol; do not equate theirscope.','Exactnumbers/f64bits are parsedJSONsignature values; pre-JSONsignedzero/NaNdistinctions cannot be recovered.','This is a diagnostic1000ms originalmoving-view control with instrumentation; noacceptanceFPS/performanceclaim.']}
(r/'diff-moving.raw.json').write_text(json.dumps(report,separators=(',',':'))+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['consecutiveFieldDiffs','innerExamples']},indent=2))

import pathlib,subprocess,os,json,datetime,shutil
r=pathlib.Path('/tmp/tenka-geographic-input-trace-current23-20261012');o=pathlib.Path('/tmp/tenka-geographic-input-trace-evidence');shutil.copyfile(o/'build.log',o/'build-launch-original-red.log');env=os.environ.copy();env['PATH']='/home/anchi/.nvm/versions/node/v22.23.3/bin:'+env['PATH'];env.update(VISUAL_GPU='1',CI='1');rows=[]
for stage,args in [('build',['npm','run','build']),('observer',['node','geographic-input-trace.mjs'])]:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (o/(stage+'.log')).open('wb') as f:code=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(stage=stage,argv=args,startedUTC=started,finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),terminalExit=code));(o/'status.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 if code:raise RuntimeError('Stop diagnostic without observer retry')

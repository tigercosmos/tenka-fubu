#!/usr/bin/env python3
import collections
import importlib.util
import json
from pathlib import Path

P=Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec=importlib.util.spec_from_file_location('postcap',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE=Path('/tmp/tenka-heap-2d872d7/diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium')

def inspect(path):
 m.HERE=BASE/'scratch';s=m.Snapshot(path)
 rows=[]
 for parent in range(s.count):
  if s.kind(parent)!='object':continue
  gpu=s.property(parent,'_gpuData')
  if gpu is None:continue
  data_edges=list(s.edges_of(gpu))
  slots=[int(label) for kind,label,target in data_edges if kind=='element']
  storage=[target for kind,label,target in data_edges if kind=='internal' and label=='elements']
  rows.append({'parentId':s.attr(parent,'id'),'parentName':s.name(parent),
               'mapId':s.attr(gpu,'id'),'mapKind':s.kind(gpu),'mapName':s.name(gpu),
               'slots':slots,'storage':[
                   {'id':s.attr(i,'id'),'kind':s.kind(i),'name':s.name(i),
                    'selfBytes':s.attr(i,'self_size'),'edgeCount':s.attr(i,'edge_count')}
                   for i in storage]})
 totals=collections.defaultdict(lambda:[0,0])
 for row in rows:
  for store in row['storage']:
   key=(tuple(row['slots']),store['kind'],store['name'])
   totals[str(key)][0]+=1;totals[str(key)][1]+=store['selfBytes']
 return {'path':str(path),'objectsWithGpuData':len(rows),'storageGroups':dict(totals),
         'examples':rows[:8],
         'storageSelfBytes':sum(store['selfBytes'] for row in rows for store in row['storage']),
         'slots':dict(collections.Counter(str(tuple(row['slots'])) for row in rows))}

if __name__=='__main__':
 print(json.dumps([inspect(BASE/'after-120-remounts.heapsnapshot'),inspect(BASE/'after-remounts.heapsnapshot')],ensure_ascii=False,indent=2))

#!/usr/bin/env python3
"""Compare two chronological V8 heap snapshots from the same isolate.

This reports self size, object identity, and shortest strong root paths. It
does not compute retained size or decide whether an object is a leak.
"""

import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "batch-bind-group-cache" / "native"
FILES = (
    SOURCE / "00-before-remounts.heapsnapshot.gz",
    SOURCE / "01-after-remounts.heapsnapshot.gz",
    SOURCE / "02-remount-heap-samples.json.gz",
)
PIXIFILE = HERE / "BitmapFontManager.js.gz"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


class Snapshot:
    def __init__(self, path):
        raw = path.read_bytes()
        self.source = {"path": str(path.relative_to(HERE.parent)), "sha256": sha256(raw)}
        self.data = json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)
        meta = self.data["snapshot"]["meta"]
        self.nf = {key: i for i, key in enumerate(meta["node_fields"])}
        self.ef = {key: i for i, key in enumerate(meta["edge_fields"])}
        self.nw = len(self.nf)
        self.ew = len(self.ef)
        self.ntypes = meta["node_types"][self.nf["type"]]
        self.etypes = meta["edge_types"][self.ef["type"]]
        self.nodes = self.data["nodes"]
        self.edges = self.data["edges"]
        self.strings = self.data["strings"]
        self.count = len(self.nodes) // self.nw
        assert len(self.nodes) % self.nw == 0
        self.starts = [0] * (self.count + 1)
        for i in range(self.count):
            self.starts[i + 1] = self.starts[i] + self.attr(i, "edge_count") * self.ew
        assert self.starts[-1] == len(self.edges)
        self.by_id = {self.attr(i, "id"): i for i in range(self.count)}

    def attr(self, i, key):
        return self.nodes[i * self.nw + self.nf[key]]

    def name(self, i):
        return self.strings[self.attr(i, "name")]

    def kind(self, i):
        return self.ntypes[self.attr(i, "type")]

    def edges_of(self, i):
        for pos in range(self.starts[i], self.starts[i + 1], self.ew):
            kind = self.etypes[self.edges[pos + self.ef["type"]]]
            label = self.edges[pos + self.ef["name_or_index"]]
            label = str(label) if kind in ("element", "hidden") else self.strings[label]
            target_offset = self.edges[pos + self.ef["to_node"]]
            assert target_offset % self.nw == 0
            target = target_offset // self.nw
            assert 0 <= target < self.count
            yield kind, label, target

    def property(self, i, key):
        return next((target for kind, label, target in self.edges_of(i)
                     if kind == "property" and label == key), None)

    def group(self):
        out = collections.defaultdict(lambda: [0, 0])
        for i in range(self.count):
            row = out[(self.kind(i), self.name(i))]
            row[0] += 1
            row[1] += self.attr(i, "self_size")
        return out

    def strong_paths(self):
        parent = [-1] * self.count
        edge = [None] * self.count
        parent[0] = 0
        queue = collections.deque([0])
        while queue:
            i = queue.popleft()
            for kind, label, target in self.edges_of(i):
                if kind == "weak" or parent[target] != -1:
                    continue
                parent[target] = i
                edge[target] = (kind, label)
                queue.append(target)
        return parent, edge

    def path(self, i, parents):
        parent, edge = parents
        steps = []
        while i and parent[i] != -1:
            source = parent[i]
            kind, label = edge[i]
            steps.append({"fromId": self.attr(source, "id"),
                          "from": self.name(source), "edgeType": kind,
                          "edge": label, "toId": self.attr(i, "id"),
                          "to": self.name(i)})
            i = source
        return list(reversed(steps)) if i == 0 else None


def family(before, after, kind, name, paths, samples=1):
    old = {before.attr(i, "id"): i for i in range(before.count)
           if before.kind(i) == kind and before.name(i) == name}
    new = {after.attr(i, "id"): i for i in range(after.count)
           if after.kind(i) == kind and after.name(i) == name}
    stable = old.keys() & new.keys()
    added = sorted((i for ident, i in new.items() if ident not in old),
                   key=lambda i: after.attr(i, "self_size"), reverse=True)
    removed = [i for ident, i in old.items() if ident not in new]
    result = {
        "kind": kind, "name": name,
        "before": {"count": len(old), "selfBytes": sum(before.attr(i, "self_size") for i in old.values())},
        "after": {"count": len(new), "selfBytes": sum(after.attr(i, "self_size") for i in new.values())},
        "stableCount": len(stable),
        "stableSelfDelta": sum(after.attr(new[ident], "self_size") - before.attr(old[ident], "self_size") for ident in stable),
        "newSelfBytes": sum(after.attr(i, "self_size") for i in added),
        "goneSelfBytes": sum(before.attr(i, "self_size") for i in removed),
        "largestNew": [{"id": after.attr(i, "id"), "selfBytes": after.attr(i, "self_size"),
                        "strongRootPath": after.path(i, paths)} for i in added[:samples]],
    }
    return result



def direct_properties(snapshot, i):
    return {label: target for kind, label, target in snapshot.edges_of(i)
            if kind == 'property'}


def shape_candidates(snapshot, required):
    found = []
    for i in range(snapshot.count):
        if snapshot.kind(i) != 'object':
            continue
        props = direct_properties(snapshot, i)
        if required <= props.keys():
            found.append(i)
    return found


def identities(before, after, required):
    a = shape_candidates(before, required)
    b = shape_candidates(after, required)
    old = {before.attr(i, 'id') for i in a}
    new = {after.attr(i, 'id') for i in b}
    return {
        'requiredProperties': sorted(required),
        'before': [{'id': before.attr(i, 'id'), 'name': before.name(i)} for i in a],
        'after': [{'id': after.attr(i, 'id'), 'name': after.name(i)} for i in b],
        'survivingIds': sorted(old & new),
    }


def cache(snapshot):
    out = []
    for owner in shape_candidates(snapshot, {'measureCache'}):
        manager = snapshot.property(owner, 'measureCache')
        if manager is None:
            continue
        props = direct_properties(snapshot, manager)
        if not {'items', 'first', 'last', 'resetTtl'} <= props.keys():
            continue
        items = props['items']
        keys = [(label, target) for kind, label, target in snapshot.edges_of(items)
                if kind == 'property' and label != '__proto__']
        out.append({'ownerId': snapshot.attr(owner, 'id'),
                    'managerId': snapshot.attr(manager, 'id'),
                    'itemsId': snapshot.attr(items, 'id'),
                    'entryCount': len(keys),
                    'sampleKey': keys[0][0] if keys else None,
                    'sampleValueId': snapshot.attr(keys[0][1], 'id') if keys else None})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('before', type=Path)
    ap.add_argument('after', type=Path)
    ap.add_argument('--samples', type=Path)
    args = ap.parse_args()
    global HERE
    HERE = args.before.parent / 'scratch'
    before = Snapshot(args.before)
    after = Snapshot(args.after)
    paths = after.strong_paths()
    g0, g1 = before.group(), after.group()
    biggest = sorted(set(g0) | set(g1), key=lambda k: g1[k][1]-g0[k][1], reverse=True)[:25]
    output = {
        'inputs': [before.source, after.source],
        'snapshots': {'beforeNodes': before.count, 'afterNodes': after.count,
                      'beforeSelfBytes': sum(v[1] for v in g0.values()),
                      'afterSelfBytes': sum(v[1] for v in g1.values())},
        'groups': [{'kind': k[0], 'name': k[1],
                    'beforeCount': g0[k][0], 'afterCount': g1[k][0],
                    'selfDelta': g1[k][1]-g0[k][1]} for k in biggest],
        'shapes': {
            'renderer': identities(before, after,
                                   {'nodeParts', 'armyParts', 'staticData', 'view', 'disposed'}),
            'application': identities(before, after,
                                      {'stage', 'renderer', '_ticker', '_resizeTo'}),
            'textCacheBefore': cache(before),
            'textCacheAfter': cache(after),
        },
    }
    old_sizes = {ident: before.attr(i, 'self_size') for ident, i in before.by_id.items()}
    growing = [(after.attr(i, 'self_size')-old_sizes[ident], i)
               for ident, i in after.by_id.items()
               if ident in old_sizes and after.attr(i, 'self_size') > old_sizes[ident]]
    growing.sort(reverse=True)
    output['largestStableGrowth'] = [
        {'id': after.attr(i, 'id'), 'kind': after.kind(i), 'name': after.name(i),
         'beforeSelfBytes': old_sizes[after.attr(i, 'id')],
         'afterSelfBytes': after.attr(i, 'self_size'), 'delta': delta,
         'shortestStrongRootPath': after.path(i, paths)}
        for delta, i in growing[:12]]
    for group in output['groups'][:12]:
        kind, name = group['kind'], group['name']
        if group['selfDelta'] <= 0:
            continue
        new = [i for i in range(after.count)
               if after.kind(i)==kind and after.name(i)==name
               and after.attr(i, 'id') not in before.by_id]
        new.sort(key=lambda i: after.attr(i, 'self_size'), reverse=True)
        group['largestNew'] = [{'id': after.attr(i, 'id'),
                                'selfBytes': after.attr(i, 'self_size'),
                                'shortestStrongRootPath': after.path(i, paths)}
                               for i in new[:2]]
    if args.samples:
        import gzip
        with gzip.open(args.samples, 'rt') if args.samples.suffix=='.gz' else args.samples.open() as fh:
            raw=json.load(fh)
        vals=raw['usedHeapBytes'] if isinstance(raw, dict) else raw
        output['samples']={'count':len(vals),'first':vals[0],'last':vals[-1],
                           'delta':vals[-1]-vals[0],
                           'last20Delta':vals[-1]-vals[-20]}
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__=='__main__':
    main()

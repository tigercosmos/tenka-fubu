#!/usr/bin/env python3
import collections
import importlib.util
import json
from pathlib import Path

P=Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec=importlib.util.spec_from_file_location('postcap',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE=Path('/tmp/tenka-heap-2d872d7/diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium')

def inspect(path):
 m.HERE=BASE/'scratch';s=m.Snapshot(path);paths=s.strong_paths()
 rows=[]
 for parent in range(s.count):
  if s.kind(parent)!='object':continue
  gpu=s.property(parent,'_gpuData')
  if gpu is None:continue
  vals={int(label):target for kind,label,target in s.edges_of(gpu) if kind=='element'}
  if len(vals)<100:continue
  storage=next((target for kind,label,target in s.edges_of(gpu)
                if kind=='internal' and label=='elements'),None)
  ownpath=s.path(parent,paths)
  rows.append({'parentId':s.attr(parent,'id'),'parentName':s.name(parent),
               'mapId':s.attr(gpu,'id'),'slots':len(vals),'min':min(vals),'max':max(vals),
               'storageBytes':s.attr(storage,'self_size') if storage is not None else None,
               'selected':{str(k):{'id':s.attr(vals[k],'id'),'name':s.name(vals[k]),
                                   'kind':s.kind(vals[k]),'selfBytes':s.attr(vals[k],'self_size')}
                           for k in (0,1,129,130,131,249,250) if k in vals},
               'path':[(x['from'],x['edge'],x['to']) for x in ownpath[-14:]]})
 freq=collections.Counter(row['parentName'] for row in rows)
 return {'path':str(path),'count':len(rows),'names':freq,'rows':rows}

if __name__=='__main__':
 print(json.dumps([inspect(BASE/'after-120-remounts.heapsnapshot'),inspect(BASE/'after-remounts.heapsnapshot')],ensure_ascii=False,indent=2))

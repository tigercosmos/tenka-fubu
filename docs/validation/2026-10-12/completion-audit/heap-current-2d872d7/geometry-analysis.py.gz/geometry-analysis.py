#!/usr/bin/env python3
import collections
import importlib.util
import json
from pathlib import Path

P = Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec = importlib.util.spec_from_file_location('postcap', P)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
BASE = Path('/tmp/tenka-heap-2d872d7/diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium')

def inspect(path):
    m.HERE=BASE/'scratch'
    s=m.Snapshot(path)
    parents=s.strong_paths()
    renderer=m.shape_candidates(s,{'nodeParts','armyParts','staticData','view','disposed'})[0]
    renderer_id=s.attr(renderer,'id')
    by_branch=collections.defaultdict(lambda:[0,0,0])
    details=[]
    for i in range(s.count):
        if s.kind(i)!='array' or s.name(i)!='(object elements)':continue
        route=s.path(i,parents)
        if route is None:continue
        hits=[k for k,p in enumerate(route) if p['fromId']==renderer_id]
        if not hits:continue
        first=route[hits[0]]['edge']
        size=s.attr(i,'self_size')
        by_branch[first][0]+=1;by_branch[first][1]+=size
        by_branch[first][2]+=s.attr(i,'edge_count')
        if size >= 20000:
            details.append({'id':s.attr(i,'id'),'size':size,'branch':first,
                            'tail':[(p['from'],p['edge'],p['to']) for p in route[hits[0]:]]})
    details.sort(key=lambda x:x['size'],reverse=True)
    return {'path':str(path),'rendererId':renderer_id,'total':sum(x[1] for x in by_branch.values()),
            'branches':dict(sorted(by_branch.items(),key=lambda kv:kv[1][1],reverse=True)),
            'largeArrays':details[:60]}

if __name__=='__main__':
    print(json.dumps([inspect(BASE/'after-120-remounts.heapsnapshot'),inspect(BASE/'after-remounts.heapsnapshot')],ensure_ascii=False,indent=2))

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> production screens have no critical axe findings and dialogs preserve one page banner
- Location: e2e/accessibility.spec.ts:34:1

# Error details

```
Error: page.evaluate: Error: __TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）
    at da (http://localhost:4173/assets/index-Bcq0V5fv.js:106:249748)
    at Object.waitMapIdle (http://localhost:4173/assets/index-Bcq0V5fv.js:106:255026)
    at eval (eval at evaluate (:303:30), <anonymous>:3:32)
    at async <anonymous>:329:30
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1560年1月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 2,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 12,000
            - generic "兵糧可支撐26個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "26"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 4,517
            - generic [ref=e44]: /4,662
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "250"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [active] [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic:
    - generic:
      - generic:
        - button:
          - img
  - img "全國小地圖" [ref=e119]
  - button "報告中心" [ref=e122] [cursor=pointer]
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: army-plate-layout.spec.ts >> native army number-plate placement >> actual Sunpu/Narumi plate bounds reduce overlap at three real UI scales without core mutation
- Location: e2e/army-plate-layout.spec.ts:358:3

# Error details

```
Error: Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  101 |           '__TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）'
  102 |       )
  103 |         return false;
  104 |       throw error;
  105 |     }
  106 |   });
  107 | }
  108 | 
  109 | async function boot(page: Page) {
  110 |   await page.addInitScript(() => {
  111 |     type Entry = { stage: string; browserMonotonicMs: number; details: Record<string, unknown> };
  112 |     const records: Entry[] = [];
  113 |     let dropped = 0;
  114 |     const blobUrls = new WeakMap<Blob, string>();
  115 |     const isMapTexture = (url: string) => url.includes('/assets/textures/');
  116 |     const record = (stage: string, details: Record<string, unknown>) => {
  117 |       try {
  118 |         if (records.length < 1024)
  119 |           records.push({ stage, browserMonotonicMs: performance.now(), details });
  120 |         else dropped++;
  121 |       } catch {
  122 |         dropped++;
  123 |       }
  124 |     };
  125 |     (window as Window & {
  126 |       __TENKA_ARMY_BOOT_PROBE__?: boolean;
  127 |       __TENKA_ARMY_BOOT_TRACE__?: {
  128 |         record: typeof record;
  129 |         snapshot: () => { records: Entry[]; dropped: number };
  130 |       };
  131 |     }).__TENKA_ARMY_BOOT_PROBE__ = true;
  132 |     (window as Window & {
  133 |       __TENKA_ARMY_BOOT_TRACE__?: {
  134 |         record: typeof record;
  135 |         snapshot: () => { records: Entry[]; dropped: number };
  136 |       };
  137 |     }).__TENKA_ARMY_BOOT_TRACE__ = {
  138 |       record,
  139 |       snapshot: () => ({ records: [...records], dropped }),
  140 |     };
  141 | 
  142 |     const originalBlob = Response.prototype.blob;
  143 |     Response.prototype.blob = function (this: Response, ...args: unknown[]): Promise<Blob> {
  144 |       const url = this.url;
  145 |       if (!isMapTexture(url)) return Reflect.apply(originalBlob, this, args) as Promise<Blob>;
  146 |       record('blob-start', { url });
  147 |       let promise: Promise<Blob>;
  148 |       try {
  149 |         promise = Reflect.apply(originalBlob, this, args) as Promise<Blob>;
  150 |       } catch (error) {
  151 |         record('blob-sync-error', { url, message: String(error) });
  152 |         throw error;
  153 |       }
  154 |       // Observe settlement on a side chain; the original promise and rejection are unchanged.
  155 |       void promise.then(
  156 |         (blob) => {
  157 |           try {
  158 |             blobUrls.set(blob, url);
  159 |             record('blob-done', { url, bytes: blob.size });
  160 |           } catch { /* diagnostic only */ }
  161 |         },
  162 |         (error: unknown) => {
  163 |           try { record('blob-error', { url, message: String(error) }); } catch { /* diagnostic only */ }
  164 |         },
  165 |       );
  166 |       return promise;
  167 |     };
  168 |     if (typeof window.createImageBitmap === 'function') {
  169 |       const originalBitmap = window.createImageBitmap;
  170 |       window.createImageBitmap = function (this: Window, ...args: unknown[]): Promise<ImageBitmap> {
  171 |         const input = args[0];
  172 |         const url = input instanceof Blob ? blobUrls.get(input) : undefined;
  173 |         if (url === undefined)
  174 |           return Reflect.apply(originalBitmap, this, args) as Promise<ImageBitmap>;
  175 |         record('bitmap-start', { url });
  176 |         let promise: Promise<ImageBitmap>;
  177 |         try {
  178 |           promise = Reflect.apply(originalBitmap, this, args) as Promise<ImageBitmap>;
  179 |         } catch (error) {
  180 |           record('bitmap-sync-error', { url, message: String(error) });
  181 |           throw error;
  182 |         }
  183 |         void promise.then(
  184 |           (bitmap) => {
  185 |             try { record('bitmap-done', { url, width: bitmap.width, height: bitmap.height }); }
  186 |             catch { /* diagnostic only */ }
  187 |           },
  188 |           (error: unknown) => {
  189 |             try { record('bitmap-error', { url, message: String(error) }); }
  190 |             catch { /* diagnostic only */ }
  191 |           },
  192 |         );
  193 |         return promise;
  194 |       } as typeof createImageBitmap;
  195 |     }
  196 |   });
  197 |   await page.goto('/?debug=visual-map');
  198 |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  199 |   await page.evaluate(() => document.fonts.ready);
  200 |   try {
> 201 |     await expect.poll(() => mapIdleOrRetry(page)).toBe(true);
      |                                                   ^ Error: Timeout 5000ms exceeded while waiting on the predicate
  202 |   } finally {
  203 |     // Post-outcome attachment never changes the original five-second predicate.
  204 |     // Capture errors are reported separately and cannot replace the original failure.
  205 |     try {
  206 |       const snapshot = await page.evaluate(() => {
  207 |         const trace = (window as Window & {
  208 |           __TENKA_ARMY_BOOT_TRACE__?: {
  209 |             snapshot: () => { records: unknown[]; dropped: number };
  210 |           };
  211 |         }).__TENKA_ARMY_BOOT_TRACE__?.snapshot();
  212 |         const resources = (performance.getEntriesByType('resource') as PerformanceResourceTiming[])
  213 |           .filter((entry) => entry.name.includes('/assets/textures/'))
  214 |           .map((entry) => ({
  215 |             name: entry.name,
  216 |             startTime: entry.startTime,
  217 |             responseEnd: entry.responseEnd,
  218 |             duration: entry.duration,
  219 |           }));
  220 |         return {
  221 |           browserTimeOrigin: performance.timeOrigin,
  222 |           capturedAt: performance.now(),
  223 |           trace,
  224 |           resources,
  225 |         };
  226 |       });
  227 |       await test.info().attach('army-asset-stages.json', {
  228 |         body: Buffer.from(JSON.stringify(snapshot)),
  229 |         contentType: 'application/json',
  230 |       });
  231 |     } catch (error) {
  232 |       process.stderr.write(`[army-asset-capture-error] ${String(error)}\n`);
  233 |     }
  234 |   }
  235 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  236 | }
  237 | 
  238 | async function setScale(page: Page, scale: 0.8 | 1 | 1.5) {
  239 |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  240 |   await page.getByRole('button', { name: '設定', exact: true }).click();
  241 |   const dialog = page.getByRole('dialog');
  242 |   const slider = dialog.getByRole('slider', { name: '介面縮放', exact: true });
  243 |   await slider.press(scale === 1.5 ? 'End' : 'Home');
  244 |   if (scale === 1) for (let step = 0; step < 4; step++) await slider.press('ArrowRight');
  245 |   await expect(slider).toHaveValue(String(scale));
  246 |   await expect
  247 |     .poll(() => page.evaluate(() => getComputedStyle(document.documentElement).fontSize))
  248 |     .toBe(`${16 * scale}px`);
  249 |   await dialog.getByRole('button', { name: '返回', exact: true }).click();
  250 |   await page.getByRole('button', { name: '回到遊戲', exact: true }).click();
  251 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  252 | }
  253 | 
  254 | async function nearCastle(page: Page, id: 'castle.sunpu' | 'castle.narumi') {
  255 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.setMapCameraPreset('close'));
  256 |   if (id === 'castle.narumi') {
  257 |     const position = await page.evaluate(() => {
  258 |       const game = (window as DebugWindow).__tenka.debug.getState();
  259 |       return Object.values(game.castles).find((castle) => castle.id === 'castle.narumi')!.pos;
  260 |     });
  261 |     const mini = page.getByTestId('minimap-frame');
  262 |     const box = await mini.boundingBox();
  263 |     expect(box).not.toBeNull();
  264 |     await mini.click({
  265 |       position: { x: (position.x / 4096) * box!.width, y: (position.y / 4096) * box!.height },
  266 |     });
  267 |   }
  268 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.waitMapIdle(3));
  269 | }
  270 | 
  271 | test.describe('native army number-plate placement', () => {
  272 |   test.use({
  273 |     viewport: { width: 1280, height: 720 },
  274 |     deviceScaleFactor: 1,
  275 |     contextOptions: { reducedMotion: 'reduce' },
  276 |   });
  277 | 
  278 |   test('boot retries only the documented unmounted renderer error', async ({ page }) => {
  279 |     await page.goto('about:blank');
  280 |     await page.evaluate(() => {
  281 |       Object.assign(window, { __idleCalls: 0 });
  282 |       Object.defineProperty(window, '__tenka', {
  283 |         configurable: true,
  284 |         value: {
  285 |           debug: {
  286 |             waitMapIdle() {
  287 |               const state = window as unknown as { __idleCalls: number };
  288 |               if (++state.__idleCalls === 1)
  289 |                 return Promise.reject(new Error('unexpected idle failure'));
  290 |               return Promise.resolve();
  291 |             },
  292 |           },
  293 |         },
  294 |       });
  295 |     });
  296 |     await expect(expect.poll(() => mapIdleOrRetry(page)).toBe(true)).rejects.toThrow(
  297 |       'unexpected idle failure',
  298 |     );
  299 |     expect(
  300 |       await page.evaluate(() => (window as unknown as { __idleCalls: number }).__idleCalls),
  301 |     ).toBe(1);
```
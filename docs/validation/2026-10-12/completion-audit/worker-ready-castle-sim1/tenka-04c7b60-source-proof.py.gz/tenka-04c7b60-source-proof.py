import pathlib,gzip,json,hashlib,sys
root=pathlib.Path('/tmp/tenka-04c7b60-worker-ready-sim1');out=pathlib.Path('/tmp/tenka-04c7b60-worker-ready-evidence')
manifest=json.loads(gzip.decompress((out/'source-manifest.json.gz').read_bytes()));bad=[]
for row in manifest['files']:
 p=root/row['path']
 if not p.is_file():bad.append({'path':row['path'],'reason':'missing'});continue
 b=p.read_bytes()
 if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:bad.append({'path':row['path'],'reason':'hash mismatch'})
proof={'commit':manifest['commit'],'phase':sys.argv[1],'checkedFiles':len(manifest['files']),'mismatches':bad}
(out/('source-verification-'+sys.argv[1]+'.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof));assert not bad

import pathlib,re,base64,zipfile,io,json,hashlib,gzip
p=pathlib.Path('/tmp/tenka-04c7b60-worker-ready-evidence');report=p/'original-playwright-report'
s=(report/'index.html').read_text();m=re.search(r'data:application/zip;base64,([A-Za-z0-9+/=\s]+)</template>',s);assert m
raw=base64.b64decode(m[1]);(p/'report-metadata.zip').write_bytes(raw)
rows=[]
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 for name in z.namelist():
  data=z.read(name);(p/('report-'+pathlib.Path(name).name)).write_bytes(data)
  if not name.endswith('.json'):continue
  obj=json.loads(data)
  for test in obj.get('tests',[]):
   for result in test['results']:
    row={'title':test['title'],'status':result['status'],'durationMs':result.get('duration'),'attachments':[]}
    for attachment in result.get('attachments',[]):
     if attachment.get('contentType')!='application/json':continue
     a=(report/attachment['path']).read_bytes() if attachment.get('path') else attachment['body'].encode()
     dest=attachment['name']+'.json';(p/dest).write_bytes(a);row['attachments'].append({'name':dest,'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest()})
    rows.append(row)
(p/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n')
traces=[]
for file in (p/'original-test-results').rglob('trace.zip'):
 raw=file.read_bytes();row={'path':str(file.relative_to(p)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};traces.append(row)
 prefix='failure-'+str(len(traces))
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  row['entries']=[{'path':info.filename,'bytes':info.file_size}for info in z.infolist()]
  for name in z.namelist():
   if name.endswith(('.trace','.network','.stacks')):(p/(prefix+'-'+pathlib.Path(name).name)).write_bytes(z.read(name))
(p/'failure-traces.json').write_text(json.dumps(traces,indent=2)+'\n')
print(json.dumps({'tests':rows,'failureTraces':len(traces)}))

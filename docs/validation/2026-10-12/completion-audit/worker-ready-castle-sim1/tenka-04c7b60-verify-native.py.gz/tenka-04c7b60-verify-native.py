import pathlib,json
p=pathlib.Path('/tmp/tenka-04c7b60-worker-ready-evidence')
load=lambda name:json.loads((p/(name+'.json')).read_text())
results=load('native-results');assert len(results)==6 and all(r['status']=='passed'for r in results)
assert (p/'native-exit-code.txt').read_text().strip()=='0'
for phase in ['before-build','after-native']:
 s=load('source-verification-'+phase);assert s['checkedFiles']==3068 and not s['mismatches']
first=load('worker-full-world-reference');assert first['actual']==first['reference']['state'] and first['actualLog']==first['reference']['log']
d=first['simulation'];assert d['wasmLoaded'] and d['workerReady'] and d['wasmBackend']=='rust-wasm' and d['pendingTicks']==0 and d['completedWorkerTicks']>=first['days']
assert any(r['status']==200 for r in first['wasmResponses'])
for name,key in [('worker-pending-save-reload-reference','actualLog'),('native-worker-cancel-generation-parity','log')]:
 o=load(name);assert o['actual']==o['reference']['state'] and o[key]==o['reference']['log']
cancel=load('native-worker-cancel-generation-parity')['cancelled'];assert cancel['posted']['pendingTicks']==1 and cancel['after']['pendingTicks']==0
assert cancel['after']['generation']>cancel['before']['generation'] and cancel['after']['completedWorkerTicks']==cancel['before']['completedWorkerTicks']
assert cancel['after']['wasmLoaded'] and cancel['after']['workerReady']
measured=[]
for name,day in [('same-host-60-day-worker-responsiveness',61),('same-host-120-day-worker-responsiveness',121),('normal-x5-worker-paced-sync-responsiveness',30)]:
 o=load(name);assert o['states'][0]==o['states'][1] and o['logs'][0]==o['logs'][1]
 assert all(state['time']['day']==day for state in o['states'])
 rows=[]
 for row in o['rows']:
  r={'backend':row['backend']}
  if 'warm'in row:
   for part in ['cold','warm']:
    m=row[part];r[part]={'requestedDays':m['requestedDays'],'completedDays':m['completedDays'],'durationMs':m['durationMs'],'worstLongTaskMs':max([a['duration']for a in m['longTasks']],default=0),'worstRafGapMs':max(m['frameGapsMs'],default=0)}
  else:
   r.update({k:row[k]for k in ['requestedDays','completedDays','durationMs']})
   r['worstLongTaskMs']=max([a['duration']for a in row['longTasks']],default=0);r['worstRafGapMs']=max(row['frameGapsMs'],default=0)
  traffic=row.get('traffic',{})
  for message in traffic.get('received',[]):assert not message.get('inconsistentThreatTotals',[])
  if traffic:r['trafficCounts']={'created':traffic['created'],'initialize':sum(m['kind']=='initialize'for m in traffic['sent']),'ticksSent':sum(m['kind']=='tick'for m in traffic['sent']),'readyReceived':sum(m['kind']=='ready'for m in traffic['received']),'completed':sum(m['kind']=='complete'for m in traffic['received'])}
  rows.append(r)
 measured.append({'attachment':name,'finalDay':day,'rows':rows})
summary={'source':'04c7b6083df32cc9c1a20d693ef45eddb806ed14','cases':results,'firstDay':first['actual']['time']['day'],'firstDiagnostics':d,'firstTrafficCounts':{'created':first['traffic']['created'],'initialize':sum(m['kind']=='initialize'for m in first['traffic']['sent']),'readyReceived':sum(m['kind']=='ready'for m in first['traffic']['received']),'completed':sum(m['kind']=='complete'for m in first['traffic']['received'])},'cancel':cancel,'measurements':measured,'limitations':['single suite; six functional native tests, not map FPS or whole-heap acceptance','normal x5 requested60 but naturally paused after29 additional days atday30','cold row is first measured day after native startup, not entire WASM startup latency']}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS: six full states/logs, current generation readiness, exact source hashes')

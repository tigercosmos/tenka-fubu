vi.mock('pixi.js', () => ({}));
// vi.mock('@ui/map/wasmGeographicScorer', () => ({}));

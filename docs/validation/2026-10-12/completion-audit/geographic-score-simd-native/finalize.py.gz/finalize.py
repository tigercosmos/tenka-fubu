import pathlib,json,hashlib,shutil
r=pathlib.Path('/tmp/tenka-simd-native-current23-20261012');o=pathlib.Path('/tmp/tenka-simd-native-current23-evidence');h=lambda b:hashlib.sha256(b).hexdigest()
files={'published-setup-recovery2.log':'/tmp/tenka-simd-native-current23-published-setup-recovery2.log','native-six.log':'/tmp/tenka-simd-native-current23-native-six.log','observer.mjs':str(r/'national120-published.mjs'),'native-six.spec.ts':str(r/'e2e/worker-simulation.spec.ts'),'native-six-full-snapshot-transport.ts':str(r/'e2e/full-snapshot-transport.ts'),'simd.wasm':str(r/'public/wasm/tenka_engine.simd.wasm'),'selected-wasm-url-bytes.json':'/tmp/tenka-simd-native-current23-published-wasm-responses.json','observer-repair.py':'/tmp/simd-native-observer-repair.py','resume-after-setup-repair.py':'/tmp/simd-native-resume-after-setup-repair.py','campaign.py':'/tmp/tenka-simd-native-templates/campaign.py','fps-driver.py':'/tmp/sim3-simd-native-run-controls.py','setup.py':'/tmp/sim3-simd-native-current23-setup.py','collect.py':'/tmp/sim3-simd-native-current23-collect.py','state-proof.py':'/tmp/sim3-simd-native-current23-state-proof.py','setup.log':'/tmp/tenka-simd-native-current23-setup.log'}
for n,p in files.items():shutil.copyfile(p,o/n)
for p in pathlib.Path('/tmp').glob('tenka-simd-native-current23-gpu-*.json'):shutil.copyfile(p,o/p.name.replace('tenka-simd-native-current23-',''))
# Preserve every unique native-six raw JSON; duplicate attachment locations retain exact hashes and aliases.
rows=[];seen={}
for p in pathlib.Path('/tmp/tenka-simd-native-current23-native-six-results').rglob('*'):
 if not p.is_file():continue
 b=p.read_bytes();sha=h(b)
 if sha not in seen:
  name='native-six-'+p.name;seen[sha]=name;shutil.copyfile(p,o/name)
 rows.append({'originalPath':str(p),'artifact':seen[sha],'bytes':len(b),'sha256':sha})
(o/'native-six-raw-manifest.json').write_text(json.dumps(rows,indent=2))
source=['src/ui/map/geographicLabelLayout.ts','src/ui/map/wasmGeographicPreparation.ts','src/ui/map/wasmGeographicScorer.ts','src/ui/map/MapRenderer.ts','rust/engine/src/geographic_preparation.rs','rust/engine/src/lib.rs','tools/wasm/artifact.ts','tools/wasm/build.ts']
for n in source:shutil.copyfile(r/n,o/n.replace('/','__'))
env=json.load(open('/tmp/tenka-prep-current23-evidence/environment.json'));env['replica']=str(r);env['sourceCommit']='f898ac94fe98c317edb7c2cafdf1831fa4528059';env['driverHashes']=[]
for p in [r/'playwright.config.ts',r/'e2e/fixtures.ts',r/'e2e/national120-map-perf.spec.ts',r/'e2e/worker-simulation.spec.ts',r/'national120-published.mjs',pathlib.Path('/home/anchi/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome')]:
 b=p.read_bytes();env['driverHashes'].append({'path':str(p),'bytes':len(b),'sha256':h(b)})
(o/'environment.json').write_text(json.dumps(env,indent=2));shutil.copyfile('/tmp/tenka-prep-current23-evidence/gpu-driver-hashes.json',o/'gpu-driver-hashes.json')
t=pathlib.Path('/tmp/sim3-simd-native-current23-source.tar.gz');(o/'transfer-proof.json').write_text(json.dumps({'path':str(t),'bytes':t.stat().st_size,'sha256':h(t.read_bytes()),'sourceFiles':1528,'frozenCommit':'f898ac94fe98c317edb7c2cafdf1831fa4528059','scope':'all frozen src/public/rust/tools/tests/e2e +13rootcode/config; actual externaldrivers stored separately'},indent=2));print(len(list(o.iterdir())))

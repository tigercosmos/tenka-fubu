import pathlib,json,gzip,hashlib
r=pathlib.Path('/tmp/tenka-simd-native-local/tenka-simd-native-current23-evidence');o=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-score-simd-native');o.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest();base=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-preparation-native')
def read(n):return json.loads((r/n).read_text())
def baseline(n):return json.loads(gzip.decompress((base/(n+'.gz')).read_bytes()))
fps=[]
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');m=q['measurement'];b=baseline(c+'.raw.json')['measurement'];fps.append(dict(camera=c,environment=q['environment'],**{k:m[k] for k in ['averageFps','slowFrameFps','frameTimeP95','durationMs','frames','completedFrames','minVisibleArmies','minMountedArmies','lodStage']},terminalExit=next(x['terminalExit'] for x in read('fps-driver-status.json') if x['camera']==c),strict60Pass=False,baselineAverageFps=b['averageFps'],baselineFrameTimeP95=b['frameTimeP95'],observedVsFeabAveragePercent=(m['averageFps']/b['averageFps']-1)*100))
module=lambda n:dict(bytes=len((r/n).read_bytes()),sha256=h((r/n).read_bytes()))
s=dict(scope='Frozen f898 automatic-SIMD-default campaign only; not acceptance of a later scalar default',frozenRuntimeCommit='f898ac94fe98c317edb7c2cafdf1831fa4528059',retentionDecision='withdraw automatic SIMD production default; retain dual-artifact foundation and explicit SIMD availability',reason='No observed overall benefit: overview−0.161%, operational+0.051%, close−3.556%; all original strict60 controls RED',baselineEvidenceCommit='44c3b30',baselineRuntimeCommit='feab20cc9c207f37afae7a2f372c437b93232a07',sourceFiles=1528,dependencyFiles=14765,pixiPatchTargets=23,sourceScope='all frozen src/public/rust/tools/tests/e2e and13rootcode/config; copied public files; only original current23 node_modules shared',scalar=module('tenka_engine.wasm'),simd=module('simd.wasm'),functionalParity=read('parity-proof.json'),fps=fps,nativeSix=dict(terminalExit=0,passed=6,reportedDurationSeconds=42.7,scope='original native Worker fullstate/log/save/reload/cancel/x5 and60/120daycoldwarm; not ordinaryFPS',source='native-six.spec.ts.gz',rawManifest='native-six-raw-manifest.json.gz'),cpuProfile=dict(executed=False,reason='Not authorized after outcome; no new profile requested'),setupRecovery=dict(attempt1='Original observer externalbodycollector CDP Network.getResponseBody RED; no completed9payload/noFPS/native6 before recovery',attempt2='Authorized setup instrumentation recovery; original nine finished once, payload/assertions/exclusions unchanged; actualbodyerrors caught and separate served-byte proof honestly labeled',originalStatus='campaign-attempt1-original-status.json.gz',recoveryStatus='campaign-setup-recovery2-status.json.gz',repair='setup-observer-repair.json.gz'),selectedWasmProof=read('selected-wasm-url-bytes.json'),stateResourceProof=read('state-resource-proof.json'),allJobsTerminal=True,noRetriesOfFPSOrNativeSix=True,limitations=['Single unreplicated same-cohort FPS windows; no broad causal or repeatability claim.','Nine functional observation attempts are2 because firstinstrumentationRED; this is explicit setup recovery, not an all-first-attempt claim.','Bodyunavailable rows prove onlyrequestedURL; separatelyServed hashes are separateHTTPfetches, not originalbody captures.','Later production default policy/source differs; these FPS results do not measure that future scalar default.'])
ver='''import pathlib,json,gzip,hashlib,sys
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):return gzip.decompress((p/(n+'.gz')).read_bytes())
def read(n):return json.loads(raw(n))
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
for stage in ['before','after','final']:
 q=read('source-'+stage+'-proof.json');assert q['commit']=='f898ac94fe98c317edb7c2cafdf1831fa4528059' and q['allMatch'] and len(q['files'])==1528 and not q['extras'] and not q['publicSymlinks'];assert all(x['match'] and x['sha256']==x['actualSHA256'] for x in q['files'])
 q=read('dependency-'+stage+'-proof.json');assert len(q['files'])==14765 and len(q['patches'])==23 and all(x['match'] for x in q['files']+q['patches'])
assert h(raw('published.raw.json'))=='af4ddbc9c9232041f23b3cd37fdb802681d1ffce7a4709eaa7dc5031f6cebe29';assert read('parity-proof.json')['excludedNonvisualCounters']==['armyPlateLayout.runs','geographicLabelLayout.runs','geographicLabelLayout.placementCache','castleRibbonLayout.runs']
assert h(raw('tenka_engine.wasm'))=='57b04ba8b63eb8af3a7a25742e676e0c2bd53eaeece7df40c85c5bd0862b189e';assert h(raw('simd.wasm'))=='0edab970302a9439995d634f2dd0c2b018651473a227b3ff9efc309b1974b38a'
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');assert 'RTX 5070 Ti' in q['environment']['renderer'] and 'Vulkan' in q['environment']['renderer'];assert q['measurement']['resourcesBefore']==q['measurement']['resourcesAfter'];assert '1 failed' in raw(c+'.log').decode()
for q in read('state-resource-proof.json'):assert q['canonicalByteEqual'] and q['resourceObjectsEqual'] and q['canonicalBeforeSha256']==q['canonicalAfterSha256']
for n in ['gpu-before','gpu-after-functional']:
 q=next(x for x in read(n+'.json') if x['context']);assert 'RTX 5070 Ti' in q['renderer'] and 'Vulkan' in q['renderer'] and not q['contextLost']
first=read('campaign-attempt1-original-status.json');assert first[-1]['stage']=='published' and first[-1]['terminalExit']==1 and 'Network.getResponseBody' in raw('published-attempt1-original-red.log').decode()
recover=read('campaign-setup-recovery2-status.json');assert all(x['terminalExit']==0 for x in recover);assert recover[0]['stage']=='published-setup-recovery2';assert '6 passed (42.7s)' in raw('native-six.log').decode()
for a in read('native-six-raw-manifest.json'):assert len(raw(a['artifact']))==a['bytes'] and h(raw(a['artifact']))==a['sha256']
q=read('selected-wasm-url-bytes.json');assert q['observed'] and all(x['url'].endswith('/tenka_engine.simd.wasm') for x in q['observed']);assert any('bodyError' in x for x in q['observed']);assert any(x.get('sha256')==s['simd']['sha256'] for x in q['observed']);assert all(x['sha256']==s['simd']['sha256'] and x['bytes']==s['simd']['bytes'] and 'separately served' in x['proof'] for x in q['separatelyServed']);assert s['cpuProfile']['executed']==False
print('PASS: all dualSHA/source/dependency checkpoints; full9af4; original3strictRED; native6PASS; actualSIMDURL/body/served proof; exactstate/resources; preservedcollectorRED/recovery; no profile or futuredefaultFPSclaim')
'''
(r/'verify-evidence.py').write_text(ver);(r/'package-producer.py').write_bytes(pathlib.Path(__file__).read_bytes());s['artifacts']=[]
for f in sorted(r.iterdir()):
 if not f.is_file():continue
 b=f.read_bytes();z=gzip.compress(b,mtime=0);name=f.name+'.gz';(o/name).write_bytes(z);s['artifacts'].append(dict(path=name,rawBytes=len(b),rawSHA256=h(b),gzipBytes=len(z),gzipSHA256=h(z),originalRemotePath='/tmp/tenka-simd-native-current23-evidence/'+f.name))
(o/'summary.json').write_text(json.dumps(s,indent=2)+'\n');(o/'README.md').write_text('''# Frozen automatic SIMD native campaign

This evidence measures only runtime f898ac94fe98c317edb7c2cafdf1831fa4528059 on sim3, with the original current23 cohort: 14,765 dependency files and 23 installed patches unchanged at three checkpoints. All 1,528 frozen source/config/fixture/public files match; public files are copied. Scalar 88,536 bytes/57b04ba8… and SIMD 88,392 bytes/0edab970… match the freeze. The observed URL was tenka_engine.simd.wasm: four original response-body hashes matched, one body-unavailable error is retained, and a separate served-byte fetch also matched (explicitly labeled separately).

Nine complete settled published payloads match af4ddbc9… byte for byte, retaining only the original four nonvisual counter exclusions. The first observer attempt failed in new external body collection before completing its payload; the original RED/script/status remain. Authorized attempt2 corrected instrumentation only, caught unavailable-body errors, and completed the original nine unchanged. FPS and Worker tests had not started before this repair.

| Camera | FPS | feab baseline | Change | p95 ms | Strict60 |
|---|---:|---:|---:|---:|---|
'''+''.join(f"| {x['camera']} | {x['averageFps']:.4f} | {x['baselineAverageFps']:.4f} | {x['observedVsFeabAveragePercent']:+.3f}% | {x['frameTimeP95']:.3f} | RED |\n" for x in fps)+'''
Original 120-army 1920×1080 controls ran once each for30seconds, sequentially, without retries or threshold changes; all actual RTX5070Ti Vulkan guards passed. Canonical state and renderer resources are identical before/after. No baseline rerun occurred. These single windows show no overall benefit; automatic SIMD production default was withdrawn while the dual-artifact foundation and explicit SIMD remain available. These results do not measure or accept a later scalar-default policy/runtime.

The original six native Worker tests then ran once sequentially: six passed in42.7seconds, including actual60/120daycold+warm, complete state/log, save/reload, cancel-generation and paced×5 controls. Their unique full raw JSON files are retained; duplicate attachment paths have byte hashes and aliases. No CPUprofile ran. All jobs ended and final source/dependency proofs passed.

Every raw artifact retains its bytes under gzip with raw/compressed SHA256 and byte counts. Decompress verify-evidence.py.gz and run it with this package path to verify all hashes, frozen source/dependencies, full payload, actual artifact/URL proofs, original REDs, Worker results and state/resources. Original source and runtime were not edited by collection.
''');print(len(s['artifacts']),sum(x['gzipBytes'] for x in s['artifacts']))

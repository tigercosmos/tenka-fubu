import pathlib,shutil,json,hashlib,os,signal
r=pathlib.Path('/tmp/tenka-simd-native-current23-20261012');o=pathlib.Path('/tmp/tenka-simd-native-current23-evidence');p=r/'national120-published.mjs';s=p.read_text();(o/'published-observer-attempt1.mjs').write_bytes(p.read_bytes());shutil.copyfile('/tmp/tenka-simd-native-current23-published.log',o/'published-attempt1-original-red.log');shutil.copyfile(o/'campaign-status.json',o/'campaign-attempt1-original-status.json')
old="const bytes=await response.body();wasmResponses.push({url:response.url(),status:response.status(),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});"
new="try{const bytes=await response.body();wasmResponses.push({url:response.url(),status:response.status(),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),proof:'actual response.body bytes'});}catch(error){wasmResponses.push({url:response.url(),status:response.status(),bodyError:String(error),proof:'observed requested URL; actual response body unavailable'});}"
assert s.count(old)==1;s=s.replace(old,new)
old=" await Promise.all(wasmPending);writeFileSync('/tmp/tenka-simd-native-current23-published-wasm-responses.json',JSON.stringify(wasmResponses));"
new=""" await Promise.all(wasmPending);
 const separatelyServed=[];for(const url of [...new Set(wasmResponses.map(r=>r.url))]){const response=await fetch(url);const bytes=Buffer.from(await response.arrayBuffer());separatelyServed.push({url,status:response.status,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),proof:'observed requested URL + separately served frozen bytes; not original response body'});}
 writeFileSync('/tmp/tenka-simd-native-current23-published-wasm-responses.json',JSON.stringify({scope:'setup recovery2; requested URLs observed by page; separately fetched served byte hashes outside CPU/FPS windows',observed:wasmResponses,separatelyServed}));"""
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s);(o/'published-observer-attempt2-setup-recovery.mjs').write_bytes(p.read_bytes())
# Clean only an orphaned preview process whose exact cwd is this owned fork.
killed=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if (proc/'cwd').resolve()!=r:continue
  args=(proc/'cmdline').read_bytes().replace(b'\0',b' ')
  if b'vite' in args and b'preview' in args and b'4173' in args:
   os.kill(int(proc.name),signal.SIGTERM);killed.append({'pid':int(proc.name),'cmdline':args.decode(errors='replace')})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
(o/'setup-observer-repair.json').write_text(json.dumps({'scope':'authorized setup instrumentation repair; original0FPS/0native6 before repair','frozenRuntimeUntouched':True,'originalNinePayloadAssertionsUnchanged':True,'attempt1ObserverSHA256':hashlib.sha256((o/'published-observer-attempt1.mjs').read_bytes()).hexdigest(),'attempt2ObserverSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'bodyCapturePolicy':'catch CDPbodyerror; record requestedURL and independentlyserved bytes honestly','killedOwnedPreviewProcesses':killed},indent=2));print('Setup collector repaired; original RED preserved; no measurements repeated')

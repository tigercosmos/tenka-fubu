import pathlib,tarfile,shutil,hashlib
r=pathlib.Path('/tmp/tenka-simd-native-current23-20261012');assert not r.exists();r.mkdir()
with tarfile.open('/tmp/sim3-simd-native-current23-source.tar.gz') as t:t.extractall(r,filter='data')
(r/'node_modules').symlink_to('/tmp/tenka-national120-current23-20261012/node_modules')
for a,b in [('national120-published.mjs','national120-published.mjs'),('simd-native-current23-profile.mjs','simd-native-current23-profile.mjs'),('simd-native-current23-profile-analysis.mjs','simd-native-current23-profile-analysis.mjs'),('sim3-simd-native-profile-attribution.mjs','profile-attribution.mjs')]:shutil.copyfile('/tmp/tenka-simd-native-templates/'+a,r/b)
assert hashlib.sha256((r/'e2e/national120-map-perf.spec.ts').read_bytes()).hexdigest()=='2d39ba643aa3c0aa7a242d0e93d081806fe54bd64b650f1ab78cbf67d4f567e4'
import json
m=json.loads(pathlib.Path('/tmp/sim3-simd-native-current23-expected.json').read_text())
assert m['commit']=='f898ac94fe98c317edb7c2cafdf1831fa4528059'
for name,sha,size in [('tenka_engine.wasm','57b04ba8b63eb8af3a7a25742e676e0c2bd53eaeece7df40c85c5bd0862b189e',88536),('tenka_engine.simd.wasm','0edab970302a9439995d634f2dd0c2b018651473a227b3ff9efc309b1974b38a',88392)]:
 b=(r/'public/wasm'/name).read_bytes();assert len(b)==size and hashlib.sha256(b).hexdigest()==sha
artifacts=[f for f in m['files'] if f['path'].startswith('public/wasm/')]
for f in artifacts:
 b=(r/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print('Fresh full frozen source/public/fixtures, original FPS spec and actual scalar/SIMD/manifest hashes PASS')

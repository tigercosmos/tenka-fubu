import { chromium } from '@playwright/test';
import { createHash } from 'node:crypto';
import { openSync, closeSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';

const output = process.argv[2];
if (!output) throw new Error('Exclusive output directory required');
const hash = (value) => createHash('sha256').update(value).digest('hex');
const previewLog = openSync(`${output}/preview.stdout-stderr.log`, 'wx');
const preview = spawn(process.execPath,
  ['node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', '4173'],
  { stdio: ['ignore', previewLog, previewLog] });
closeSync(previewLog);
let browser;
try {
  let ready = false;
  for (let i = 0; i < 100; i++) {
    try {
      ready = (await fetch('http://127.0.0.1:4173')).ok;
      if (ready) break;
    } catch { /* server starting */ }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!ready) throw new Error('Preview did not start');
  browser = await chromium.launch({ channel: 'chromium', headless: true,
    args: ['--enable-gpu', '--use-angle=vulkan'] });
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 },
    reducedMotion: 'no-preference' });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4173/?debug=1&seed=15600519');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await page.getByTestId('screen-daimyo-select').waitFor();
  await page.getByTestId('daimyo-next').click();
  await page.getByTestId('screen-difficulty-select').waitFor();
  if (!(await page.getByRole('radio', { name: '中級', exact: true }).isChecked()))
    throw new Error('Default difficulty changed');
  await page.getByTestId('difficulty-next').click();
  await page.getByTestId('screen-seed-select').waitFor();
  if ((await page.getByTestId('newgame-seed').getAttribute('aria-invalid')) !== 'false')
    throw new Error('Default seed invalid');
  await page.getByTestId('newgame-start').click();
  await page.getByTestId('screen-strategy').waitFor();
  await page.getByTestId('speed-pause').click();
  const preparation = await page.evaluate(() => window.__tenka.debug.prepareLiveNationalMapWorkload(120));
  if (preparation.count !== 120 || preparation.commands !== 120)
    throw new Error('Canonical fixture count changed');
  await page.evaluate(async () => {
    await document.fonts.ready;
    await window.__tenka.debug.setMapCameraPreset('close');
    await window.__tenka.debug.waitMapIdle(3);
  });
  const gpu = async () => page.evaluate(() => {
    const canvas = document.querySelector('canvas');
    const gl = canvas?.getContext('webgl2') ?? canvas?.getContext('webgl');
    if (!(gl instanceof WebGLRenderingContext || gl instanceof WebGL2RenderingContext))
      throw new Error('Actual WebGL required');
    const extension = gl.getExtension('WEBGL_debug_renderer_info');
    return { contextLost: gl.isContextLost(),
      renderer: String(gl.getParameter(extension ? extension.UNMASKED_RENDERER_WEBGL : gl.RENDERER)),
      vendor: String(gl.getParameter(extension ? extension.UNMASKED_VENDOR_WEBGL : gl.VENDOR)) };
  });
  const gpuBefore = await gpu();
  if (gpuBefore.contextLost || !gpuBefore.renderer.includes('RTX 5070 Ti') ||
      !gpuBefore.renderer.includes('Vulkan')) throw new Error('Original GPU guard failed');
  const before = await page.evaluate(() => ({
    state: JSON.stringify(window.__tenka.debug.getState()),
    commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
    resources: window.__tenka.debug.getMapDiagnostics().resources,
  }));
  const client = await context.newCDPSession(page);
  await client.send('Profiler.enable');
  await client.send('Profiler.setSamplingInterval', { interval: 1000 });
  await client.send('Profiler.start');
  const measurement = await page.evaluate(() => window.__tenka.debug.measureNationalMapFrames('close', 10_000));
  const { profile } = await client.send('Profiler.stop');
  const gpuAfter = await gpu();
  const after = await page.evaluate(() => ({
    state: JSON.stringify(window.__tenka.debug.getState()),
    commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
    resources: window.__tenka.debug.getMapDiagnostics().resources,
  }));
  const driver = await page.evaluate(() => window.__tenka.debug.getLiveNationalMapWorkload());
  writeFileSync(`${output}/close.cpuprofile`, JSON.stringify(profile), { flag: 'wx' });
  writeFileSync(`${output}/summary.json`, JSON.stringify({
    scope: 'separate10secondCPUProfile/notAcceptanceFPS', preparation, driver,
    gpuBefore, gpuAfter, before: { stateSha256: hash(before.state), commandsSha256: hash(before.commands), resources: before.resources },
    after: { stateSha256: hash(after.state), commandsSha256: hash(after.commands), resources: after.resources },
    equal: { state: before.state === after.state, commands: before.commands === after.commands,
      resources: JSON.stringify(before.resources) === JSON.stringify(after.resources) }, measurement,
    profile: { nodes: profile.nodes.length, samples: profile.samples.length },
  }, null, 2), { flag: 'wx' });
  if (gpuAfter.contextLost || !gpuAfter.renderer.includes('RTX 5070 Ti') ||
      !gpuAfter.renderer.includes('Vulkan') || before.state !== after.state ||
      before.commands !== after.commands ||
      JSON.stringify(before.resources) !== JSON.stringify(after.resources) || driver.ticks !== 0)
    throw new Error('Profile control invariant failed');
  console.log(JSON.stringify({ samples: profile.samples.length, nodes: profile.nodes.length,
    stateEqual: true, commandsEqual: true, resourcesEqual: true, driverTicks: driver.ticks }));
} finally {
  await browser?.close();
  preview.kill('SIGTERM');
}

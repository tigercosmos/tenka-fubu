#!/usr/bin/env bash
set -euo pipefail
MODE=$1
RUN_DIR=$2
RUNTIME=/tmp/tenka-castle-955-clean-c1
NODE_BIN=/home/anchi/.nvm/versions/node/v25.9.0/bin
BROWSERS=/tmp/tenka-20261012-sim2-browser/runtime/browsers
[[ -x "$NODE_BIN/node" && -x "$BROWSERS/chromium-1228/chrome-linux64/chrome" && -x "$RUNTIME/node_modules/.bin/playwright" ]]
export PATH="$NODE_BIN:/usr/local/bin:/usr/bin:/bin"
export PLAYWRIGHT_BROWSERS_PATH="$BROWSERS"
export VISUAL_GPU=1
export VISUAL_PERF=1
export CI=1
FILE='e2e/national120-map-perf\.spec\.ts$'
TITLE='close: 120 canonical armies and actual postrender cadence'
if [[ "$MODE" == list ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium --grep "$TITLE" --list
fi
if [[ "$MODE" == native ]]; then
  exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir "$RUN_DIR" --cwd "$RUNTIME" --browser -- \
    "$RUNTIME/node_modules/.bin/playwright" test "$FILE" --config playwright.config.ts --project=chromium --grep "$TITLE"
fi
exit 2

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: national120-map-perf.spec.ts >> national120 canonical-army renderer prerequisite (not live ×5 acceptance) >> close: 120 canonical armies and actual postrender cadence
- Location: e2e/national120-map-perf.spec.ts:8:5

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 60
Received:    33.23673940610271
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]:
          - strong [ref=e14]: 織田家
        - time [ref=e15]: 1560年1月1日
        - generic [ref=e16]:
          - generic [ref=e17]:
            - img [ref=e18]
            - generic [ref=e21]: 金錢
          - strong [ref=e24]: 2,000
        - generic [ref=e25]:
          - generic [ref=e26]:
            - img [ref=e27]
            - generic [ref=e29]: 兵糧
          - generic [ref=e30]:
            - strong [ref=e32]: 12,000
            - generic "兵糧可支撐26個月" [ref=e33]:
              - text: 兵糧可支撐
              - strong [ref=e34]: "26"
              - text: 個月
        - generic [ref=e35]:
          - generic [ref=e36]:
            - img [ref=e37]
            - generic [ref=e41]: 兵力
          - generic [ref=e43]:
            - strong [ref=e44]: 4,517
            - generic [ref=e45]: /4,662
        - generic [ref=e46]:
          - generic [ref=e47]:
            - img [ref=e48]
            - generic [ref=e50]: 威信
          - strong [ref=e53]: "250"
    - generic [ref=e54]:
      - generic [ref=e55]:
        - button "暫停" [active] [pressed] [ref=e56] [cursor=pointer]:
          - img [ref=e57]
        - button "一倍速" [ref=e59] [cursor=pointer]:
          - img [ref=e60]
        - button "二倍速" [ref=e62] [cursor=pointer]:
          - img [ref=e63]
        - button "五倍速" [ref=e65] [cursor=pointer]:
          - img [ref=e66]
      - button "系統選單" [ref=e68] [cursor=pointer]:
        - img [ref=e69]
  - navigation "內政" [ref=e72]:
    - button "地圖一覽" [ref=e73] [cursor=pointer]:
      - img [ref=e74]
      - generic [ref=e77]:
        - generic [ref=e78]: 地圖
        - generic [ref=e79]: 一覽
    - button "織田家 （本城）" [ref=e80] [cursor=pointer]:
      - img [ref=e81]
      - generic "織田家" [ref=e86]: 織田
    - generic [ref=e88]: 軍政
    - button "軍事" [ref=e89] [cursor=pointer]:
      - img [ref=e90]
      - text: 軍事
    - button "內政" [ref=e92] [cursor=pointer]:
      - img [ref=e93]
      - text: 內政
    - button "武將" [ref=e95] [cursor=pointer]:
      - img [ref=e96]
      - text: 武將
    - generic [ref=e101]: 交涉
    - button "外交" [ref=e102] [cursor=pointer]:
      - img [ref=e103]
      - text: 外交
    - button "調略" [ref=e105] [cursor=pointer]:
      - img [ref=e106]
      - text: 調略
    - generic [ref=e110]: 國策
    - button "政策" [ref=e111] [cursor=pointer]:
      - img [ref=e112]
      - text: 政策
    - button "軍團" [ref=e114] [cursor=pointer]:
      - img [ref=e115]
      - text: 軍團
    - button "大命" [ref=e117] [cursor=pointer]:
      - img [ref=e118]
      - text: 大命
  - generic:
    - generic:
      - generic:
        - button:
          - img
  - img "全國小地圖" [ref=e120]
  - button "報告中心" [ref=e123] [cursor=pointer]
```

# Test source

```ts
  1  | import { completeNewGameWizard } from './new-game-wizard';
  2  | import { writeFile } from 'node:fs/promises';
  3  | import { test, expect } from './fixtures';
  4  | 
  5  | test.describe('national120 canonical-army renderer prerequisite (not live ×5 acceptance)', () => {
  6  |   test.describe.configure({ mode: 'serial' });
  7  |   for (const preset of ['overview', 'operational', 'close'] as const) {
  8  |     test(`${preset}: 120 canonical armies and actual postrender cadence`, async ({
  9  |       page,
  10 |     }, info) => {
  11 |       test.skip(
  12 |         process.env.VISUAL_GPU !== '1' || process.env.VISUAL_PERF !== '1',
  13 |         'Requires an explicitly leased reference GPU host; software/headless discovery is not performance evidence.',
  14 |       );
  15 |       await page.setViewportSize({ width: 1920, height: 1080 });
  16 |       await page.emulateMedia({ reducedMotion: 'no-preference' });
  17 |       await page.goto('/?debug=1&seed=15600519');
  18 |       await page.getByTestId('title-newgame').click();
  19 |       await page.getByTestId('scenario-pick-s1560').click();
  20 |       await page.getByTestId('clan-pick-clan.oda').click();
  21 |       await completeNewGameWizard(page);
  22 |       await expect(page.getByTestId('screen-strategy')).toBeVisible();
  23 |       await page.getByTestId('speed-pause').click();
  24 |       const preparation = await page.evaluate(() =>
  25 |         window.__tenka.debug.prepareLiveNationalMapWorkload(120),
  26 |       );
  27 |       expect(preparation.count).toBe(120);
  28 |       expect(preparation.commands).toBe(120);
  29 |       expect(preparation.geographyRegions).toHaveLength(9);
  30 |       expect(preparation.armyRegions).toHaveLength(7);
  31 |       await page.evaluate(async (camera) => {
  32 |         await document.fonts.ready;
  33 |         await window.__tenka.debug.setMapCameraPreset(camera);
  34 |         await window.__tenka.debug.waitMapIdle(3);
  35 |       }, preset);
  36 |       const before = await page.evaluate(() => JSON.stringify(window.__tenka.debug.getState()));
  37 |       const environment = await page.evaluate(() => {
  38 |         const canvas = document.querySelector('canvas');
  39 |         const gl = canvas?.getContext('webgl2') ?? canvas?.getContext('webgl');
  40 |         if (!(gl instanceof WebGLRenderingContext || gl instanceof WebGL2RenderingContext))
  41 |           throw new Error('National reference measurement requires actual WebGL rendering');
  42 |         const extension = gl.getExtension('WEBGL_debug_renderer_info');
  43 |         return {
  44 |           userAgent: navigator.userAgent,
  45 |           renderer: String(
  46 |             gl.getParameter(extension ? extension.UNMASKED_RENDERER_WEBGL : gl.RENDERER),
  47 |           ),
  48 |           vendor: String(gl.getParameter(extension ? extension.UNMASKED_VENDOR_WEBGL : gl.VENDOR)),
  49 |         };
  50 |       });
  51 |       expect(environment.renderer).not.toMatch(/swiftshader|llvmpipe|software/i);
  52 |       const measurement = await page.evaluate(
  53 |         (camera) => window.__tenka.debug.measureNationalMapFrames(camera, 30_000),
  54 |         preset,
  55 |       );
  56 |       const after = await page.evaluate(() => JSON.stringify(window.__tenka.debug.getState()));
  57 |       const path = info.outputPath(`national-${preset}-frames.json`);
  58 |       await writeFile(path, JSON.stringify({ environment, preparation, measurement }, null, 2));
  59 |       await info.attach('raw-postrender-samples', { path, contentType: 'application/json' });
  60 |       await info.attach('actual-national-renderer', {
  61 |         body: await page.screenshot(),
  62 |         contentType: 'image/png',
  63 |       });
  64 |       expect(after).toBe(before);
  65 |       expect(measurement.scope).toBe('canonical-armies/render-only-paused-prerequisite');
  66 |       expect(measurement.geography.regions).toHaveLength(9);
  67 |       expect(measurement.geography.castles).toBe(121);
  68 |       expect(measurement.geography.districts).toBe(344);
  69 |       expect(measurement.armyCount).toBe(120);
  70 |       expect(new Set(measurement.armyRegions.map((army) => army.region)).size).toBe(7);
  71 |       expect(measurement.visibilityMetric).toBe(
  72 |         'renderer-cull-visible-chips/not-GPU-presented-pixels',
  73 |       );
  74 |       expect(measurement.minMountedArmies).toBe(120);
  75 |       expect(measurement.minVisibleArmies).toBeGreaterThan(0);
  76 |       expect(measurement.durationMs).toBeGreaterThanOrEqual(30_000);
> 77 |       expect(measurement.averageFps).toBeGreaterThanOrEqual(60);
     |                                      ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  78 |       expect(measurement.slowFrameFps).toBeGreaterThanOrEqual(60);
  79 |       expect(measurement.frameTimeP95).toBeLessThanOrEqual(1000 / 60);
  80 |       expect(measurement.resourcesAfter).toEqual(measurement.resourcesBefore);
  81 |       expect(measurement.lodStage).toBe(
  82 |         { overview: 'far', operational: 'mid', close: 'near' }[preset],
  83 |       );
  84 |     });
  85 |   }
  86 | });
  87 | 
```
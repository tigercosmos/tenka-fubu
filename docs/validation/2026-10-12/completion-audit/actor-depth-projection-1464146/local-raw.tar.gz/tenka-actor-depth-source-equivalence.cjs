const fs = require('node:fs');
const crypto = require('node:crypto');
const ts = require('/Users/tigercosmos/tenka-fubu/node_modules/typescript');
const [oldPath, finalPath] = process.argv.slice(2);
const oldSource = fs.readFileSync(oldPath, 'utf8');
const finalSource = fs.readFileSync(finalPath, 'utf8');
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');
const structure = (source) => {
  const file = ts.createSourceFile('actor-depth-layout.spec.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (file.parseDiagnostics.length) throw new Error('parse diagnostics: ' + file.parseDiagnostics.length);
  const walk = (node) => {
    const children = [];
    ts.forEachChild(node, (child) => children.push(walk(child)));
    return [node.kind, node.kind !== ts.SyntaxKind.SourceFile && typeof node.text === 'string' ? node.text : null, children];
  };
  return JSON.stringify(walk(file));
};
const compiled = (source) => ts.transpileModule(source, {
  fileName: 'actor-depth-layout.spec.ts',
  compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext, jsx: ts.JsxEmit.ReactJSX },
}).outputText;
const oldAst = structure(oldSource), finalAst = structure(finalSource);
const oldJs = compiled(oldSource), finalJs = compiled(finalSource);
const result = {
  oldSourceSha256: hash(oldSource), finalSourceSha256: hash(finalSource),
  oldAstSha256: hash(oldAst), finalAstSha256: hash(finalAst), astIdentical: oldAst === finalAst,
  oldJavascriptSha256: hash(oldJs), finalJavascriptSha256: hash(finalJs), javascriptIdentical: oldJs === finalJs,
};
console.log(JSON.stringify(result));
if (!result.astIdentical || !result.javascriptIdentical) process.exit(1);

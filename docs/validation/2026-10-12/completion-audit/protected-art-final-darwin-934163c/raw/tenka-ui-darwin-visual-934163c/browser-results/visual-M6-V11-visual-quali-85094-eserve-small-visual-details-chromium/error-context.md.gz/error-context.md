# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual.spec.ts >> M6-V11 visual quality gates >> three camera baselines preserve small visual details
- Location: e2e/visual.spec.ts:41:3

# Error details

```
Error: expect(page).toHaveScreenshot(expected) failed

  185869 pixels (ratio 0.21 of all image pixels) are different.

  Snapshot: strategy-overview.png

Call log:
  - Expect "soft toHaveScreenshot(strategy-overview.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 185869 pixels (ratio 0.21 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 185869 pixels (ratio 0.21 of all image pixels) are different.

```

```
Error: expect(page).toHaveScreenshot(expected) failed

  269381 pixels (ratio 0.30 of all image pixels) are different.

  Snapshot: strategy-operational.png

Call log:
  - Expect "soft toHaveScreenshot(strategy-operational.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 269381 pixels (ratio 0.30 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 269381 pixels (ratio 0.30 of all image pixels) are different.

```

```
Error: expect(page).toHaveScreenshot(expected) failed

  291228 pixels (ratio 0.32 of all image pixels) are different.

  Snapshot: strategy-close.png

Call log:
  - Expect "soft toHaveScreenshot(strategy-close.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 291228 pixels (ratio 0.32 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 291228 pixels (ratio 0.32 of all image pixels) are different.

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  1   | import { existsSync } from 'node:fs';
  2   | import { writeFile } from 'node:fs/promises';
  3   | import type { Page } from '@playwright/test';
  4   | import type { TenkaDebugApi } from '../src/app/debug';
  5   | import { test, expect } from './fixtures';
  6   | 
  7   | type DebugWindow = Window & { __tenka: { debug: TenkaDebugApi } };
  8   | declare global {
  9   |   interface Window {
  10  |     __tenka: { debug: TenkaDebugApi };
  11  |     __contextLosses?: number;
  12  |   }
  13  | }
  14  | const CAMERA_PRESETS = ['overview', 'operational', 'close'] as const;
  15  | 
  16  | async function bootMap(page: Page): Promise<void> {
  17  |   await page.goto('/?debug=visual-map');
  18  |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  19  |   await page.evaluate(() => document.fonts.ready);
  20  |   await expect
  21  |     .poll(async () =>
  22  |       page.evaluate(async () => {
  23  |         try {
  24  |           await (window as DebugWindow).__tenka.debug.waitMapIdle();
  25  |           return true;
  26  |         } catch {
  27  |           return false;
  28  |         }
  29  |       }),
  30  |     )
  31  |     .toBe(true);
  32  | }
  33  | 
  34  | test.describe('M6-V11 visual quality gates', () => {
  35  |   test.use({
  36  |     viewport: { width: 1280, height: 720 },
  37  |     deviceScaleFactor: 1,
  38  |     contextOptions: { reducedMotion: 'reduce' },
  39  |   });
  40  | 
  41  |   test('three camera baselines preserve small visual details', async ({ page }, testInfo) => {
  42  |     for (const preset of CAMERA_PRESETS) {
  43  |       const baseline = testInfo.snapshotPath(`strategy-${preset}.png`);
  44  |       if (process.env.UPDATE_VISUAL !== '1') {
  45  |         expect(existsSync(baseline), `Missing required visual baseline: ${baseline}`).toBe(true);
  46  |       }
  47  |     }
  48  |     await bootMap(page);
  49  |     for (const preset of CAMERA_PRESETS) {
  50  |       await page.evaluate(
  51  |         (p) => (window as DebugWindow).__tenka.debug.setMapCameraPreset(p),
  52  |         preset,
  53  |       );
> 54  |       await expect.soft(page).toHaveScreenshot(`strategy-${preset}.png`, {
      |                               ^ Error: expect(page).toHaveScreenshot(expected) failed
  55  |         maxDiffPixels: 100,
  56  |         threshold: 0.15,
  57  |       });
  58  |     }
  59  |   });
  60  | 
  61  |   test('required renderer layers contain visible content at each LOD', async ({ page }) => {
  62  |     await bootMap(page);
  63  |     for (const preset of CAMERA_PRESETS) {
  64  |       await page.evaluate(
  65  |         (p) => (window as DebugWindow).__tenka.debug.setMapCameraPreset(p),
  66  |         preset,
  67  |       );
  68  |       const diagnostics = await page.evaluate(() =>
  69  |         (window as DebugWindow).__tenka.debug.getMapDiagnostics(),
  70  |       );
  71  |       expect(diagnostics.ready).toBe(true);
  72  |       for (const name of [
  73  |         'terrainBase',
  74  |         'territory',
  75  |         'roads',
  76  |         'nodeMarkers',
  77  |         'actorBodies',
  78  |         'armies',
  79  |         // V9 moved castle labels into nameplates: province labels are overview-only.
  80  |         // docs/design/m6-v9-hud-readability.md §2.3; m6-v9b-map-plates.md §2.7.
  81  |         preset === 'overview' ? 'labels' : 'nameplates',
  82  |       ] as const) {
  83  |         expect(
  84  |           diagnostics.layers[name]?.children,
  85  |           `${preset}: ${name} has content`,
  86  |         ).toBeGreaterThan(0);
  87  |         expect(diagnostics.layers[name]?.visible, `${preset}: ${name} is visible`).toBe(true);
  88  |         expect(
  89  |           diagnostics.layers[name]?.visibleDrawables,
  90  |           `${preset}: ${name} draws visible content`,
  91  |         ).toBeGreaterThan(0);
  92  |         expect(diagnostics.layers[name]?.dirty, `${preset}: ${name} is idle`).toBe(false);
  93  |       }
  94  |     }
  95  |   });
  96  | 
  97  |   test('zoom cycles and renderer remount preserve resource counts without context loss', async ({
  98  |     page,
  99  |   }, testInfo) => {
  100 |     if (process.env.VISUAL_HEAP === '1') test.setTimeout(180_000);
  101 |     await bootMap(page);
  102 |     const control = page.getByTestId('layer-control');
  103 |     await control.locator('summary').click();
  104 |     await control.locator('input[value="faction"]').check();
  105 |     await page.evaluate(() => window.__tenka.debug.waitMapIdle());
  106 |     const cdp = await page.context().newCDPSession(page);
  107 |     const heapSamples: number[] = [];
  108 |     const sampleHeap = async () => {
  109 |       await cdp.send('HeapProfiler.collectGarbage');
  110 |       heapSamples.push((await cdp.send('Runtime.getHeapUsage')).usedSize);
  111 |     };
  112 |     const snapshotHeap = async (name: string) => {
  113 |       const chunks: string[] = [];
  114 |       const collect = ({ chunk }: { chunk: string }) => chunks.push(chunk);
  115 |       cdp.on('HeapProfiler.addHeapSnapshotChunk', collect);
  116 |       try {
  117 |         await cdp.send('HeapProfiler.takeHeapSnapshot', { reportProgress: false });
  118 |         const source = chunks.join('');
  119 |         if (process.env.VISUAL_HEAP === '1')
  120 |           await writeFile(testInfo.outputPath(`${name}.heapsnapshot`), source);
  121 |         const snapshot = JSON.parse(source) as {
  122 |           snapshot: { meta: { node_fields: string[]; edge_fields: string[] } };
  123 |           nodes: number[];
  124 |           edges: number[];
  125 |           strings: string[];
  126 |         };
  127 |         const fields = snapshot.snapshot.meta.node_fields;
  128 |         const nameIndex = fields.indexOf('name');
  129 |         let fontAtlasCanvases = 0;
  130 |         let canvas2dContexts = 0;
  131 |         let bitmapTexts = 0;
  132 |         const edgeFields = snapshot.snapshot.meta.edge_fields;
  133 |         const edgeCountIndex = fields.indexOf('edge_count');
  134 |         const edgeNameIndex = edgeFields.indexOf('name_or_index');
  135 |         const edgeTargetIndex = edgeFields.indexOf('to_node');
  136 |         let edgeOffset = 0;
  137 |         for (let index = 0; index < snapshot.nodes.length; index += fields.length) {
  138 |           const nodeName = snapshot.strings[snapshot.nodes[index + nameIndex]!];
  139 |           if (nodeName === '<canvas width="512" height="512">') fontAtlasCanvases += 1;
  140 |           if (nodeName === 'CanvasRenderingContext2D') canvas2dContexts += 1;
  141 |           for (let edge = 0; edge < snapshot.nodes[index + edgeCountIndex]!; edge += 1) {
  142 |             const offset = edgeOffset + edge * edgeFields.length;
  143 |             const target = snapshot.edges[offset + edgeTargetIndex]!;
  144 |             if (
  145 |               snapshot.strings[snapshot.edges[offset + edgeNameIndex]!] === 'renderPipeId' &&
  146 |               snapshot.strings[snapshot.nodes[target + nameIndex]!] === 'bitmapText'
  147 |             )
  148 |               bitmapTexts += 1;
  149 |           }
  150 |           edgeOffset += snapshot.nodes[index + edgeCountIndex]! * edgeFields.length;
  151 |         }
  152 |         return { fontAtlasCanvases, canvas2dContexts, bitmapTexts };
  153 |       } finally {
  154 |         cdp.off('HeapProfiler.addHeapSnapshotChunk', collect);
```
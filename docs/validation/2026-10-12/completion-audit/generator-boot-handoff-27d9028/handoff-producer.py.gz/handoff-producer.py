import gzip,hashlib,json,sys
from pathlib import Path
repo=Path('/Users/tigercosmos/tenka-fubu')
out=repo/'docs/validation/2026-10-12/completion-audit/generator-boot-handoff-27d9028'
out.mkdir()
items=[]
def retain(name,path):
 path=Path(path); data=path.read_bytes(); packed=gzip.compress(data,mtime=0)
 with (out/name).open('xb') as f:f.write(packed)
 items.append({'file':name,'source':str(path),'rawBytes':len(data),'rawSha256':hashlib.sha256(data).hexdigest(),'gzipBytes':len(packed),'gzipSha256':hashlib.sha256(packed).hexdigest()})
for name,path in [('root-generator.log.gz','/tmp/tenka-root-earned-wasm.0DVskz'),('root-army-initial-red.log.gz','/tmp/tenka-root-armycohort.umqxmp'),('root-army-final.log.gz',sys.argv[1])]:retain(name,path)
for capture in ['tenka-generator-boot-docs-format-27d-c1','tenka-generator-boot-docs-diffcheck-27d-c1']:
 directory=Path('/tmp')/capture
 assert json.loads((directory/'result.json').read_text())['exitCode']==0
 for p in sorted(directory.iterdir()):
  if p.is_file():retain(capture+'__'+p.name+'.gz',p)
retain('handoff-producer.py.gz',__file__)
(out/'manifest.json').write_text(json.dumps({'items':items},indent=2)+'\n')
(out/'README.md').write_text('''# Generator and loaded boot diagnostic checkpoint

This package retains the independent root verifier logs for the regional earned-route WASM comparison and the 18-case army boot cohort. The first army verification failed because README changed while the package was still being finalized. The final run verifies the frozen package. These are preopened output captures; process exit statuses were separately reported by root in the collaboration transcript.

No production or E2E change was adopted. The WASM pair did not show useful deadline margin. The instrumented cohort reproduced two original five-second boot failures and observed active frame waiters blocked by terrain/castle pending flags, without attributing the delay to a specific asset operation. Browser and Playwright/Node clocks remain separate. All native runs are terminal; no retry or full-suite campaign followed.

The original full955 440-case gate remains RED; later discovery lists 441 cases. Strict60, whole-heap, long-run, all M6–M9 requirements, and pending rule/art decisions remain open. No threshold, deadline, skip, baseline, milestone, or gameplay rule changed. Nothing was pushed or deployed.

The additive artifact inventory preserves the 5,629 historical rows and bytes at 27d9028. This package contains only completed captures; index and commit logs remain outside it to avoid archiving a running subprocess.
''')
print(json.dumps({'path':str(out),'items':len(items)}))

from pathlib import Path
import hashlib,json
base=Path('/Users/tigercosmos/tenka-fubu/docs/validation/2026-10-12/completion-audit')
out=base/'fnv-integrated-a48eb2c'
manifest=(out/'manifest.json').read_bytes(); count=len(json.loads(manifest)['items'])
s=(base/'hojo-armyboot-integrated-8ca952c/verify.py').read_text().replace('frozen Hojo and army boot E2E','frozen FNV arithmetic').replace('8ca952c30a8ae007ca988fd9c3294b59d3402b14','a48eb2c2a139108f3ff9fcc4e2c3e11a0bf6a875').replace('2581a73632ca4b4c0fcacf1490a1515a1e03afe34602fb279d794c06526415e4',hashlib.sha256(manifest).hexdigest()).replace('len(items) == 38',f'len(items) == {count}').replace('1650','1652')
s=s.replace("'inventory', 'typecheck', 'eslint', 'discovery', 'format'", "'inventory', 'focused', 'typecheck', 'eslint', 'build', 'bundle', 'format'")
a=s.index("assert 'Total: 441 tests")
b=s.index("assert '0 errors, 2 warnings'",a)
s=s[:a]+"assert '13 passed (13)' in raw('inner__focused.log').decode()\nassert '135 passed (135)' in raw('inner__focused.log').decode()\nassert obj('inner__focused.command.json')['argv'][:2] == ['node_modules/.bin/vitest', 'run']\nassert len(obj('inner__focused.command.json')['argv'][2:]) == 13\n"+s[b:]
s=s.replace("print('PASS: 38 archived artifacts, 1652 source inputs, 29 dependency targets, types/lint/441 discovery/format')",f"print('PASS: {count} archived artifacts, 1652 source inputs, 29 dependencies, 135 focused tests, types/lint/build/bundle/format')")
(out/'verify.py').write_text(s)
(out/'README.md').write_text('''# Frozen FNV arithmetic integration — a48eb2c

The adopted commit is `a48eb2c2a139108f3ff9fcc4e2c3e11a0bf6a875`. It changes only the FNV64 multiplication, adds an independent exact legacy BigInt fixture and differential regression, and records the arithmetic equivalence in plan17. The UTF-8 encoder, canonical serializer, simulation rules, and golden snapshots are unchanged.

The frozen local run passed all 135 tests in 13 files: core serialization and limb compatibility; helper hash vectors; determinism; mini, AI, and diplomacy golden trajectories; replay and event replay; save, save metadata, fixture compatibility, and commands. Vitest reported 2.00 seconds. Type checking, full ESLint (zero errors, two existing warnings), production build, bundle budget, and touched formatting also passed. The runner continues separate checks after a failure rather than hiding later results; this run had none.

The 1,652 tracked scoped Git inputs (including the two new test files) and 29 patched Pixi targets matched before and after. Every subprocess has an exclusive preopened merged log and command/result records. This package contains those completed captures and their producers; no browser or full-core run is claimed.

The separate measured route remains labeled b1a8fc8 plus exact candidate overlays, not a later full-commit native run. Its byte parity and timing evidence belong to that package. Existing long no-heir failure, full native 300-second gate, strict60, whole-heap, long-run, and pending rule/art decisions remain open. No snapshot, timeout, or baseline was changed.

Run `python3 docs/validation/2026-10-12/completion-audit/fnv-integrated-a48eb2c/verify.py` to check archived bytes, source/dependency proof, and all scoped results.
''')
print({'items':count,'source':1652})

#!/usr/bin/env python3
"""Archive the complete frozen FNV arithmetic integration capture without rewriting inputs."""

import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path('/Users/tigercosmos/tenka-fubu')
TARGET = ROOT / 'docs/validation/2026-10-12/completion-audit/fnv-integrated-a48eb2c'
INPUTS = [
    ('inner', Path('/tmp/tenka-fnv-integrated-a48-c1')),
    ('outer', Path('/tmp/tenka-fnv-integrated-launch-a48-c1')),
]
PRODUCERS = [
    ('runner', Path('/tmp/tenka-fnv-integrated-run-b1-c1.py')),
    ('outer-capture', Path('/tmp/tenka-validation-capture-961f0ae.py')),
    ('scoped-source-inventory', ROOT / 'docs/validation/2026-10-12/completion-audit/scoped-source-snapshot-79682cd/tenka-scoped-source-archive.py'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


TARGET.mkdir(exist_ok=False)
raw = TARGET / 'raw'
raw.mkdir(exist_ok=False)
items = []


def archive(label, source):
    data = source.read_bytes()
    packed = gzip.compress(data, mtime=0)
    name = label.replace('/', '__') + '.gz'
    path = raw / name
    with path.open('xb') as stream:
        stream.write(packed)
    items.append({
        'source': str(source),
        'file': str(path.relative_to(TARGET)),
        'rawBytes': len(data),
        'rawSha256': sha(data),
        'gzipBytes': len(packed),
        'gzipSha256': sha(packed),
    })


for prefix, directory in INPUTS:
    assert directory.is_dir(), directory
    for source in sorted(path for path in directory.rglob('*') if path.is_file()):
        archive(prefix + '/' + str(source.relative_to(directory)), source)
for label, source in PRODUCERS:
    assert source.is_file(), source
    archive('producer/' + label + source.suffix, source)

manifest = {
    'scope': 'Exact a48eb2c FNV arithmetic integration captures and their producers',
    'items': items,
}
with (TARGET / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
print(json.dumps({
    'path': str(TARGET),
    'files': len(items),
    'rawBytes': sum(item['rawBytes'] for item in items),
    'gzipBytes': sum(item['gzipBytes'] for item in items),
    'manifestSha256': sha((TARGET / 'manifest.json').read_bytes()),
}))

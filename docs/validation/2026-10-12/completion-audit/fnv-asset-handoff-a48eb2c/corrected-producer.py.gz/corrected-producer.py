import gzip,hashlib,json
from pathlib import Path
repo=Path('/Users/tigercosmos/tenka-fubu');out=repo/'docs/validation/2026-10-12/completion-audit/fnv-asset-handoff-a48eb2c';out.mkdir()
items=[]
def retain(name,source):
 p=Path(source);data=p.read_bytes();packed=gzip.compress(data,mtime=0)
 with (out/name).open('xb') as f:f.write(packed)
 items.append({'file':name,'source':str(p),'rawBytes':len(data),'rawSha256':hashlib.sha256(data).hexdigest(),'gzipBytes':len(packed),'gzipSha256':hashlib.sha256(packed).hexdigest()})
for name,p in [('root-integration.log.gz','/tmp/tenka-root-fnv-integrated.neDZlb'),('root-asset.log.gz','/tmp/tenka-root-asset-stages.CKX8tY'),('root-route.log.gz','/tmp/tenka-root-takeda-hash.m3Wicn')]:
 data=Path(p).read_bytes();assert (json.loads(data)['passed'] if name=='root-route.log.gz' else b'PASS' in data);retain(name,p)
for capture in ['tenka-fnv-integrated-pack-a48-c1','tenka-fnv-integrated-verify-a48-c1','tenka-fnv-asset-docs-format-a48-c1','tenka-fnv-asset-docs-format-a48-c2','tenka-fnv-asset-docs-diffcheck-a48-c1']:
 d=Path('/tmp')/capture;assert json.loads((d/'result.json').read_text())['exitCode']==0
 for p in sorted(d.iterdir()):
  if p.is_file():retain(capture+'__'+p.name+'.gz',p)
for name in ['tenka-fnv-integrated-pack-a48-c1.py','tenka-fnv-integrated-docs-a48-c1.py','tenka-fnv-asset-handoff-a48-c1.py']:retain(name+'.gz',Path('/tmp')/name)
for p in sorted(Path('/tmp/tenka-fnv-asset-handoff-partial-a48-c1').iterdir()):retain('initial-partial__'+p.name+'.gz',p)
retain('corrected-producer.py.gz',__file__)
(out/'manifest.json').write_text(json.dumps({'items':items},indent=2)+'\n')
(out/'README.md').write_text('''# FNV and asset-stage checkpoint

The three independent root verifiers passed for the earned-route hash comparison, the asset-stage diagnostic, and the committed a48eb2c integration. Their preopened output logs are retained here; root reported each process exit zero in the collaboration transcript. The remaining captures preserve completed compact packaging, verification, documentation formatting, and diff checking.

The adopted production change is the equivalent FNV64 arithmetic at a48eb2c. The single serial earned-route comparison retained all original assertions and exact serialized outputs; it does not prove repeatability or a loaded full-suite deadline. The 18-case asset diagnostic had 14 passes and four retained failures, with no asset-loading fix adopted. Browser jobs and local integration are terminal.

The initial scratch Prettier failure had no preopened subprocess capture; its tool transcript was retained separately by the worker. Later source checks have complete captures. The first final-handoff packaging producer also lacked a preopened capture and rejected the route verifier JSON because it expected the literal PASS; its tool-transcript record and partial copied logs are retained. The corrected producer recognizes passed:true and uses the capture wrapper. The asset type-cast and initial verifier-list failures are preserved in its evidence package. Do not describe all setup logging as complete.

The next safe action is a reviewed full-native acceptance decision on the meaningful hash fix, or a discriminating asset-body delivery investigation. Do not blindly retry unchanged configurations, extend deadlines, or revert the image-worker lifetime fix. Full native, strict60, whole-heap, long-run, M6–M9 scope, and pending rule/art decisions remain open. No snapshot, baseline, rule, milestone, push, or deployment changed.

The additive inventory preserves all 5,686 historical rows and bytes at b1a8fc8. Index and commit captures remain outside this immutable package because they complete after indexing.
''')
print(json.dumps({'items':len(items),'path':str(out)}))

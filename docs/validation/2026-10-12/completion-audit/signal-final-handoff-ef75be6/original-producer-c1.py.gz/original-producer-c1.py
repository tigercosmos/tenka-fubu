import gzip
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path('/Users/tigercosmos/tenka-fubu')
base = repo / 'docs/validation/2026-10-12/completion-audit'
out = base / 'signal-final-handoff-ef75be6'
out.mkdir()
proof = Path('/tmp/tenka-signal-final-handoff-proof-c1')
proof.mkdir()
roots = [
    ('fullnative-phase-9550', '/tmp/tenka-root-phase-verify.3mSg7k'),
    ('castle-axis-packet-census-9550e39', '/tmp/tenka-root-census-verify.22LqmU'),
    ('castle-close-profile-9550e39', '/tmp/tenka-root-close-verify.ydHdxE'),
    ('fullnative-current-9550', '/tmp/tenka-root-full-verify.5aRDAi'),
    ('signal-integrated-ef75be6', '/tmp/tenka-root-signal-integrated.MN9a2q'),
    ('army-signal-zero-x-ef75be6', '/tmp/tenka-root-signal-native.iTPRe3'),
]
rows = []
def retain(name, raw, origin):
    data = gzip.compress(raw, mtime=0)
    (out / name).write_bytes(data)
    rows.append({'path': name, 'origin': origin, 'bytes': len(data),
                 'sha256': hashlib.sha256(data).hexdigest(),
                 'rawBytes': len(raw), 'rawSha256': hashlib.sha256(raw).hexdigest()})
for name, source in roots:
    raw = Path(source).read_bytes()
    assert b'PASS' in raw
    retain('root-' + name + '.log.gz', raw, source)
retain('producer.py.gz', Path(__file__).read_bytes(), __file__)
(out / 'README.md').write_text('''# Final handoff for the current native census and signal optimization

Production is pinned to `ef75be660e0a142da9c6130ac04ffefc9820e7fb`. Its 207 focused tests, typecheck, full ESLint, build, bundle, and formatting checks passed. The original full 440-case native run remains pinned to `9550e397568ff448689bc5904ec0651b04bfe717` and failed the unchanged 300-second gate. Candidate native controls use that base plus the exact adopted production-file overlay; they do not claim an entire later-tree browser run.

The root independently ran all six package verifiers and reported exit 0. This package preserves its six preopened merged-output logs exactly. Commands were `python3 verify.py` for each named sibling package. The logs contain the verifier output; the root's reported exit codes come from its tool transcript, not newly invented status files. No package verification is represented as another native or unit run.

All browser and integration jobs are terminal. Source/dependency and owned-process observations remain in the individual packages. No further timing, browser, core-suite, or deployment action followed the final validation. The final documentation formatting and diff checks are separate captured subprocesses retained here.

The native improvement is incremental: one close-view pair measured 33.2367 to 34.1319 FPS, with p95 36 to 35ms, and both strict60 results remain RED. Exact geometry and budget semantics were preserved. Contradictory early microbenchmarks, the later post-observation warmup choice, and the final dense synthetic 7.6% regression remain disclosed. Current full-suite boot, pause-boundary, generator, color, and timeout failures require causal follow-up. Whole-heap, long-run, M6–M9 acceptance, and pending gameplay/art decisions remain open. No protected baseline, rule, milestone, push, or deployment changed.

The additive artifact inventory preserves all 4,780 historical rows from `9550e39`. Its final row count is recorded by the separate inventory producer and final commit handoff; the inventory does not recursively hash itself.
''')
def run(label, argv):
    (proof / (label + '.command.json')).write_text(json.dumps({'argv': argv, 'cwd': str(repo)}, indent=2) + '\n')
    with (proof / (label + '.log')).open('xb') as log:
        result = subprocess.run(argv, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    (proof / (label + '.result.json')).write_text(json.dumps({'exitCode': result.returncode}) + '\n')
    for suffix in ['command.json', 'log', 'result.json']:
        p = proof / (label + '.' + suffix)
        retain(p.name + '.gz', p.read_bytes(), str(p))
    assert result.returncode == 0, label
run('format', ['node_modules/.bin/prettier', '--write', 'CLAUDE.md', 'README.md', 'wip.md', str(base / 'README.md'), str(out / 'README.md')])
run('diff-check', ['git', 'diff', '--check'])
(out / 'manifest.json').write_text(json.dumps({'rootReportedExitCodes': {name: 0 for name, _ in roots}, 'artifacts': rows}, indent=2) + '\n')
print(json.dumps({'package': str(out), 'retainedArtifacts': len(rows)}))

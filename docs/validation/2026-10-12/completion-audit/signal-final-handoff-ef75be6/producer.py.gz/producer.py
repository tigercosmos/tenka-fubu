from pathlib import Path

original = Path('/tmp/tenka-signal-final-handoff-c1.py').read_text()
source = original.replace('out.mkdir()', 'out.mkdir(exist_ok=True)').replace(
    "Path('/tmp/tenka-signal-final-handoff-proof-c1')",
    "Path('/tmp/tenka-signal-final-handoff-proof-c2')",
).replace(
    "    (out / name).write_bytes(data)",
    "    if (out / name).exists():\n        assert (out / name).read_bytes() == data, name\n    else:\n        with (out / name).open('xb') as stream:\n            stream.write(data)",
).replace(
    "    assert b'PASS' in raw",
    "    assert b'PASS' in raw or (name == 'castle-close-profile-9550e39' and json.loads(raw)['verifiedItems'] == 87)",
).replace(
    "retain('producer.py.gz', Path(__file__).read_bytes(), __file__)",
    """retain('producer.py.gz', Path(__file__).read_bytes(), __file__)
retain('original-producer-c1.py.gz', Path('/tmp/tenka-signal-final-handoff-c1.py').read_bytes(), '/tmp/tenka-signal-final-handoff-c1.py')
for p in sorted(Path('/tmp/tenka-signal-final-handoff-capture-c1').iterdir()):
    if p.is_file(): retain('initial-failed-' + p.name + '.gz', p.read_bytes(), str(p))""",
).replace(
    'The additive artifact inventory preserves',
    'The first handoff producer incorrectly required the literal word PASS in every root log; the close-profile verifier emits a JSON result. That setup failure and original producer are retained. The corrected producer accepts its explicit verifiedItems=87 result and reuses the two earlier gzip copies only after exact-byte comparison. No verifier or validation was rerun.\n\nThe additive artifact inventory preserves',
)
exec(compile(source, __file__, 'exec'))

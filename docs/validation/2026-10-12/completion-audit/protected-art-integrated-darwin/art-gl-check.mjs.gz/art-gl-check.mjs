import { preview } from 'vite';
import { chromium } from '@playwright/test';
const server = await preview({ preview: { port: 4189, strictPort: true, host: '127.0.0.1' } });
const browser = await chromium.launch({ channel: 'chromium', headless: true, args: ['--use-angle=metal'] });
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4189/?debug=visual-map');
  await page.getByTestId('screen-strategy').waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => window.__tenka.debug.waitMapIdle());
  const result = await page.evaluate(() => [...document.querySelectorAll('canvas')].map((canvas, index) => {
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return {index, width: canvas.width, height: canvas.height, context: 'none'};
    const debug = gl.getExtension('WEBGL_debug_renderer_info');
    return {index, width: canvas.width, height: canvas.height, context: 'webgl', vendor: gl.getParameter(gl.VENDOR), renderer: gl.getParameter(gl.RENDERER), unmaskedVendor: debug && gl.getParameter(debug.UNMASKED_VENDOR_WEBGL), unmaskedRenderer: debug && gl.getParameter(debug.UNMASKED_RENDERER_WEBGL)};
  }));
  console.log(JSON.stringify(result, null, 2));
  await context.close();
} finally {
  await browser.close();
  await new Promise((resolve) => server.httpServer.close(resolve));
}

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
out = Path(sys.argv[1])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
tracked = subprocess.check_output(['git', 'ls-files', '-z']).split(b'\0')
roots = ('src/', 'tests/', 'e2e/', 'public/', 'tools/', 'rust/', 'plan/')
root_files = {'package.json', 'package-lock.json', 'playwright.config.ts', 'vite.config.ts', 'vitest.config.ts', 'tsconfig.json', 'tsconfig.node.json', 'eslint.config.js', '.prettierrc', 'CLAUDE.md'}
files = []
for raw in tracked:
    if not raw:
        continue
    path = raw.decode()
    if not path.startswith(roots) and path not in root_files:
        continue
    data = (root/path).read_bytes()
    files.append({'path': path, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
manifest = json.loads((root/'tools/dependencies/pixi-8.19-patch.json').read_text())
runtime=[]
for target in manifest['targets']:
    path = root/'node_modules/pixi.js'/target['path']
    data=path.read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    runtime.append({'path': str(path.relative_to(root)), 'sha256': sha, 'expectedPatchedSha256': target['patchedSha256'], 'matchesPatched': sha == target['patchedSha256']})
result={'head':head,'trackedInputs':files,'runtimeTargets':runtime,'runtimeAllPatched':all(x['matchesPatched'] for x in runtime)}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'head':head,'trackedInputCount':len(files),'runtimeTargetCount':len(runtime),'runtimeAllPatched':result['runtimeAllPatched'],'out':str(out)}))

import gzip,hashlib,json,pathlib,shutil,sys
repo=pathlib.Path('/Users/tigercosmos/tenka-fubu');src=pathlib.Path(__file__).parent
out=repo/'docs/validation/2026-10-12/completion-audit/integrated-89acc88-regression';out.mkdir(exist_ok=True)
rows=[]
for p in sorted(src.iterdir()):
 if p.is_file():
  raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);target=out/(p.name+'.gz');target.write_bytes(packed);rows.append(dict(path=target.name,bytes=len(packed),sha256=hashlib.sha256(packed).hexdigest(),rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest()))
summary=dict(sourceInputs=1555,source='89acc88c6cf0f11801f0b3d701020857ddcdea21',checks=json.loads((src/'status.json').read_text()),artifacts=rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

import fs from 'node:fs';
import crypto from 'node:crypto';
import ts from '/Users/tigercosmos/tenka-fubu/node_modules/typescript/lib/typescript.js';
const path='/Users/tigercosmos/tenka-fubu/tests/ui/wasmGeographicScorer.spec.ts';
const before=fs.readFileSync(new URL('./wasmGeographicScorer.before.ts',import.meta.url),'utf8');
const after=fs.readFileSync(new URL('./wasmGeographicScorer.after.ts',import.meta.url),'utf8');
const emit=(source)=>ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,sourceMap:false,removeComments:false},fileName:'wasmGeographicScorer.spec.ts'}).outputText;
const a=emit(before),b=emit(after);
const structure=(source)=>{const tree=ts.createSourceFile('test.js',source,ts.ScriptTarget.ES2022,true,ts.ScriptKind.JS);const visit=(node)=>{const children=[];ts.forEachChild(node,child=>{children.push(visit(child));});return {kind:node.kind,text:ts.isIdentifier(node)||ts.isLiteralExpression(node)?node.text:undefined,children};};return JSON.stringify(visit(tree));};
if(structure(a)!==structure(b))throw new Error('Transpiled AST differs');
const hash=(s)=>crypto.createHash('sha256').update(s).digest('hex');
fs.writeFileSync('/tmp/tenka-integrated-89acc88-regression/format-proof.json',JSON.stringify({path:'tests/ui/wasmGeographicScorer.spec.ts',beforeSha256:hash(before),afterSha256:hash(after),transpiledBeforeSha256:hash(a),transpiledAfterSha256:hash(b),transpiledBytesIdentical:a===b,transpiledAstSha256:hash(structure(a)),transpiledAstIdentical:true},null,2)+'\n');


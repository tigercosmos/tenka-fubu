import { chromium } from '/Users/tigercosmos/tenka-fubu/node_modules/playwright/index.mjs';
import { writeFile } from 'node:fs/promises';

const url = process.argv[2];
const output = process.argv[3];
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
const errors = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
page.on('pageerror', (error) => errors.push(error.message));
await page.goto(url);
await page.getByTestId('title-newgame').click();
await page.getByTestId('scenario-pick-s1560').click();
await page.getByTestId('clan-pick-clan.oda').click();
await page.getByTestId('newgame-start').click();
await page.getByTestId('speed-pause').click();
await page.getByTestId('rail-officers').click();
await page.evaluate(() => {
  window.__hotkeyObserved = [];
  window.addEventListener('keydown', (event) => {
    if (event.key === 'm' || event.key === 'Home')
      window.__hotkeyObserved.push({ key: event.key, defaultPrevented: event.defaultPrevented });
  });
});
const baselineSelection = await page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection);
const guardResults = [];
for (const [name, selector, keys] of [
  ['typing input', '[data-testid="officer-list"] input[type="search"]', ['m', 'Home']],
  ['native button', '[data-testid="rail-officers"]', ['m', 'Home']],
  ['resource strip', '[data-testid="hud-resources"] span[tabindex="0"]', ['Home']],
]) {
  const control = page.locator(selector).first();
  await control.focus();
  for (const key of keys) await page.keyboard.press(key);
  guardResults.push({
    name,
    focused: await control.evaluate((element) => element === document.activeElement),
    minimap: await page.locator('[data-testid="minimap"]').count(),
    selection: await page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection),
  });
  if (name === 'typing input') await control.fill('');
}
await page.getByTestId('officer-list').locator('tbody tr').filter({ hasText: '織田信長' }).click();
const trait = page.getByTestId('officer-detail').locator('span[tabindex="0"]').first();
await trait.focus();
if (!(await trait.evaluate((element) => element === document.activeElement))) throw new Error('Trait focus failed');
const before = await page.evaluate(() => ({
  minimap: document.querySelectorAll('[data-testid="minimap"]').length,
  view: window.__tenka.debug.getMapPublishedViewSnapshot(),
}));
await page.keyboard.press('m');
const afterM = await page.evaluate(() => ({
  minimap: document.querySelectorAll('[data-testid="minimap"]').length,
  focus: document.activeElement?.outerHTML.slice(0, 180),
}));
await page.keyboard.press('Home');
await page.evaluate(() => window.__tenka.debug.waitMapIdle(2));
const afterHome = await page.evaluate(() => ({
  view: window.__tenka.debug.getMapPublishedViewSnapshot(),
  focus: document.activeElement?.outerHTML.slice(0, 180),
  observed: window.__hotkeyObserved,
}));
const result = { url, baselineSelection, guardResults, before, afterM, afterHome, errors };
await writeFile(output, JSON.stringify(result, null, 2) + '\n');
process.stdout.write(`${output}\n${JSON.stringify({beforeMinimap:before.minimap,afterMinimap:afterM.minimap,observed:afterHome.observed,errors},null,2)}\n`);
await browser.close();

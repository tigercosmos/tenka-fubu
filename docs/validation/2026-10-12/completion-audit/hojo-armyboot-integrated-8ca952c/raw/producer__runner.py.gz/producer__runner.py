#!/usr/bin/env python3
"""Validate frozen Hojo and army boot E2E changes without browser or core reruns."""

import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path('/Users/tigercosmos/tenka-fubu')
SNAPSHOT = ROOT / 'docs/validation/2026-10-12/completion-audit/scoped-source-snapshot-79682cd/tenka-scoped-source-archive.py'
FORMAT = ['e2e/earned-hojo-aid.spec.ts', 'e2e/army-plate-layout.spec.ts']


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def blob_id(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--revision', required=True, help='Full adopted commit SHA')
parser.add_argument('--output', required=True, help='New, absent output directory')
args = parser.parse_args()
out = Path(args.output).resolve()
out.mkdir(parents=True, exist_ok=False)
statuses = []


def run(label, command):
    write_new(out / (label + '.command.json'), {
        'argv': command,
        'cwd': str(ROOT),
        'startedUtc': now(),
    })
    started = time.monotonic()
    with (out / (label + '.log')).open('xb', buffering=0) as log:
        os.fsync(log.fileno())
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            code = result.returncode
        except BaseException as error:
            log.write((type(error).__name__ + ': ' + str(error) + '\n').encode())
            code = 127
    row = {
        'label': label,
        'exitCode': code,
        'seconds': time.monotonic() - started,
        'finishedUtc': now(),
    }
    write_new(out / (label + '.result.json'), row)
    statuses.append(row)
    print(json.dumps(row), flush=True)
    return code


inventory_dir = out / 'source-inventory'
if run('inventory', [
    sys.executable,
    str(SNAPSHOT),
    '--repo', str(ROOT),
    '--revision', args.revision,
    '--output', str(inventory_dir),
    '--inventory-only',
]) != 0:
    write_new(out / 'status.json', statuses)
    sys.exit(1)

manifest = json.loads((inventory_dir / 'manifest.json').read_text())
if manifest['revision'] != args.revision or not manifest['entries']:
    write_new(out / 'status.json', statuses)
    raise SystemExit('Inventory revision mismatch or empty inventory')


def proof(label):
    source_rows = []
    for name, expected in sorted(manifest['entries'].items()):
        path = ROOT / name
        if path.is_file():
            data = path.read_bytes()
            actual_blob = blob_id(data)
            digest = hashlib.sha256(data).hexdigest()
            mode_matches = bool(path.stat().st_mode & 0o111) == (expected['mode'] == '100755')
        else:
            actual_blob = digest = None
            mode_matches = False
        source_rows.append({
            'path': name,
            'expectedBlob': expected['gitBlob'],
            'actualBlob': actual_blob,
            'sha256': digest,
            'modeMatches': mode_matches,
        })
    source_ok = all(
        row['expectedBlob'] == row['actualBlob'] and row['modeMatches']
        for row in source_rows
    )
    write_new(out / (label + '-source.json'), {
        'revision': manifest['revision'],
        'count': len(source_rows),
        'passed': source_ok,
        'rows': source_rows,
    })

    targets = json.loads((ROOT / 'tools/dependencies/pixi-8.19-patch.json').read_text())['targets']
    dependency_rows = []
    for target in targets:
        name = target['path']
        path = ROOT / 'node_modules/pixi.js' / name
        digest = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        dependency_rows.append({
            'path': name,
            'expectedSha256': target['patchedSha256'],
            'actualSha256': digest,
        })
    dependencies_ok = len(dependency_rows) == 29 and all(
        row['expectedSha256'] == row['actualSha256'] for row in dependency_rows
    )
    write_new(out / (label + '-pixi.json'), {
        'count': len(dependency_rows),
        'passed': dependencies_ok,
        'rows': dependency_rows,
    })
    write_new(out / (label + '-result.json'), {
        'sourcePassed': source_ok,
        'dependenciesPassed': dependencies_ok,
        'passed': source_ok and dependencies_ok,
    })
    return source_ok and dependencies_ok


before_ok = proof('before')
if before_ok:
    checks = [
        ('typecheck', ['npm', 'run', 'typecheck']),
        ('eslint', ['node_modules/.bin/eslint', '.']),
        ('discovery', ['node_modules/.bin/playwright', 'test', '--list', '--project=chromium']),
        ('format', ['node_modules/.bin/prettier', '--check', *FORMAT]),
    ]
    for label, command in checks:
        run(label, command)
after_ok = proof('after')
write_new(out / 'status.json', {
    'revision': manifest['revision'],
    'beforePassed': before_ok,
    'afterPassed': after_ok,
    'checks': statuses,
    'passed': before_ok and after_ok and all(row['exitCode'] == 0 for row in statuses),
})
sys.exit(0 if before_ok and after_ok and all(row['exitCode'] == 0 for row in statuses) else 1)

set -eu
cd /tmp/tenka-texture-cache-baseline
export PATH=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin:$PATH
tar xzf source.tar.gz
cp /tmp/tenka-gpu-cache-candidate/proof.py .
python3 proof.py source-before
npm ci > npm-ci.log 2>&1
npm run build > build.log 2>&1
set +e
CI=1 VISUAL_GPU=1 npx playwright test e2e/visual.spec.ts --grep 'three camera baselines|required renderer layers' --workers=1 --output=visual-results > visual.log 2>&1
printf '%s\n' "$?" > visual.exit
node art-gl-check.mjs > art-gl.log 2>&1
printf '%s\n' "$?" > art-gl.exit
set -e
python3 proof.py source-final

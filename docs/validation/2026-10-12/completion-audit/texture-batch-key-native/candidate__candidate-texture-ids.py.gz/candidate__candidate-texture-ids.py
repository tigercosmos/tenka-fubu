#!/usr/bin/env python3
"""Inspect all BatchTextureArray.ids maps, indexed and named keys."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
BASE=Path('/tmp/tenka-texture-cache-candidate')
SNAP=BASE/'diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium'
P=Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec=importlib.util.spec_from_file_location('postcap',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=BASE/'scratch'

def inspect(path):
 s=m.Snapshot(path);parents=s.strong_paths();rows=[]
 for i in range(s.count):
  if s.kind(i)!='object':continue
  props={label:target for kind,label,target in s.edges_of(i) if kind=='property'}
  if not {'ids','textures'}<=props.keys():continue
  ids=props['ids']
  if s.kind(ids)!='object':continue
  pathrow=s.path(ids,parents)
  if not pathrow or pathrow[-1]['edge']!='ids':continue
  edges=list(s.edges_of(ids))
  indexed=[(int(label),target) for kind,label,target in edges if kind=='element']
  named=[(label,target) for kind,label,target in edges if kind=='property' and label.lstrip('-').isdigit()]
  stores=[target for kind,label,target in edges if kind=='internal' and label=='elements']
  rows.append({'ownerId':s.attr(i,'id'),'ownerName':s.name(i),'idsId':s.attr(ids,'id'),
               'indexedCount':len(indexed),'indexedMax':max((key for key,_ in indexed),default=None),
               'namedCount':len(named),'namedKeys':[key for key,_ in named],
               'indexedNull':sum(s.kind(target)=='native' and s.name(target)=='null' for _,target in indexed),
               'namedNull':sum(s.kind(target)=='native' and s.name(target)=='null' for _,target in named),
               'backingBytes':sum(s.attr(target,'self_size') for target in stores),
               'pathTail':[(x['from'],x['edge'],x['to']) for x in pathrow[-10:]]})
 rows.sort(key=lambda r:(r['backingBytes'],r['namedCount']),reverse=True)
 return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'count':len(rows),'backingBytes':sum(r['backingBytes'] for r in rows),
         'indexedCount':sum(r['indexedCount'] for r in rows),
         'namedCount':sum(r['namedCount'] for r in rows),
         'indexedNull':sum(r['indexedNull'] for r in rows),
         'namedNull':sum(r['namedNull'] for r in rows),
         'largest':rows[:12],'rows':rows}
result=[inspect(SNAP/'after-120-remounts.heapsnapshot'),inspect(SNAP/'after-remounts.heapsnapshot')]
a={(r['ownerId'],r['idsId']) for r in result[0]['rows']};b={(r['ownerId'],r['idsId']) for r in result[1]['rows']}
print(json.dumps({'snapshots':result,'stableOwnerMapIds':len(a&b)},indent=2))

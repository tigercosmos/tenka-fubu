import hashlib,json,pathlib
root=pathlib.Path(__file__).parent
for r in [root,root.parent/'tenka-texture-cache-baseline']:
 rows=[]
 for p in sorted((r/'node_modules').rglob('*')):
  if p.is_file():rows.append({'path':str(p.relative_to(r/'node_modules')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 (r/'dependency-final.json').write_text(json.dumps(rows,indent=2)+'\n');print(r.name,len(rows))

import base from './playwright.config';
export default { ...base, globalTimeout: 660_000, reporter: [['list']], outputDir: 'diagnostic-results' };

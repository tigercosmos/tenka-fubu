import gzip,hashlib,json,pathlib,tarfile
root=pathlib.Path(__file__).parent; baseline=root.parent/'tenka-texture-cache-baseline';output=root/'package';output.mkdir(exist_ok=True)
rows=[];omitted=[]
for label,folder in [('baseline',baseline),('candidate',root)]:
 files=[p for p in folder.iterdir() if p.is_file() and p.suffix in ['.log','.json','.py','.sh','.exit','.ts','.mjs']]
 for dirname in ['visual-results','original-results','diagnostic-results']:
  files.extend(p for p in (folder/dirname).rglob('*') if p.is_file())
 for name in ['tools/dependencies/pixi-8.19-patch.json','tests/ci/pixiDependencyPatch.spec.ts','tests/ci/pixiTextureBatchIds.spec.ts','e2e/heap-diagnostic.spec.ts']:
  if (folder/name).is_file():files.append(folder/name)
 for p in sorted(set(files)):
  source=str(p.relative_to(folder));raw=p.read_bytes()
  if p.name=='trace.zip':
   omitted.append({'scope':label,'sourcePath':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'reason':'Retained at original remote path; excluded from local evidence archive. Raw errors and screenshot actual/expected/diff are archived.'});continue
  packed=gzip.compress(raw,mtime=0);name=label+'__'+source.replace('/','__')+'.gz';(output/name).write_bytes(packed);rows.append({'path':name,'scope':label,'sourcePath':source,'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest()})
summary={'source':json.loads((root/'source-origin.json').read_text()),'artifacts':rows,'omitted':omitted}
for kind in ['original','diagnostic']:
 data=json.loads(next((root/(kind+'-results')).rglob('remount-heap-samples.json')).read_text());a=data['usedHeapBytes'];v={'exit':int((root/(kind+'.exit')).read_text()),'sampleCount':len(a),'first':a[0],'last':a[-1],'delta':a[-1]-a[0],'last20SamplesDelta':a[-1]-a[-20],'cacheBefore':data['cacheBefore'],'cacheAfter':data['cacheAfter']}
 if len(a)>120:v.update(after120=a[120],second120Delta=a[-1]-a[120])
 summary[kind]=v
images=[]
for view in ['overview','operational','close']:
 b=next((baseline/'visual-results').rglob('strategy-'+view+'-actual.png')).read_bytes();c=next((root/'visual-results').rglob('strategy-'+view+'-actual.png')).read_bytes();images.append({'view':view,'baselineSha256':hashlib.sha256(b).hexdigest(),'candidateSha256':hashlib.sha256(c).hexdigest(),'byteIdentical':b==c})
summary['sameHostActualImageComparison']=images
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:t.add(output,arcname='texture-batch-key-native')
print(json.dumps({k:v for k,v in summary.items() if k!='artifacts'},indent=2))

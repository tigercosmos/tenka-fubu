#!/usr/bin/env python3
"""Compare reachable V8 object-elements allocation categories after cap."""
import collections
import importlib.util
import json
import re
from pathlib import Path
BASE=Path('/tmp/tenka-texture-cache-candidate')
SNAP=BASE/'diagnostic-results/heap-diagnostic-M6-V11-vis-4c5e6-counts-without-context-loss-chromium'
P=Path('/tmp/tenka-heap-2d872d7/post-cap-analysis.py')
spec=importlib.util.spec_from_file_location('postcap',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=BASE/'scratch'

def get(path):
 s=m.Snapshot(path);parents=s.strong_paths();rows=[]
 for i in range(s.count):
  if s.kind(i)!='array' or s.name(i)!='(object elements)':continue
  path=s.path(i,parents)
  names=[x['edge'] for x in path] if path else []
  marker=next((name for name in ('coastLandGfx','groundSurface','overlayGfx','terrainGfx') if name in names),'other')
  key='>'.join(names[-7:]) if path else None
  rows.append({'id':s.attr(i,'id'),'bytes':s.attr(i,'self_size'),'marker':marker,'tail':key})
 return rows
old=get(SNAP/'after-120-remounts.heapsnapshot');new=get(SNAP/'after-remounts.heapsnapshot')
a={r['id']:r for r in old};b={r['id']:r for r in new}
summary={}
by_tail={}
for name,rows in [('mid',old),('final',new)]:
 by=collections.defaultdict(lambda:[0,0])
 for r in rows:
  by[r['marker']][0]+=1;by[r['marker']][1]+=r['bytes']
 summary[name]={k:{'count':v[0],'bytes':v[1]} for k,v in by.items()}
 tail=collections.defaultdict(lambda:[0,0])
 for r in rows:
  key='>'.join('#' if re.fullmatch(r'-?\d+',part) else part for part in (r['tail'] or '').split('>'))
  tail[key][0]+=1;tail[key][1]+=r['bytes']
 by_tail[name]=tail
tail_deltas=[]
for key in by_tail['mid'].keys()|by_tail['final'].keys():
 a0,a1=by_tail['mid'][key];b0,b1=by_tail['final'][key]
 if b1!=a1:tail_deltas.append({'tail':key,'midCount':a0,'finalCount':b0,'midBytes':a1,'finalBytes':b1,'delta':b1-a1})
tail_deltas.sort(key=lambda r:r['delta'],reverse=True)
result={'groups':summary,
        'tailDeltas':tail_deltas[:50],
        'largestNew':[r for r in sorted((r for r in new if r['id'] not in a),key=lambda r:r['bytes'],reverse=True)[:20]],
        'largestGone':[r for r in sorted((r for r in old if r['id'] not in b),key=lambda r:r['bytes'],reverse=True)[:20]],
        'stableBytesDelta':sum(b[i]['bytes']-a[i]['bytes'] for i in a.keys()&b.keys())}
print(json.dumps(result,indent=2))

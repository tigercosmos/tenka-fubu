import hashlib,json,pathlib,platform,subprocess
r=pathlib.Path(__file__).parent
out={'host':'sim4','platform':platform.platform(),'capture':'post-run executable identity; no before/after executable hash proof'}
for name,path in [('node','/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin/node'),('browser','/home/anchi/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome')]:
 p=pathlib.Path(path);raw=p.read_bytes();out[name]={'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'version':subprocess.check_output([path,'--version'],text=True).strip()}
out['lockSha256']=hashlib.sha256((r/'package-lock.json').read_bytes()).hexdigest()
out['freshNpmCi']=True
out['originalGpuIdentity']='not captured in original page; same launch flags only'
out['diagnosticGpuIdentity']=json.loads(next((r/'diagnostic-results').rglob('gpu-identity.json')).read_text())
(r/'environment.json').write_text(json.dumps(out,indent=2)+'\n')

set -eu
cd /tmp/tenka-texture-cache-candidate
export PATH=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin:$PATH
tar xzf overlay.tar.gz
cp candidate-manifest.json source-manifest.json
cp candidate-origin.json source-origin.json
python3 proof.py source-before
npm ci > npm-ci.log 2>&1
npm run build > build.log 2>&1
set +e
CI=1 VISUAL_GPU=1 npx playwright test e2e/visual.spec.ts --grep 'three camera baselines|required renderer layers' --workers=1 --output=visual-results > visual.log 2>&1
printf '%s\n' "$?" > visual.exit
node art-gl-check.mjs > art-gl.log 2>&1
printf '%s\n' "$?" > art-gl.exit
set -e
python3 proof.py source-after-visual
set +e
CI=1 VISUAL_GPU=1 VISUAL_HEAP=1 npx playwright test e2e/visual.spec.ts --grep 'zoom cycles and renderer remount' --workers=1 --output=original-results > original-heap.log 2>&1
printf '%s\n' "$?" > original.exit
set -e
python3 proof.py source-after-original
python3 prepare-diagnostic.py
set +e
CI=1 VISUAL_GPU=1 VISUAL_HEAP=1 npx playwright test e2e/heap-diagnostic.spec.ts --config heap-diagnostic.config.ts --grep 'zoom cycles and renderer remount' --workers=1 > diagnostic-heap.log 2>&1
printf '%s\n' "$?" > diagnostic.exit
set -e
python3 proof.py source-final
python3 capture-environment.py

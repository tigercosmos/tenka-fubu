import hashlib,json,pathlib,sys
r=pathlib.Path(__file__).parent
m=json.loads((r/'source-manifest.json').read_text())
rows=[]
for name,expected in m.items():
 p=r/name
 actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 rows.append({'path':name,'expected':expected,'actual':actual,'equal':actual==expected})
result={'passed':all(x['equal'] for x in rows),'sourceCount':len(rows),'rows':rows}
(r/(sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print({'passed':result['passed'],'count':len(rows)})
assert result['passed']

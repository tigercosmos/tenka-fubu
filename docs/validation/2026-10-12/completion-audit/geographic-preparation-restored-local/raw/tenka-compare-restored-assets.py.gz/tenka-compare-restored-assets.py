from pathlib import Path
import hashlib
import json

old = Path('/tmp/tenka-fixed-6795-integration/dist')
new = Path('/tmp/tenka-fixed-3d6a-integration/dist')
a = {p.name: p for p in (old / 'assets').iterdir() if p.suffix in ('.js', '.css')}
b = {p.name: p for p in (new / 'assets').iterdir() if p.suffix in ('.js', '.css')}
rows = []
for name in sorted(a.keys() | b.keys()):
    x, y = a.get(name), b.get(name)
    xb = x.read_bytes() if x else None
    yb = y.read_bytes() if y else None
    rows.append({'path': name, 'oldBytes': len(xb) if xb is not None else None,
                 'newBytes': len(yb) if yb is not None else None,
                 'oldSha256': hashlib.sha256(xb).hexdigest() if xb is not None else None,
                 'newSha256': hashlib.sha256(yb).hexdigest() if yb is not None else None,
                 'equal': xb == yb})
xb = (old / 'wasm/tenka_engine.wasm').read_bytes()
yb = (new / 'wasm/tenka_engine.wasm').read_bytes()
wasm = {'oldBytes': len(xb), 'newBytes': len(yb),
        'oldSha256': hashlib.sha256(xb).hexdigest(),
        'newSha256': hashlib.sha256(yb).hexdigest(), 'equal': xb == yb}
result = {'scope': 'Emitted dist/assets JS/CSS and served WASM binary only. Excludes sourcemaps, other public assets, manifest metadata and dependencies. Not a native FPS rerun.',
          'oldSourceHead': '04c7b60', 'newSourceHead': '3d6a953',
          'oldBuild': str(old), 'newBuild': str(new),
          'allEqual': all(r['equal'] for r in rows) and wasm['equal'],
          'assets': rows, 'wasm': wasm}
Path('/tmp/tenka-fixed-3d6a-compiled-assets.json').write_text(json.dumps(result, indent=2) + '\n')
assert result['allEqual']
print(f'PASS: {len(rows)} emitted JS/CSS files and {len(yb)}-byte WASM binary byte-identical')

import subprocess,pathlib,json,hashlib,tarfile,io
head='c2302c4ad1fa7ad524f79a13084b8ceedc3b4a7e';old=json.loads(pathlib.Path('/tmp/sim3-prep-current23-expected.json').read_text());roots={x['path'] for x in old['files'] if '/' not in x['path']};files=subprocess.check_output(['git','ls-tree','-r','--name-only',head],text=True).splitlines();selected=[x for x in files if x in roots or x.split('/')[0] in ['src','public','rust','tools','tests','e2e']];rows=[]
with tarfile.open('/tmp/sim3-endpoints-current23-source.tar.gz','w:gz') as tar:
 for n in selected:
  b=subprocess.check_output(['git','show',head+':'+n]);info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b));rows.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),gitBlob=subprocess.check_output(['git','rev-parse',head+':'+n],text=True).strip()))
pathlib.Path('/tmp/sim3-endpoints-current23-expected.json').write_text(json.dumps({'commit':head,'files':rows},indent=2));print(len(rows))

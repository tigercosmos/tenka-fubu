import pathlib,tarfile,shutil,hashlib
r=pathlib.Path('/tmp/tenka-endpoints-current23-20261012');assert not r.exists();r.mkdir()
with tarfile.open('/tmp/sim3-endpoints-current23-source.tar.gz') as t:t.extractall(r,filter='data')
(r/'node_modules').symlink_to('/tmp/tenka-national120-current23-20261012/node_modules')
for a,b in [('national120-published.mjs','national120-published.mjs'),('endpoints-current23-profile.mjs','endpoints-current23-profile.mjs'),('endpoints-current23-profile-analysis.mjs','endpoints-current23-profile-analysis.mjs'),('sim3-endpoints-profile-attribution.mjs','profile-attribution.mjs')]:shutil.copyfile('/tmp/tenka-endpoints-templates/'+a,r/b)
assert hashlib.sha256((r/'e2e/national120-map-perf.spec.ts').read_bytes()).hexdigest()=='2d39ba643aa3c0aa7a242d0e93d081806fe54bd64b650f1ab78cbf67d4f567e4'
b=(r/'public/wasm/tenka_engine.wasm').read_bytes();assert len(b)==89761 and hashlib.sha256(b).hexdigest()=='69af4226d451a71211b209101cc4223045b1aeca2f1178d16e9beaa91166b736'
print('Fresh frozen source/public/fixtures, shared same current23 deps; original FPS spec and actual new WASM hashes PASS')

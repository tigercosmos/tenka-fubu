import pathlib,json,gzip,hashlib
r=pathlib.Path('/tmp/tenka-endpoints-local/tenka-endpoints-current23-evidence');o=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-score-endpoints-native');o.mkdir(exist_ok=True);parent=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-preparation-native');h=lambda b:hashlib.sha256(b).hexdigest()
def read(n):return json.loads((r/n).read_text())
def baseline(n):return json.loads(gzip.decompress((parent/(n+'.gz')).read_bytes()))
p=read('close-profile-summary.json');a=read('close-profile-source-summary.json');bp=baseline('close-profile-summary.json');ba=baseline('close-profile-source-summary.json');f=p['measurement']['completedFrames'];bf=bp['measurement']['completedFrames']
def row(rows,name,path):return next(x for x in rows if x['function']==name and x['source'].endswith(path))
g=row(a['mappedSourceRows'],'layoutGeographicLabels','geographicLabelLayout.ts');bg=row(ba['mappedSourceRows'],'layoutGeographicLabels','geographicLabelLayout.ts');gm=g['inclusiveUs']/1000/f;bm=bg['inclusiveUs']/1000/bf
fps=[]
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');m=q['measurement'];b=baseline(c+'.raw.json')['measurement'];fps.append(dict(camera=c,environment=q['environment'],**{k:m[k] for k in ['averageFps','slowFrameFps','frameTimeP95','durationMs','completedFrames','frames','minMountedArmies','minVisibleArmies','lodStage']},terminalExit=next(x['terminalExit'] for x in read('fps-driver-status.json') if x['camera']==c),strict60Pass=False,baselineAverageFps=b['averageFps'],baselineFrameTimeP95=b['frameTimeP95'],observedAverageFpsChangePercent=(m['averageFps']/b['averageFps']-1)*100,observedP95ChangePercent=(m['frameTimeP95']/b['frameTimeP95']-1)*100))
wasm=(r/'tenka_engine.wasm').read_bytes();geo=[x for x in a['mappedSourceRows'] if x['source'].endswith('/wasmGeographicPreparation.ts')];sig=row(a['mappedSourceRows'],'geographicPreparationSignature','wasmGeographicPreparation.ts');prep=row(a['mappedSourceRows'],'prepare','wasmGeographicPreparation.ts');score=row(a['mappedSourceRows'],'scorePrepared','wasmGeographicPreparation.ts')
s=dict(scope='single same-current23 dependency endpoint Rust candidate native renderer campaign; not live strategy acceptance',candidateCommit='c2302c4ad1fa7ad524f79a13084b8ceedc3b4a7e',candidateStatus='withdrawal decided; source revert pending parent commit',retentionDecision='withdraw',retentionReason='No clear overall benefit: close averageFPS−0.911%, JS layout parent+1.308%, score WASM+1.618%, normalized overlap-like self no improvement; binary grows1286bytes',baselineEvidenceCommit='44c3b30',baselineRuntimeSourceCommit='feab20cc9c207f37afae7a2f372c437b93232a07',replica='sim3:/tmp/tenka-endpoints-current23-20261012',sourceFiles=1524,sourceScope='full frozen src/public/rust/tools/tests/e2e and thirteen root code/config files; e2e was newly included in source proofs',dependencyFiles=14765,pixiPatchTargets=23,sourceBeforeAfterFinalMatch=True,dependenciesBeforeAfterFinalUnchanged=True,compiledWasm=dict(bytes=len(wasm),sha256=h(wasm),exports=a['wasmExportMap']),functionalParity=read('parity-proof.json'),fps=fps,stateResourceProof=read('state-resource-proof.json'),setup=dict(successfulCurrentSetup=True,originalPrematureTransferRED=read('setup-original-transfer-red-status.json')),cpuProfile=dict(scope='one separate10s close CPUprofile after all timing controls; not ordinary FPS',measurementDurationMs=p['measurement']['durationMs'],completedFrames=f,postrenderIntervals=p['measurement']['frames'],profileSampledSpanUs=a['totalUs'],samples=a['samples'],driverTicks=p['driver']['ticks'],canonicalStateByteEqual=p['canonicalStateByteEqual'],canonicalBeforeSha256=p['canonicalBeforeSha256'],canonicalAfterSha256=p['canonicalAfterSha256'],resourceBeforeSha256=p['resourceBeforeSha256'],resourceAfterSha256=p['resourceAfterSha256'],JSGeographicLayoutParent=g,JSGeographicLayoutParentInclusiveMsPerCompletedRender=gm,baselineJSGeographicLayoutParent=bg,baselineCompletedRenders=bf,baselineJSGeographicLayoutParentInclusiveMsPerCompletedRender=bm,observedParentChangePercent=(gm/bm-1)*100,JSPreparationRows=geo,JSPreparationExclusiveSelfUs=sum(x['selfUs'] for x in geo),WasmExclusiveSelfUsByMappedCaller=read('profile-caller-attribution.json')['wasmExclusiveSelfUsByMappedCaller'],exportFrames=[x for x in a['wasmRows'] if x.get('exports')],cacheBefore=p['cacheBefore'],cacheAfter=p['cacheAfter'],cacheDelta={k:p['cacheAfter'][k]-p['cacheBefore'][k] for k in p['cacheBefore']},caveats=['Inclusive layout/prepare/scorePrepared already contain child WASM; do not add.','Direct exported WASM frames omit internal/inline observations; mapped-JS-caller exclusive WASM leaf grouping includes those.','Cache capture brackets a broader span than the measured CPU/frame window.','Single unreplicated windows; preserve original strict60 REDs.','New internal Rust helper names are inference from stripped actual binary arithmetic/callgraph, not retained symbolic proof.']))
ver=gzip.decompress((parent/'verify-evidence.py.gz').read_bytes()).decode().replace('==1413','==1524');ver += """
# Recompute existing-profile exclusive WASM leaf rows, and actual new export indices.
import collections,re
q=read('close.cpuprofile');m=read('profile-caller-attribution.json');ns={n['id']:n for n in q['nodes']};labels={n['id']:n for n in m['mappedNodes']};pa={c:n['id'] for n in q['nodes'] for c in n.get('children',[])};rows=collections.defaultdict(lambda:[0,0])
for id,dt in zip(q['samples'],q['timeDeltas']):
 n=ns[id];cur=id;caller=None
 while cur is not None:
  l=labels[cur]
  if l['source'].endswith('/wasmGeographicPreparation.ts') and l['name'] in ['prepare','scorePrepared']:caller=l['name'];break
  cur=pa.get(cur)
 if caller=='scorePrepared' and n['callFrame']['url'].startswith('wasm:'):
  k=n['callFrame']['functionName'];rows[k][0]+=dt;rows[k][1]+=1
f=read('endpoints-internal-leaves.json');assert sum(x[0] for x in rows.values())==f['totalSelfUs']==2350798
for x in f['rows']:assert rows[x['function']]==[x['selfUs'],x['selfSamples']]
assert read('endpoints-wasm-names.json')=={'customSections':[],'functionNames':{}}
parts=re.split(r'\\n(?=[0-9a-f]{8} <)',gzip.decompress((p/'c230-wasm-disassembly.txt.gz').read_bytes()).decode())[1:];assert len(parts)==144 and '<CODE>' in parts[0]
for i in [26,28,31,34,52,59]:assert parts[i].encode()==gzip.decompress((p/('c230-function-'+str(i)+'.txt.gz')).read_bytes())
assert '<geo_score_prepared>' in parts[59] and 'call\\t34' in parts[59]
a=read('close-profile-source-summary.json');assert next(x for x in a['wasmExportMap'] if x['name']=='geo_score_prepared')['index']==59 and next(x for x in a['wasmExportMap'] if x['name']=='geo_prepare')['index']==57
print('PASS: existing profile leaf counts and actual new export/snippet mapping; symbolic names remain inference')
"""
(r/'verify-evidence.py').write_text(ver)
(r/'package-producer.py').write_bytes(pathlib.Path(__file__).read_bytes())
s['artifacts']=[]
for file in sorted(r.iterdir()):
 if not file.is_file():continue
 raw=file.read_bytes();z=gzip.compress(raw,mtime=0);name=file.name+'.gz';(o/name).write_bytes(z);s['artifacts'].append(dict(path=name,rawBytes=len(raw),rawSHA256=h(raw),gzipBytes=len(z),gzipSHA256=h(z),originalRemotePath='/tmp/tenka-endpoints-current23-evidence/'+file.name))
(o/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
(o/'README.md').write_text(f'''# Geographic scoring endpoint native evidence

Frozen runtime `{s['candidateCommit']}` ran once on sim3 with the same current23 dependency cohort as feab (`44c3b30`):14,765 dependency files and23 installed Pixi patch targets. Three source/dependency checkpoints match. The1,524 source proofs now include full frozen e2e along with src/public/rust/tools/tests and root config. Public files are copied; only node_modules shares the original fresh current23 tree. Actual WASM is {len(wasm):,} bytes, `{h(wasm)}`.

The parent decided to withdraw this candidate: close FPS fell0.911%, geographic layout parent cost rose1.308%, score WASM cost rose1.618%, and the binary grew1,286bytes. The source revert was pending when this evidence was committed; c230 raw pins remain unchanged. New helper correspondence is useful diagnostic inference, not demonstrated performance benefit.

Nine settled full published payloads match reference `af4ddbc9c9232041f23b3cd37fdb802681d1ffce7a4709eaa7dc5031f6cebe29` byte for byte, with only the original four named nonvisual counter exclusions.

| Camera | Average FPS | feab baseline | Change | p95 ms | Strict60 |
|---|---:|---:|---:|---:|---|
'''+''.join(f"| {x['camera']} | {x['averageFps']:.4f} | {x['baselineAverageFps']:.4f} | {x['observedAverageFpsChangePercent']:+.3f}% | {x['frameTimeP95']:.3f} | RED |\n" for x in fps)+f'''
Original120 canonical armies at1920×1080 controls ran once30seconds per camera, sequentially without retry or changed thresholds. No baseline was rerun. Actual controls and profile pre/post guards show RTX5070Ti Vulkan. Canonical state and renderer resources match before/after. These are single-window observations; strict60 remains RED.

One separate close CPUprofile completed {f} renders/{p['measurement']['frames']} intervals in {p['measurement']['durationMs']:.3f} ms; sampled span {a['totalUs']} µs. Driver ticks0. Geographic layout parent inclusive cost {gm:.4f} ms/render versus feab {bm:.4f} ({(gm/bm-1)*100:+.3f}%). Signature own sampled cost {sig['selfUs']} µs; prepare inclusive {prep['inclusiveUs']} µs; scorePrepared inclusive {score['inclusiveUs']} µs. These inclusive rows contain child work and must not be added. Actual export map, direct export own/inclusive rows, nearest-mapped-JS-caller WASM leaf grouping, current served JS/maps and raw profile are retained. Cache captures span more than the CPU window; no exact per-frame hit-rate claim is made.

The actual stripped binary has no name/DWARF sections. Function26 is inferred as overlap_candidate-like from supplied right/bottom scalar parameters, padding and clipping arithmetic. Its own scoring samples are1,241,988µs/1,183samples (52.83% of score WASM leaf time), or3.8812ms/render versus feab overlap-like44 at3.8669ms/render. Internal capsule-like52 is18.87%; directexport59 calls internal34. Actual binary disassembly/snippets and existing-profile leaf reconstruction are preserved; Rust names remain inference.

The premature source transfer referenced its manifest before the existing archive producer finished. The captured scp missing-file RED and its observed outer-shell exit0 are preserved; the individual scp exit was not captured. The same live archive producer completed; finalized archive and manifest hashes matched before successful setup/build. No measurement had started at that failure. All original FPS failures remain untouched.

Each raw artifact is gzip compressed without byte rewriting; summary records raw and gzip byte counts and SHA256. Decompress verify-evidence.py.gz and run it with this directory to verify source/dependency checkpoints, full payload, original REDs, RTX guards and state/resource/profile proofs. No production source was edited for collection.
''')
print(len(s['artifacts']),sum(x['gzipBytes'] for x in s['artifacts']))

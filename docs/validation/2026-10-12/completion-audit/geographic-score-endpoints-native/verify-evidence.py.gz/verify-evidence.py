import sys,pathlib,json,gzip,hashlib
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text())
def read(n):return json.loads(gzip.decompress((p/(n+'.gz')).read_bytes()))
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert hashlib.sha256(z).hexdigest()==a['gzipSHA256'];assert hashlib.sha256(b).hexdigest()==a['rawSHA256']
for phase in ['before','after','final']:
 q=read('source-'+phase+'-proof.json');assert q['allMatch'] and len(q['files'])==1524 and not q['extras'] and not q['publicSymlinks']
 q=read('dependency-'+phase+'-proof.json');assert len(q['files'])==14765 and len(q['patches'])==23 and all(r['match'] for r in q['files']+q['patches'])
published=gzip.decompress((p/'published.raw.json.gz').read_bytes());assert hashlib.sha256(published).hexdigest()=='af4ddbc9c9232041f23b3cd37fdb802681d1ffce7a4709eaa7dc5031f6cebe29'
for c in ['overview','operational','close']:
 q=read(c+'.raw.json');assert 'RTX 5070 Ti' in q['environment']['renderer'] and 'Vulkan' in q['environment']['renderer'];assert q['measurement']['resourcesBefore']==q['measurement']['resourcesAfter'];assert '1 failed' in gzip.decompress((p/(c+'.log.gz')).read_bytes()).decode()
for q in read('state-resource-proof.json'):assert q['canonicalByteEqual'] and q['resourceObjectsEqual'] and q['canonicalBeforeSha256']==q['canonicalAfterSha256']
q=read('close-profile-summary.json');assert q['canonicalStateByteEqual'] and q['driver']['ticks']==0 and q['canonicalBeforeSha256']==q['canonicalAfterSha256'] and q['resourceBeforeSha256']==q['resourceAfterSha256']
for n in ['gpu-before','gpu-after-functional','gpu-before-profile','gpu-after-profile']:
 q=next(r for r in read(n+'.json') if r['context']);assert 'RTX 5070 Ti' in q['renderer'] and 'Vulkan' in q['renderer'] and not q['contextLost']
assert len(read('profile-caller-attribution.json')['mappedNodes'])>0
print('PASS: all dual hashes, three source/dependency checkpoints, exact9payload, three original strict60REDs, actual RTX pre/post guards, canonical/resource and uniqueprofile proofs')

# Recompute existing-profile exclusive WASM leaf rows, and actual new export indices.
import collections,re
q=read('close.cpuprofile');m=read('profile-caller-attribution.json');ns={n['id']:n for n in q['nodes']};labels={n['id']:n for n in m['mappedNodes']};pa={c:n['id'] for n in q['nodes'] for c in n.get('children',[])};rows=collections.defaultdict(lambda:[0,0])
for id,dt in zip(q['samples'],q['timeDeltas']):
 n=ns[id];cur=id;caller=None
 while cur is not None:
  l=labels[cur]
  if l['source'].endswith('/wasmGeographicPreparation.ts') and l['name'] in ['prepare','scorePrepared']:caller=l['name'];break
  cur=pa.get(cur)
 if caller=='scorePrepared' and n['callFrame']['url'].startswith('wasm:'):
  k=n['callFrame']['functionName'];rows[k][0]+=dt;rows[k][1]+=1
f=read('endpoints-internal-leaves.json');assert sum(x[0] for x in rows.values())==f['totalSelfUs']==2350798
for x in f['rows']:assert rows[x['function']]==[x['selfUs'],x['selfSamples']]
assert read('endpoints-wasm-names.json')=={'customSections':[],'functionNames':{}}
parts=re.split(r'\n(?=[0-9a-f]{8} <)',gzip.decompress((p/'c230-wasm-disassembly.txt.gz').read_bytes()).decode())[1:];assert len(parts)==144 and '<CODE>' in parts[0]
for i in [26,28,31,34,52,59]:assert parts[i].encode()==gzip.decompress((p/('c230-function-'+str(i)+'.txt.gz')).read_bytes())
assert '<geo_score_prepared>' in parts[59] and 'call\t34' in parts[59]
a=read('close-profile-source-summary.json');assert next(x for x in a['wasmExportMap'] if x['name']=='geo_score_prepared')['index']==59 and next(x for x in a['wasmExportMap'] if x['name']=='geo_prepare')['index']==57
print('PASS: existing profile leaf counts and actual new export/snippet mapping; symbolic names remain inference')

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: army-plate-layout.spec.ts >> native army number-plate placement >> the three observed dense-cluster plate pairs no longer overlap independently of castle ribbons
- Location: e2e/army-plate-layout.spec.ts:370:3

# Error details

```
Error: Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1561年3月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 3,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 26,306
            - generic "兵糧可支撐6個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "6"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 5,200
            - generic [ref=e44]: /3,000
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "300"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 800" [ref=e130]:
          - generic [ref=e131]: 兵力 800
        - img "兵糧 6,916" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,916
        - img "耐久 1,000" [ref=e138]:
          - generic [ref=e139]: 耐久 1,000
        - img "士氣 80" [ref=e142]:
          - generic [ref=e143]: 士氣 80
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - generic:
    - button "通報 1 則" [ref=e154] [cursor=pointer]:
      - img [ref=e155]
    - generic "通報 1 則" [ref=e157]:
      - alert [ref=e158]:
        - generic [ref=e159]:
          - img [ref=e161]
          - generic [ref=e163]:
            - strong [ref=e164]: 駿府城遭織田家包圍！
            - time [ref=e165]: 1561年3月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
    - button "報告中心" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  40  | // Independent, unpadded intersection area. Diagnostics expose actual part
  41  | // bounds, not rendered glyph pixels; retained screenshots need visual review.
  42  | function intersection(a: Rect, b: Rect): number {
  43  |   return (
  44  |     Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)) *
  45  |     Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y))
  46  |   );
  47  | }
  48  | 
  49  | // Rectangle union, not a sum: overlapping HUD panels must not be subtracted twice.
  50  | function visibleArea(rect: Rect, canvas: Rect, hud: Rect[]): number {
  51  |   const left = Math.max(rect.x, canvas.x),
  52  |     right = Math.min(rect.x + rect.width, canvas.x + canvas.width),
  53  |     top = Math.max(rect.y, canvas.y),
  54  |     bottom = Math.min(rect.y + rect.height, canvas.y + canvas.height);
  55  |   if (right <= left || bottom <= top) return 0;
  56  |   const xs = [...new Set([left, right, ...hud.flatMap((r) => [r.x, r.x + r.width])])]
  57  |     .filter((x) => x >= left && x <= right)
  58  |     .sort((a, b) => a - b);
  59  |   const ys = [...new Set([top, bottom, ...hud.flatMap((r) => [r.y, r.y + r.height])])]
  60  |     .filter((y) => y >= top && y <= bottom)
  61  |     .sort((a, b) => a - b);
  62  |   let area = 0;
  63  |   for (let i = 1; i < xs.length; i++)
  64  |     for (let j = 1; j < ys.length; j++) {
  65  |       const x = (xs[i - 1]! + xs[i]!) / 2,
  66  |         y = (ys[j - 1]! + ys[j]!) / 2;
  67  |       if (!hud.some((r) => x > r.x && x < r.x + r.width && y > r.y && y < r.y + r.height))
  68  |         area += (xs[i]! - xs[i - 1]!) * (ys[j]! - ys[j - 1]!);
  69  |     }
  70  |   return area;
  71  | }
  72  | 
  73  | function overlap(data: Awaited<ReturnType<typeof layout>>, baseline: boolean): number {
  74  |   let area = 0;
  75  |   data.plates.forEach((plate, index) => {
  76  |     const rect = baseline ? plate.baseline : plate.rect;
  77  |     for (const castle of data.castles) area += intersection(rect, castle.rect);
  78  |     for (const other of data.plates.slice(index + 1))
  79  |       area += intersection(rect, baseline ? other.baseline : other.rect);
  80  |   });
  81  |   return area;
  82  | }
  83  | 
  84  | async function mapIdleOrRetry(page: Page): Promise<boolean> {
  85  |   return page.evaluate(async () => {
  86  |     if ((window as Window & { __TENKA_ARMY_BOOT_PROBE__?: boolean }).__TENKA_ARMY_BOOT_PROBE__)
  87  |       console.info(
  88  |         `[army-boot] ${JSON.stringify({
  89  |           stage: 'evaluate-enter',
  90  |           browserEpochMs: performance.timeOrigin + performance.now(),
  91  |           browserMonotonicMs: performance.now(),
  92  |         })}`,
  93  |       );
  94  |     try {
  95  |       await (window as DebugWindow).__tenka.debug.waitMapIdle();
  96  |       if ((window as Window & { __TENKA_ARMY_BOOT_PROBE__?: boolean }).__TENKA_ARMY_BOOT_PROBE__)
  97  |         console.info(
  98  |           `[army-boot] ${JSON.stringify({
  99  |             stage: 'evaluate-idle-resolved',
  100 |             browserEpochMs: performance.timeOrigin + performance.now(),
  101 |             browserMonotonicMs: performance.now(),
  102 |           })}`,
  103 |         );
  104 |       return true;
  105 |     } catch (error) {
  106 |       if ((window as Window & { __TENKA_ARMY_BOOT_PROBE__?: boolean }).__TENKA_ARMY_BOOT_PROBE__)
  107 |         console.info(
  108 |           `[army-boot] ${JSON.stringify({
  109 |             stage: 'evaluate-error',
  110 |             browserEpochMs: performance.timeOrigin + performance.now(),
  111 |             browserMonotonicMs: performance.now(),
  112 |             message: error instanceof Error ? error.message : String(error),
  113 |           })}`,
  114 |         );
  115 |       if (
  116 |         error instanceof Error &&
  117 |         error.message ===
  118 |           '__TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）'
  119 |       )
  120 |         return false;
  121 |       throw error;
  122 |     }
  123 |   });
  124 | }
  125 | 
  126 | async function boot(page: Page) {
  127 |   const title = test.info().title;
  128 |   page.on('console', (message) => {
  129 |     if (!message.text().startsWith('[army-boot]')) return;
  130 |     process.stdout.write(
  131 |       `${JSON.stringify({ title, deliveredEpochMs: Date.now(), browserRecord: message.text() })}\n`,
  132 |     );
  133 |   });
  134 |   await page.addInitScript(() => {
  135 |     (window as Window & { __TENKA_ARMY_BOOT_PROBE__?: boolean }).__TENKA_ARMY_BOOT_PROBE__ = true;
  136 |   });
  137 |   await page.goto('/?debug=visual-map');
  138 |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  139 |   await page.evaluate(() => document.fonts.ready);
> 140 |   await expect.poll(() => mapIdleOrRetry(page)).toBe(true);
      |                                                 ^ Error: Timeout 5000ms exceeded while waiting on the predicate
  141 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  142 | }
  143 | 
  144 | async function setScale(page: Page, scale: 0.8 | 1 | 1.5) {
  145 |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  146 |   await page.getByRole('button', { name: '設定', exact: true }).click();
  147 |   const dialog = page.getByRole('dialog');
  148 |   const slider = dialog.getByRole('slider', { name: '介面縮放', exact: true });
  149 |   await slider.press(scale === 1.5 ? 'End' : 'Home');
  150 |   if (scale === 1) for (let step = 0; step < 4; step++) await slider.press('ArrowRight');
  151 |   await expect(slider).toHaveValue(String(scale));
  152 |   await expect
  153 |     .poll(() => page.evaluate(() => getComputedStyle(document.documentElement).fontSize))
  154 |     .toBe(`${16 * scale}px`);
  155 |   await dialog.getByRole('button', { name: '返回', exact: true }).click();
  156 |   await page.getByRole('button', { name: '回到遊戲', exact: true }).click();
  157 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  158 | }
  159 | 
  160 | async function nearCastle(page: Page, id: 'castle.sunpu' | 'castle.narumi') {
  161 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.setMapCameraPreset('close'));
  162 |   if (id === 'castle.narumi') {
  163 |     const position = await page.evaluate(() => {
  164 |       const game = (window as DebugWindow).__tenka.debug.getState();
  165 |       return Object.values(game.castles).find((castle) => castle.id === 'castle.narumi')!.pos;
  166 |     });
  167 |     const mini = page.getByTestId('minimap-frame');
  168 |     const box = await mini.boundingBox();
  169 |     expect(box).not.toBeNull();
  170 |     await mini.click({
  171 |       position: { x: (position.x / 4096) * box!.width, y: (position.y / 4096) * box!.height },
  172 |     });
  173 |   }
  174 |   await page.evaluate(() => (window as DebugWindow).__tenka.debug.waitMapIdle(3));
  175 | }
  176 | 
  177 | test.describe('native army number-plate placement', () => {
  178 |   test.use({
  179 |     viewport: { width: 1280, height: 720 },
  180 |     deviceScaleFactor: 1,
  181 |     contextOptions: { reducedMotion: 'reduce' },
  182 |   });
  183 | 
  184 |   test('boot retries only the documented unmounted renderer error', async ({ page }) => {
  185 |     await page.goto('about:blank');
  186 |     await page.evaluate(() => {
  187 |       Object.assign(window, { __idleCalls: 0 });
  188 |       Object.defineProperty(window, '__tenka', {
  189 |         configurable: true,
  190 |         value: {
  191 |           debug: {
  192 |             waitMapIdle() {
  193 |               const state = window as unknown as { __idleCalls: number };
  194 |               if (++state.__idleCalls === 1)
  195 |                 return Promise.reject(new Error('unexpected idle failure'));
  196 |               return Promise.resolve();
  197 |             },
  198 |           },
  199 |         },
  200 |       });
  201 |     });
  202 |     await expect(expect.poll(() => mapIdleOrRetry(page)).toBe(true)).rejects.toThrow(
  203 |       'unexpected idle failure',
  204 |     );
  205 |     expect(
  206 |       await page.evaluate(() => (window as unknown as { __idleCalls: number }).__idleCalls),
  207 |     ).toBe(1);
  208 |     await page.evaluate(() => {
  209 |       Object.assign(window, { __idleCalls: 0 });
  210 |       Object.defineProperty(window, '__tenka', {
  211 |         configurable: true,
  212 |         value: {
  213 |           debug: {
  214 |             waitMapIdle() {
  215 |               const state = window as unknown as { __idleCalls: number };
  216 |               if (++state.__idleCalls === 1)
  217 |                 return Promise.reject(
  218 |                   new Error(
  219 |                     '__TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）',
  220 |                   ),
  221 |                 );
  222 |               return Promise.resolve();
  223 |             },
  224 |           },
  225 |         },
  226 |       });
  227 |     });
  228 |     await expect.poll(() => mapIdleOrRetry(page)).toBe(true);
  229 |     expect(
  230 |       await page.evaluate(() => (window as unknown as { __idleCalls: number }).__idleCalls),
  231 |     ).toBe(2);
  232 |   });
  233 | 
  234 |   test('the independent tether oracle detects interiors but excludes edge and corner touches', () => {
  235 |     const rect = { x: 0, y: 0, width: 10, height: 10 };
  236 |     for (const [start, end, expected] of [
  237 |       [{ x: -5, y: 5 }, { x: 15, y: 5 }, true],
  238 |       [{ x: 5, y: -5 }, { x: 5, y: 15 }, true],
  239 |       [{ x: -5, y: -5 }, { x: 15, y: 15 }, true],
  240 |       [{ x: -5, y: 5 }, { x: 5, y: -5 }, false],
```
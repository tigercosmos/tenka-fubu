# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: army-plate-material.spec.ts >> army plate material retains actual selected army and mandatory far channels
- Location: e2e/army-plate-material.spec.ts:26:1

# Error details

```
Error: page.evaluate: Error: __TENKA_DEBUG__: map renderer 尚未掛載（尚未進入含地圖的畫面，如 MainScreen）
    at ra (http://localhost:4173/assets/index-C4klHJcU.js:106:249748)
    at Object.setMapCameraPreset (http://localhost:4173/assets/index-C4klHJcU.js:106:254915)
    at eval (eval at evaluate (:303:30), <anonymous>:1:28)
    at UtilityScript.evaluate (<anonymous>:305:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e5]:
    - group [ref=e6]:
      - generic "戰略圖層 · 一般地圖" [ref=e7] [cursor=pointer]
  - banner [ref=e8]:
    - group "金錢、兵糧、兵力、威信" [ref=e9]:
      - generic [ref=e10]:
        - group "織田家" [ref=e11]
        - time [ref=e13]: 1561年3月1日
        - generic [ref=e14]:
          - generic [ref=e15]:
            - img [ref=e16]
            - generic [ref=e19]: 金錢
          - strong [ref=e22]: 3,000
        - generic [ref=e23]:
          - generic [ref=e24]:
            - img [ref=e25]
            - generic [ref=e27]: 兵糧
          - generic [ref=e28]:
            - strong [ref=e30]: 26,306
            - generic "兵糧可支撐6個月" [ref=e31]:
              - text: 兵糧可支撐
              - strong [ref=e32]: "6"
              - text: 個月
        - generic [ref=e33]:
          - generic [ref=e34]:
            - img [ref=e35]
            - generic [ref=e39]: 兵力
          - generic [ref=e41]:
            - strong [ref=e42]: 5,200
            - generic [ref=e43]: /3,000
        - generic [ref=e44]:
          - generic [ref=e45]:
            - img [ref=e46]
            - generic [ref=e48]: 威信
          - strong [ref=e51]: "300"
    - generic [ref=e52]:
      - generic [ref=e53]:
        - button "暫停" [pressed] [ref=e54] [cursor=pointer]:
          - img [ref=e55]
        - button "一倍速" [ref=e57] [cursor=pointer]:
          - img [ref=e58]
        - button "二倍速" [ref=e60] [cursor=pointer]:
          - img [ref=e61]
        - button "五倍速" [ref=e63] [cursor=pointer]:
          - img [ref=e64]
      - button "系統選單" [ref=e66] [cursor=pointer]:
        - img [ref=e67]
  - navigation "內政" [ref=e70]:
    - button "地圖一覽" [ref=e71] [cursor=pointer]:
      - img [ref=e72]
      - generic [ref=e75]:
        - generic [ref=e76]: 地圖
        - generic [ref=e77]: 一覽
    - button "織田家 （本城）" [ref=e78] [cursor=pointer]:
      - img [ref=e79]
      - generic "織田家" [ref=e84]: 織田
    - generic [ref=e86]: 軍政
    - button "軍事" [ref=e87] [cursor=pointer]:
      - img [ref=e88]
      - text: 軍事
    - button "內政" [ref=e90] [cursor=pointer]:
      - img [ref=e91]
      - text: 內政
    - button "武將" [ref=e93] [cursor=pointer]:
      - img [ref=e94]
      - text: 武將
    - generic [ref=e99]: 交涉
    - button "外交" [ref=e100] [cursor=pointer]:
      - img [ref=e101]
      - text: 外交
    - button "調略" [ref=e103] [cursor=pointer]:
      - img [ref=e104]
      - text: 調略
    - generic [ref=e108]: 國策
    - button "政策" [ref=e109] [cursor=pointer]:
      - img [ref=e110]
      - text: 政策
    - button "軍團" [ref=e112] [cursor=pointer]:
      - img [ref=e113]
      - text: 軍團
    - button "大命" [ref=e115] [cursor=pointer]:
      - img [ref=e116]
      - text: 大命
  - generic [ref=e119]:
    - generic [ref=e120]:
      - generic [ref=e121]: 鳴海城（尾張）
      - button "鳴海城（尾張）" [ref=e122] [cursor=pointer]:
        - img [ref=e123]
    - generic [ref=e126]:
      - generic [ref=e128]:
        - img "兵力 800" [ref=e129]:
          - generic [ref=e130]: 兵力 800
        - img "兵糧 6,916" [ref=e133]:
          - generic [ref=e134]: 兵糧 6,916
        - img "耐久 1,000" [ref=e137]:
          - generic [ref=e138]: 耐久 1,000
        - img "士氣 80" [ref=e141]:
          - generic [ref=e142]: 士氣 80
      - generic [ref=e145]:
        - button "城面板" [ref=e146] [cursor=pointer]
        - button "出陣" [ref=e147] [cursor=pointer]
        - button "輸送" [ref=e148] [cursor=pointer]
  - img "全國小地圖" [ref=e149]
  - generic:
    - button "通報 1 則" [ref=e153] [cursor=pointer]:
      - img [ref=e154]
    - generic "通報 1 則" [ref=e156]:
      - alert [ref=e157]:
        - generic [ref=e158]:
          - img [ref=e160]
          - generic [ref=e162]:
            - strong [ref=e163]: 駿府城遭織田家包圍！
            - time [ref=e164]: 1561年3月1日
          - button "關閉通知" [ref=e166] [cursor=pointer]:
            - img [ref=e167]
    - button "報告中心" [ref=e169] [cursor=pointer]
```
import { writeFile } from 'node:fs/promises';
import { test, expect } from './fixtures';
test('diagnostic blank GPU RAF ceiling; no game acceptance', async ({page},info) => {
  await page.setViewportSize({width:1920,height:1080});
  await page.emulateMedia({reducedMotion:'no-preference'});
  await page.goto('about:blank');
  await page.setContent('<style>body{margin:0}</style><canvas width="1920" height="1080"></canvas>');
  const measurement=await page.evaluate(async()=>{
    const canvas=document.querySelector('canvas')!;
    const gl=canvas.getContext('webgl2')??canvas.getContext('webgl');
    if(!gl)throw Error('No WebGL');
    const extension=gl.getExtension('WEBGL_debug_renderer_info');
    const environment={userAgent:navigator.userAgent,renderer:String(gl.getParameter(extension?extension.UNMASKED_RENDERER_WEBGL:gl.RENDERER)),visibility:document.visibilityState,dpr:devicePixelRatio,viewport:[innerWidth,innerHeight],canvas:[canvas.width,canvas.height]};
    for(let i=0;i<3;i++)await new Promise<void>(resolve=>requestAnimationFrame(()=>{gl.clearColor(0.02,0.08,0.1,1);gl.clear(gl.COLOR_BUFFER_BIT);resolve()}));
    const schedulerIntervals:number[]=[],completionIntervals:number[]=[];
    const start=performance.now();let first:number|null=null,last:number|null=null,previousScheduler:number|null=null,frames=0;
    await new Promise<void>(resolve=>{
      const frame=(scheduler:number)=>{
        gl.clearColor(0.02,0.08,0.1+(frames%2)*0.001,1);gl.clear(gl.COLOR_BUFFER_BIT);
        const now=performance.now();first??=now;frames++;
        if(last!==null)completionIntervals.push(now-last);if(previousScheduler!==null)schedulerIntervals.push(scheduler-previousScheduler);
        last=now;previousScheduler=scheduler;
        if(now-start>=30000)resolve();else requestAnimationFrame(frame);
      };requestAnimationFrame(frame);
    });
    const end=performance.now();const p95=(values:number[])=>values.toSorted((a,b)=>a-b)[Math.ceil(values.length*0.95)-1]!;
    return{scope:'diagnostic/no-game/blank-hardware-WebGL/rAF-and-post-clear',environment,durationMs:end-start,frames,averageFps:1000*frames/(end-start),schedulerP95Ms:p95(schedulerIntervals),completionP95Ms:p95(completionIntervals),headGapMs:first!-start,tailGapMs:end-last!,schedulerIntervals,completionIntervals};
  });
  const path=info.outputPath('native-no-game-raf.raw.json');
  await writeFile(path,JSON.stringify(measurement,null,2));await info.attach('diagnostic-raw-cadence',{path,contentType:'application/json'});
  expect(measurement.environment.renderer).not.toMatch(/swiftshader|llvmpipe|software/i);
  expect(measurement.environment.visibility).toBe('visible');
  expect(measurement.durationMs).toBeGreaterThanOrEqual(30000);
  // Sensitivity probe applies the current strict renderer gates unchanged.
  // Failure diagnoses the environment; it is not an application defect verdict.
  expect(measurement.averageFps).toBeGreaterThanOrEqual(60);
  expect(measurement.completionP95Ms).toBeLessThanOrEqual(1000/60);
});

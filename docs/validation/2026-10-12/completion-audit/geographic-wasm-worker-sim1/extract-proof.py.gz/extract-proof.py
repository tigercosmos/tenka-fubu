import pathlib,json,gzip,hashlib,copy
p=pathlib.Path('/tmp/tenka-fb9fd7f-wasm-worker-evidence')
def decode(value,objects=None):
 if objects is None:objects={}
 if 'ref'in value:return objects[value['ref']]
 if 'o'in value:
  result={}
  if 'id'in value:objects[value['id']]=result
  for item in value['o']:result[item['k']]=decode(item['v'],objects)
  return result
 if 'a'in value:
  result=[]
  if 'id'in value:objects[value['id']]=result
  result.extend(decode(item,objects)for item in value['a']);return result
 for key in ['s','n','b']:
  if key in value:return value[key]
 if value.get('v')=='null':return None
 raise ValueError(value)
report=json.loads((p/'report-2f146aecbcd2c5b32fbb.json').read_text())
for test in report['tests']:
 for result in test['results']:
  for attachment in result['attachments']:
   if attachment.get('contentType')=='application/json':
    name=attachment['name']+'.json'
    raw=(p/'original-playwright-report'/attachment['path']).read_bytes()if attachment.get('path')else attachment['body'].encode()
    (p/name).write_bytes(raw)
rows=[json.loads(line)for line in (p/'failed-0-trace.trace').read_text().splitlines()]
for row in rows:
 if row.get('type')!='after' or 'result'not in row or 'value'not in row['result']:continue
 value=row['result']['value']
 if 's'in value and value['s'].startswith('{"meta"'):
  (p/f"failed-snapshot-{row['callId']}.json").write_bytes(value['s'].encode());continue
 try:result=decode(value)
 except ValueError:continue
 if isinstance(result,dict):
  if 'wasmLoaded'in result or 'inconsistentThreatTotals'in str(result)or ('formatVersion'in result and 'entries'in result):
   (p/f"failed-decoded-{row['callId']}.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads(gzip.decompress((p/'source-manifest.json.gz').read_bytes()));repo=pathlib.Path('/tmp/tenka-fb9fd7f-wasm-worker-sim1');mismatches=[]
for row in manifest['files']:
 f=repo/row['path']
 if not f.is_file():mismatches.append({'path':row['path'],'reason':'missing'});continue
 raw=f.read_bytes()
 if len(raw)!=row['bytes']or hashlib.sha256(raw).hexdigest()!=row['sha256']:mismatches.append({'path':row['path'],'reason':'hash mismatch'})
(p/'source-verification.json').write_text(json.dumps({'commit':manifest['commit'],'checkedFiles':len(manifest['files']),'mismatches':mismatches},indent=2)+'\n');assert not mismatches
print('sources',len(manifest['files']),'tests',[(t['title'],t['results'][0]['status'])for t in report['tests']])
for file in p.glob('failed-decoded*'):print(file.name,list(json.loads(file.read_text())))

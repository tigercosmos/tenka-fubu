# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: worker-simulation.spec.ts >> native seeded full-world worker ticks preserve queued commands, complete state and replay log
- Location: e2e/worker-simulation.spec.ts:123:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1560年1月4日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 2,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 11,956
            - generic "兵糧可支撐26個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "26"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 4,517
            - generic [ref=e44]: /4,662
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "250"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [active] [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic:
    - generic:
      - generic:
        - button:
          - img
  - img "全國小地圖" [ref=e119]
  - button "報告中心" [ref=e122] [cursor=pointer]
```

# Test source

```ts
  105 |     ),
  106 |   );
  107 |   const engine = createRuntimeEventEngine(catalog.events);
  108 |   const recorder = new CommandLogRecorder();
  109 |   if (loaded) recorder.reset({ incompleteReason: 'loadedGame' });
  110 |   for (let day = 0; day < days; day++) {
  111 |     enqueuePendingAiOrders(state, queue);
  112 |     const submitted = queue.drain();
  113 |     const result = advanceDay(state, submitted, { eventEngine: engine });
  114 |     recorder.recordTick(result.appliedCommands, {
  115 |       ...(result.appliedCommands.length === submitted.length
  116 |         ? {}
  117 |         : { incompleteReason: 'hardRejection' as const }),
  118 |     });
  119 |   }
  120 |   return { state, log: recorder.export(state) };
  121 | }
  122 | 
  123 | test('native seeded full-world worker ticks preserve queued commands, complete state and replay log', async ({
  124 |   page,
  125 | }, info) => {
  126 |   const workers: string[] = [];
  127 |   const wasmResponses: { url: string; status: number }[] = [];
  128 |   page.on('worker', (worker) => workers.push(worker.url()));
  129 |   page.on('response', (response) => {
  130 |     if (new URL(response.url()).pathname.endsWith('/wasm/tenka_engine.wasm'))
  131 |       wasmResponses.push({ url: response.url(), status: response.status() });
  132 |   });
  133 |   await observeWorkerTraffic(page);
  134 |   await nativeGame(page);
  135 |   const initial = await snapshot(page);
  136 |   expect(initial.meta.scenarioId).toBe('s1560');
  137 |   expect(initial.meta.seed).toBe(1);
  138 |   expect(Object.keys(initial.clans).length).toBeGreaterThan(20);
  139 |   expect(validateState(initial)).toEqual([]);
  140 |   const clanId = initial.meta.playerClanId;
  141 |   const castle = initial.castles[initial.clans[clanId]!.homeCastleId]!;
  142 |   const candidate = Object.values(initial.officers)
  143 |     .filter(
  144 |       (officer) =>
  145 |         officer.id !== castle.lordId &&
  146 |         officer.status === 'serving' &&
  147 |         officer.clanId === clanId &&
  148 |         officer.locationCastleId === castle.id &&
  149 |         officer.armyId === null &&
  150 |         RANK_VALUES.indexOf(officer.rank) >= RANK_VALUES.indexOf('samurai-taisho'),
  151 |     )
  152 |     .sort((a, b) => a.id.localeCompare(b.id))[0];
  153 |   expect(candidate).toBeDefined();
  154 |   const command: Command = {
  155 |     type: 'appointLord',
  156 |     clanId,
  157 |     castleId: castle.id,
  158 |     officerId: candidate!.id,
  159 |   };
  160 |   const accepted = await page.evaluate((cmd) => window.__tenka.debug.dispatch(cmd), command);
  161 |   expect(accepted.ok).toBe(true);
  162 |   expect(await snapshot(page)).toEqual(initial);
  163 |   const beforeLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  164 |   expect(beforeLog.entries).toEqual([]);
  165 |   // Normal resume must drive the production Worker, including a command that
  166 |   // remained queued during the pause. Stop at an observed day rather than a timer.
  167 |   await page.getByTestId('speed-1').click();
  168 |   await expect
  169 |     .poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day), { intervals: [50] })
  170 |     .toBeGreaterThan(initial.time.day);
  171 |   await page.getByTestId('speed-pause').click();
  172 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  173 |   await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  174 |   const actual = await snapshot(page);
  175 |   const actualLog: CommandLogFile = await page.evaluate(() =>
  176 |     window.__tenka.debug.exportCommandLog(),
  177 |   );
  178 |   const days = actual.time.day - initial.time.day;
  179 |   const reference = synchronousReference(initial, [command], days);
  180 |   expect(days).toBeGreaterThan(0);
  181 |   expect(actual.castles[castle.id]!.lordId).toBe(candidate!.id);
  182 |   expect(validateState(actual)).toEqual([]);
  183 |   expect(actual).toEqual(reference.state);
  184 |   expect(actualLog).toEqual(reference.log);
  185 |   expect(workers.length, 'native strategy days use a real browser Worker').toBeGreaterThan(0);
  186 |   expect(wasmResponses.some((response) => response.status === 200)).toBe(true);
  187 |   const traffic = await page.evaluate(
  188 |     () =>
  189 |       (
  190 |         window as unknown as {
  191 |           __workerEvidence: {
  192 |             created: number;
  193 |             sent: { kind: unknown; requestId: unknown }[];
  194 |             received: { kind: unknown; requestId: unknown; backend: unknown }[];
  195 |             longTasks: { startTime: number; duration: number }[];
  196 |           };
  197 |         }
  198 |       ).__workerEvidence,
  199 |   );
  200 |   expect(traffic.created).toBeGreaterThan(0);
  201 |   expect(traffic.sent.length).toBeGreaterThan(0);
  202 |   expect(traffic.received.some((message) => message.backend === 'rust-wasm')).toBe(true);
  203 |   const simulation = await page.evaluate(() => window.__tenka.debug.getSimulationDiagnostics());
  204 |   expect(simulation.backend).toBe('worker');
> 205 |   expect(simulation.wasmLoaded).toBe(true);
      |                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  206 |   expect(simulation.wasmBackend).toBe('rust-wasm');
  207 |   expect(simulation.completedWorkerTicks).toBeGreaterThanOrEqual(days);
  208 |   expect(simulation.pendingTicks).toBe(0);
  209 |   await info.attach('worker-full-world-reference', {
  210 |     body: JSON.stringify({
  211 |       workers,
  212 |       wasmResponses,
  213 |       traffic,
  214 |       simulation,
  215 |       days,
  216 |       initial,
  217 |       actual,
  218 |       actualLog,
  219 |       reference,
  220 |     }),
  221 |     contentType: 'application/json',
  222 |   });
  223 | });
  224 | 
  225 | test('native save and browser reload preserve an unconsumed command for the next worker day', async ({
  226 |   page,
  227 | }, info) => {
  228 |   await observeWorkerTraffic(page);
  229 |   await nativeGame(page);
  230 |   const initial = await snapshot(page);
  231 |   const clanId = initial.meta.playerClanId;
  232 |   const officer = Object.values(initial.officers).find(
  233 |     (entry) =>
  234 |       entry.clanId === clanId &&
  235 |       entry.id !== initial.clans[clanId]!.leaderId &&
  236 |       entry.status === 'serving' &&
  237 |       entry.hasComeOfAge,
  238 |   );
  239 |   expect(officer).toBeDefined();
  240 |   const command: Command = {
  241 |     type: 'rewardOfficer',
  242 |     clanId,
  243 |     officerId: officer!.id,
  244 |     tier: 'small',
  245 |   };
  246 |   expect(await page.evaluate((cmd) => window.__tenka.debug.dispatch(cmd), command)).toEqual({
  247 |     ok: true,
  248 |   });
  249 |   expect(await snapshot(page)).toEqual(initial);
  250 |   await page.getByRole('button', { name: '系統選單', exact: true }).click();
  251 |   await page.getByRole('button', { name: '存檔', exact: true }).click();
  252 |   const panel = page.getByTestId('save-load-panel');
  253 |   const slot = page.getByTestId('save-slot-manual:1');
  254 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  255 |   await slot.getByRole('button', { name: '存檔', exact: true }).click();
  256 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  257 |   await expect(slot).toContainText(initial.clans[clanId]!.name);
  258 |   await page.reload();
  259 |   await page.getByTestId('title-save-list').click();
  260 |   await expect(panel).toHaveAttribute('aria-busy', 'false');
  261 |   await slot.getByRole('button', { name: '載入', exact: true }).click();
  262 |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  263 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  264 |   expect(await snapshot(page)).toEqual(initial);
  265 |   await page.getByTestId('speed-1').click();
  266 |   await expect
  267 |     .poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day), { intervals: [50] })
  268 |     .toBeGreaterThan(initial.time.day);
  269 |   await page.getByTestId('speed-pause').click();
  270 |   await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  271 |   const actual = await snapshot(page);
  272 |   const actualLog = await page.evaluate(() => window.__tenka.debug.exportCommandLog());
  273 |   const reference = synchronousReference(
  274 |     initial,
  275 |     [command],
  276 |     actual.time.day - initial.time.day,
  277 |     true,
  278 |   );
  279 |   expect(actual).toEqual(reference.state);
  280 |   expect(actualLog).toEqual(reference.log);
  281 |   expect(actualLog.entries.filter((entry) => entry.command.type === 'rewardOfficer')).toHaveLength(
  282 |     1,
  283 |   );
  284 |   await info.attach('worker-pending-save-reload-reference', {
  285 |     body: JSON.stringify({ initial, command, actual, actualLog, reference }),
  286 |     contentType: 'application/json',
  287 |   });
  288 | });
  289 | 
  290 | for (const days of [60, 120]) {
  291 |   test(`same-host full-world ${days}-day synchronous and Worker measurements preserve complete state`, async ({
  292 |     page,
  293 |   }, info) => {
  294 |     await observeWorkerTraffic(page);
  295 |     const rows = [];
  296 |     const states: GameState[] = [];
  297 |     const logs: CommandLogFile[] = [];
  298 |     for (const backend of ['sync', 'worker'] as const) {
  299 |       await nativeGame(page);
  300 |       await page.evaluate(() => window.__tenka.debug.waitMapIdle(2));
  301 |       const initial = await snapshot(page);
  302 |       const measure = async (n: number) =>
  303 |         page.evaluate(
  304 |           async ({ backend, n }) => {
  305 |             const longTasks: { startTime: number; duration: number }[] = [];
```
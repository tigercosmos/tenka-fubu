new MapRenderer();
new MapRenderer(owner);
// new MapRenderer();

const fs = require('node:fs');
const path = require('node:path');
const ts = require('/Users/tigercosmos/tenka-fubu/node_modules/typescript');
const root = process.argv[2] || process.cwd();
const files = [];
function walk(dir) { for (const e of fs.readdirSync(dir,{withFileTypes:true})) { const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else if(/\.spec\.tsx?$/.test(p)) files.push(p); } }
for (const dir of ['src','tests']) walk(path.join(root,dir));
let count=0;
for (const file of files.sort()) {
 const text=fs.readFileSync(file,'utf8');
 const ast=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,file.endsWith('tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 function visit(n) {
  if(ts.isNewExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='MapRenderer'&&(!n.arguments||n.arguments.length===0)) {
   const line=ast.getLineAndCharacterOfPosition(n.getStart(ast)).line+1;
   console.log(`${path.relative(root,file)}:${line} -- unit fixture requires explicit compiled render WASM owner`);count++;
  }
  ts.forEachChild(n,visit);
 }
 visit(ast);
}
console.log('EXCLUDED: production/non-spec files, e2e, dependencies, generated artifacts');
console.log(`VIOLATIONS: ${count}`);

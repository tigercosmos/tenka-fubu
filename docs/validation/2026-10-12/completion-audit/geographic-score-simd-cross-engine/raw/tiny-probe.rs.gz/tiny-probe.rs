use core::arch::wasm32::*;
fn js_min(a: f64, b: f64) -> f64 {
    if a.is_nan() || b.is_nan() { f64::NAN }
    else if a == 0.0 && b == 0.0 { if a.is_sign_negative() || b.is_sign_negative() { -0.0 } else { 0.0 } }
    else if a < b { a } else { b }
}
fn js_max(a: f64, b: f64) -> f64 {
    if a.is_nan() || b.is_nan() { f64::NAN }
    else if a == 0.0 && b == 0.0 { if a.is_sign_negative() && b.is_sign_negative() { -0.0 } else { 0.0 } }
    else if a > b { a } else { b }
}
#[no_mangle]
pub extern "C" fn scalar(ax:f64,ay:f64,aw:f64,ah:f64,bx:f64,by:f64,bw:f64,bh:f64,p:f64)->f64 {
    js_max(0.0,js_min(ax+aw+p,bx+bw+p)-js_max(ax-p,bx-p))
        *js_max(0.0,js_min(ay+ah+p,by+bh+p)-js_max(ay-p,by-p))
}
#[no_mangle]
#[target_feature(enable="simd128")]
pub unsafe extern "C" fn lanes(ax:f64,ay:f64,aw:f64,ah:f64,bx:f64,by:f64,bw:f64,bh:f64,p:f64)->f64 {
    let apos=f64x2(ax,ay);let bpos=f64x2(bx,by);let pad=f64x2_splat(p);
    let ar=f64x2_add(f64x2_add(apos,f64x2(aw,ah)),pad);
    let br=f64x2_add(f64x2_add(bpos,f64x2(bw,bh)),pad);
    let left=f64x2_max(f64x2_sub(apos,pad),f64x2_sub(bpos,pad));
    let size=f64x2_max(f64x2_splat(0.0),f64x2_sub(f64x2_min(ar,br),left));
    f64x2_extract_lane::<0>(size)*f64x2_extract_lane::<1>(size)
}

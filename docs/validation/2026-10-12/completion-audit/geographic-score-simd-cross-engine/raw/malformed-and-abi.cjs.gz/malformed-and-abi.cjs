const fs=require('node:fs'),crypto=require('node:crypto');
const encode=v=>{if(Number.isNaN(v))return 'NaN';let b=Buffer.alloc(8);b.writeDoubleLE(v);return b.toString('hex');};
const make=p=>{const b=fs.readFileSync(p);if(!WebAssembly.validate(b))throw Error('module validation failed');const e=new WebAssembly.Instance(new WebAssembly.Module(b),{env:{path_node_cost(){throw Error('unexpected path');}}}).exports;const versions={};for(const k of ['engine_abi_version','geographic_abi_version','castle_ribbon_abi_version','geographic_preparation_abi_version']){versions[k]=e[k]();if(versions[k]!==1)throw Error('ABI mismatch');}return {e,sha:crypto.createHash('sha256').update(b).digest('hex'),versions};};
const a=make('evidence/baseline.wasm'),b=make('evidence/prototype.wasm');
const cases=[];
function run(e,target,index,value,phase='score'){
 const f=[1,1,1,0,0,0,0,0,8,8,1,0,0,0,0,0,0,0,8,8],r=[1,0,0,0,0,0,0,0];const cap=64;
 const fp=e.engine_alloc(f.length),pp=e.engine_alloc(cap),rp=e.engine_alloc(r.length);
 new Float64Array(e.memory.buffer,fp,f.length).set(f);new Float64Array(e.memory.buffer,rp,r.length).set(r);new Float64Array(e.memory.buffer,pp,cap).fill(123);
 let result,before,after;
 if(phase==='prepare'){
  new Float64Array(e.memory.buffer,fp,f.length)[index]=value;before=Array.from(new Float64Array(e.memory.buffer,pp,cap));result=e.geo_prepare(fp,f.length,pp,cap);after=Array.from(new Float64Array(e.memory.buffer,pp,cap));
 }else{
  const n=e.geo_prepare(fp,f.length,pp,cap);if(n<0)throw Error('valid prepare failed');
  const ptr=target==='frame'?fp:target==='road'?rp:pp,len=target==='frame'?f.length:target==='road'?r.length:n;
  new Float64Array(e.memory.buffer,ptr,len)[index]=value;
  before=Array.from(new Float64Array(e.memory.buffer,pp,n));result=e.geo_score_prepared(fp,f.length,pp,n,rp,r.length);after=Array.from(new Float64Array(e.memory.buffer,pp,n));
 }
 e.engine_free(fp,f.length);e.engine_free(pp,cap);e.engine_free(rp,r.length);
 if(result!==-2||JSON.stringify(before.map(encode))!==JSON.stringify(after.map(encode)))throw Error('malformed not atomic');return {result,before:before.map(encode),after:after.map(encode)};
}
for(const [target,index,value] of [['prep',0,2],['prep',1,2],['prep',2,1],['prep',3,.5],['prep',6,17],['prep',11,2],['prep',12,-0],['prep',16,99],['frame',0,2],['frame',10,2],['frame',6,-0],['road',0,2],['road',1,2],['road',5,3],['road',6,1],['road',7,1]]){
 const x=run(a.e,target,index,value),y=run(b.e,target,index,value);if(JSON.stringify(x)!==JSON.stringify(y))throw Error('old/new malformed mismatch');cases.push({target,index,value:encode(value),result:x});
}
for(const [index,value] of [[0,2],[1,0],[2,.5],[5,1],[6,Infinity],[8,-1],[10,0],[11,1]]){
 const x=run(a.e,'frame',index,value,'prepare'),y=run(b.e,'frame',index,value,'prepare');if(JSON.stringify(x)!==JSON.stringify(y))throw Error('old/new bad prepare mismatch');cases.push({phase:'prepare',index,value:encode(value),result:x});
}
const report={scope:'Actual baseline/SIMD-prototype ABI and malformed atomicity, not timing',baseline:a.sha,prototype:b.sha,baselineVersions:a.versions,prototypeVersions:b.versions,validatedBoth:true,cases};fs.writeFileSync('evidence/malformed-and-abi.raw.json',JSON.stringify(report)+'\n');console.log(JSON.stringify({...report,cases:cases.length},null,2));

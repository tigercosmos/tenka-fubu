import pathlib,sys,json,gzip,hashlib,subprocess
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'manifest.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):return gzip.decompress((p/'raw'/(n+'.gz')).read_bytes())
def read(n):return json.loads(raw(n))
for a in s['files']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
for a in read('input-source-proof.json'):
 b=subprocess.check_output(['git','cat-file','blob',a['gitBlob']]);assert len(b)==a['bytes'] and h(b)==a['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==a['gitBlob']
 if 'decompressedSHA256' in a:assert h(gzip.decompress(b))==a['decompressedSHA256']
inputs=read('simd-parity.raw.json');bad=read('malformed-and-abi.raw.json');assert len(inputs['observations'])==2121 and inputs['summary']['validExtremeCases']==196 and len(bad['cases'])==24
for engine in ['firefox','webkit']:
 q=read(engine+'.raw.json');a=q['result'];assert q['verdict']=='PASS';assert a['capabilities']=={'tinyStrictProbeValidate':True,'scalarFullModuleValidate':True,'prototypeFullModuleValidate':True};assert a['tinyCheck']['allEqual'];assert all(x==1 for x in a['scalarABI'].values()) and all(x==1 for x in a['prototypeABI'].values());assert a['counts']=={'legal':2121,'originalJSDerived':1920,'validExtreme':196,'derivedMutations':5,'malformed':24}
 assert q['inputs']['baseline']['sha256']==h(raw('baseline.wasm'))=='64241ba7fb1e8cc5a5a10205a600bb7b9dbecb59e0f6b2cf71ffe4ebea79870b';assert q['inputs']['prototype']['sha256']==h(raw('prototype.wasm'))=='4ba2591c5205e363f92ee896c6f40c441fb2a7d613e587a2fe6aa2aee0408d0a';assert q['inputs']['tiny']['sha256']==h(raw('tiny-probe.wasm'))
 assert q['inputs']['casesSHA256']==h(raw('simd-parity.raw.json')) and q['inputs']['malformedSHA256']==h(raw('malformed-and-abi.raw.json'))
 for i,row in enumerate(a['legalRows']):assert row['index']==i and row['baseline']==row['prototype']==inputs['observations'][i]['result']
 for i,row in enumerate(a['malformedRows']):
  x=row['baseline'];assert row['index']==i and x==row['prototype']==bad['cases'][i]['result'];assert x['result']==-2 and x['before']==x['after']
 assert q['launch']['headless'] and a['userAgent']
assert int(raw('browser-install.exit'))==0;assert read('metadata-lookup-original-red-status.json')['terminalExit']==1
print('PASS: dualSHA/sourceGitblobs; actual Firefox/WebKit full2121+24 outputs, strictprobe/fullmodule capabilities and ABI; packaging RED retained; no Safari/game/GPU/performance claim')

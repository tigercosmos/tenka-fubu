import pathlib,json,gzip,hashlib,subprocess
r=pathlib.Path('/tmp/tenka-simd-cross-engine-20261012');out=pathlib.Path('docs/validation/2026-10-12/completion-audit/geographic-score-simd-cross-engine');(out/'raw').mkdir(parents=True,exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest()
ver='''import pathlib,sys,json,gzip,hashlib,subprocess
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'manifest.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def raw(n):return gzip.decompress((p/'raw'/(n+'.gz')).read_bytes())
def read(n):return json.loads(raw(n))
for a in s['files']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert h(z)==a['gzipSHA256'] and h(b)==a['rawSHA256']
for a in read('input-source-proof.json'):
 b=subprocess.check_output(['git','cat-file','blob',a['gitBlob']]);assert len(b)==a['bytes'] and h(b)==a['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\\0'+b).hexdigest()==a['gitBlob']
 if 'decompressedSHA256' in a:assert h(gzip.decompress(b))==a['decompressedSHA256']
inputs=read('simd-parity.raw.json');bad=read('malformed-and-abi.raw.json');assert len(inputs['observations'])==2121 and inputs['summary']['validExtremeCases']==196 and len(bad['cases'])==24
for engine in ['firefox','webkit']:
 q=read(engine+'.raw.json');a=q['result'];assert q['verdict']=='PASS';assert a['capabilities']=={'tinyStrictProbeValidate':True,'scalarFullModuleValidate':True,'prototypeFullModuleValidate':True};assert a['tinyCheck']['allEqual'];assert all(x==1 for x in a['scalarABI'].values()) and all(x==1 for x in a['prototypeABI'].values());assert a['counts']=={'legal':2121,'originalJSDerived':1920,'validExtreme':196,'derivedMutations':5,'malformed':24}
 assert q['inputs']['baseline']['sha256']==h(raw('baseline.wasm'))=='64241ba7fb1e8cc5a5a10205a600bb7b9dbecb59e0f6b2cf71ffe4ebea79870b';assert q['inputs']['prototype']['sha256']==h(raw('prototype.wasm'))=='4ba2591c5205e363f92ee896c6f40c441fb2a7d613e587a2fe6aa2aee0408d0a';assert q['inputs']['tiny']['sha256']==h(raw('tiny-probe.wasm'))
 assert q['inputs']['casesSHA256']==h(raw('simd-parity.raw.json')) and q['inputs']['malformedSHA256']==h(raw('malformed-and-abi.raw.json'))
 for i,row in enumerate(a['legalRows']):assert row['index']==i and row['baseline']==row['prototype']==inputs['observations'][i]['result']
 for i,row in enumerate(a['malformedRows']):
  x=row['baseline'];assert row['index']==i and x==row['prototype']==bad['cases'][i]['result'];assert x['result']==-2 and x['before']==x['after']
 assert q['launch']['headless'] and a['userAgent']
assert int(raw('browser-install.exit'))==0;assert read('metadata-lookup-original-red-status.json')['terminalExit']==1
print('PASS: dualSHA/sourceGitblobs; actual Firefox/WebKit full2121+24 outputs, strictprobe/fullmodule capabilities and ABI; packaging RED retained; no Safari/game/GPU/performance claim')
'''
(r/'verify.py').write_text(ver);(r/'package-producer.py').write_bytes(pathlib.Path(__file__).read_bytes());engines=[]
for e in ['firefox','webkit']:
 q=json.loads((r/(e+'.raw.json')).read_text());engines.append({k:q[k] for k in ['engine','verdict','browserVersion','launch','host','playwright','inputs','startedUTC','finishedUTC'] }|{k:q['result'][k] for k in ['userAgent','platform','capabilities','scalarABI','prototypeABI','counts','summary']})
s=dict(schemaVersion=1,scope='Actual full-module cross-engine numeric compatibility only; no Safari product/fullgame/GPU/performance/runtime selection claim',sourcePackageCommit=subprocess.check_output(['git','rev-parse','fbeb80a'],text=True).strip(),tinyProbeCommit=subprocess.check_output(['git','rev-parse','aa18b75'],text=True).strip(),baselineSHA256=h((r/'baseline.wasm').read_bytes()),prototypeSHA256=h((r/'prototype.wasm').read_bytes()),classification='NaN class; every other f64 exact little-endian bits',browserInstallTerminalExit=0,browserCampaignTerminalExit=0,browserCampaigns=engines,unsupportedSelectionLimits=['Actual observed installed engines support strictSIMD; unsupported branch was not exercised.','The fullprototype unconditionally contains SIMD; engines rejecting it cannot instantiate it; scalar validated independently.','No capability-selection/fallback or source/default adoption was implemented or tested.'],packagingRED='metadata collector looked up obsolete Playwright internal path; preserved, corrected without browser rerun',files=[])
selected=['run.cjs','run.log','status.json','firefox.raw.json','webkit.raw.json','baseline.wasm','prototype.wasm','simd-parity.raw.json','malformed-and-abi.raw.json','simd-parity.ts','malformed-and-abi.cjs','tiny-probe.wasm','tiny-probe.rs','tiny-check.cjs','input-source-proof.json','environment.cjs','environment.json','project-browsers.json','webkit-launch-wrapper.sh','browser-install.log','browser-install.exit','metadata-lookup-original-red.log','metadata-lookup-original-red-status.json','verify.py','package-producer.py']
for n in selected:
 b=(r/n).read_bytes();z=gzip.compress(b,mtime=0);name='raw/'+n+'.gz';(out/name).write_bytes(z);s['files'].append(dict(path=name,rawBytes=len(b),rawSHA256=h(b),gzipBytes=len(z),gzipSHA256=h(z),originalPath=str(r/n)))
(out/'manifest.json').write_text(json.dumps(s,indent=2)+'\n')
(out/'README.md').write_text('''# Full SIMD module cross-engine numeric compatibility

Actual Playwright1.61.1 headless Firefox151.0 and WebKit26.5 independently validated and instantiated the full frozen scalar64241ba… (88,475bytes) and unconditional SIMD4ba2591… (88,469bytes) modules. Each engine matched all2,121 original input/result cases:1,920 original-JS-derived label steps,196 valid extremes and5 derived offset controls. All full prepared before/after arrays and winner results match both modules and the frozen original rows, using NaN classification and exact little-endian bits for every other f64.

Each engine also passed24 malformed atomicity controls (return−2 with unchanged output) and all four ABI version functions returned1. The pinned strict SIMD tiny probe validated and instantiated, with four explicit arithmetic controls matching its scalar export. Tiny capability validation alone is not used as full-module proof: actual full module instantiation and all numeric cases are retained separately.

Only matching Firefox1532 and WebKit2311 were downloaded; Chromium was not installed again. Disk was2.0GiB before and1.4GiB after download. Existing project node_modules were reused through an isolated/tmp symlink; no npmci claim is made. Raw default UA, browser versions, executable paths/hashes, launch arguments, project browser manifest and library versions are preserved. WebKit is the Playwright bundled engine, not the Safari product, even though its default UA contains Safari. No game, GPU, FPS, browser performance or other-version/OS claim is made.

Both observed engines support the strict SIMD prototype. This does not establish support in older engines. The unconditional full SIMD module cannot instantiate where validation rejects its SIMD; scalar validation remains separate. The unsupported branch is preserved in the observer but was not exercised, and this task implements no runtime selection/fallback or source/default adoption.

Browser installation and the two numeric runs succeeded without a rerun. A later packaging metadata lookup assumed an obsolete Playwright internal file and failed; that RED is retained. Metadata collection was corrected using current package/browser entrypoints without launching another browser.

Inputs, modules and original producers come from frozen commitfbeb80a; the tiny probe/source come from aa18b75. All raw artifacts retain their bytes under gzip, with compressed/raw SHA256 and byte counts in manifest. The full browser-produced rows are retained for both engines. Decompress raw/verify.py.gz and run it with this package path from the repository to verify every output against original rows, source Git blobs, module hashes, capabilities, ABI and RED preservation.
''')
print(len(selected),sum(f['gzipBytes'] for f in s['files']))

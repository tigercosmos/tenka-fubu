# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard-minimum.spec.ts >> minimum viewport rail, report, camera, Home and M keys work from Main
- Location: e2e/keyboard-minimum.spec.ts:79:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByTestId('minimap')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByTestId('minimap')
    12 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - region "戰略圖層" [ref=e6]:
      - group [ref=e7]:
        - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
    - banner [ref=e9]:
      - group "金錢、兵糧、兵力、威信" [ref=e10]:
        - generic [ref=e11]:
          - group "織田家" [ref=e12]
          - time [ref=e14]: 1560年1月1日
          - generic [ref=e15]:
            - generic [ref=e16]:
              - img [ref=e17]
              - generic [ref=e20]: 金錢
            - strong [ref=e23]: 2,000
          - generic [ref=e24]:
            - generic [ref=e25]:
              - img [ref=e26]
              - generic [ref=e28]: 兵糧
            - generic [ref=e29]:
              - strong [ref=e31]: 12,000
              - generic "兵糧可支撐26個月" [ref=e32]:
                - text: 兵糧可支撐
                - strong [ref=e33]: "26"
                - text: 個月
          - generic [ref=e34]:
            - generic [ref=e35]:
              - img [ref=e36]
              - generic [ref=e40]: 兵力
            - generic [ref=e42]:
              - strong [ref=e43]: 4,517
              - generic [ref=e44]: /4,662
          - generic [ref=e45]:
            - generic [ref=e46]:
              - img [ref=e47]
              - generic [ref=e49]: 威信
            - strong [ref=e52]: "250"
      - generic [ref=e53]:
        - generic [ref=e54]:
          - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
            - img [ref=e56]
          - button "一倍速" [ref=e58] [cursor=pointer]:
            - img [ref=e59]
          - button "二倍速" [ref=e61] [cursor=pointer]:
            - img [ref=e62]
          - button "五倍速" [ref=e64] [cursor=pointer]:
            - img [ref=e65]
        - button "系統選單" [ref=e67] [cursor=pointer]:
          - img [ref=e68]
    - navigation "內政" [ref=e71]:
      - button "地圖一覽" [ref=e72] [cursor=pointer]:
        - img [ref=e73]
        - generic [ref=e76]:
          - generic [ref=e77]: 地圖
          - generic [ref=e78]: 一覽
      - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
        - img [ref=e80]
        - generic "織田家" [ref=e85]: 織田
      - generic [ref=e87]: 軍政
      - button "軍事" [ref=e88] [cursor=pointer]:
        - img [ref=e89]
        - text: 軍事
      - button "內政" [ref=e91] [cursor=pointer]:
        - img [ref=e92]
        - text: 內政
      - button "武將" [ref=e94] [cursor=pointer]:
        - img [ref=e95]
        - text: 武將
      - generic [ref=e100]: 交涉
      - button "外交" [ref=e101] [cursor=pointer]:
        - img [ref=e102]
        - text: 外交
      - button "調略" [ref=e104] [cursor=pointer]:
        - img [ref=e105]
        - text: 調略
      - generic [ref=e109]: 國策
      - button "政策" [ref=e110] [cursor=pointer]:
        - img [ref=e111]
        - text: 政策
      - button "軍團" [ref=e113] [cursor=pointer]:
        - img [ref=e114]
        - text: 軍團
      - button "大命" [ref=e116] [cursor=pointer]:
        - img [ref=e117]
        - text: 大命
    - complementary [ref=e119]:
      - generic [ref=e120]:
        - generic [ref=e121]:
          - generic [ref=e122]: 織田信長・織田家・宿老
          - button "織田信長・織田家・宿老" [ref=e123] [cursor=pointer]:
            - img [ref=e124]
        - generic [ref=e126]:
          - generic [ref=e128]: 織田家
          - generic [ref=e129]:
            - img "統率 105" [ref=e130]:
              - generic [ref=e131]: 統率
              - generic [ref=e135]: "105"
            - img "武勇 92" [ref=e136]:
              - generic [ref=e137]: 武勇
              - generic [ref=e140]: "92"
            - img "知略 108" [ref=e141]:
              - generic [ref=e142]: 知略
              - generic [ref=e146]: "108"
            - img "政務 104" [ref=e147]:
              - generic [ref=e148]: 政務
              - generic [ref=e152]: "104"
          - generic [ref=e153]:
            - heading "能力成長" [level=3] [ref=e154]
            - generic [ref=e155]:
              - generic [ref=e156]:
                - paragraph [ref=e157]: 統率成長經驗
                - progressbar "統率成長經驗" [ref=e159]
                - paragraph [ref=e160]: 基礎105・成長＋0/5
              - generic [ref=e161]:
                - paragraph [ref=e162]: 武勇成長經驗
                - progressbar "武勇成長經驗" [ref=e164]
                - paragraph [ref=e165]: 基礎92・成長＋0/5
              - generic [ref=e166]:
                - paragraph [ref=e167]: 知略成長經驗
                - progressbar "知略成長經驗" [ref=e169]
                - paragraph [ref=e170]: 基礎108・成長＋0/5
              - generic [ref=e171]:
                - paragraph [ref=e172]: 政務成長經驗
                - progressbar "政務成長經驗" [ref=e174]
                - paragraph [ref=e175]: 基礎104・成長＋0/5
          - generic [ref=e176]:
            - generic [ref=e177]:
              - term [ref=e178]: 忠誠
              - definition [ref=e179]: "100"
            - generic [ref=e180]:
              - term [ref=e181]: 功績
              - definition [ref=e182]: "0"
            - generic [ref=e183]:
              - term [ref=e184]: 年齡
              - definition [ref=e185]: "26"
            - generic [ref=e186]:
              - term [ref=e187]: 身分
              - definition [ref=e188]: 宿老
            - generic [ref=e189]:
              - term [ref=e190]: 役職
              - definition [ref=e191]: 清洲城城主
          - region "可解鎖戰法：" [ref=e192]:
            - heading "可解鎖戰法：" [level=3] [ref=e193]
            - list [ref=e194]:
              - listitem [ref=e195]: 突擊（采配5）
              - listitem [ref=e196]: 齊射（采配4）
              - listitem [ref=e197]: 鐵砲三段（采配8）
            - paragraph [ref=e198]: 解鎖不代表目前可使用；仍須符合合戰中的采配、冷卻與目標條件。
          - generic [ref=e199]:
            - heading "特性" [level=3] [ref=e200]
            - generic [ref=e201]:
              - generic [active] [ref=e202]: 威風堂堂
              - generic [ref=e203]: 鐵砲名人
              - generic [ref=e204]: 野心家
          - generic [ref=e205]:
            - heading "知行" [level=3] [ref=e206]
            - paragraph [ref=e207]: （無資料）
          - generic [ref=e208]:
            - heading "經歷" [level=3] [ref=e209]
            - paragraph [ref=e210]: （無資料）
          - generic [ref=e212]:
            - heading "操作" [level=3] [ref=e213]
            - generic [ref=e214]:
              - generic [ref=e215]:
                - text: 任命城主：選擇城池
                - combobox "任命城主：選擇城池" [ref=e216]:
                  - option "請選擇" [selected]
                  - option "清洲城"
                  - option "那古野城"
                  - option "犬山城"
              - generic [ref=e217]:
                - button "任命城主" [disabled] [ref=e218]
                - generic [ref=e219]: 目標不屬於我方勢力
              - generic [ref=e220]:
                - text: 分封知行：選擇郡
                - combobox "分封知行：選擇郡" [ref=e221]:
                  - option "請選擇" [selected]
                  - option "春日井郡"
                  - option "海東郡"
                  - option "中島郡"
                  - option "海西郡"
                  - option "愛知郡"
                  - option "知多郡"
                  - option "丹羽郡"
                  - option "葉栗郡"
              - generic [ref=e222]:
                - button "分封知行" [disabled] [ref=e223]
                - generic [ref=e224]: 目標不屬於我方勢力
            - paragraph [ref=e225]: 年內已賞賜：0次
            - generic [ref=e226]:
              - generic [ref=e227]:
                - button "小額賞賜：50貫・忠誠＋0" [disabled] [ref=e228]
                - generic [ref=e229]: 目標不屬於我方勢力
              - generic [ref=e230]:
                - button "中額賞賜：100貫・忠誠＋0" [disabled] [ref=e231]
                - generic [ref=e232]: 目標不屬於我方勢力
              - generic [ref=e233]:
                - button "大額賞賜：200貫・忠誠＋0" [disabled] [ref=e234]
                - generic [ref=e235]: 目標不屬於我方勢力
              - generic [ref=e236]:
                - button "身分推舉" [disabled] [ref=e237]
                - generic [ref=e238]: 目標無效或已不存在
    - generic:
      - generic:
        - generic:
          - button:
            - img
    - img "全國小地圖" [ref=e239]
    - button "報告中心" [ref=e242] [cursor=pointer]
  - tooltip "合戰勝利威風等級 +1 級；已為大威風時擴散範圍 +1 郡跳數。 同項乘數相乘、加值相加。":
    - generic:
      - generic: 合戰勝利威風等級 +1 級；已為大威風時擴散範圍 +1 郡跳數。
      - generic: 同項乘數相乘、加值相加。
```

# Test source

```ts
  54  |   await search.focus();
  55  |   await page.keyboard.press('m');
  56  |   await page.keyboard.press('1');
  57  |   await page.keyboard.press('Alt+2');
  58  |   await expect(search).toHaveValue('m1');
  59  |   await expect.poll(() => mode(page)).toBe('none');
  60  |   await expect(page.getByTestId('minimap')).toBeVisible();
  61  |   await page.keyboard.press('Escape');
  62  |   await expect(search).not.toBeFocused();
  63  |   await expect(list).toBeVisible();
  64  |   await page.keyboard.press('Escape');
  65  |   await expect(list).toHaveCount(0);
  66  | 
  67  |   await backgroundFocus(page);
  68  |   await page.keyboard.press('Escape');
  69  |   const menu = page.getByRole('dialog', { name: '系統選單', exact: true });
  70  |   await expect(menu).toBeVisible();
  71  |   await page.keyboard.press('Alt+3');
  72  |   await page.keyboard.press('F7');
  73  |   await page.keyboard.press('2');
  74  |   await expect(menu).toBeVisible();
  75  |   await expect.poll(() => mode(page)).toBe('none');
  76  |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  77  | });
  78  | 
  79  | test('minimum viewport rail, report, camera, Home and M keys work from Main', async ({ page }) => {
  80  |   await startPausedGame(page);
  81  |   const game = await page.evaluate(() => window.__tenka.debug.getState());
  82  |   const homeCastleId = game.clans[game.meta.playerClanId]!.homeCastleId;
  83  |   await backgroundFocus(page);
  84  |   await page.keyboard.press('Home');
  85  |   await expect
  86  |     .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection))
  87  |     .toEqual({ kind: 'node', id: homeCastleId });
  88  |   await page.keyboard.press('m');
  89  |   await expect(page.getByTestId('minimap')).toHaveCount(0);
  90  |   await page.keyboard.press('m');
  91  |   await expect(page.getByTestId('minimap')).toBeVisible();
  92  | 
  93  |   for (const [key, rail] of [
  94  |     ['F1', 'rail-domestic'],
  95  |     ['F3', 'rail-diplomacy'],
  96  |     ['F4', 'rail-officers'],
  97  |     ['F5', 'rail-policy'],
  98  |     ['F6', 'rail-corps'],
  99  |     ['F7', 'rail-taimei'],
  100 |   ] as const) {
  101 |     await backgroundFocus(page);
  102 |     await page.keyboard.press(key);
  103 |     await expect(page.getByTestId(rail)).toHaveAttribute('aria-pressed', 'true');
  104 |     await page.keyboard.press('Escape');
  105 |     await expect(page.getByTestId(rail)).toHaveAttribute('aria-pressed', 'false');
  106 |   }
  107 |   await backgroundFocus(page);
  108 |   await page.keyboard.press('F2');
  109 |   await expect(page.getByTestId('march-modal')).toBeVisible();
  110 |   await page.keyboard.press('Escape');
  111 |   await expect(page.getByTestId('march-modal')).toHaveCount(0);
  112 |   await backgroundFocus(page);
  113 |   await page.keyboard.press('r');
  114 |   await expect(page.getByTestId('reports-panel')).toBeVisible();
  115 |   await page.keyboard.press('Escape');
  116 |   await expect(page.getByTestId('reports-panel')).toHaveCount(0);
  117 | 
  118 |   await backgroundFocus(page);
  119 |   const frame = page.getByTestId('minimap-frame');
  120 |   const pixels = () => frame.evaluate((node: HTMLCanvasElement) => node.toDataURL());
  121 |   let previous = await pixels();
  122 |   for (const key of [
  123 |     'w',
  124 |     'a',
  125 |     's',
  126 |     'd',
  127 |     'ArrowUp',
  128 |     'ArrowLeft',
  129 |     'ArrowDown',
  130 |     'ArrowRight',
  131 |     '+',
  132 |     '-',
  133 |   ]) {
  134 |     await page.keyboard.press(key);
  135 |     await expect.poll(pixels).not.toBe(previous);
  136 |     previous = await pixels();
  137 |   }
  138 |   const canvas = page.getByTestId('map-canvas-host').locator('canvas');
  139 |   await canvas.hover({ position: { x: 400, y: 300 } });
  140 |   await page.mouse.wheel(0, -150);
  141 |   await expect.poll(pixels).not.toBe(previous);
  142 | 
  143 |   await backgroundFocus(page);
  144 |   await page.keyboard.press('Escape');
  145 |   await expect
  146 |     .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection))
  147 |     .toBeNull();
  148 |   await page.keyboard.press('F4');
  149 |   await page.getByTestId('officer-list').locator('tbody tr').filter({ hasText: '織田信長' }).click();
  150 |   const trait = page.getByTestId('officer-detail').locator('span[tabindex="0"]').first();
  151 |   await trait.focus();
  152 |   await expect(trait).toBeFocused();
  153 |   await page.keyboard.press('m');
> 154 |   await expect(page.getByTestId('minimap')).toHaveCount(0);
      |                                             ^ Error: expect(locator).toHaveCount(expected) failed
  155 |   await page.keyboard.press('Home');
  156 |   await expect
  157 |     .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection))
  158 |     .toEqual({ kind: 'node', id: homeCastleId });
  159 |   expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(game);
  160 | });
  161 | 
  162 | test('minimum viewport speed, quick save/load, and danger Enter keep focus priority', async ({
  163 |   page,
  164 | }) => {
  165 |   await startPausedGame(page);
  166 |   await backgroundFocus(page);
  167 |   for (const [key, speed] of [
  168 |     ['1', 'speed-1'],
  169 |     ['2', 'speed-2'],
  170 |     ['3', 'speed-5'],
  171 |   ] as const) {
  172 |     await page.keyboard.press(key);
  173 |     await expect(page.getByTestId(speed)).toHaveAttribute('aria-pressed', 'true');
  174 |   }
  175 |   await page.keyboard.press('Space');
  176 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  177 |   const savedDay = await page.evaluate(() => window.__tenka.debug.getState().time.day);
  178 |   await page.keyboard.press('Control+s');
  179 |   await expect
  180 |     .poll(() =>
  181 |       page.evaluate(() => {
  182 |         const event = new Event('beforeunload', { cancelable: true });
  183 |         window.dispatchEvent(event);
  184 |         return event.defaultPrevented;
  185 |       }),
  186 |     )
  187 |     .toBe(false);
  188 |   await page.keyboard.press('1');
  189 |   await expect
  190 |     .poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day))
  191 |     .toBeGreaterThan(savedDay);
  192 |   await page.keyboard.press('Space');
  193 |   const dirtyDay = await page.evaluate(() => window.__tenka.debug.getState().time.day);
  194 |   await page.keyboard.press('F9');
  195 |   const confirmation = page.getByRole('dialog').last();
  196 |   await expect(confirmation).toContainText('尚有未存檔的進度');
  197 |   await page.keyboard.press('2');
  198 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  199 |   await confirmation.focus();
  200 |   await page.keyboard.press('Enter');
  201 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  202 |   expect(await page.evaluate(() => window.__tenka.debug.getState().time.day)).toBe(dirtyDay);
  203 |   await backgroundFocus(page);
  204 |   await page.keyboard.press('F9');
  205 |   await expect(confirmation).toBeVisible();
  206 |   await confirmation.getByRole('button', { name: '確定', exact: true }).click();
  207 |   await expect.poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day)).toBe(savedDay);
  208 | });
  209 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard-minimum.spec.ts >> minimum viewport camera directions and both zoom controls change settled frames
- Location: e2e/keyboard-minimum.spec.ts:153:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByTestId('minimap-frame')
    - locator resolved to visible <canvas width="176" height="176" data-testid="minimap-frame"></canvas>

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1560年1月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 2,000
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 12,000
            - generic "兵糧可支撐26個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "26"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 4,517
            - generic [ref=e44]: /4,662
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "250"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [pressed] [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - button "系統選單" [ref=e67] [cursor=pointer]:
        - img [ref=e68]
  - navigation "內政" [ref=e71]:
    - button "地圖一覽" [ref=e72] [cursor=pointer]:
      - img [ref=e73]
      - generic [ref=e76]:
        - generic [ref=e77]: 地圖
        - generic [ref=e78]: 一覽
    - button "織田家 （本城）" [ref=e79] [cursor=pointer]:
      - img [ref=e80]
      - generic "織田家" [ref=e85]: 織田
    - generic [ref=e87]: 軍政
    - button "軍事" [ref=e88] [cursor=pointer]:
      - img [ref=e89]
      - text: 軍事
    - button "內政" [ref=e91] [cursor=pointer]:
      - img [ref=e92]
      - text: 內政
    - button "武將" [ref=e94] [cursor=pointer]:
      - img [ref=e95]
      - text: 武將
    - generic [ref=e100]: 交涉
    - button "外交" [ref=e101] [cursor=pointer]:
      - img [ref=e102]
      - text: 外交
    - button "調略" [ref=e104] [cursor=pointer]:
      - img [ref=e105]
      - text: 調略
    - generic [ref=e109]: 國策
    - button "政策" [ref=e110] [cursor=pointer]:
      - img [ref=e111]
      - text: 政策
    - button "軍團" [ref=e113] [cursor=pointer]:
      - img [ref=e114]
      - text: 軍團
    - button "大命" [ref=e116] [cursor=pointer]:
      - img [ref=e117]
      - text: 大命
  - generic [ref=e120]:
    - generic [ref=e121]:
      - generic [ref=e122]: 清洲城（尾張）
      - button "清洲城（尾張）" [ref=e123] [cursor=pointer]:
        - img [ref=e124]
    - generic [ref=e127]:
      - generic [ref=e129]:
        - img "兵力 2,365" [ref=e130]:
          - generic [ref=e131]: 兵力 2,365
        - img "兵糧 6,500" [ref=e134]:
          - generic [ref=e135]: 兵糧 6,500
        - img "耐久 3,000" [ref=e138]:
          - generic [ref=e139]: 耐久 3,000
        - img "士氣 70" [ref=e142]:
          - generic [ref=e143]: 士氣 70
      - generic [ref=e146]:
        - button "城面板" [ref=e147] [cursor=pointer]
        - button "出陣" [ref=e148] [cursor=pointer]
        - button "輸送" [ref=e149] [cursor=pointer]
  - img "全國小地圖" [ref=e150]
  - button "報告中心" [ref=e153] [cursor=pointer]
```

# Test source

```ts
  1   | import type { Page } from '@playwright/test';
  2   | import { test, expect } from './fixtures';
  3   | 
  4   | async function startPausedGame(page: Page): Promise<void> {
  5   |   await page.setViewportSize({ width: 1280, height: 720 });
  6   |   await page.goto('/?debug=1');
  7   |   await page.getByTestId('title-newgame').click();
  8   |   await page.getByTestId('scenario-pick-s1560').click();
  9   |   await page.getByTestId('clan-pick-clan.oda').click();
  10  |   await page.getByTestId('newgame-start').click();
  11  |   await expect(page.getByTestId('screen-strategy')).toBeVisible();
  12  |   await page.getByTestId('speed-pause').click();
  13  |   await expect(page.getByTestId('screen-too-small')).toHaveCount(0);
  14  | }
  15  | 
  16  | async function backgroundFocus(page: Page): Promise<void> {
  17  |   await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  18  | }
  19  | 
  20  | async function mode(page: Page): Promise<string> {
  21  |   return page.evaluate(() => window.__tenka.debug.getMapDiagnostics().analysisMode);
  22  | }
  23  | 
  24  | async function settledCameraFrame(page: Page): Promise<string> {
  25  |   const frame = page.getByTestId('minimap-frame');
> 26  |   const pixels = () => frame.evaluate((node: HTMLCanvasElement) => node.toDataURL());
      |                              ^ Error: locator.evaluate: Test timeout of 60000ms exceeded.
  27  |   await page.evaluate(() => window.__tenka.debug.waitMapIdle(2));
  28  |   let previous = await pixels();
  29  |   let stableSamples = 0;
  30  |   for (let sample = 0; sample < 30; sample++) {
  31  |     await page.waitForTimeout(75);
  32  |     const current = await pixels();
  33  |     stableSamples = current === previous ? stableSamples + 1 : 0;
  34  |     if (stableSamples >= 3) return current;
  35  |     previous = current;
  36  |   }
  37  |   throw new Error('Minimap camera frame did not settle');
  38  | }
  39  | 
  40  | test('minimum viewport map modes keep Tab navigation and input/modal ownership', async ({ page }) => {
  41  |   await startPausedGame(page);
  42  |   await backgroundFocus(page);
  43  |   await page.keyboard.press('Tab');
  44  |   await expect.poll(() => mode(page)).toBe('faction');
  45  |   await page.keyboard.press('Shift+Tab');
  46  |   await expect.poll(() => mode(page)).toBe('faction');
  47  |   await expect
  48  |     .poll(() => page.evaluate(() => document.activeElement !== document.body))
  49  |     .toBe(true);
  50  |   await backgroundFocus(page);
  51  |   await page.keyboard.press('Alt+1');
  52  |   await expect.poll(() => mode(page)).toBe('none');
  53  |   for (const [key, expected] of [
  54  |     ['1', 'faction'],
  55  |     ['2', 'supply'],
  56  |     ['3', 'roadCapacity'],
  57  |     ['4', 'terrainAdvantage'],
  58  |     ['5', 'castleDefense'],
  59  |   ] as const) {
  60  |     await page.keyboard.press(`Alt+${key}`);
  61  |     await expect.poll(() => mode(page)).toBe(expected);
  62  |   }
  63  |   await page.keyboard.press('Alt+5');
  64  |   await expect.poll(() => mode(page)).toBe('none');
  65  | 
  66  |   await page.keyboard.press('F4');
  67  |   const list = page.getByTestId('officer-list');
  68  |   await expect(list).toBeVisible();
  69  |   const search = list.locator('input[type="search"]');
  70  |   await search.focus();
  71  |   await page.keyboard.press('m');
  72  |   await page.keyboard.press('1');
  73  |   await page.keyboard.press('Alt+2');
  74  |   await expect(search).toHaveValue('m1');
  75  |   await expect.poll(() => mode(page)).toBe('none');
  76  |   await expect(page.getByTestId('minimap')).toBeVisible();
  77  |   await page.keyboard.press('Escape');
  78  |   await expect(search).not.toBeFocused();
  79  |   await expect(list).toBeVisible();
  80  |   await page.keyboard.press('Escape');
  81  |   await expect(list).toHaveCount(0);
  82  | 
  83  |   await backgroundFocus(page);
  84  |   await page.keyboard.press('Escape');
  85  |   const menu = page.getByRole('dialog', { name: '系統選單', exact: true });
  86  |   await expect(menu).toBeVisible();
  87  |   await page.keyboard.press('Alt+3');
  88  |   await page.keyboard.press('F7');
  89  |   await page.keyboard.press('2');
  90  |   await expect(menu).toBeVisible();
  91  |   await expect.poll(() => mode(page)).toBe('none');
  92  |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  93  | });
  94  | 
  95  | test('minimum viewport rail, report, camera, Home and M keys work from Main', async ({ page }) => {
  96  |   await startPausedGame(page);
  97  |   const game = await page.evaluate(() => window.__tenka.debug.getState());
  98  |   const homeCastleId = game.clans[game.meta.playerClanId]!.homeCastleId;
  99  |   await backgroundFocus(page);
  100 |   await page.keyboard.press('Home');
  101 |   await expect
  102 |     .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection))
  103 |     .toEqual({ kind: 'node', id: homeCastleId });
  104 |   await page.keyboard.press('m');
  105 |   await expect(page.getByTestId('minimap')).toHaveCount(0);
  106 |   await page.keyboard.press('m');
  107 |   await expect(page.getByTestId('minimap')).toBeVisible();
  108 | 
  109 |   for (const [key, rail] of [
  110 |     ['F1', 'rail-domestic'],
  111 |     ['F3', 'rail-diplomacy'],
  112 |     ['F4', 'rail-officers'],
  113 |     ['F5', 'rail-policy'],
  114 |     ['F6', 'rail-corps'],
  115 |     ['F7', 'rail-taimei'],
  116 |   ] as const) {
  117 |     await backgroundFocus(page);
  118 |     await page.keyboard.press(key);
  119 |     await expect(page.getByTestId(rail)).toHaveAttribute('aria-pressed', 'true');
  120 |     await page.keyboard.press('Escape');
  121 |     await expect(page.getByTestId(rail)).toHaveAttribute('aria-pressed', 'false');
  122 |   }
  123 |   await backgroundFocus(page);
  124 |   await page.keyboard.press('F2');
  125 |   await expect(page.getByTestId('march-modal')).toBeVisible();
  126 |   await page.keyboard.press('Escape');
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard-minimum.spec.ts >> minimum viewport speed, quick save/load, and danger Enter keep focus priority
- Location: e2e/keyboard-minimum.spec.ts:218:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('dialog').last()
Expected substring: "尚有未存檔的進度"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('dialog').last()

```

```yaml
- region "戰略圖層":
  - group: 戰略圖層 · 一般地圖
- banner:
  - group "金錢、兵糧、兵力、威信":
    - group "織田家"
    - time: 1560年1月5日
    - text: 金錢
    - strong: 2,000
    - text: 兵糧
    - strong: 11,941
    - text: 兵糧可支撐
    - strong: "26"
    - text: 個月 兵力
    - strong: 4,517
    - text: /4,662 威信
    - strong: "250"
  - button "暫停" [pressed]
  - button "一倍速"
  - button "二倍速"
  - button "五倍速"
  - button "系統選單"
- navigation "內政":
  - button "地圖一覽"
  - button "織田家 （本城）": 織田
  - button "軍事"
  - button "內政"
  - button "武將"
  - button "外交"
  - button "調略"
  - button "政策"
  - button "軍團"
  - button "大命"
- img "全國小地圖"
- button "通報 1 則"
- status:
  - strong: 已快速存檔
  - time: 1560年1月5日
  - button "關閉通知"
- button "報告中心"
```

# Test source

```ts
  152 |   await expect(trait).toBeFocused();
  153 |   await page.keyboard.press('m');
  154 |   await expect(page.getByTestId('minimap')).toHaveCount(0);
  155 |   await page.keyboard.press('Home');
  156 |   await expect
  157 |     .poll(() => page.evaluate(() => window.__tenka.debug.getMapPublishedViewSnapshot().selection))
  158 |     .toEqual({ kind: 'node', id: homeCastleId });
  159 |   expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(game);
  160 | });
  161 | 
  162 | for (const [label, keys] of [
  163 |   ['WASD', ['w', 'a', 's', 'd']],
  164 |   ['arrows', ['ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight']],
  165 | ] as const) {
  166 |   test(`minimum viewport ${label} keys move the settled camera`, async ({ page }, testInfo) => {
  167 |     await startPausedGame(page);
  168 |     const game = await page.evaluate(() => window.__tenka.debug.getState());
  169 |     await backgroundFocus(page);
  170 |     await page.keyboard.press('Home');
  171 |     const observations = [];
  172 |     for (const key of keys) {
  173 |       const before = await settledCameraFrame(page);
  174 |       await page.keyboard.down(key);
  175 |       await page.waitForTimeout(150);
  176 |       await page.keyboard.up(key);
  177 |       const after = await settledCameraFrame(page);
  178 |       expect(after, `Camera movement for ${key}`).not.toBe(before);
  179 |       observations.push({ key, before: frameHash(before), after: frameHash(after) });
  180 |     }
  181 |     await testInfo.attach('settled-camera-inputs', {
  182 |       body: JSON.stringify(observations, null, 2),
  183 |       contentType: 'application/json',
  184 |     });
  185 |     expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(game);
  186 |   });
  187 | }
  188 | 
  189 | test('minimum viewport keyboard and native wheel zoom change settled camera frames', async ({
  190 |   page,
  191 | }, testInfo) => {
  192 |   await startPausedGame(page);
  193 |   const game = await page.evaluate(() => window.__tenka.debug.getState());
  194 |   await backgroundFocus(page);
  195 |   await page.keyboard.press('Home');
  196 |   const observations = [];
  197 |   for (const key of ['+', '-']) {
  198 |     const before = await settledCameraFrame(page);
  199 |     await page.keyboard.press(key);
  200 |     const after = await settledCameraFrame(page);
  201 |     expect(after, `Keyboard zoom for ${key}`).not.toBe(before);
  202 |     observations.push({ key, before: frameHash(before), after: frameHash(after) });
  203 |   }
  204 |   const canvas = page.getByTestId('map-canvas-host').locator('canvas');
  205 |   await canvas.hover({ position: { x: 400, y: 300 } });
  206 |   const beforeWheel = await settledCameraFrame(page);
  207 |   await page.mouse.wheel(0, -150);
  208 |   const afterWheel = await settledCameraFrame(page);
  209 |   expect(afterWheel, 'Native wheel zoom').not.toBe(beforeWheel);
  210 |   observations.push({ key: 'wheel', before: frameHash(beforeWheel), after: frameHash(afterWheel) });
  211 |   await testInfo.attach('settled-camera-inputs', {
  212 |     body: JSON.stringify(observations, null, 2),
  213 |     contentType: 'application/json',
  214 |   });
  215 |   expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(game);
  216 | });
  217 | 
  218 | test('minimum viewport speed, quick save/load, and danger Enter keep focus priority', async ({
  219 |   page,
  220 | }) => {
  221 |   await startPausedGame(page);
  222 |   await backgroundFocus(page);
  223 |   for (const [key, speed] of [
  224 |     ['1', 'speed-1'],
  225 |     ['2', 'speed-2'],
  226 |     ['3', 'speed-5'],
  227 |   ] as const) {
  228 |     await page.keyboard.press(key);
  229 |     await expect(page.getByTestId(speed)).toHaveAttribute('aria-pressed', 'true');
  230 |   }
  231 |   await page.keyboard.press('Space');
  232 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  233 |   const savedDay = await page.evaluate(() => window.__tenka.debug.getState().time.day);
  234 |   await page.keyboard.press('Control+s');
  235 |   await expect
  236 |     .poll(() =>
  237 |       page.evaluate(() => {
  238 |         const event = new Event('beforeunload', { cancelable: true });
  239 |         window.dispatchEvent(event);
  240 |         return event.defaultPrevented;
  241 |       }),
  242 |     )
  243 |     .toBe(false);
  244 |   await page.keyboard.press('1');
  245 |   await expect
  246 |     .poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day))
  247 |     .toBeGreaterThan(savedDay);
  248 |   await page.keyboard.press('Space');
  249 |   const dirtyDay = await page.evaluate(() => window.__tenka.debug.getState().time.day);
  250 |   await page.keyboard.press('F9');
  251 |   const confirmation = page.getByRole('dialog').last();
> 252 |   await expect(confirmation).toContainText('尚有未存檔的進度');
      |                              ^ Error: expect(locator).toContainText(expected) failed
  253 |   await page.keyboard.press('2');
  254 |   await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed', 'true');
  255 |   await confirmation.focus();
  256 |   await page.keyboard.press('Enter');
  257 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  258 |   expect(await page.evaluate(() => window.__tenka.debug.getState().time.day)).toBe(dirtyDay);
  259 |   await backgroundFocus(page);
  260 |   await page.keyboard.press('F9');
  261 |   await expect(confirmation).toBeVisible();
  262 |   await confirmation.getByRole('button', { name: '確定', exact: true }).click();
  263 |   await expect
  264 |     .poll(() => page.evaluate(() => window.__tenka.debug.getState().time.day))
  265 |     .toBe(savedDay);
  266 | });
  267 | 
```
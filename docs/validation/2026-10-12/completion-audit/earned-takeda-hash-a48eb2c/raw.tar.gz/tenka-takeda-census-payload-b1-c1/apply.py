#!/usr/bin/env python3
import hashlib,json,shutil,tarfile
from pathlib import Path
runtime=Path('/tmp/tenka-takeda-census-runtime-b1-c1')
payload=Path('/tmp/tenka-takeda-census-payload-b1-c1')
meta=json.loads((payload/'payload.json').read_text())
source=json.loads((payload/'source-manifest.json').read_text())
assert source['revision']==meta['revision']
for name,row in meta['files'].items():
 b=(payload/name).read_bytes()
 assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],name
assert source['archivePaths']==['CLAUDE.md'] and source['deletedPaths']==[]
with tarfile.open(payload/'source.tar') as tar:
 assert tar.getnames()==['CLAUDE.md']
 data=tar.extractfile('CLAUDE.md').read()
(runtime/'CLAUDE.md').write_bytes(data)
shutil.copy2(payload/'ending-original.spec.tsx',runtime/'tests/app/earnedRegionalEndingJourney.spec.tsx')
shutil.copy2(payload/'helper.ts',runtime/'tests/helpers/earnedMiyoshiTakeda.ts')
shutil.copy2(payload/'test.spec.ts',runtime/'tests/app/earnedMiyoshiTakedaJourney.spec.ts')
print(json.dumps({'applied':source['archivePaths'],'restored':'tests/app/earnedRegionalEndingJourney.spec.tsx','overlays':['tests/helpers/earnedMiyoshiTakeda.ts','tests/app/earnedMiyoshiTakedaJourney.spec.ts']}))

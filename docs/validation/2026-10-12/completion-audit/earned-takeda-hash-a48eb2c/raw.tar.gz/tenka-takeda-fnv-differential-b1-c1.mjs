import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
function utf8Bytes(text) {
  const bytes = [];
  for (const ch of text) {
    const cp = ch.codePointAt(0) ?? 0;
    if (cp < 0x80) bytes.push(cp);
    else if (cp < 0x800) bytes.push(0xc0 | (cp >> 6), 0x80 | (cp & 0x3f));
    else if (cp < 0x10000) bytes.push(0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
    else bytes.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
  }
  return bytes;
}
// Frozen b1 production reference: src/core/state/serialize.ts fnv1a64 body.
function oldFnv(text) {
  let h = 0xcbf29ce484222325n;
  const prime = 0x00000100000001b3n;
  const mask = 0xffffffffffffffffn;
  for (const b of utf8Bytes(text)) { h ^= BigInt(b); h = (h * prime) & mask; }
  return h.toString(16).padStart(16, '0');
}
function limbFnv(text) {
  let hi = 0xcbf29ce4;
  let lo = 0x84222325;
  for (const b of utf8Bytes(text)) {
    const x = (lo ^ b) >>> 0;
    const p = x * 435;
    hi = (Math.imul(hi, 435) + Math.floor(p / 0x100000000) + ((x << 8) >>> 0)) >>> 0;
    lo = p >>> 0;
  }
  return hi.toString(16).padStart(8, '0') + lo.toString(16).padStart(8, '0');
}
let checked=0;
function same(label, value) { const old=oldFnv(value), next=limbFnv(value); assert.equal(next,old,label); checked++; }
same('empty','');assert.equal(oldFnv(''),'cbf29ce484222325');
for (let unit=0;unit<65536;unit++) same('unit:'+unit,String.fromCharCode(unit));
const edge=[0,1,127,128,255,256,0x7ff,0x800,0xd7ff,0xd800,0xdbff,0xdc00,0xdfff,0xe000,0xffff];
for (const hi of edge) for (const lo of edge) same('pair:'+hi+':'+lo,String.fromCharCode(hi,lo));
let seed=0x84222325;
function next() { seed=(Math.imul(seed,1664525)+1013904223)>>>0; return seed; }
for (let trial=0;trial<2000;trial++) { const len=next()%201;let s='';for(let i=0;i<len;i++)s+=String.fromCharCode(next()&0xffff);same('random:'+trial,s); }
const base='docs/validation/2026-10-12/completion-audit/earned-takeda-native/';
const save=gunzipSync(readFileSync(base+'native-CPU-prefix.tfusave.gz')).toString('utf8');
const evidence=gunzipSync(readFileSync(base+'native-CPU-prefix-green.json.gz')).toString('utf8');
const parsed=JSON.parse(evidence);
same('actual-save',save);
same('actual-evidence',evidence);
same('actual-final-state-json',JSON.stringify(parsed.state));
same('actual-first-month-state-json',JSON.stringify(parsed.months[0].state));
console.log(JSON.stringify({passed:true,checked,actualSaveBytes:Buffer.byteLength(save),actualEvidenceBytes:Buffer.byteLength(evidence),actualEvidenceFnv:limbFnv(evidence)}));

#!/usr/bin/env bash
set -euo pipefail
runtime=/tmp/tenka-takeda-limb-runtime-b1-c1
node_bin=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin/node
export PATH=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin:$PATH
export TAKEDA_BENCH_SAVE_PATH=/tmp/tenka-takeda-limb-save-b1-c1.tfusave
exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir /tmp/tenka-takeda-limb-benchmark-child-b1-c1 --cwd "$runtime" -- "$node_bin" node_modules/vitest/vitest.mjs run --project core tests/core/fnvLimbBenchmark.spec.ts --minWorkers=1 --maxWorkers=1

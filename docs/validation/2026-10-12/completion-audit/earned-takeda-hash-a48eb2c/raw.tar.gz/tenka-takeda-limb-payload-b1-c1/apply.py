#!/usr/bin/env python3
import hashlib,json,shutil
from pathlib import Path
runtime=Path('/tmp/tenka-takeda-limb-runtime-b1-c1')
payload=Path('/tmp/tenka-takeda-limb-payload-b1-c1')
meta=json.loads((payload/'payload.json').read_text())
for name,row in meta['files'].items():
 b=(payload/name).read_bytes()
 assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],name
mapping={'serialize.ts':'src/core/state/serialize.ts','helper.ts':'tests/helpers/earnedMiyoshiTakeda.ts','test.spec.ts':'tests/app/earnedMiyoshiTakedaJourney.spec.ts','fnvBigIntB1.ts':'tests/core/fixtures/fnvBigIntB1.ts','fnvLimbCompatibility.spec.ts':'tests/core/fnvLimbCompatibility.spec.ts','fnvLimbBenchmark.spec.ts':'tests/core/fnvLimbBenchmark.spec.ts'}
for name,target in mapping.items():
 dest=runtime/target
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(payload/name,dest)
print(json.dumps({'overlays':mapping}))

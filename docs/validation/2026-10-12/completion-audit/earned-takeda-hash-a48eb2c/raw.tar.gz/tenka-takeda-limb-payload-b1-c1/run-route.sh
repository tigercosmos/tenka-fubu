#!/usr/bin/env bash
set -euo pipefail
runtime=/tmp/tenka-takeda-limb-runtime-b1-c1
node_bin=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin/node
export PATH=/tmp/tenka-fubu-parallel-20261011.FC6Shj/runtime/bin:$PATH
export EARNED_MIYOSHI_TAKEDA_SAVE_PATH=/tmp/tenka-takeda-limb-save-b1-c1.tfusave
exec python3 /tmp/tenka-validation-capture-961f0ae.py --run-dir /tmp/tenka-takeda-limb-route-child-b1-c1 --cwd "$runtime" -- "$node_bin" node_modules/vitest/vitest.mjs run --project app tests/app/earnedMiyoshiTakedaJourney.spec.ts --minWorkers=1 --maxWorkers=1 -t 'generates a CPU-earned day300 Miyoshi Takeda checkpoint with all actual arrivals answered'

#!/usr/bin/env python3
import hashlib,json,os
from pathlib import Path
runtime=Path('/tmp/tenka-takeda-limb-runtime-b1-c1')
payload=Path('/tmp/tenka-takeda-limb-payload-b1-c1')
source=json.loads((payload/'source-manifest.json').read_text())
meta=json.loads((payload/'payload.json').read_text())
assert source['revision']==meta['revision']
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
for name,row in meta['files'].items():
 data=(payload/name).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['size'],name
overlays={'src/core/state/serialize.ts':'serialize.ts','tests/helpers/earnedMiyoshiTakeda.ts':'helper.ts','tests/app/earnedMiyoshiTakedaJourney.spec.ts':'test.spec.ts'}
extras_allowed={'tests/core/fixtures/fnvBigIntB1.ts':'fnvBigIntB1.ts','tests/core/fnvLimbCompatibility.spec.ts':'fnvLimbCompatibility.spec.ts','tests/core/fnvLimbBenchmark.spec.ts':'fnvLimbBenchmark.spec.ts'}
bad=[]
for name,row in source['entries'].items():
 p=runtime/name
 if not p.is_file():bad.append([name,'missing']);continue
 data=p.read_bytes()
 if name in overlays:
  if sha(data)!=meta['files'][overlays[name]]['sha256'] or blob(data)==row['gitBlob']:bad.append([name,'overlay'])
 elif blob(data)!=row['gitBlob']:bad.append([name,'gitBlob'])
 if bool(p.stat().st_mode & 0o111)!=(row['mode']=='100755'):bad.append([name,'mode'])
for name,payload_name in extras_allowed.items():
 if not (runtime/name).is_file() or sha((runtime/name).read_bytes())!=meta['files'][payload_name]['sha256']:bad.append([name,'extra-overlay'])
actual=set()
for root,dirs,files in os.walk(runtime,followlinks=False):
 dirs[:]=[d for d in dirs if d not in {'node_modules','dist','playwright-report','runs'}]
 for f in files:actual.add(str((Path(root)/f).relative_to(runtime)))
extras=sorted(actual-set(source['entries'])-set(extras_allowed));missing=sorted(set(source['entries'])-actual)
targets=json.loads((runtime/'tools/dependencies/pixi-8.19-patch.json').read_text())['targets']
deps=[{'path':r['path'],'expected':r['patchedSha256'],'actual':sha((runtime/'node_modules/pixi.js'/r['path']).read_bytes())} for r in targets]
result={'revision':source['revision'],'entries':len(source['entries']),'overlays':{k:meta['files'][v]['sha256'] for k,v in overlays.items()},'extraTests':{k:meta['files'][v]['sha256'] for k,v in extras_allowed.items()},'bad':bad,'extras':extras,'missing':missing,'dependencies':deps,'passed':not bad and not extras and not missing and len(deps)==29 and all(r['expected']==r['actual'] for r in deps)}
print(json.dumps(result))
assert result['passed']

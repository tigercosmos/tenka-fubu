import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { GameState } from '../../src/core/state/gameState';
import { canonicalStringify, stateHash } from '../../src/core/state/serialize';
import { fnv1a64 as legacyFnv1a64 } from './fixtures/fnvBigIntB1';

function legacyStateHash(state: GameState): string {
  return legacyFnv1a64(canonicalStringify({ ...state, ai: { ...state.ai, intentLog: [] } }));
}

describe('day-300 full-state hash composite diagnostic', () => {
  it('compares alternating order on the freshly earned state', () => {
    const savePath = process.env.TAKEDA_BENCH_SAVE_PATH;
    expect(savePath).toBeTruthy();
    const state = (JSON.parse(readFileSync(savePath!, 'utf8')) as { state: GameState }).state;
    expect(state.time.day).toBe(300);
    for (let i = 0; i < 2; i++) expect(stateHash(state)).toBe(legacyStateHash(state));
    const expected = stateHash(state);
    const times = { legacy: [] as number[], limb: [] as number[] };
    for (let i = 0; i < 12; i++) {
      const order = i % 2 === 0 ? (['legacy', 'limb'] as const) : (['limb', 'legacy'] as const);
      for (const implementation of order) {
        const start = performance.now();
        const result = implementation === 'legacy' ? legacyStateHash(state) : stateHash(state);
        times[implementation].push(performance.now() - start);
        expect(result).toBe(expected);
      }
    }
    const sorted = (values: number[]) => [...values].sort((a, b) => a - b);
    const median = (values: number[]) => {
      const data = sorted(values);
      return (data[5]! + data[6]!) / 2;
    };
    console.log(
      'FNV_COMPOSITE ' +
        JSON.stringify({
          day: state.time.day,
          repeats: 12,
          legacyMedianMs: median(times.legacy),
          limbMedianMs: median(times.limb),
          times,
        }),
    );
  });
});

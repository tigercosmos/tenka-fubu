from pathlib import Path
import hashlib
root=Path('/Users/tigercosmos/tenka-fubu')
out=Path('/tmp/tenka-takeda-census-overlay-b1-c2')
out.mkdir(exist_ok=False)
helper=(root/'tests/helpers/earnedMiyoshiTakeda.ts').read_text()
test=(root/'tests/app/earnedMiyoshiTakedaJourney.spec.ts').read_text()
def repl(s,old,new,n=1):
 assert s.count(old)==n,(old,s.count(old),n)
 return s.replace(old,new)
helper=repl(helper,"export const MIYOSHI =",'''export const takedaCensus: Record<string, { count: number; ms: number }> = {};
function timed<T>(name: string, operation: () => T): T {
  const start = performance.now();
  try {
    return operation();
  } finally {
    const row = (takedaCensus[name] ??= { count: 0, ms: 0 });
    row.count++;
    row.ms += performance.now() - start;
  }
}
export const MIYOSHI =''')
helper=repl(helper,'const game = buildGameStateFromScenario(await loadS1560Scenario(), {',"const scenario = await timedAsync('scenarioLoad', () => loadS1560Scenario());\n  const game = timed('scenarioBuild', () => buildGameStateFromScenario(scenario, {")
helper=repl(helper,"    startDay: 0,\n  });\n  const engine = await loadScenarioEventEngine(game.meta.scenarioId);", "    startDay: 0,\n  }));\n  const engine = await timedAsync('eventEngineLoad', () => loadScenarioEventEngine(game.meta.scenarioId));")
helper=repl(helper,"function timed<T>(name: string, operation: () => T): T {", "async function timedAsync<T>(name: string, operation: () => Promise<T>): Promise<T> {\n  const start = performance.now();\n  try {\n    return await operation();\n  } finally {\n    const row = (takedaCensus[name] ??= { count: 0, ms: 0 });\n    row.count++;\n    row.ms += performance.now() - start;\n  }\n}\nfunction timed<T>(name: string, operation: () => T): T {")
helper=repl(helper,"const initial = structuredClone(game);", "const initial = timed('initialClone', () => structuredClone(game));")
helper=repl(helper,"assert.deepEqual(validateCommand(game, command, undefined, { eventEngine: engine }), {", "assert.deepEqual(timed('commandValidate', () => validateCommand(game, command, undefined, { eventEngine: engine })), {")
helper=repl(helper,"const before = stateHash(game);", "const before = timed('commandHash', () => stateHash(game));")
helper=repl(helper,"assert.deepEqual(dispatchCommand(command), { ok: true });", "assert.deepEqual(timed('commandDispatch', () => dispatchCommand(command)), { ok: true });")
helper=repl(helper,"assert.equal(stateHash(game), before);", "assert.equal(timed('commandHash', () => stateHash(game)), before);")
helper=repl(helper,"  for (let tick = 0; tick < 300; tick++) {", "  const dailyLoopStart = performance.now();\n  for (let tick = 0; tick < 300; tick++) {")
helper=repl(helper,"const emitted = runOneDay();", "const emitted = timed('runOneDay', () => runOneDay());")
helper=repl(helper,"events.push(structuredClone(emitted));", "events.push(timed('eventClone', () => structuredClone(emitted)));")
helper=repl(helper,"assert.deepEqual(validateState(game), []);", "assert.deepEqual(timed('validateState', () => validateState(game)), []);")
helper=repl(helper,"dailyHashes.push({ day: game.time.day, hash: stateHash(game) });", "dailyHashes.push({ day: game.time.day, hash: timed('dailyHash', () => stateHash(game)) });")
helper=repl(helper,"state: structuredClone(game),\n      });", "state: timed('monthClone', () => structuredClone(game)),\n      });")
helper=repl(helper,"  assert.equal(game.time.day, 300);", "  takedaCensus.dailyLoopWall = { count: 300, ms: performance.now() - dailyLoopStart };\n  assert.equal(game.time.day, 300);")
helper=repl(helper,"const raw = encodeSave(game, 0);", "const raw = timed('encodeSave', () => encodeSave(game, 0));")
helper=repl(helper,"const decoded = decodeSave(raw);", "const decoded = timed('decodeSave', () => decodeSave(raw));")
helper=repl(helper,"assert.deepEqual(persistentMiyoshiState(decoded.saveFile.state), persistentMiyoshiState(game));", "assert.deepEqual(timed('persistentClone', () => persistentMiyoshiState(decoded.saveFile.state)), timed('persistentClone', () => persistentMiyoshiState(game)));")
helper=repl(helper,"    state: structuredClone(game),", "    state: timed('finalClone', () => structuredClone(game)),")
helper=repl(helper,"    log: exportCommandLog(),", "    log: timed('exportCommandLog', () => exportCommandLog()),")
test=repl(test,"  NAGAYOSHI,\n", "  NAGAYOSHI,\n  takedaCensus,\n")
test=repl(test,"  const result = await earnMiyoshiTakedaCheckpoint();", "  const callbackStart = performance.now();\n  let helperEnd = callbackStart;\n  try {\n  const result = await earnMiyoshiTakedaCheckpoint();\n  helperEnd = performance.now();")
test=repl(test,"    await writeFile(process.env.EARNED_MIYOSHI_TAKEDA_SAVE_PATH, result.raw);\n    await writeFile(\n      `${process.env.EARNED_MIYOSHI_TAKEDA_SAVE_PATH}.evidence.json`,\n      JSON.stringify(result, null, 2),\n    );", "    const saveWriteStart = performance.now();\n    await writeFile(process.env.EARNED_MIYOSHI_TAKEDA_SAVE_PATH, result.raw);\n    takedaCensus.saveWrite = { count: 1, ms: performance.now() - saveWriteStart };\n    const stringifyStart = performance.now();\n    const evidence = JSON.stringify(result, null, 2);\n    takedaCensus.evidenceStringify = { count: 1, ms: performance.now() - stringifyStart };\n    takedaCensus.evidenceBytes = { count: Buffer.byteLength(evidence), ms: 0 };\n    const evidenceWriteStart = performance.now();\n    await writeFile(`${process.env.EARNED_MIYOSHI_TAKEDA_SAVE_PATH}.evidence.json`, evidence);\n    takedaCensus.evidenceWrite = { count: 1, ms: performance.now() - evidenceWriteStart };")
test=repl(test,"  }\n}, 60_000);", "  }\n  } finally {\n    const end = performance.now();\n    const buckets = Object.entries(takedaCensus).filter(([name]) => !['dailyLoopWall', 'evidenceBytes'].includes(name));\n    const timedSum = buckets.reduce((sum, [, row]) => sum + row.ms, 0);\n    console.error('TAKEDA_CENSUS ' + JSON.stringify({ callbackWallMs: end - callbackStart, helperWallMs: helperEnd - callbackStart, dailyLoopWallMs: takedaCensus.dailyLoopWall?.ms ?? null, timedSumMs: timedSum, unaccountedCallbackMs: end - callbackStart - timedSum, buckets: takedaCensus }));\n  }\n}, 60_000);")
for name,value in [('earnedMiyoshiTakeda.ts',helper),('earnedMiyoshiTakedaJourney.spec.ts',test)]:
 p=out/name;p.write_text(value);print(name,hashlib.sha256(p.read_bytes()).hexdigest(),len(p.read_bytes()))

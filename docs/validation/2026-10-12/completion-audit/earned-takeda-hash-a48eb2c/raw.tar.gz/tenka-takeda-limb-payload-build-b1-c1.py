from pathlib import Path
import hashlib,json,shutil
out=Path('/tmp/tenka-takeda-limb-payload-b1-c1');out.mkdir(exist_ok=False)
files={
 'serialize.ts':Path('/tmp/tenka-serialize-limb-candidate-b1-c1.ts'),
 'helper.ts':Path('/tmp/tenka-takeda-census-overlay-b1-c3/earnedMiyoshiTakeda.ts'),
 'test.spec.ts':Path('/tmp/tenka-takeda-census-overlay-b1-c3/earnedMiyoshiTakedaJourney.spec.ts'),
 'fnvBigIntB1.ts':Path('/tmp/tenka-fnv-bigint-b1-fixture-c1.ts'),
 'fnvLimbCompatibility.spec.ts':Path('/tmp/tenka-fnv-limb-compatibility-b1-c2.spec.ts'),
 'fnvLimbBenchmark.spec.ts':Path('/tmp/tenka-fnv-limb-benchmark-b1-c1.spec.ts'),
 'source-manifest.json':Path('/tmp/tenka-takeda-census-delta-b1-c1/manifest.json'),
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,p in files.items():shutil.copy2(p,out/name)
meta={'revision':'b1a8fc8b21119bc3e540a6d5c5a83f1bd9911353','files':{name:{'sha256':sha(out/name),'size':(out/name).stat().st_size} for name in files}}
(out/'payload.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))

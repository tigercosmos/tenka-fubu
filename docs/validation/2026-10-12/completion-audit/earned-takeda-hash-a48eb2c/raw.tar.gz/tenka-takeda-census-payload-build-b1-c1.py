from pathlib import Path
import hashlib,json,shutil
out=Path('/tmp/tenka-takeda-census-payload-b1-c1');out.mkdir(exist_ok=False)
files={
 'helper.ts':Path('/tmp/tenka-takeda-census-overlay-b1-c3/earnedMiyoshiTakeda.ts'),
 'test.spec.ts':Path('/tmp/tenka-takeda-census-overlay-b1-c3/earnedMiyoshiTakedaJourney.spec.ts'),
 'ending-original.spec.tsx':Path('/Users/tigercosmos/tenka-fubu/tests/app/earnedRegionalEndingJourney.spec.tsx'),
 'source.tar':Path('/tmp/tenka-takeda-census-delta-b1-c1/source.tar'),
 'source-manifest.json':Path('/tmp/tenka-takeda-census-delta-b1-c1/manifest.json'),
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,p in files.items():shutil.copy2(p,out/name)
meta={'revision':'b1a8fc8b21119bc3e540a6d5c5a83f1bd9911353','files':{name:{'sha256':sha(out/name),'size':(out/name).stat().st_size} for name in files}}
(out/'payload.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))

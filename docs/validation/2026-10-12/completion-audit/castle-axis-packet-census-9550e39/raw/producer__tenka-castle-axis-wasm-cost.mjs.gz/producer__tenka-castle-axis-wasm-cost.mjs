import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';

const root = process.argv[2];
const wasm = readFileSync(`${root}/public/wasm/tenka_engine.wasm`);
const { instance } = await WebAssembly.instantiate(wasm, {
  env: { path_node_cost: () => { throw new Error('Pathfinding must not run in ribbon cost control'); } },
});
const backend = instance.exports;
const results = [];
for (const camera of ['overview', 'operational', 'close']) {
  const input = readFileSync(`${root}/packet-binary/${camera}.bin`);
  const expected = readFileSync(`${root}/packet-binary/${camera}.output.bin`);
  const words = input.length / 8;
  const pointer = backend.engine_alloc(words);
  const outputStart = input.length - expected.length;
  const invoke = () => {
    new Uint8Array(backend.memory.buffer, pointer, input.length).set(input);
    const status = backend.castle_ribbon_solve(pointer, words);
    const output = Buffer.from(new Uint8Array(backend.memory.buffer, pointer + outputStart, expected.length));
    if (!output.equals(expected)) throw new Error(`bitwise output differs for ${camera}`);
    return status;
  };
  const first = invoke();
  for (let i = 0; i < 50; i++) invoke();
  const batches = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100; i++) invoke();
    batches.push((performance.now() - start) / 100);
  }
  backend.engine_free(pointer, words);
  results.push({ camera, first, words, batchesMs: batches, medianMs: [...batches].sort((a,b)=>a-b)[2] });
}
console.log(JSON.stringify({ wasmSha256: createHash('sha256').update(wasm).digest('hex'),
  scope: 'offline Node WASM full-solver cost; includes input copy/output comparison; not browser frame FPS',
  results }, null, 2));

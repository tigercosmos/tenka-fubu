import { writeFile } from 'node:fs/promises';
import { test, expect } from './fixtures';
import { completeNewGameWizard } from './new-game-wizard';

test('read-only complete castle solver packets for three national cameras', async ({ page }, info) => {
  await page.setViewportSize({ width: 1920, height: 1080 });
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/?debug=1&seed=15600519');
  await page.getByTestId('title-newgame').click();
  await page.getByTestId('scenario-pick-s1560').click();
  await page.getByTestId('clan-pick-clan.oda').click();
  await completeNewGameWizard(page);
  await expect(page.getByTestId('screen-strategy')).toBeVisible();
  await page.getByTestId('speed-pause').click();
  const preparation = await page.evaluate(() => window.__tenka.debug.prepareLiveNationalMapWorkload(120));
  expect(preparation.count).toBe(120);
  const before = await page.evaluate(() => ({
    state: JSON.stringify(window.__tenka.debug.getState()),
    commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
    resources: window.__tenka.debug.getMapDiagnostics().resources,
  }));
  const environment = await page.evaluate(() => {
    const canvas = document.querySelector('canvas');
    const gl = canvas?.getContext('webgl2') ?? canvas?.getContext('webgl');
    if (!(gl instanceof WebGLRenderingContext || gl instanceof WebGL2RenderingContext))
      throw new Error('Actual WebGL context required');
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    return {
      renderer: String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER)),
      vendor: String(gl.getParameter(ext ? ext.UNMASKED_VENDOR_WEBGL : gl.VENDOR)),
      userAgent: navigator.userAgent,
    };
  });
  expect(environment.renderer).not.toMatch(/swiftshader|llvmpipe|software/i);
  const captures = [];
  for (const preset of ['overview', 'operational', 'close'] as const) {
    const capture = await page.evaluate(async (camera) => {
      Reflect.set(globalThis, '__tenkaRibbonCaptureLabel', camera);
      await document.fonts.ready;
      await window.__tenka.debug.setMapCameraPreset(camera);
      await window.__tenka.debug.waitMapIdle(3);
      const diagnostics = window.__tenka.debug.getMapDiagnostics();
      const store = Reflect.get(globalThis, '__tenkaRibbonCaptureStore') as Record<string, unknown>;
      const packet = store?.[camera];
      Reflect.deleteProperty(globalThis, '__tenkaRibbonCaptureLabel');
      return { camera, packet, layout: diagnostics.castleRibbonLayout };
    }, preset);
    expect(capture.packet).toBeDefined();
    captures.push(capture);
  }
  const after = await page.evaluate(() => ({
    state: JSON.stringify(window.__tenka.debug.getState()),
    commands: JSON.stringify(window.__tenka.debug.exportCommandLog()),
    resources: window.__tenka.debug.getMapDiagnostics().resources,
  }));
  expect(after).toEqual(before);
  const path = info.outputPath('castle-solver-full-packets.json');
  await writeFile(path, JSON.stringify({ environment, preparation, before, after, captures }));
  await info.attach('castle-solver-full-packets', { path, contentType: 'application/json' });
});

#!/usr/bin/env python3
import json
import struct
import sys
from pathlib import Path

source = json.loads(Path(sys.argv[1]).read_text())
destination = Path(sys.argv[2])
destination.mkdir(parents=True, exist_ok=False)
for item in source['captures']:
    p = item['packet']
    words = [int(x, 16) for x in p['inputHex']]
    words.extend([0] * p['outputWords'])
    data = b''.join(struct.pack('<Q', value) for value in words)
    (destination / (item['camera'] + '.bin')).write_bytes(data)
    reference = b''.join(struct.pack('<Q', int(value, 16)) for value in p['outputHex'])
    (destination / (item['camera'] + '.output.bin')).write_bytes(reference)

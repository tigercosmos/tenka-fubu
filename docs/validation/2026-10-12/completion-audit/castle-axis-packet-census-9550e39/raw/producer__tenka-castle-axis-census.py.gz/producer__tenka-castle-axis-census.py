#!/usr/bin/env python3
import json
import math
import statistics
import struct
import sys

raw = json.load(open(sys.argv[1]))
f64 = lambda value: struct.unpack('<d', struct.pack('<Q', int(value, 16)))[0]

def rect(words):
    return tuple(words[:4])

def axis_hits(r, baseline, vertical):
    if vertical:
        start, extent, origin, size = r[1], r[3], baseline[1], baseline[3]
    else:
        start, extent, origin, size = r[0], r[2], baseline[0], baseline[2]
    a = ((start - origin) - size) - 4.0
    b = ((start + extent) + 4.0) - origin
    return int(math.isfinite(a) and abs(a) <= 48.0), int(math.isfinite(b) and abs(b) <= 48.0)

def sweep(r, b, gap):
    left, top = b[0] - 48.0 - gap, b[1] - 48.0 - gap
    right, bottom = b[0] + 48.0 + b[2] + gap, b[1] + 48.0 + b[3] + gap
    return r[0] <= right and r[0] + r[2] >= left and r[1] <= bottom and r[1] + r[3] >= top

for item in raw['captures']:
    packet = item['packet']
    words = list(map(f64, packet['inputHex']))
    output = list(map(f64, packet['outputHex']))
    c, ordinary, hard, leaders = map(int, words[1:5])
    assert packet['inputWords'] == 16 + c * 8 + (ordinary + hard + leaders) * 4
    assert packet['outputWords'] == c * 16
    candidates = [rect(words[16 + i * 8:16 + i * 8 + 8]) for i in range(c)]
    fixed_start = 16 + c * 8
    fixed = [rect(words[fixed_start + i * 4:fixed_start + i * 4 + 4]) for i in range(ordinary)]
    hard_start = fixed_start + ordinary * 4
    hard_rows = [rect(words[hard_start + i * 4:hard_start + i * 4 + 4]) for i in range(hard)]
    placed = [rect(output[i * 16 + 2:i * 16 + 6]) for i in range(c)]
    rows = []
    for i, baseline in enumerate(candidates):
        reserved = fixed + placed[:i] + candidates[i + 1:]
        x = [axis_hits(r, baseline, False) for r in reserved]
        y = [axis_hits(r, baseline, True) for r in reserved]
        score = sum(sweep(r, baseline, 4.0) for r in reserved)
        hard_local = sum(sweep(r, baseline, 0.0) for r in hard_rows)
        rows.append({
            'reserved': len(reserved), 'fixed': len(fixed), 'dynamic': len(reserved) - len(fixed),
            'xRects': sum(any(t) for t in x), 'yRects': sum(any(t) for t in y),
            'xEndpoints': sum(sum(t) for t in x), 'yEndpoints': sum(sum(t) for t in y),
            'scoreSweep': score, 'hardSweep': hard_local,
            'fixedXRects': sum(any(t) for t in x[:len(fixed)]),
            'fixedYRects': sum(any(t) for t in y[:len(fixed)]),
        })
    keys = rows[0].keys() if rows else []
    print(json.dumps({
        'camera': item['camera'], 'candidateCount': c, 'ordinaryCount': ordinary,
        'hardCount': hard, 'leaderCount': leaders,
        'work': f64(packet['workHex']),
        'sum': {key: sum(row[key] for row in rows) for key in keys},
        'mean': {key: statistics.mean(row[key] for row in rows) for key in keys},
        'minMax': {key: [min(row[key] for row in rows), max(row[key] for row in rows)] for key in keys},
    }, sort_keys=True))

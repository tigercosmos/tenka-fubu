#!/usr/bin/env python3
import gzip
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
manifest = json.loads((root / 'manifest.json').read_text())
baseline = json.loads(gzip.decompress(Path(sys.argv[2]).read_bytes()))
overlay = json.loads(Path(sys.argv[3]).read_text()) if len(sys.argv) > 3 else {}
bad = []
for name, entry in manifest['entries'].items():
    path = root / name
    if not path.is_file():
        bad.append([name, 'missing'])
        continue
    data = path.read_bytes()
    oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    sha = hashlib.sha256(data).hexdigest()
    if name in overlay and sha != overlay[name]:
        bad.append([name, sha, overlay[name]])
    elif name not in overlay and oid != entry['gitBlob']:
        bad.append([name, oid, entry['gitBlob']])
for name, expected in overlay.items():
    if name in manifest['entries']:
        continue
    path = root / name
    sha = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if sha != expected:
        bad.append([name, sha, expected])
dependencies = []
for entry in baseline['dependencies']:
    path = root / 'node_modules' / 'pixi.js' / entry['path']
    digest = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if digest != entry['expected']:
        bad.append([str(path), digest, entry['expected']])
    dependencies.append({'path': entry['path'], 'sha256': digest})
out = {'revision': manifest['revision'], 'sourceCount': len(manifest['entries']),
       'dependencyCount': len(dependencies), 'bad': bad,
       'nodeModulesTarget': str((root / 'node_modules').resolve()),
       'dependencies': dependencies, 'overlay': overlay}
print(json.dumps(out, indent=2))
if bad:
    raise SystemExit(1)

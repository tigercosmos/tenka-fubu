#!/usr/bin/env python3
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
path = root / 'src/ui/map/wasmCastleRibbonPlanner.ts'
data = path.read_text()
old = '      const status = backend.castle_ribbon_solve(pointer, words);'
new = '''      const captureLabel = Reflect.get(globalThis, '__tenkaRibbonCaptureLabel');
      const bits = (values: Float64Array, start: number, end: number): string[] => {
        const view = new DataView(values.buffer, values.byteOffset, words * 8);
        return Array.from({ length: end - start }, (_, offset) =>
          view.getBigUint64((start + offset) * 8, true).toString(16).padStart(16, '0'),
        );
      };
      const inputHex = typeof captureLabel === 'string' ? bits(arena, 0, outputStart) : null;
      const status = backend.castle_ribbon_solve(pointer, words);'''
assert data.count(old) == 1
data = data.replace(old, new)
old = '      const resultArena = arenaFor(words);'
new = '''      const resultArena = arenaFor(words);
      if (inputHex !== null) {
        let store = Reflect.get(globalThis, '__tenkaRibbonCaptureStore') as
          | Record<string, unknown>
          | undefined;
        if (store === undefined) {
          store = {};
          Reflect.set(globalThis, '__tenkaRibbonCaptureStore', store);
        }
        store[captureLabel] = {
          label: captureLabel,
          inputWords: outputStart,
          outputWords: words - outputStart,
          status,
          inputHex,
          outputHex: bits(resultArena, outputStart, words),
          workHex: bits(resultArena, 6, 7)[0],
        };
      }'''
assert data.count(old) == 1
data = data.replace(old, new)
path.write_text(data)
print(json.dumps({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))

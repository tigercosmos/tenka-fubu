#[path = "../rust/engine/src/geographic.rs"]
mod geographic;
use geographic::{js_min,js_max,Rect};
fn overlap_candidate(a: Rect, right: f64, bottom: f64, b: Rect, padding: f64) -> f64 {
    js_max(
        0.0,
        js_min(right + padding, b.x + b.width + padding) - js_max(a.x - padding, b.x - padding),
    ) * js_max(
        0.0,
        js_min(bottom + padding, b.y + b.height + padding) - js_max(a.y - padding, b.y - padding),
    )
}

#[test]
fn direct_exact_old_new_f64_grid() {
    let values = [-0.0,0.0,f64::from_bits(1),-f64::from_bits(1),f64::MIN_POSITIVE,-f64::MIN_POSITIVE,1.0,-1.0,4.0,48.0,1e200,-1e200,f64::MAX,-f64::MAX,f64::INFINITY,f64::NEG_INFINITY,f64::NAN];
    let blockers = [
        Rect{x:0.0,y:0.0,width:0.0,height:0.0},
        Rect{x:-0.0,y:-0.0,width:-0.0,height:-0.0},
        Rect{x:-4.0,y:-4.0,width:8.0,height:8.0},
        Rect{x:1e200,y:0.0,width:1e200,height:1e200},
        Rect{x:-f64::MAX,y:f64::MAX,width:f64::MAX,height:0.0},
        Rect{x:f64::INFINITY,y:0.0,width:0.0,height:f64::INFINITY},
        Rect{x:f64::NAN,y:0.0,width:1.0,height:1.0},
    ];
    let mut count=0;
    for x in values {for y in values {for width in values {for height in values {
        let a=Rect{x,y,width,height};let right=a.x+a.width;let bottom=a.y+a.height;
        for b in blockers {for padding in [0.0,2.0] {
            let old=geographic::overlap(a,b,padding);
            let new=overlap_candidate(a,right,bottom,b,padding);
            if old.is_nan() {assert!(new.is_nan());} else {assert_eq!(old.to_bits(),new.to_bits(),"x={x:?} y={y:?} w={width:?} h={height:?} pad={padding}");}
            count+=1;
        }}
    }}}}
    println!("DIRECT_HELPER_PARITY_CASES={count}");
}

import pathlib,json,hashlib,os,subprocess,platform,time
r=pathlib.Path('/tmp/tenka-national120-current23-20261012'); out=pathlib.Path('/tmp/tenka-current23-evidence');out.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.load(open('/tmp/tenka-current23-expected.json')); rows=[]
for f in m['files']:
 p=r/f['path'];b=p.read_bytes() if p.exists() else b'';rows.append({**f,'actualSHA256':h(b),'actualBytes':len(b),'match':p.exists() and h(b)==f['sha256']})
expected={x['path'] for x in rows};extras=[]
for folder in ['src','public','rust','tools','tests']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and str(p.relative_to(r)) not in expected:extras.append(str(p.relative_to(r)))
proof={'commit':m['commit'],'scope':'all frozen src/public/rust/tools/tests and root code/config files','files':rows,'extras':extras,'allMatch':all(x['match'] for x in rows),'publicSymlinks':[str(p) for p in (r/'public').rglob('*') if p.is_symlink()]}
(out/'source-proof.json').write_text(json.dumps(proof,indent=2));assert proof['allMatch'] and not extras and not proof['publicSymlinks']
patch=json.loads((r/'tools/dependencies/pixi-8.19-patch.json').read_text());pr=[]
for f in patch['targets']:
 p=r/'node_modules/pixi.js'/f['path'];b=p.read_bytes();pr.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':h(b),'expectedSHA256':f['patchedSha256'],'match':h(b)==f['patchedSha256']})
(out/'dependency-proof.json').write_text(json.dumps({'freshInstallLogSHA256':h(pathlib.Path('/tmp/tenka-current23-npmci.log').read_bytes()),'freshInstallLog':'validated23 written23; added359','nodeModulesRealPath':str((r/'node_modules').resolve()),'packageLockSHA256':h((r/'package-lock.json').read_bytes()),'patches':pr},indent=2));assert len(pr)==23 and all(x['match'] for x in pr)
ref=pathlib.Path('/tmp/tenka-national120-published-reference.json');a=pathlib.Path('/tmp/tenka-national120-published-current23.json');j=json.loads(a.read_text());refj=json.loads(ref.read_text())
pp={'referenceSHA256':h(ref.read_bytes()),'actualSHA256':h(a.read_bytes()),'fullPayloadEqual':j==refj,'snapshotsEqual':j['snapshots']==refj['snapshots'],'snapshots':len(j['snapshots']),'days':[s['day'] for s in j['snapshots']],'excludedNonvisualCounters':j['excludedNonvisualCounters']}
(out/'parity-proof.json').write_text(json.dumps(pp,indent=2));assert pp['fullPayloadEqual']
env={'host':platform.node(),'uname':platform.platform(),'environment':{k:os.environ.get(k) for k in ['PATH','DISPLAY','XDG_RUNTIME_DIR','VK_ICD_FILENAMES']},'node':subprocess.check_output(['node','--version']).decode().strip(),'npm':subprocess.check_output(['npm','--version']).decode().strip(),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader']).decode(),'driverHashes':[]}
for p in [r/'playwright.config.ts',r/'e2e/fixtures.ts',r/'e2e/national120-map-perf.spec.ts',r/'national120-published.mjs',pathlib.Path('/home/anchi/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome')]:
 b=p.read_bytes();env['driverHashes'].append({'path':str(p),'sha256':h(b),'bytes':len(b)})
(out/'environment.json').write_text(json.dumps(env,indent=2))
print(json.dumps({'sourceAllMatch':proof['allMatch'],'fileCount':len(rows),'patchCount':len(pr),'parity':pp}))

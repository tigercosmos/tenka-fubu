#!/bin/bash
# Recorded commands; measurements already ran once. Do not execute to retry.
export PATH="$HOME/.nvm/versions/node/v22.23.3/bin:$PATH"
cd /tmp/tenka-national120-current23-20261012
# npm ci was completed by the inherited setup, before the recovery agent.
# Missing frozen tests fixtures were then transferred with git archive c05a46c tests.
npm run build > /tmp/tenka-current23-build-final.log 2>&1
node national120-published.mjs current23 > /tmp/tenka-current23-published.log 2>&1
for camera in overview operational close; do
 VISUAL_GPU=1 VISUAL_PERF=1 CI=1 npx playwright test e2e/national120-map-perf.spec.ts --project=chromium --workers=1 --retries=0 --grep "$camera:" --output="/tmp/tenka-current23-$camera-results" > "/tmp/tenka-current23-$camera.log" 2>&1
done

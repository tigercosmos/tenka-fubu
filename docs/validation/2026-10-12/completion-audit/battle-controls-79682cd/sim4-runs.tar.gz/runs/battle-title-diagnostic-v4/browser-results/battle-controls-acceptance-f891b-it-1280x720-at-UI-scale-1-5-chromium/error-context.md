# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-controls-acceptance.spec.ts >> real battle controls fit 1280x720 at UI scale 1.5
- Location: e2e/battle-controls-acceptance.spec.ts:47:3

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 32
Received:    33
```

# Page snapshot

```yaml
- main [ref=e5]:
  - generic [ref=e6]:
    - heading "合戰 ─ 1,600 對 1,600 ─ 第0刻" [level=1] [ref=e7]
    - button "暫停" [pressed] [ref=e8] [cursor=pointer]: ⏸
    - button "一倍速" [ref=e9] [cursor=pointer]: ×1
    - button "二倍速" [ref=e10] [cursor=pointer]: ×2
    - button "五倍速" [ref=e11] [cursor=pointer]: ×5
    - button "全軍委任：關" [ref=e12] [cursor=pointer]
    - button "撤退" [ref=e13] [cursor=pointer]
  - generic [ref=e14]:
    - complementary [ref=e15]:
      - heading "我方部隊" [level=2] [ref=e16]
      - button "甲家當主 1,100人 86 士氣 86 待命" [pressed] [ref=e17] [cursor=pointer]:
        - strong [ref=e18]: 甲家當主
        - generic [ref=e19]: 1,100人
        - generic [ref=e20]:
          - progressbar "士氣 86" [ref=e21]
          - generic [ref=e23]: 士氣 86
        - generic "待命" [ref=e25]
      - button "甲家武士 500人 81 士氣 81 待命" [ref=e26] [cursor=pointer]:
        - strong [ref=e27]: 甲家武士
        - generic [ref=e28]: 500人
        - generic [ref=e29]:
          - progressbar "士氣 81" [ref=e30]
          - generic [ref=e32]: 士氣 81
        - generic "待命" [ref=e34]
    - group "戰術地圖" [ref=e35]:
      - button "本陣 jin.0-1 旗 1,000" [ref=e36] [cursor=pointer]:
        - generic [ref=e37]: 攻方 防禦加成 40%
      - button "jin.0-2 旗 400" [ref=e38] [cursor=pointer]:
        - generic [ref=e39]: 攻方 防禦加成 15%
      - button "jin.1-0 旗 400" [ref=e40] [cursor=pointer]:
        - generic [ref=e41]: 攻方 防禦加成 15%
      - button "jin.1-1 旗 400" [ref=e42] [cursor=pointer]:
        - generic [ref=e43]: 攻方 防禦加成 15%
      - button "jin.1-2 旗 400" [ref=e44] [cursor=pointer]:
        - generic [ref=e45]: 攻方 防禦加成 15%
      - button "jin.2-0 旗 400" [ref=e46] [cursor=pointer]:
        - generic [ref=e47]: 中立 防禦加成 15%
      - button "jin.2-1 旗 400" [ref=e48] [cursor=pointer]:
        - generic [ref=e49]: 中立 防禦加成 15%
      - button "jin.2-2 旗 400" [ref=e50] [cursor=pointer]:
        - generic [ref=e51]: 中立 防禦加成 15%
      - button "jin.3-1 旗 400" [ref=e52] [cursor=pointer]:
        - generic [ref=e53]: 守方 防禦加成 15%
      - button "本陣 jin.4-1 旗 1,000" [disabled] [ref=e54]:
        - generic [ref=e55]: 守方 防禦加成 40%
      - button "jin.4-2 旗 400" [disabled] [ref=e56]:
        - generic [ref=e57]: 守方 防禦加成 15%
      - button "甲家當主 1,100人" [pressed] [ref=e58] [cursor=pointer]:
        - generic [ref=e59]:
          - text: 甲家當主 士氣 86
          - generic [ref=e60]: 待命
      - button "甲家武士 500人" [ref=e61] [cursor=pointer]:
        - generic [ref=e62]:
          - text: 甲家武士 士氣 81
          - generic [ref=e63]: 待命
      - button "敵軍 1,100人" [ref=e64] [cursor=pointer]:
        - generic [ref=e65]:
          - text: 守方 bu.000003 士氣 86
          - generic [ref=e66]: 待命
      - button "敵軍 500人" [ref=e67] [cursor=pointer]:
        - generic [ref=e68]:
          - text: 守方 bu.000004 士氣 81
          - generic [ref=e69]: 待命
    - complementary [ref=e70]:
      - heading "戰況記錄" [level=2] [ref=e72]
      - log "戰況記錄" [ref=e73]:
        - list
  - generic [ref=e74]:
    - generic [ref=e75]:
      - progressbar "采配 5／20" [ref=e76]
      - generic [ref=e78]: 采配 5／20
    - generic "戰法" [ref=e79]:
      - button "突擊 5" [ref=e80] [cursor=pointer]
      - button "齊射 4" [ref=e81] [cursor=pointer]
```

# Test source

```ts
  8   |   await page.goto('/?debug=1');
  9   |   await page.evaluate(() => window.__tenka.debug.startBattle('debug-battle-01'));
  10  |   await expect(page.getByTestId('screen-battle')).toBeVisible();
  11  |   await expect(page.getByTestId('battle-canvas').locator('canvas')).toHaveCount(1);
  12  |   await expect(page.getByTestId('viewport-too-small')).toHaveCount(0);
  13  | }
  14  | 
  15  | async function setScale(page: Page, index: number): Promise<number> {
  16  |   const scale = Number((0.8 + index * 0.05).toFixed(2));
  17  |   await page.keyboard.press('Escape');
  18  |   const menu = page.getByRole('dialog', { name: '系統選單', exact: true });
  19  |   await expect(menu).toBeVisible();
  20  |   await menu.getByRole('button', { name: '設定', exact: true }).click();
  21  |   const settings = page.getByRole('dialog').last();
  22  |   const slider = settings.getByRole('slider', { name: '介面縮放', exact: true });
  23  |   await slider.press('Home');
  24  |   for (let step = 0; step < index; step += 1) await slider.press('ArrowRight');
  25  |   await expect(slider).toHaveValue(String(scale));
  26  |   await settings.getByRole('button', { name: '返回', exact: true }).click();
  27  |   await menu.getByRole('button', { name: '回到遊戲', exact: true }).click();
  28  |   await expect(page.getByRole('dialog')).toHaveCount(0);
  29  |   return scale;
  30  | }
  31  | 
  32  | async function physicalBox(page: Page, testId: string, scroll = false): Promise<void> {
  33  |   const control = page.getByTestId(testId);
  34  |   if (scroll) await control.scrollIntoViewIfNeeded();
  35  |   const box = await control.boundingBox();
  36  |   expect(box, testId).not.toBeNull();
  37  |   expect(box!.width, testId).toBeGreaterThanOrEqual(32);
  38  |   expect(box!.height, testId).toBeGreaterThanOrEqual(32);
  39  |   expect(box!.x, testId).toBeGreaterThanOrEqual(-1);
  40  |   expect(box!.y, testId).toBeGreaterThanOrEqual(-1);
  41  |   expect(box!.x + box!.width, testId).toBeLessThanOrEqual(minimum.width + 1);
  42  |   expect(box!.y + box!.height, testId).toBeLessThanOrEqual(minimum.height + 1);
  43  | }
  44  | 
  45  | for (let index = 0; index < 15; index += 1) {
  46  |   const expectedScale = Number((0.8 + index * 0.05).toFixed(2));
  47  |   test(`real battle controls fit 1280x720 at UI scale ${expectedScale}`, async ({ page }, info) => {
  48  |     await bootBattle(page);
  49  |     const initial = await page.evaluate(() => window.__tenka.debug.getState());
  50  |     const scale = await setScale(page, index);
  51  |     expect(scale).toBe(expectedScale);
  52  |     const screen = page.getByTestId('screen-battle');
  53  |     const geometry = await screen.evaluate((element) => {
  54  |       const header = element.querySelector('header')!;
  55  |       const title = header.querySelector('h1')!;
  56  |       const titleRange = document.createRange();
  57  |       titleRange.selectNodeContents(title);
  58  |       const footer = element.querySelector('footer')!;
  59  |       const field = element.querySelector('[data-testid="battlefield"]')!;
  60  |       const bounds = (node: { getBoundingClientRect(): DOMRect }) => {
  61  |         const box = node.getBoundingClientRect();
  62  |         return { x: box.x, y: box.y, width: box.width, height: box.height };
  63  |       };
  64  |       return {
  65  |         scale: getComputedStyle(document.documentElement).fontSize,
  66  |         documentWidth: document.documentElement.scrollWidth,
  67  |         bodyWidth: document.body.scrollWidth,
  68  |         screen: bounds(element),
  69  |         header: bounds(header),
  70  |         title: {
  71  |           ...bounds(title),
  72  |           scrollWidth: title.scrollWidth,
  73  |           clientWidth: title.clientWidth,
  74  |           scrollHeight: title.scrollHeight,
  75  |           clientHeight: title.clientHeight,
  76  |           text: bounds(titleRange),
  77  |           overflowX: getComputedStyle(title).overflowX,
  78  |           overflowY: getComputedStyle(title).overflowY,
  79  |         },
  80  |         footer: bounds(footer),
  81  |         field: bounds(field),
  82  |         headerButtons: [...header.querySelectorAll('button')].map((button) => ({
  83  |           name: button.getAttribute('aria-label') ?? button.textContent,
  84  |           ...bounds(button),
  85  |         })),
  86  |         tacticButtons: [...footer.querySelectorAll('button')].map((button) => ({
  87  |           name: button.textContent,
  88  |           ...bounds(button),
  89  |         })),
  90  |       };
  91  |     });
  92  |     expect(Number.parseFloat(geometry.scale)).toBeCloseTo(16 * scale, 1);
  93  |     expect(geometry.documentWidth).toBeLessThanOrEqual(minimum.width + 1);
  94  |     expect(geometry.bodyWidth).toBeLessThanOrEqual(minimum.width + 1);
  95  |     expect(geometry.screen.width).toBeLessThanOrEqual(minimum.width + 1);
  96  |     expect(geometry.field.width).toBeGreaterThan(0);
  97  |     expect(geometry.field.height).toBeGreaterThan(0);
  98  |     await info.attach('battle-control-geometry', {
  99  |       body: JSON.stringify(geometry),
  100 |       contentType: 'application/json',
  101 |     });
  102 |     if (index === 14)
  103 |       await info.attach('battle-high-scale-view', {
  104 |         body: await page.screenshot(),
  105 |         contentType: 'image/png',
  106 |       });
  107 |     expect(geometry.title.scrollWidth).toBeLessThanOrEqual(geometry.title.clientWidth + 1);
> 108 |     expect(geometry.title.scrollHeight).toBeLessThanOrEqual(geometry.title.clientHeight + 1);
      |                                         ^ Error: expect(received).toBeLessThanOrEqual(expected)
  109 |     for (const button of geometry.headerButtons) {
  110 |       expect(button.width, button.name ?? '').toBeGreaterThanOrEqual(32);
  111 |       expect(button.height, button.name ?? '').toBeGreaterThanOrEqual(32);
  112 |       expect(button.x, button.name ?? '').toBeGreaterThanOrEqual(-1);
  113 |       expect(button.x + button.width, button.name ?? '').toBeLessThanOrEqual(minimum.width + 1);
  114 |     }
  115 |     const battle = Object.values(initial.battles)[0]!;
  116 |     const playerSide =
  117 |       initial.meta.playerClanId === battle.attackerClanId ? 'attacker' : 'defender';
  118 |     for (const jin of battle.jins) await physicalBox(page, `battle-jin-${jin.id}`);
  119 |     for (const unit of battle.units.filter((candidate) => !candidate.exited))
  120 |       await physicalBox(page, `battle-unit-${unit.id}`);
  121 |     for (const unit of battle.units.filter(
  122 |       (candidate) => candidate.side === playerSide && !candidate.exited,
  123 |     ))
  124 |       await physicalBox(page, `battle-unit-card-${unit.id}`, true);
  125 |     for (const button of await screen.locator('footer button').all()) {
  126 |       await button.scrollIntoViewIfNeeded();
  127 |       const box = await button.boundingBox();
  128 |       expect(box).not.toBeNull();
  129 |       expect(box!.width).toBeGreaterThanOrEqual(32);
  130 |       expect(box!.height).toBeGreaterThanOrEqual(32);
  131 |       expect(box!.x).toBeGreaterThanOrEqual(-1);
  132 |       expect(box!.x + box!.width).toBeLessThanOrEqual(minimum.width + 1);
  133 |     }
  134 |     expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(initial);
  135 |   });
  136 | }
  137 | 
  138 | test('battle native controls keep Space while local speed keys and Escape use battle ownership', async ({
  139 |   page,
  140 | }) => {
  141 |   await bootBattle(page);
  142 |   await setScale(page, 14);
  143 |   const screen = page.getByTestId('screen-battle');
  144 |   const initial = await page.evaluate(() => window.__tenka.debug.getState());
  145 |   const battle = Object.values(initial.battles)[0]!;
  146 |   const side = initial.meta.playerClanId === battle.attackerClanId ? 'attacker' : 'defender';
  147 |   const units = battle.units.filter((unit) => unit.side === side && !unit.exited);
  148 |   expect(units.length).toBeGreaterThan(1);
  149 |   const secondCard = screen.getByTestId(`battle-unit-card-${units[1]!.id}`);
  150 |   await secondCard.focus();
  151 |   await page.keyboard.press('Space');
  152 |   await expect(secondCard).toHaveAttribute('aria-pressed', 'true');
  153 |   const pause = screen.getByRole('button', { name: '暫停', exact: true });
  154 |   await expect(pause).toHaveAttribute('aria-pressed', 'true');
  155 |   expect(await page.evaluate(() => window.__tenka.debug.getState())).toEqual(initial);
  156 | 
  157 |   const x2 = screen.getByRole('button', { name: '二倍速', exact: true });
  158 |   await x2.focus();
  159 |   await page.keyboard.press('Space');
  160 |   await expect(x2).toHaveAttribute('aria-pressed', 'true');
  161 |   await pause.click();
  162 |   await screen.getByTestId('battle-log').focus();
  163 |   await page.keyboard.press('Space');
  164 |   await expect(pause).toHaveAttribute('aria-pressed', 'true');
  165 |   await page.keyboard.press('Escape');
  166 |   const menu = page.getByRole('dialog', { name: '系統選單', exact: true });
  167 |   await expect(menu).toBeVisible();
  168 |   for (const name of ['存檔', '讀檔'])
  169 |     await expect(menu.getByRole('button', { name, exact: true })).toBeDisabled();
  170 |   await page.keyboard.press('Escape');
  171 |   await expect(menu).toHaveCount(0);
  172 |   await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  173 |   const day = await page.evaluate(() => window.__tenka.debug.getState().time.day);
  174 |   for (const [key, name] of [
  175 |     ['1', '一倍速'],
  176 |     ['2', '二倍速'],
  177 |     ['3', '五倍速'],
  178 |   ] as const) {
  179 |     await page.keyboard.press(key);
  180 |     await expect(screen.getByRole('button', { name, exact: true })).toHaveAttribute(
  181 |       'aria-pressed',
  182 |       'true',
  183 |     );
  184 |     await page.keyboard.press('Space');
  185 |     await expect(pause).toHaveAttribute('aria-pressed', 'true');
  186 |   }
  187 |   expect(await page.evaluate(() => window.__tenka.debug.getState().time.day)).toBe(day);
  188 | });
  189 | 
```
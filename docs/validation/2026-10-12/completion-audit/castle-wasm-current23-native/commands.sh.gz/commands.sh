#!/bin/bash
# Recorded commands; do not execute as an FPS retry.
export PATH="$HOME/.nvm/versions/node/v22.23.3/bin:$PATH"
cd /tmp/tenka-castle-current23-20261012
# Frozen04 src/public/rust/tools/tests and root config were extracted from git archive.
# The c05 baseline tree stays intact. Only node_modules is shared intentionally.
# ln -s /tmp/tenka-national120-current23-20261012/node_modules node_modules
python3 /tmp/tenka-castle-current23-proof.py before
npm run build > /tmp/tenka-castle-current23-build.log 2>&1
node national120-published.mjs castle-current23 > /tmp/tenka-castle-current23-published.log 2>&1
python3 /tmp/tenka-castle-current23-proof.py after
for camera in overview operational close; do
 VISUAL_GPU=1 VISUAL_PERF=1 CI=1 npx playwright test e2e/national120-map-perf.spec.ts --project=chromium --workers=1 --retries=0 --grep "$camera:" --output="/tmp/tenka-castle-current23-$camera-results" > "/tmp/tenka-castle-current23-$camera.log" 2>&1
done
# One separate CPU profile follows completed acceptance controls.
node castle-current23-profile.mjs > /tmp/tenka-castle-current23-profile.log 2>&1
node castle-current23-profile-analysis.mjs > /tmp/tenka-castle-current23-profile-analysis.log 2>&1
python3 /tmp/tenka-castle-current23-proof.py final

import pathlib,json,hashlib,zipfile
out=pathlib.Path('/tmp/tenka-castle-current23-evidence');out.mkdir(exist_ok=True);manifest=[];proof=[]
def sha(d):return hashlib.sha256(d).hexdigest()
def add(name,p):
 p=pathlib.Path(p);d=p.read_bytes();(out/name).write_bytes(d);manifest.append({'name':name,'origin':str(p),'bytes':len(d),'sha256':sha(d)})
for camera in ['overview','operational','close']:
 root=pathlib.Path('/tmp/tenka-castle-current23-'+camera+'-results');raw=next(root.rglob('national-'+camera+'-frames.json'));add(''+camera+'.raw.json',raw);add(''+camera+'.log','/tmp/tenka-castle-current23-'+camera+'.log'); trace=next(root.rglob('trace.zip')); states=[]
 with zipfile.ZipFile(trace) as z:
  for name in z.namelist():
   if not name.endswith('.trace'):continue
   for line in z.read(name).splitlines():
    try:r=json.loads(line)
    except:continue
    s=r.get('result',{}).get('value',{}).get('s')
    if r.get('type')=='after' and isinstance(s,str) and s.startswith('{"meta":'):states.append(s.encode())
 assert len(states)==2,(camera,len(states));assert states[0]==states[1]
 if camera=='overview':(out/'canonical-state.raw.json').write_bytes(states[0]);manifest.append({'name':'canonical-state.raw.json','origin':str(trace)+'#exact-page-evaluate-result','bytes':len(states[0]),'sha256':sha(states[0])})
 m=json.loads(raw.read_text())['measurement']; rb=json.dumps(m['resourcesBefore'],sort_keys=True,separators=(',',':')).encode();ra=json.dumps(m['resourcesAfter'],sort_keys=True,separators=(',',':')).encode();assert rb==ra
 proof.append({'camera':camera,'canonicalBeforeSha256':sha(states[0]),'canonicalAfterSha256':sha(states[1]),'canonicalBytes':len(states[0]),'canonicalByteEqual':True,'resourceBeforeSha256':sha(rb),'resourceAfterSha256':sha(ra),'resourceObjectsEqual':True,'tracePath':str(trace),'traceSha256':sha(trace.read_bytes()),'stateSource':'Exact before/after page.evaluate JSON.stringify(getState()) results decoded from Playwright trace value.s','resourceHashEncoding':'UTF8 sorted-key compact JSON'})
(out/'state-resource-proof.json').write_text(json.dumps(proof,indent=2)+'\n')

import { getTrust, getSentiment } from '../src/core/systems/diplomacyCommon';
import { clanPower, evaluateProposal, reinforcementAidScore } from '../src/core/systems/diplomacyEval';
import { validateCommand } from '../src/core/commands/validate';
import type { ClanId } from '../src/core/state/ids';
import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { Page } from '@playwright/test';
import type { GameState } from '../src/core/state/gameState';
import { validateState } from '../src/core/state/invariants';
import { validateStartDiploWork } from '../src/core/commands/diplomacyCommands';
import { monthlyDiplomacyWorkCost } from '../src/core/systems/court';
import { effectiveStat } from '../src/core/systems/officers';
import { BAL } from '../src/core/balance';
import { buildSaveFile } from '../src/core/save/serialize';
import { test, expect } from './fixtures';
import { encodeFullSnapshot } from './full-snapshot-transport';

const scriptedEvents = JSON.parse(
  readFileSync(new URL('../src/data/scenarios/s1560/events.json', import.meta.url), 'utf8'),
) as { events: { choices: { label: string }[] }[] };
const eventChoices = new Set(
  scriptedEvents.events.flatMap((event) => event.choices.map((choice) => choice.label)),
);

const state = async (page: Page): Promise<GameState> => {
  // Trusted self-contained encoder executes in-page; only the complete JSON
  // string crosses the protocol, not Playwright's recursive object encoding.
  const json = await page.evaluate<string>(
    `(${encodeFullSnapshot.toString()})(window.__tenka.debug.getState())`,
  );
  return JSON.parse(json) as GameState;
};
const day = (page: Page) => page.evaluate(() => window.__tenka.debug.getState().time.day);
const log = (page: Page) => page.evaluate(() => window.__tenka.debug.exportCommandLog());

async function dismissKnownOwners(page: Page, choices: string[], holdSummary = false) {
  for (let index = 0; index < 12; index++) {
    const dialog = page.getByRole('dialog');
    if ((await dialog.count()) === 0) return;
    expect(await dialog.count(), 'One native FIFO owner at a time').toBe(1);
    if (await page.getByTestId('month-summary').isVisible()) {
      if (holdSummary) return;
      await page.getByTestId('month-summary-continue').click();
    } else if (await page.getByTestId('proposal-inbox').isVisible()) {
      choices.push('proposal:全部駁回');
      await dialog.getByRole('button', { name: '全部駁回', exact: true }).click();
    } else if (await page.getByTestId('envoy-modal').isVisible()) {
      choices.push('envoy:拒絕');
      await dialog.getByRole('button', { name: '拒絕', exact: true }).click();
    } else if (await page.getByTestId('event-modal').isVisible()) {
      // Read identity and button eligibility in one DOM observation. A queued
      // choice can replace this owner between separate locator property reads.
      const observations = await page.getByTestId('event-modal').evaluateAll((elements) =>
        elements.map((element) => {
          const dialog = element.closest('[role="dialog"]');
          const titleId = dialog?.getAttribute('aria-labelledby');
          return {
            title: titleId ? (document.getElementById(titleId)?.textContent ?? '') : '',
            busy: element.getAttribute('aria-busy') === 'true',
            buttons: Array.from(element.querySelectorAll('button')).map((button) => ({
              label: button.textContent?.trim() ?? '',
              enabled: !button.disabled,
            })),
          };
        }),
      );
      if (observations.length === 0) continue;
      expect(observations).toHaveLength(1);
      const observed = observations[0]!;
      expect(observed.title).not.toBe('');
      const owner = page
        .getByRole('dialog', { name: observed.title, exact: true })
        .filter({ has: page.getByTestId('event-modal') });
      if (observed.busy) {
        await expect(owner).not.toBeVisible({ timeout: 5000 });
        continue;
      }
      const choice = observed.buttons.find(
        (button) => button.enabled && (button.label === '繼續' || eventChoices.has(button.label)),
      );
      if (!choice && !(await owner.isVisible())) continue;
      expect(choice, 'Only authored enabled historical choices are admitted').toBeDefined();
      try {
        await owner
          .getByRole('button', { name: choice!.label, exact: true })
          .click({ timeout: 5000 });
      } catch (error) {
        if (!(await owner.isVisible())) continue;
        throw error;
      }
      choices.push(`event:${choice!.label}`);
      await expect(owner).not.toBeVisible({ timeout: 5000 });
    } else throw new Error('Unknown modal owner; refusing to bypass it');
  }
  throw new Error('Native modal queue did not drain');
}

async function pauseAtBoundary(page: Page) {
  // Modal dismissal may restore its prior speed. Frozen clock means pause input
  // cannot race an extra day while preparing commands or reading settlement.
  const before = await day(page);
  const pause = page.getByTestId('speed-pause');
  if ((await pause.getAttribute('aria-pressed')) !== 'true') await pause.click();
  await expect(pause).toHaveAttribute('aria-pressed', 'true');
  expect(await day(page)).toBe(before);
}

interface DaySchedule {
  before: number;
  after: number;
  slices: number[];
}
async function normalDay(page: Page, schedules: DaySchedule[]) {
  const before = await day(page);
  const schedule: DaySchedule = { before, after: before, slices: [] };
  schedules.push(schedule);
  const pause = page.getByTestId('speed-pause');
  if ((await pause.getAttribute('aria-pressed')) === 'true') {
    await pause.focus();
    schedule.slices.push(32);
    await page.clock.runFor(32);
    expect(await day(page)).toBe(before);
    await page.getByTestId('speed-5').click();
    await expect(page.getByTestId('speed-5')).toHaveAttribute('aria-pressed', 'true');
    // Production x5 advances one normal day per 120ms. The 32ms margin
    // covers the RAF boundary but remains below a second day's 240ms.
    schedule.slices.push(152);
    await page.clock.runFor(152);
  } else {
    // Keep the normal x5 scheduler running between days. Only controlled RAF
    // time advances; native pause is reserved for command/settlement boundaries.
    await expect(page.getByTestId('speed-5')).toHaveAttribute('aria-pressed', 'true');
    schedule.slices.push(120);
    await page.clock.runFor(120);
  }
  // RAF dispatches asynchronously; read only after the real Worker commit.
  await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  // Modal resume resets the accumulator between RAF boundaries. Admit at most
  // three more ordinary 16ms frames while x5 is still selected and unobstructed;
  // never resume an auto-pause, and stop immediately on the first committed day.
  for (let frame = 0; frame < 3 && (await day(page)) === before; frame++) {
    if (
      (await page.getByRole('dialog').count()) !== 0 ||
      (await page.getByTestId('speed-5').getAttribute('aria-pressed')) !== 'true'
    )
      break;
    schedule.slices.push(16);
    await page.clock.runFor(16);
    await page.evaluate(() => window.__tenka.debug.waitSimulationIdle());
  }
  const after = await state(page);
  schedule.after = after.time.day;
  expect(after.time.day).toBe(before + 1);
  expect(validateState(after), `All invariants after normal day ${after.time.day}`).toEqual([]);
  return after;
}

async function openCourt(page: Page) {
  await page.getByTestId('rail-diplomacy').click();
  const panel = page.getByTestId('diplomacy-panel');
  await panel.getByRole('tab', { name: '朝廷', exact: true }).click();
  return panel;
}


test('observe paid Oda work toward Takeda for ten ordinary native months', async ({page}, info) => {
  test.setTimeout(270_000);
  const evidence: Record<string,unknown> = {};
  const choices: string[] = [];
  const schedules: DaySchedule[] = [];
  const months: unknown[] = [];
  try {
    await page.emulateMedia({reducedMotion:'reduce'});
    await page.clock.install();
    await page.goto('/?debug=1&seed=42');
    await page.getByTestId('title-newgame').click();
    await page.getByTestId('scenario-pick-s1560').click();
    await page.getByTestId('clan-pick-clan.oda').click();
    await page.getByTestId('newgame-start').click();
    await expect(page.getByTestId('screen-strategy')).toBeVisible();
    await expect(page.getByTestId('speed-pause')).toHaveAttribute('aria-pressed','true');
    await page.clock.pauseAt((await page.evaluate(()=>Date.now()))+10000);
    const initial=await state(page); evidence.initial=initial;
    const actor='clan.oda' as ClanId, ally='clan.takeda' as ClanId;
    const executor=Object.values(initial.officers).filter(o=>validateStartDiploWork(initial,{type:'startDiploWork',clanId:actor,target:ally,executorId:o.id}).ok).sort((a,b)=>effectiveStat(b,'pol')-effectiveStat(a,'pol'))[0]!;
    evidence.executor=executor;
    await page.getByTestId('rail-diplomacy').click();
    const panel=page.getByTestId('diplomacy-panel');
    await panel.getByRole('button',{name:/武田家 ·/}).click();
    await panel.getByRole('combobox',{name:'執行武將',exact:true}).selectOption(executor.id);
    await panel.getByRole('button',{name:'開始工作',exact:true}).click();
    expect(await state(page)).toEqual(initial);
    await page.keyboard.press('Escape');
    let current=initial;
    while(current.time.day<300) {
      await dismissKnownOwners(page,choices);
      const before=current;
      current=await normalDay(page,schedules);
      if(current.time.day%30===0) {
        await dismissKnownOwners(page,choices,true);
        const mission=before.diplomacy.missions.find(m=>m.fromClanId===actor&&m.target===ally);
        const row={day:current.time.day,trust:getTrust(current,actor,ally),sentiment:getSentiment(current,ally,actor),powers:[clanPower(current,actor),clanPower(current,ally)],score:evaluateProposal(current,actor,ally,'proposeAlliance'),aidScore:reinforcementAidScore(current,actor,ally),gold:current.clans[actor]!.gold,mission,charge:mission?monthlyDiplomacyWorkCost(before,mission):0,state:current};
        months.push(row); console.log('MONTH',JSON.stringify({...row,state:undefined}));
      }
    }
    evidence.final=current;
    evidence.finalVerdict=validateCommand(current,{type:'proposePact',clanId:actor,targetClanId:ally,kind:'proposeAlliance',reinforceAgainstClanId:null});
    evidence.finalScore=evaluateProposal(current,actor,ally,'proposeAlliance');
  } finally {
    evidence.months=months; evidence.choices=choices; evidence.schedules=schedules;
    evidence.log=await log(page);
    await writeFile(info.outputPath('takeda-paid-observation.json'),JSON.stringify(evidence,null,2));
  }
});

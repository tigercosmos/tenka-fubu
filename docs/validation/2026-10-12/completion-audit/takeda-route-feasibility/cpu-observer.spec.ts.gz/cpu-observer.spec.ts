import { afterEach, expect, it } from 'vitest';
import { writeFile } from 'node:fs/promises';
import { loadS1560Scenario } from '../../src/data/scenarios/s1560';
import { buildGameStateFromScenario } from '../../src/core/state/builder';
import { validateState } from '../../src/core/state/invariants';
import { validateCommand } from '../../src/core/commands/validate';
import { stateHash } from '../../src/core/state/serialize';
import type { ClanId } from '../../src/core/state/ids';
import type { Command } from '../../src/core/commands/types';
import { getTrust, getSentiment } from '../../src/core/systems/diplomacyCommon';
import { evaluateProposal, clanPower, reinforcementAidScore } from '../../src/core/systems/diplomacyEval';
import { effectiveStat } from '../../src/core/systems/officers';
import { validateStartDiploWork } from '../../src/core/commands/diplomacyCommands';
import { loadScenarioEventEngine } from '../../src/app/events/scenarioEventEngine';
import { dispatchCommand, runOneDay, initializeBridgeSession, exportCommandLog, resetBridgeForTests } from '../../src/app/bridge';
import { setGame, store, resetGameStoreForTests } from '../../src/app/store';
import { uiStore } from '../../src/ui/hooks/uiStore';

afterEach(()=>{resetBridgeForTests(); resetGameStoreForTests(null); uiStore.getState().actions.reset();});
for(const [actorString, limit, policy] of [['clan.oda',300,false],['clan.miyoshi',420,true]] as const) {
 it(`CPU read-only earned Takeda feasibility ${actorString}`,async()=>{
  const actor=actorString as ClanId, ally='clan.takeda' as ClanId;
  const game=buildGameStateFromScenario(await loadS1560Scenario(),{appVersion:'0.0.0',seed:42,playerClanId:actor,difficulty:'normal',startDay:0});
  const engine=await loadScenarioEventEngine('s1560');
  setGame(game);initializeBridgeSession(game,[],{eventEngine:engine});store.getState().actions.setScreen('main');
  const evidence:any={initial:structuredClone(game),commands:[],months:[],events:[],dailyHashes:[]};
  const path=`/tmp/tenka-takeda-cpu-${actorString}.json`;
  const save=async()=>{evidence.log=exportCommandLog();await writeFile(path,JSON.stringify(evidence,null,2));};
  const submit=(command:Command)=>{expect(validateCommand(game,command,undefined,{eventEngine:engine}).ok).toBe(true);const hash=stateHash(game);expect(dispatchCommand(command)).toEqual({ok:true});expect(stateHash(game)).toBe(hash);evidence.commands.push({day:game.time.day,command});};
  try {
   const executor=Object.values(game.officers).filter(o=>validateStartDiploWork(game,{type:'startDiploWork',clanId:actor,target:ally,executorId:o.id}).ok).sort((a,b)=>effectiveStat(b,'pol')-effectiveStat(a,'pol'))[0]!;
   evidence.executor=executor.id;
   if(policy){const command={type:'enactPolicy',clanId:actor,policyId:'pol.enkokinko'} as Command;evidence.policyVerdict=validateCommand(game,command);if(evidence.policyVerdict.ok)submit(command);}
   submit({type:'startDiploWork',clanId:actor,target:ally,executorId:executor.id});
   await save();
   for(let i=0;i<limit;i++){
    if(game.events.pendingChoiceEventId!==null){const eventId=game.events.pendingChoiceEventId;const choices=Array.from({length:10},(_,choiceIndex)=>({type:'resolveEventChoice',clanId:actor,eventId,choiceIndex}) as Command);const command=choices.find(c=>validateCommand(game,c,undefined,{eventEngine:engine}).ok);expect(command).toBeDefined();submit(command!);}
    for(const p of Object.values(game.proposals).filter(p=>p.clanId===actor&&p.status==='pending'))submit({type:'resolveProposal',clanId:actor,proposalId:p.id,accept:false});
    const events=runOneDay(); evidence.events.push(events);
    expect(game.time.day).toBe(i+1);expect(validateState(game)).toEqual([]);expect(store.getState().session.fatalError).toBeNull();
    evidence.dailyHashes.push({day:game.time.day,hash:stateHash(game)});
    if(game.time.day%30===0){const row={day:game.time.day,trust:getTrust(game,actor,ally),sentiment:getSentiment(game,ally,actor),powers:[clanPower(game,actor),clanPower(game,ally)],score:evaluateProposal(game,actor,ally,'proposeAlliance'),aidScore:reinforcementAidScore(game,actor,ally),gold:game.clans[actor].gold,mission:game.diplomacy.missions.find(m=>m.fromClanId===actor&&m.target===ally),state:structuredClone(game)};evidence.months.push(row);console.log('MONTH',JSON.stringify({...row,state:undefined}));await save();}
    if(actorString==='clan.miyoshi'&&getTrust(game,actor,ally)>=80&&evaluateProposal(game,actor,ally,'proposeAlliance')>=60){evidence.eligible=structuredClone(game);break;}
   }
   evidence.final=structuredClone(game); evidence.verdict=validateCommand(game,{type:'proposePact',clanId:actor,targetClanId:ally,kind:'proposeAlliance',reinforceAgainstClanId:null});
  }finally{await save();}
 },60000);
}

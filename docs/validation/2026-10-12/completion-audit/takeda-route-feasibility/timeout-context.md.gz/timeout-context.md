# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: earned-takeda-observer.spec.ts >> observe paid Oda work toward Takeda for ten ordinary native months
- Location: e2e/earned-takeda-observer.spec.ts:166:1

# Error details

```
Test timeout of 270000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "戰略圖層" [ref=e6]:
    - group [ref=e7]:
      - generic "戰略圖層 · 一般地圖" [ref=e8] [cursor=pointer]
  - banner [ref=e9]:
    - group "金錢、兵糧、兵力、威信" [ref=e10]:
      - generic [ref=e11]:
        - group "織田家" [ref=e12]
        - time [ref=e14]: 1560年9月1日
        - generic [ref=e15]:
          - generic [ref=e16]:
            - img [ref=e17]
            - generic [ref=e20]: 金錢
          - strong [ref=e23]: 1,106
        - generic [ref=e24]:
          - generic [ref=e25]:
            - img [ref=e26]
            - generic [ref=e28]: 兵糧
          - generic [ref=e29]:
            - strong [ref=e31]: 87,721
            - generic "兵糧可支撐199個月" [ref=e32]:
              - text: 兵糧可支撐
              - strong [ref=e33]: "199"
              - text: 個月
        - generic [ref=e34]:
          - generic [ref=e35]:
            - img [ref=e36]
            - generic [ref=e40]: 兵力
          - generic [ref=e42]:
            - strong [ref=e43]: 4,402
            - generic [ref=e44]: /4,402
        - generic [ref=e45]:
          - generic [ref=e46]:
            - img [ref=e47]
            - generic [ref=e49]: 威信
          - strong [ref=e52]: "450"
    - generic [ref=e53]:
      - generic [ref=e54]:
        - button "暫停" [ref=e55] [cursor=pointer]:
          - img [ref=e56]
        - button "一倍速" [ref=e58] [cursor=pointer]:
          - img [ref=e59]
        - button "二倍速" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
        - button "五倍速" [pressed] [ref=e64] [cursor=pointer]:
          - img [ref=e65]
      - status "3項命令待下一日執行" [ref=e67]
      - button "系統選單" [ref=e68] [cursor=pointer]:
        - img [ref=e69]
  - navigation "內政" [ref=e72]:
    - button "地圖一覽" [ref=e73] [cursor=pointer]:
      - img [ref=e74]
      - generic [ref=e77]:
        - generic [ref=e78]: 地圖
        - generic [ref=e79]: 一覽
    - button "織田家 （本城）" [ref=e80] [cursor=pointer]:
      - img [ref=e81]
      - generic "織田家" [ref=e86]: 織田
    - generic [ref=e88]: 軍政
    - button "軍事" [ref=e89] [cursor=pointer]:
      - img [ref=e90]
      - text: 軍事
    - button "內政" [ref=e92] [cursor=pointer]:
      - img [ref=e93]
      - text: 內政
    - button "武將" [ref=e95] [cursor=pointer]:
      - img [ref=e96]
      - text: 武將
    - generic [ref=e101]: 交涉
    - button "外交" [ref=e102] [cursor=pointer]:
      - img [ref=e103]
      - text: 外交
    - button "調略" [ref=e105] [cursor=pointer]:
      - img [ref=e106]
      - text: 調略
    - generic [ref=e110]: 國策
    - button "政策" [ref=e111] [cursor=pointer]:
      - img [ref=e112]
      - text: 政策
    - button "軍團" [ref=e114] [cursor=pointer]:
      - img [ref=e115]
      - text: 軍團
    - button "大命" [ref=e117] [cursor=pointer]:
      - img [ref=e118]
      - text: 大命
  - generic:
    - generic:
      - generic:
        - button:
          - img
  - img "全國小地圖" [ref=e120]
  - generic:
    - button "通報 4 則" [ref=e124] [cursor=pointer]:
      - img [ref=e125]
    - generic "通報 4 則" [ref=e127]:
      - status [ref=e128]:
        - generic [ref=e129]:
          - img [ref=e131]
          - generic [ref=e135]:
            - strong [ref=e136]: 收到塙直政的具申。
            - time [ref=e137]: 1560年9月1日
          - button "關閉通知" [ref=e139] [cursor=pointer]:
            - img [ref=e140]
      - status [ref=e142]:
        - generic [ref=e143]:
          - img [ref=e145]
          - generic [ref=e149]:
            - strong [ref=e150]: 收到簗田政綱的具申。
            - time [ref=e151]: 1560年9月1日
          - button "關閉通知" [ref=e153] [cursor=pointer]:
            - img [ref=e154]
      - status [ref=e156]:
        - generic [ref=e157]:
          - img [ref=e159]
          - generic [ref=e163]:
            - strong [ref=e164]: 收到毛利良勝的具申。
            - time [ref=e165]: 1560年9月1日
          - button "關閉通知" [ref=e167] [cursor=pointer]:
            - img [ref=e168]
      - status [ref=e170]:
        - generic [ref=e171]:
          - img [ref=e173]
          - generic [ref=e175]:
            - strong [ref=e176]: 金錢不足，本月俸祿未能全額發放，家臣心生不滿。
            - time [ref=e177]: 1560年9月1日
          - button "關閉通知" [ref=e179] [cursor=pointer]:
            - img [ref=e180]
    - button "報告中心" [ref=e182] [cursor=pointer]
```
#!/usr/bin/env python3
"""Inventory immutable browser output tree after the original native run."""
import hashlib
import json
from pathlib import Path

root = Path('/tmp/tenka-fullnative-9550-full-c1/browser-results')
target = Path('/tmp/tenka-fullnative-9550-browser-inventory-c1.json')
rows = []
total = 0
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    rows.append({'path': str(path.relative_to(root)), 'size': size, 'sha256': digest.hexdigest()})
    total += size
data = {'root': str(root), 'count': len(rows), 'totalBytes': total, 'files': rows}
with target.open('x') as output:
    json.dump(data, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'root': str(root), 'count': len(rows), 'totalBytes': total,
                  'output': str(target)}))

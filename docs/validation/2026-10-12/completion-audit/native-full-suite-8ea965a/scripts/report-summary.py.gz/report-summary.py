import collections
import json
import pathlib
import sys

report = pathlib.Path(sys.argv[1])
data = json.loads(report.read_text())
rows = []

def visit(suite, lineage):
    trail = lineage + [suite.get("title", "")]
    for spec in suite.get("specs", []):
        for test in spec.get("tests", []):
            results = test.get("results", [])
            rows.append({
                "file": spec.get("file"),
                "line": spec.get("line"),
                "title": " > ".join(item for item in trail + [spec.get("title", "")] if item),
                "outcome": test.get("status"),
                "expectedStatus": test.get("expectedStatus"),
                "results": [{
                    "status": result.get("status"),
                    "duration": result.get("duration"),
                    "errors": [err.get("message", "") for err in result.get("errors", [])],
                    "attachments": [item.get("path") for item in result.get("attachments", []) if item.get("path")],
                } for result in results],
            })
    for child in suite.get("suites", []):
        visit(child, trail)

for suite in data.get("suites", []):
    visit(suite, [])
summary = {
    "stats": data.get("stats"),
    "topErrors": data.get("errors", []),
    "totalRows": len(rows),
    "outcomes": dict(collections.Counter(row["outcome"] for row in rows)),
    "resultStatuses": dict(collections.Counter(result["status"] for row in rows for result in row["results"])),
    "unexpected": [row for row in rows if row["outcome"] == "unexpected"],
    "didNotRun": [row for row in rows if not row["results"]],
    "skippedWithResults": [row for row in rows if row["outcome"] == "skipped" and row["results"]],
}
print(json.dumps(summary, ensure_ascii=False, indent=2))

import hashlib
import json
import os
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
manifest = json.loads(pathlib.Path(sys.argv[2]).read_text())
expected = manifest["entries"]
roots = {"src", "e2e", "tests", "tools", "public", "assets", "rust", "plan", ".github"}
root_files = {".gitignore", ".prettierignore", ".prettierrc.json", "CLAUDE.md", "package.json", "package-lock.json", "index.html", "milestone.json", "eslint.config.js", "tsconfig.json", "tsconfig.core.json", "vite.config.ts", "vitest.workspace.ts", "playwright.config.ts", "playwright.cold-load.config.ts", "playwright.soak.config.ts"}
problems = []
for rel, spec in expected.items():
    path = root / rel
    try:
        data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
    except (OSError, ValueError) as error:
        problems.append({"path": rel, "error": str(error)})
        continue
    actual = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    if actual != spec["gitBlob"]:
        problems.append({"path": rel, "expected": spec["gitBlob"], "actual": actual})
actual_paths = set()
for name in roots:
    subtree = root / name
    if subtree.exists():
        actual_paths.update(str(path.relative_to(root)) for path in subtree.rglob("*") if path.is_file() or path.is_symlink())
actual_paths.update(name for name in root_files if (root / name).exists())
extras = sorted(actual_paths - set(expected))
print(json.dumps({"revision": manifest["revision"], "checked": len(expected), "problems": problems, "extras": extras}, indent=2))
sys.exit(1 if problems else 0)

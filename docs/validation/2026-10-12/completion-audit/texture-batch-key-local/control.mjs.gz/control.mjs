import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire, Module } from 'node:module';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const repo = process.cwd();
const pixi = resolve(repo, 'node_modules/pixi.js');
const require = createRequire(resolve(pixi, 'package.json'));
const manifest = JSON.parse(readFileSync(resolve(repo, 'tools/dependencies/pixi-8.19-patch.json')));
const sourcePath = 'lib/rendering/renderers/shared/texture/sources/TextureSource.js';
const arrayPath = 'lib/rendering/batcher/shared/BatchTextureArray.js';
function original(relative) {
  const target = manifest.targets.find((entry) => entry.path === relative);
  assert(target);
  let body = readFileSync(resolve(pixi, relative), 'utf8');
  for (const { from, to } of [...target.replacements].reverse()) {
    if (!to && from.startsWith('//# sourceMappingURL=')) body += from;
    else body = body.replace(to, from);
  }
  return body;
}
function compile(relative, source) {
  const file = resolve(pixi, relative);
  const mod = new Module(file);
  mod.filename = file;
  mod.paths = Module._nodeModulePaths(dirname(file));
  mod._compile(source, file);
  return mod.exports;
}
const oldSource = compile(sourcePath, original(sourcePath)).TextureSource;
const oldArray = compile(arrayPath, original(arrayPath)).BatchTextureArray;
const cjsSource = require(resolve(pixi, sourcePath)).TextureSource;
const cjsArray = require(resolve(pixi, arrayPath)).BatchTextureArray;
const { TextureSource: esmSource } = await import(pathToFileURL(resolve(pixi, sourcePath.replace(/\.js$/, '.mjs'))));
const { BatchTextureArray: esmArray } = await import(pathToFileURL(resolve(pixi, arrayPath.replace(/\.js$/, '.mjs'))));
function cycle(Source, ArrayType) {
  const batch = new ArrayType();
  const uids = new Set();
  let firstId, lastId;
  for (let i = 0; i < 130; i++) {
    const source = new Source({ width: 1, height: 1 });
    if (i === 0) firstId = source.uid;
    lastId = source.uid;
    assert(Number.isSafeInteger(source.uid));
    uids.add(source.uid);
    batch.ids[source.uid] = 0;
    batch.textures[0] = source;
    batch.count = 1;
    assert.equal(batch.ids[source.uid], 0);
    batch.clear();
    source.destroy();
  }
  assert.equal(uids.size, 130);
  return { firstId, lastId, keysAfterClear: Object.keys(batch.ids).length,
           nullValues: Object.values(batch.ids).filter((value) => value === null).length,
           count: batch.count };
}
const baseline25 = cycle(oldSource, oldArray);
const cjs29 = cycle(cjsSource, cjsArray);
const esm29 = cycle(esmSource, esmArray);
assert.equal(baseline25.keysAfterClear, 130);
assert.equal(baseline25.nullValues, 130);
for (const row of [cjs29, esm29]) {
  assert.equal(row.keysAfterClear, 0);
  assert.equal(row.nullValues, 0);
  assert(row.firstId < 0 && row.lastId < 0);
  assert(row.firstId !== 0 && row.lastId !== 0);
}
const signedProperty = [];
signedProperty[cjs29.firstId] = 1;
assert.equal(signedProperty.length, 0);
console.log(JSON.stringify({ baseline25, cjs29, esm29, negativeKeyArrayLength: signedProperty.length }, null, 2));

import pathlib,json,hashlib,os,subprocess,platform,sys
r=pathlib.Path('/tmp/tenka-castle-current23-20261012');o=pathlib.Path('/tmp/tenka-worker-batch-lightweight-sim3-evidence');o.mkdir(exist_ok=True);stage=sys.argv[1]
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.load(open('/tmp/sim3-castle-current23-expected.json'));rows=[]
for f in m['files']:
 p=r/f['path'];b=p.read_bytes() if p.exists() else b'';rows.append({**f,'actualSHA256':h(b),'actualBytes':len(b),'match':p.exists() and h(b)==f['sha256']})
expected={x['path'] for x in rows};extra=[]
for folder in ['src','public','rust','tools','tests']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and str(p.relative_to(r)) not in expected:extra.append(str(p.relative_to(r)))
p={'commit':m['commit'],'files':rows,'extras':extra,'allMatch':all(x['match'] for x in rows),'publicSymlinks':[str(p) for p in (r/'public').rglob('*') if p.is_symlink()]};(o/('source-'+stage+'-proof.json')).write_text(json.dumps(p,indent=2));assert p['allMatch'] and not extra and not p['publicSymlinks']
baseline=json.load(open('/tmp/tenka-current23-evidence/dependency-tree-manifest.json'));actual=[]
for f in baseline['files']:
 b=(r/f['path']).read_bytes();actual.append({**f,'actualSHA256':h(b),'match':h(b)==f['sha256']})
count=sum(p.is_file() for p in (r/'node_modules').rglob('*'));assert count==14765 and all(f['match'] for f in actual)
patch=json.loads((r/'tools/dependencies/pixi-8.19-patch.json').read_text());prs=[]
for f in patch['targets']:
 b=(r/'node_modules/pixi.js'/f['path']).read_bytes();prs.append({'path':f['path'],'sha256':h(b),'expectedSHA256':f['patchedSha256'],'match':h(b)==f['patchedSha256']})
assert len(prs)==23 and all(x['match'] for x in prs)
d={'sharedNodeModulesSymlink':(r/'node_modules').is_symlink(),'sharedNodeModulesRealPath':str((r/'node_modules').resolve()),'sameFrozenCurrent23DependencyTree':True,'fileCount':count,'patches':prs,'files':actual};(o/('dependency-'+stage+'-proof.json')).write_text(json.dumps(d,indent=2))
if stage=='after':
 ref=pathlib.Path('/tmp/tenka-national120-published-reference.json');a=pathlib.Path('/tmp/tenka-national120-published-castle-current23.json');j=json.loads(a.read_text());q=json.loads(ref.read_text());pp={'referenceSHA256':h(ref.read_bytes()),'actualSHA256':h(a.read_bytes()),'fullPayloadEqual':j==q,'snapshotsEqual':j['snapshots']==q['snapshots'],'snapshots':len(j['snapshots']),'days':[s['day'] for s in j['snapshots']],'excludedNonvisualCounters':j['excludedNonvisualCounters']};(o/'parity-proof.json').write_text(json.dumps(pp,indent=2));assert pp['fullPayloadEqual']
print(json.dumps({'stage':stage,'sourceCount':len(rows),'depsCount':count,'patchCount':len(prs),'allPass':True}))

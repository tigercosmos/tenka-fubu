import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const path='/tmp/tenka-worker-batch-lightweight-sim3-evidence/';
const raw=readFileSync(path+'observation.json');
const j=JSON.parse(raw);const m=j.measurement;const traffic=j.after.traffic;
const hash=(s)=>createHash('sha256').update(s).digest('hex');
const proof=[];
for(const [name,value] of Object.entries({'actual-initial-state':j.freshInitial,'actual-warm-state':j.warmInitial,'actual-final-state':j.actual,'reference-warm-state':j.warmReference.state,'reference-final-state':j.reference.state,'actual-initial-log':j.initialLog,'actual-warm-log':j.warmLog,'actual-final-log':j.actualLog,'reference-warm-log':j.warmReference.log,'reference-final-log':j.reference.log})){
 const s=JSON.stringify(value);writeFileSync(path+name+'.decoded.json',s);proof.push({name,bytes:Buffer.byteLength(s),sha256:hash(s),representation:'actual observation object extracted and re-encoded with JS JSON.stringify; exact full original observation archived'});
}
const sends=traffic.sent.filter(r=>r.kind==='tick'&&r.postedAt>=m.stepStart&&r.postedAt<=m.stepEnd);
const pairs=sends.map(s=>{const r=traffic.received.find(r=>r.kind==='complete'&&r.epoch===s.epoch&&r.requestId===s.requestId);if(!r)throw Error('Missing observed reply');return {...s,receivedAt:r.receivedAt,computeMs:r.computeMs,backend:r.backend,replyKeys:r.replyKeys,scalarReplyFields:r.scalarReplyFields,postCallMs:s.returnedAt-s.postedAt,postToReceiveMs:r.receivedAt-s.postedAt};});
if(pairs.length!==120||pairs.some(r=>r.backend!=='rust-wasm'))throw Error('Bad observed batch');
writeFileSync(path+'transport-metadata.decoded.json',JSON.stringify(traffic));
const summary={scope:'ONE lightweightmetadata profilednative120warm diagnostic/notNormalFPS',measurement:m,initialDay:j.freshInitial.time.day,warmDay:j.warmInitial.time.day,finalDay:j.actual.time.day,originalAssertionVerdict:JSON.parse(readFileSync(path+'verdict.json')),actualFullStateLogHashes:proof,observationSHA256:hash(raw),batchRequests:sends.length,batchReplies:pairs.length,pairs,computeMsSum:pairs.reduce((a,r)=>a+r.computeMs,0),postCallMsSum:pairs.reduce((a,r)=>a+r.postCallMs,0),postToReceiveMsSum:pairs.reduce((a,r)=>a+r.postToReceiveMs,0),limits:['profile adds overhead; not ordinary unprofiled acceptance timing','post-to-receive encompasses transport/queues/scheduling; cannot prove GPU wait or sum overlapping segments','Main event.data access may force native payload deserialization; sampled empty-source callbacks are not isolated observer cost']};
writeFileSync(path+'observed-batch-summary.json',JSON.stringify(summary,null,2));
console.log(JSON.stringify({stepMs:m.stepMs,idleMs:m.idleMs,batchRequests:summary.batchRequests,batchReplies:summary.batchReplies,computeMsSum:summary.computeMsSum,postCallMsSum:summary.postCallMsSum,postToReceiveMsSum:summary.postToReceiveMsSum,verdict:summary.originalAssertionVerdict}));

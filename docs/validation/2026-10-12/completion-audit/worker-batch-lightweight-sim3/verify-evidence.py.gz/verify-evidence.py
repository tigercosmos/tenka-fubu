import sys,pathlib,json,gzip,hashlib
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text())
def read(n):return json.loads(gzip.decompress((p/(n+'.gz')).read_bytes()))
for a in s['artifacts']:
 z=(p/a['path']).read_bytes();b=gzip.decompress(z);assert len(z)==a['gzipBytes'] and len(b)==a['rawBytes'];assert hashlib.sha256(z).hexdigest()==a['gzipSHA256'];assert hashlib.sha256(b).hexdigest()==a['rawSHA256']
for stage in ['before','after']:
 j=read('source-lightweight-'+stage+'-proof.json');assert j['allMatch'] and not j['extras'] and not j['publicSymlinks'] and len(j['files'])==1404
 j=read('dependency-lightweight-'+stage+'-proof.json');assert len(j['files'])==14765 and len(j['patches'])==23 and all(r['match'] for r in j['files']+j['patches'])
j=read('observation.json');v=read('verdict.json');assert all(v[k] is True for k in ['warmFullStateEqual','warmFullLogEqual','finalFullStateEqual','finalFullLogEqual','assertionsCompletedBeforeObservationExport']);assert j['warmInitial']==j['warmReference']['state'] and j['actual']==j['reference']['state'];assert j['warmLog']==j['warmReference']['log'] and j['actualLog']==j['reference']['log'];assert j['actual']['time']['day']==121
for g in [j['beforeGpu'],j['afterGpu']]:
 c=next(c for c in g['identity']['canvases'] if c['context']);assert 'RTX 5070 Ti' in c['unmaskedRenderer'] and 'Vulkan' in c['unmaskedRenderer'] and not c['contextLost'] and c['width']==1280 and c['height']==720
r=read('observed-batch-summary.json');assert r['batchRequests']==r['batchReplies']==120 and all(q['backend']=='rust-wasm' for q in r['pairs']);assert '1 passed' in gzip.decompress((p/'original-terminal.log.gz').read_bytes()).decode();print('PASS: dual hashes, immutable sources/deps, both RTX guards, actual full warm/final state+log equality, observed120 Rust replies, original one-run verdict')

import { writeFileSync,readFileSync } from 'node:fs';
import {createHash} from 'node:crypto';
import {layoutCastleRibbons,type CastleRibbonCandidate,type RibbonRect} from '/tmp/tenka-castle-wasm-reference-9e49cc9.ts';
let seed=0x92ba623;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/0x100000000;};
const pieces:Buffer[]=[];let cases=0;
function add(candidates:CastleRibbonCandidate[],ordinary:RibbonRect[],hard:RibbonRect[]) {
 const priority=(c:CastleRibbonCandidate)=>c.selected?0:c.critical?1:c.target?2:3;
 const sorted=[...candidates].sort((a,b)=>priority(a)-priority(b)||(a.id<b.id?-1:a.id>b.id?1:0));
 const fixed=[...ordinary].sort((a,b)=>a.x-b.x||a.y-b.y||a.width-b.width||a.height-b.height);
 const leaders=sorted.flatMap(c=>c.leaderObstacles??[]), C=sorted.length,O=fixed.length,H=hard.length,L=leaders.length;
 const words=16+24*C+4*(O+H+L),out=16+8*C+4*(O+H+L);const input=new Float64Array(words);input.set([1,C,O,H,L,16,0]);
 let n=16,leaderStart=0;
 for(const c of sorted){const r=c.baseline,count=c.leaderObstacles?.length??0;input.set([r.x,r.y,r.width,r.height,c.anchor.x,c.anchor.y,leaderStart,count],n);n+=8;leaderStart+=count;}
 for(const r of [...fixed,...hard,...leaders]){input.set([r.x,r.y,r.width,r.height],n);n+=4;}
 let work=-1,callbacks=0;const before=JSON.stringify([candidates,ordinary,hard]);const placements=layoutCastleRibbons(candidates,ordinary,hard,{onWork:(w)=>{work=w;callbacks++;}});
 if(callbacks!==1||before!==JSON.stringify([candidates,ordinary,hard]))throw Error('Oracle callback/mutation contract');
 const expected=new Float64Array(input);expected[6]=work;
 for(let i=0;i<C;i++){const p=placements.get(sorted[i]!.id)!;expected.set([p.offset.x,p.offset.y,p.rect.x,p.rect.y,p.rect.width,p.rect.height,p.overlapArea,p.baselineOverlapArea,p.unresolved?1:0,p.triedPlacements,p.budgetLimited?1:0,p.leader.start.x,p.leader.start.y,p.leader.end.x,p.leader.end.y,p.leader.visible?1:0],out+i*16);}
 const size=Buffer.alloc(8);size.writeUInt32LE(words,0);size.writeUInt32LE(C,4);pieces.push(size,Buffer.from(input.buffer),Buffer.from(expected.buffer));cases++;
}
for(let scene=0;scene<320;scene++){
 const dense=scene%2===0;
 const candidates=Array.from({length:4},(_,i):CastleRibbonCandidate=>({id:['castle.\u{10000}','castle.\ue000','castle.alpha','castle.beta'][i]!,baseline:{x:random()*(dense?80:500)-100,y:random()*(dense?50:350)-100,width:10+random()*120,height:10+random()*30},anchor:{x:random()*250-125,y:random()*200-100},selected:i===scene%4,critical:i===2,target:i===3}));
 const rects=Array.from({length:scene%3?35:100},():RibbonRect=>({x:random()*(dense?160:900)-150,y:random()*(dense?120:800)-150,width:1+random()*140,height:1+random()*50}));
 const hard=rects.filter((_,i)=>i%5===0).reverse();for(const c of candidates)c.leaderObstacles=hard.filter((_,i)=>i%3===0);
 add(candidates,rects,hard);
}
add([],[],[]);
for(const anchor of [0,-0,1e100,-1e100,Number.MAX_VALUE,-Number.MAX_VALUE])add([{id:'a',baseline:{x:-0,y:0,width:20,height:10},anchor:{x:anchor,y:anchor},leaderObstacles:[{x:-10,y:10,width:20,height:20}]}],[{x:0,y:0,width:20,height:10}],[{x:1,y:1,width:8,height:8}]);
for(const epsilon of [-1e-10,0,1e-10])for(const edge of [-48,0,48])add([{id:'a',baseline:{x:0,y:0,width:20,height:10},anchor:{x:0,y:0}}],[{x:20+edge+epsilon,y:0,width:8,height:10},{x:0,y:10+edge+epsilon,width:20,height:8}],[]);
const many=Array.from({length:256},(_,i):CastleRibbonCandidate=>({id:`c${String(i).padStart(3,'0')}`,baseline:{x:i%4,y:i%3,width:100,height:20},anchor:{x:0,y:0}}));const blockers=Array.from({length:1024},():RibbonRect=>({x:0,y:0,width:200,height:200}));add(many,blockers,blockers);
const bytes=Buffer.concat(pieces);writeFileSync('/tmp/tenka-castle-ribbon-rust/fixtures.bin',bytes);writeFileSync('/tmp/tenka-castle-ribbon-rust/oracle-manifest.json',JSON.stringify({cases,referenceSha256:createHash('sha256').update(readFileSync('/tmp/tenka-castle-wasm-reference-9e49cc9.ts')).digest('hex'),fixtureBytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')},null,2));console.log(JSON.stringify({cases,bytes:bytes.length}));

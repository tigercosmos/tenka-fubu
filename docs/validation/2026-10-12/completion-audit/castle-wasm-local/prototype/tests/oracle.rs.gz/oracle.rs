use tenka_castle_ribbon_prototype::solve;

#[test]
fn all_frozen_js_fields_work_and_order_are_bit_exact() {
    let bytes = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/fixtures.bin")).unwrap();
    let mut cursor = 0;
    let mut cases = 0;
    while cursor < bytes.len() {
        let words = u32::from_le_bytes(bytes[cursor..cursor + 4].try_into().unwrap()) as usize;
        let candidates = u32::from_le_bytes(bytes[cursor + 4..cursor + 8].try_into().unwrap());
        cursor += 8;
        let mut input: Vec<f64> = bytes[cursor..cursor + words * 8]
            .chunks_exact(8)
            .map(|v| f64::from_le_bytes(v.try_into().unwrap()))
            .collect();
        cursor += words * 8;
        let expected = &bytes[cursor..cursor + words * 8];
        cursor += words * 8;
        let result = unsafe { solve(input.as_mut_ptr() as usize, words) };
        assert_eq!(result, candidates as i32, "case {cases}: status");
        for (word, value) in input.iter().enumerate() {
            let bits = u64::from_le_bytes(expected[word * 8..word * 8 + 8].try_into().unwrap());
            assert_eq!(
                value.to_bits(),
                bits,
                "case {cases}, word {word}: got {value}, expected {}",
                f64::from_bits(bits)
            );
        }
        cases += 1;
    }
    assert_eq!(cases, 337);
}

#[test]
fn malformed_headers_ranges_and_alignment_fail_without_output_mutation() {
    let mut base = vec![0.0; 40];
    base[..7].copy_from_slice(&[1.0, 1.0, 0.0, 0.0, 0.0, 16.0, 0.0]);
    base[16..24].copy_from_slice(&[0.0, 0.0, 20.0, 10.0, 0.0, 0.0, 0.0, 0.0]);
    for (word, value) in [
        (0, 2.0),
        (1, 257.0),
        (1, 0.5),
        (2, f64::INFINITY),
        (3, f64::NAN),
        (4, 4097.0),
        (5, 15.0),
        (6, 1.0),
        (15, 1.0),
        (18, 0.0),
        (20, f64::INFINITY),
        (22, 1.0),
        (23, 1025.0),
    ] {
        let mut input = base.clone();
        input[word] = value;
        let before: Vec<u64> = input.iter().map(|v| v.to_bits()).collect();
        let status = unsafe { solve(input.as_mut_ptr() as usize, input.len()) };
        assert_eq!(status, -2, "word {word}");
        assert_eq!(
            input.iter().map(|v| v.to_bits()).collect::<Vec<_>>(),
            before
        );
    }
    assert_eq!(unsafe { solve(0, 16) }, -2);
    assert_eq!(
        unsafe { solve(base.as_mut_ptr() as usize + 1, base.len()) },
        -2
    );
    assert_eq!(
        unsafe { solve(base.as_mut_ptr() as usize, base.len() - 1) },
        -2
    );
}

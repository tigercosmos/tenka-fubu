import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { layoutCastleRibbons } from '/tmp/tenka-castle-wasm-reference-9e49cc9.ts';

const directory = '/tmp/tenka-castle-mixed-sign-control';
const records: object[] = [];
const pieces: Buffer[] = [];
for (const [x, y] of [[-0, 0], [0, -0]]) {
  const baseline = { x: -0, y: 0, width: 20, height: 10 };
  const ordinary = [{ x: 0, y: 0, width: 20, height: 10 }];
  const hard = [{ x: 1, y: 1, width: 8, height: 8 }];
  const leaders = [{ x: -10, y: 10, width: 20, height: 20 }];
  const candidate = { id: 'a', baseline, anchor: { x: x!, y: y! }, leaderObstacles: leaders };
  const input = new Float64Array(52);
  input.set([1, 1, 1, 1, 1, 16, 0]);
  input.set([-0, 0, 20, 10, x!, y!, 0, 1], 16);
  input.set([0, 0, 20, 10, 1, 1, 8, 8, -10, 10, 20, 20], 24);
  let work = -1, callbacks = 0;
  const result = layoutCastleRibbons([candidate], ordinary, hard, { onWork: (value) => { work = value; callbacks++; } }).get('a')!;
  if (callbacks !== 1) throw new Error('Unexpected observer count');
  const expected = new Float64Array(input);
  expected[6] = work;
  expected.set([result.offset.x, result.offset.y, result.rect.x, result.rect.y,
    result.rect.width, result.rect.height, result.overlapArea, result.baselineOverlapArea,
    Number(result.unresolved), result.triedPlacements, Number(result.budgetLimited),
    result.leader.start.x, result.leader.start.y, result.leader.end.x, result.leader.end.y,
    Number(result.leader.visible)], 36);
  const header = Buffer.alloc(8); header.writeUInt32LE(52, 0); header.writeUInt32LE(1, 4);
  pieces.push(header, Buffer.from(input.buffer), Buffer.from(expected.buffer));
  const bits = (values: Float64Array) => Array.from(new BigUint64Array(values.buffer), (word) => word.toString(16).padStart(16, '0'));
  records.push({ inputBits: bits(input), expectedBits: bits(expected), work, callbacks,
    expectedOutputBits: bits(expected).slice(36) });
}
const bytes = Buffer.concat(pieces);
const sha = (data: Buffer) => createHash('sha256').update(data).digest('hex');
writeFileSync(`${directory}/controls.bin`, bytes);
writeFileSync(`${directory}/controls.json`, JSON.stringify({ origin: 'Independent frozen JavaScript producer, not Rust output',
  referenceSha256: sha(readFileSync('/tmp/tenka-castle-wasm-reference-9e49cc9.ts')),
  controls: records, bytes: bytes.length, sha256: sha(bytes) }, null, 2) + '\n');
console.log(JSON.stringify({ controls: 2, bytes: bytes.length, sha256: sha(bytes), work: records.map((value) => (value as { work: number }).work) }));

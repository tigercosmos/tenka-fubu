import pathlib,json,gzip,hashlib,sys,collections
p=pathlib.Path(sys.argv[1]);s=json.loads((p/'summary.json').read_text())
for r in s['artifacts']:
 z=(p/r['path']).read_bytes();b=gzip.decompress(z);assert hashlib.sha256(z).hexdigest()==r['gzipSHA256'] and hashlib.sha256(b).hexdigest()==r['rawSHA256'] and len(b)==r['rawBytes'] and len(z)==r['gzipBytes']
counts=json.loads(gzip.decompress((p/'capacity-counts.json.gz').read_bytes()));geo=json.loads(gzip.decompress((p/'native-nine-geography.decoded.json.gz').read_bytes()));hard={'castle','castleBody','castleDurability','castleWarning','hud','canvasEdge'}
for r,w in zip(geo,counts['nativeRows'],strict=True):
 g=r['geographic'];P=sum(o['kind'] not in {'hud','canvasEdge'} for o in g['obstacles']);H=sum(o['kind'] in hard for o in g['obstacles']);C=len(g['labels']);assert (P,H,C)==(w['P'],w['H'],w['admittedCandidates']);assert w['totalWords']==78+6*P+6*H+5*C and w['totalBytes']==8*w['totalWords']
large=json.loads(gzip.decompress((p/'large-valid-original-js.raw.json.gz').read_bytes()))
for x,w in zip(large,counts['largeRows'],strict=True):
 P=len(x['input']['primary']);H=len(x['input']['hard']);C=len(x['input']['labels']);assert P==x['count'] and x['allFullPreparedFieldsMatchReferenceBits'] and w['totalWords']==78+6*P+6*H+5*C
assert counts['nativeMaximum']['totalWords']==4376 and counts['largeRows'][0]['totalWords']==49235 and counts['largeRows'][1]['totalWords']==196691;assert 49235<131072<196691;print('PASS: all byte hashes, actual9formal counts, full8192/32768originalJSrows, exactmemory formulas; no timing or observedadaptermode claim')

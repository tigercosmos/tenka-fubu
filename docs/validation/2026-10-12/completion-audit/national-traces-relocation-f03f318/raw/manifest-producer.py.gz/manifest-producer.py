import os,sys,json,hashlib,stat
from pathlib import Path
root=Path(sys.argv[1]);rows=[]
for folder,dirs,files in os.walk(root,followlinks=False):
 for name in sorted(dirs+files):
  p=Path(folder)/name;s=p.lstat();r={'path':p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode)}
  if p.is_symlink():r.update(type='symlink',target=os.readlink(p))
  elif p.is_dir():r.update(type='directory')
  elif p.is_file():
   h=hashlib.sha256()
   with p.open('rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
   r.update(type='file',bytes=s.st_size,sha256=h.hexdigest())
  else:raise RuntimeError('Unsupported file type: '+str(p))
  rows.append(r)
rows.sort(key=lambda r:r['path'])

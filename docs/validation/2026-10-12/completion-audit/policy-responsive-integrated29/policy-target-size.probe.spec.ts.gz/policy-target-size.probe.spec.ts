import { writeFile } from 'node:fs/promises';
import { test, expect } from './fixtures';

const SCALES = Array.from({ length: 15 }, (_, i) => Number((0.8 + i * 0.05).toFixed(2)));

for (const scale of SCALES) {
  test('policy physical targets at uiScale ' + scale, async ({ page }, testInfo) => {
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.goto('/?debug=1&seed=42');
    await page.getByTestId('title-settings').click();
    const settings = page.getByRole('dialog');
    const slider = settings.getByRole('slider', { name: '介面縮放', exact: true });
    await slider.press('Home');
    for (let i = 0; i < Math.round((scale - 0.8) / 0.05); i++) await slider.press('ArrowRight');
    await expect(slider).toHaveValue(String(scale));
    await settings.getByRole('button', { name: '返回', exact: true }).click();
    await page.getByTestId('title-newgame').click();
    await page.getByTestId('scenario-pick-s1560').click();
    await page.getByTestId('clan-pick-clan.oda').click();
    await page.getByTestId('newgame-start').click();
    await expect(page.getByTestId('screen-strategy')).toBeVisible();
    await page.getByTestId('speed-pause').click();
    await page.keyboard.press('F5');
    const panel = page.getByTestId('policy-panel');
    await expect(panel).toBeVisible();
    const result: { scale: number; target: string; width: number; height: number }[] = [];
    async function measure(target: string, locator: ReturnType<typeof panel.locator>) {
      await locator.scrollIntoViewIfNeeded();
      const box = await locator.boundingBox();
      expect(box, target).not.toBeNull();
      result.push({ scale, target, width: box!.width, height: box!.height });
      expect(box!.width, target + ' width').toBeGreaterThanOrEqual(32);
      expect(box!.height, target + ' height').toBeGreaterThanOrEqual(32);
    }
    await measure('panel-close', panel.getByRole('button', { name: '政策', exact: true }));
    const cards = panel.locator('[data-testid^="policy-card-"]');
    await expect(cards).toHaveCount(12);
    for (let i = 0; i < 12; i++) {
      const card = cards.nth(i);
      const id = await card.getAttribute('data-testid') ?? String(i);
      const button = card.getByRole('button', { name: /查看.+詳情/ });
      await measure(id + '-open', button);
      await button.click();
      const action = page.getByTestId('policy-detail').getByRole('button', { name: /採用|廢止/ });
      await measure(id + '-action', action);
    }
    await writeFile(testInfo.outputPath('policy-target-size-' + scale + '.json'), JSON.stringify(result, null, 2));
  });
}

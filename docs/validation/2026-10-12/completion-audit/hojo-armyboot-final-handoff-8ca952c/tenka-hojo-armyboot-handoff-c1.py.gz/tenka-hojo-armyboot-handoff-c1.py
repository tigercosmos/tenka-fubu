import gzip
import hashlib
import json
from pathlib import Path

repo = Path('/Users/tigercosmos/tenka-fubu')
out = repo / 'docs/validation/2026-10-12/completion-audit/hojo-armyboot-final-handoff-8ca952c'
out.mkdir(exist_ok=False)
items = []


def retain(name, source):
    data = source.read_bytes()
    packed = gzip.compress(data, mtime=0)
    with (out / name).open('xb') as stream:
        stream.write(packed)
    items.append({
        'file': name, 'source': str(source),
        'rawBytes': len(data), 'rawSha256': hashlib.sha256(data).hexdigest(),
        'gzipBytes': len(packed), 'gzipSha256': hashlib.sha256(packed).hexdigest(),
    })


for name, source in [
    ('root-hojo.log.gz', '/tmp/tenka-root-hojo-pause.fwfzS8'),
    ('root-armyboot.log.gz', '/tmp/tenka-root-armyboot.zn0lO6'),
    ('root-integrated.log.gz', '/tmp/tenka-root-boot-integrated.85DcXP'),
]:
    path = Path(source)
    assert b'PASS' in path.read_bytes(), source
    retain(name, path)
for capture in [
    'tenka-hojo-armyboot-runner-setup-c1',
    'tenka-hojo-armyboot-pack-setup-c1',
    'tenka-hojo-armyboot-pack-setup-c2',
    'tenka-hojo-armyboot-integrated-pack-c2',
    'tenka-hojo-armyboot-integrated-docs-c1',
    'tenka-hojo-armyboot-integrated-verify-c1',
    'tenka-hojo-armyboot-docs-format-c1',
    'tenka-hojo-armyboot-docs-diffcheck-c1',
]:
    directory = Path('/tmp') / capture
    assert json.loads((directory / 'result.json').read_text())['exitCode'] == 0
    for path in sorted(directory.iterdir()):
        if path.is_file():
            retain(capture + '__' + path.name + '.gz', path)
for name in ['tenka-hojo-armyboot-integrated-pack-c1.py', 'tenka-hojo-armyboot-integrated-pack-c2.py', 'tenka-hojo-armyboot-handoff-c1.py']:
    retain(name + '.gz', Path('/tmp') / name)
with (out / 'manifest.json').open('x') as stream:
    json.dump({'items': items}, stream, indent=2)
    stream.write('\n')
with (out / 'README.md').open('x') as stream:
    stream.write('''# Hojo and army boot final handoff

This package retains the three independent root verifier outputs for the Hojo native pause, army-plate boot, and frozen combined 8ca952c validation packages. Each root verifier reported PASS with exit zero. The copied files are their preopened merged output logs; they do not contain separate process-exit records. Root reported those exit results in the collaboration transcript.

The remaining captures record setup, compact packaging, the coordinator's integrated verifier, final documentation formatting, and diff checking. The first integration packaging draft had an incorrect replacement path, found by inspection before it was executed; the second producer corrected it. Both drafts and their setup captures are retained. No source test or native run was repeated for that correction.

All browser runs are terminal. Only the two scoped E2E commits were adopted. The original full955 440-case gate remains RED; current discovery lists 441 cases. Isolated Hojo and army-plate controls do not close the full-suite deadline. Strict60, whole-heap, long-run, the full M6–M9 objective, and pending gameplay/art decisions remain open. There was no push, deployment, baseline update, or deadline change.

The additive inventory preserves all 5,298 historical rows and their bytes from 4dd1a55. New package entries are appended only after their contents are final. The post-index and commit command captures remain outside this immutable package to avoid indexing a running capture.
''')
print(json.dumps({'path': str(out), 'artifacts': len(items)}))
